package ae.emaratech.uaevision.crm.report;

import ae.emaratech.uaevision.fis.common.exception.BusinessException;
import ae.emaratech.uaevision.fis.report.core.FISReport;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperReportGenerator;
import net.sf.jasperreports.engine.JRDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;

/**
 * Created by Deep.Gupta on 4/30/2017.
 */
@Component
public class ManualTransferReportGenerator {

    /**
     * Static containing the logger for the class.
     */
    private static final Logger LOGGER = LogManager.getLogger();

    private static final String JASPER_TEMPLATE = "manual-transfer-report";

    @Autowired
    private ManualTransferReportDataSource manualTransferReportDataSource;

    @Autowired
    private JasperReportGenerator jasperReportGenerator;

    public FISReport generateReport(ReportParameters parameters)
            throws BusinessException {

        LOGGER.entry();
        LOGGER.info("method  generateReport() start");

        JRDataSource dataSource = manualTransferReportDataSource.getDataSource(parameters);
        FISReport report = new FISReport();
        report.setContent(jasperReportGenerator.generateReport(JASPER_TEMPLATE, new HashMap(), dataSource));

        LOGGER.info("method  generateReport() stop");

        return report;


    }

}
