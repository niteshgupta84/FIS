package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceDefinition;
import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceService;
import ae.emaratech.uaevision.fis.common.key.NoteKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by Nitesh.Gupta on 6/5/2016.
 */
@Component
public class CaseNoteKeyProvider {

    @Autowired
    private SequenceService sequenceService;

    public NoteKey next() {
        Long nextSequenceNumber = sequenceService.nextValue(SequenceDefinition.CASE_NOTE);
        return new NoteKey(nextSequenceNumber);
    }
}
