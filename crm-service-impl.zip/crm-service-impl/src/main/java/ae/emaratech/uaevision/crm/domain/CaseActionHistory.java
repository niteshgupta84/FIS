package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.entitylistener.Creatable;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedByListener;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedDateListener;
import ae.emaratech.uaevision.lookup.service.annotation.LookupField;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;

import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the ARREST_ACTION_HISTORY database table.
 */
@Entity
@EntityListeners({
        CreatedDateListener.class,
        CreatedByListener.class
})
@Table(name = "CASE_ACTION_HISTORY")
public class CaseActionHistory implements Creatable {

    private static final Long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "CASE_ACTION_HISTORY_ID_GENERATOR", sequenceName = "SEQ_CASE_ACTION_HISTORY", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CASE_ACTION_HISTORY_ID_GENERATOR")
    @Column(name = "ID", unique = true, nullable = false, precision = 22, scale = 0)
    private Long id;


    @LookupField(LookupDefinition.ARREST_ACTION)
    @Column(name = "CASE_ACTION_ID", nullable = false)
    private Long caseActionId;

    @Column(name = "CREATED_BY", length = 20, nullable = false)
    private String createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE", nullable = false)
    private Date createdDate;

    @Column(name = "COMMENTS", length = 500)
    private String comments;

    @Column(name = "CASE_ID", nullable = false)
    private Long caseId;

    private CaseActionHistory() {

    }

    public CaseActionHistory(Builder builder) {
        this.comments = builder.comments;
        this.caseId = builder.caseId;
        this.caseActionId = builder.caseActionId;
        this.createdBy = builder.userLoginId;

    }

    public Long getId() {
        return id;
    }

    public Long getCaseActionId() {
        return caseActionId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    @Override
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getComments() {
        return comments;
    }

    public Long getCaseId() {
        return caseId;
    }

    /**
     * Static method to prepare DeportationActionHistory object using Builder design pattern.
     */
    public static class Builder {

        private Long caseId;
        private Long caseActionId;
        private String comments;
        private String userLoginId;

        public Builder(Long caseId) {
            this.caseId = caseId;
        }

        public Builder withActionId(Long caseActionId) {
            this.caseActionId = caseActionId;
            return this;
        }

        public Builder withComments(String comments) {
            this.comments = comments;
            return this;
        }
        public Builder withUserId(String userLoginId) {
            this.userLoginId = userLoginId;
            return this;
        }

        public CaseActionHistory build() {
            return new CaseActionHistory(this);
        }


    }
}