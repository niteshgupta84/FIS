package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.infrastructure.HibernateCaseRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by Nitesh.Gupta on 6/15/2016.
 */
@Repository
public interface CaseRepository extends HibernateCaseRepository {

}
