package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceDefinition;
import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceService;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by Nitesh.Gupta on 6/15/2016.
 */
@Component
public class CaseKeyProvider {

    @Autowired
    private SequenceService sequenceService;

    public CaseKey next() {
        Long nextSequenceNumber = sequenceService.nextValue(SequenceDefinition.CASE);
        return new CaseKey(nextSequenceNumber);
    }
}
