package ae.emaratech.uaevision.crm.query;

import ae.emaratech.uaevision.crm.application.CaseNotificationCode;
import ae.emaratech.uaevision.crm.application.CasePageBuilder;
import ae.emaratech.uaevision.crm.application.dto.*;
import ae.emaratech.uaevision.crm.domain.*;
import ae.emaratech.uaevision.document.application.AttachedDocumentDto;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.common.key.CaseTransferKey;
import ae.emaratech.uaevision.fis.common.notification.Notification;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.util.PageBuilder;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Service Class for Quering Case Domain based on different-2 Criteria provided. Created by
 * Nitesh.Gupta on 6/19/2016.
 */
@Service
@Transactional
public class CaseQueryServiceImpl implements CaseQueryService {

    @Autowired
    private CaseActionHistoryRepository caseActionHistoryRepository;

    @Autowired
    private CaseMapper caseMapper;

    @Autowired
    private CaseRepository caseRepository;

    @Autowired
    private CaseActionHistoryMapper caseActionHistoryMapper;

    @Autowired
    private CaseNoteMapper caseNoteMapper;

    @Autowired
    private NotificationBus notificationBus;

    @Autowired
    private CaseAttachmentMapper caseAttachmentMapper;

    @Autowired
    private DocumentInspectionMapper documentInspectionMapper;

    @Autowired
    private CaseAssociationMapper caseAssociationMapper;

    @Autowired
    private CaseNoteRepository caseNoteRepository;

    @Autowired
    private CaseAssociationRepository caseAssociationRepository;

    @Autowired
    private CaseTransferDetailRepository caseTransferDetailRepository;
    @Autowired
    private CaseTransferDetailMapper caseTransferDetailMapper;

    @Override
    public List<CaseTrackDto> retrieveCaseHistory(RetrieveCaseHistoryQuery caseHistoryQuery) {
        // Create Predicate to retrieve ArrestHistory instances for Arrest identifier.
        Predicate predicate =
                CasePredicates.getHistoryByCaseId(
                        caseHistoryQuery.getCaseKey());
        // Create order specifier for ordering the ArrestHistory instances based on created date.
        OrderSpecifier orderSpecifier = CasePredicates.getActionHistoryOrderSpecifier();
        Iterable<CaseActionHistory> caseTrackDtoIterator =
                caseActionHistoryRepository.findAll(predicate, orderSpecifier);

        // Populate ArrestTrack transfer object list from entity.
        List<CaseTrackDto> caseTrackDtoList = new ArrayList<>();
        for (CaseActionHistory caseActionHistory : caseTrackDtoIterator) {
            caseTrackDtoList.add(
                    caseActionHistoryMapper.mapCaseTrackDto(caseActionHistory));
        }

        return caseTrackDtoList;
    }

    /**
     * Retrieving Case Based on Case Key
     */
    @Override
    public CaseDto retrieveCase(RetrieveCaseQuery retrieveCaseQuery) {
        Case caseEntity = caseRepository.findOne(retrieveCaseQuery.getCaseKey().id());

        CaseDto caseDto = caseMapper.mapToCaseDto(caseEntity);

        //Setting Notes in the Dto List

        //Setting Attachments in the Dto List
        return caseDto;
    }

    /**
     * Retrieving Cases based on criteria passed from UI
     */
    @Override
    public Map<Long, CaseDto> retrieveCasesBySearchCriteria(
            RetrieveCasesBySearchQuery retrieveCasesBySearchQuery) {
        Predicate predicate = null;
        if (retrieveCasesBySearchQuery != null) {
            predicate = CasePredicates.getCasesBySearchCriteria(retrieveCasesBySearchQuery);
        } else {
            predicate = CasePredicates.hasNoPredicate();
        }
        OrderSpecifier orderSpecifier = CasePredicates.getOrderSpecifier();
        Iterable<Case> iter = caseRepository.findAll(predicate, orderSpecifier);
        List<Case> list = new LinkedList<>();
        for (Case incident : iter) {
            list.add(incident);
        }
        return caseMapper.mapEntityToDTOList(list);
    }

    /**
     * List Incidents Created By Current User
     *
     * @param query
     * @return
     */
    @Override
    public CasePageBuilder retrieveCasesCreatedByUser(
            RetrieveCasesWithOwnerDetailQuery query) {
        Predicate predicate = QCase.case$.createdBy.eq(query.getUserId());

        int start = query.getCasePageBuilder().getStart() != 0 ? query.getCasePageBuilder().getStart() + 1 : 0;
        int currentPage = (start % query.getCasePageBuilder().getLength()) + 1;

        Pageable
                pageable =
                new PageBuilder<>(currentPage, query.getCasePageBuilder().getLength(), query.getCasePageBuilder()
                        .getStart(),
                        new Sort(Sort.Direction.DESC, query.getCasePageBuilder().getSortColumns()));

        Page<Case> cases = caseRepository.findAll(predicate, pageable);

        return new CasePageBuilder(cases.getTotalElements(),
                caseMapper.mapEntityToDTOList(cases.getContent()));
    }

    /**
     * Retrieving All cases based on Criteria Provided
     *
     * @param criterias
     * @param query
     * @return
     */
    @Override
    public CasePageBuilder retrieveCasesBySearchCriteria(CasePageBuilder criterias,
                                                         RetrieveCasesBySearchQuery query) {
        Predicate predicate = null;
        if (query != null) {
            predicate = CasePredicates.getCasesBySearchCriteria(query);
        } else {
            predicate = CasePredicates.hasNoPredicate();
        }
        int start = criterias.getStart() != 0 ? criterias.getStart() + 1 : 0;
        int currentPage = (start % criterias.getLength()) + 1;

        Pageable
                pageable =
                new PageBuilder<>(currentPage, criterias.getLength(), criterias.getStart(),
                        new Sort(Sort.Direction.DESC, criterias.getSortColumns()));

        Page<Case> cases = caseRepository.findAll(predicate, pageable);

        return new CasePageBuilder(cases.getTotalElements(),
                caseMapper.mapEntityToDTOList(cases.getContent()));
    }

    @Override
    public CaseDto retrieveCaseForParty(RetrieveCaseForPartyQuery caseQuery) {
        BooleanExpression queryExpression = QCase.case$.parties.any().partyId.eq(caseQuery.getPartyKey().id());

        if (CollectionUtils.isNotEmpty(caseQuery.getSectionsList())) {
            List<Long> sections = caseQuery.getSectionsList();
            queryExpression = queryExpression.and(QCase.case$.latestSection.in(sections));
        }

        return caseMapper.mapToCaseDto(caseRepository.findOne(queryExpression));

    }


    @Override
    public List<CaseDto> retrieveCasesForParty(RetrieveCaseForPartyQuery caseQuery) {
        BooleanExpression queryExpression = QCase.case$.parties.any().partyId.in(caseQuery.getPartyKeys());

        if (CollectionUtils.isNotEmpty(caseQuery.getSectionsList())) {
            List<Long> sections = caseQuery.getSectionsList();
            queryExpression = queryExpression.and(QCase.case$.owner.section.in(sections));
        }
        Iterable<Case> iter = caseRepository.findAll(queryExpression);
        List<CaseDto> caseDtoList = new ArrayList<>();
        for (Case incident : iter) {
            caseDtoList.add(caseMapper.mapToCaseDto(incident));
        }

        return caseDtoList;

    }

    @Override
    public List<CaseDto> retrieveCaseForArrest(RetrieveCaseForArrestQuery retrieveCaseForArrestQuery) {

        Predicate predicate = QCase.case$.arrestId.eq(retrieveCaseForArrestQuery.getArrestReportKey().id());
        Iterable<Case> iter = caseRepository.findAll(predicate);

        List<CaseDto> list = new LinkedList<>();
        for (Case incident : iter) {
            list.add(caseMapper.mapToCaseDto(incident));
        }
        return list;
    }

    /**
     * Retrieving all notes against case
     *
     * @param retrieveCaseQuery
     * @return
     */
    @Override
    public List<CaseNoteDto> retrieveNotesForCase(RetrieveCaseQuery retrieveCaseQuery) {
        Predicate predicate = QCaseNote.caseNote.caseReference.id.eq(retrieveCaseQuery.getCaseKey().id());
        Iterable<CaseNote> caseNotes
                = caseNoteRepository.findAll(predicate);
        List<CaseNoteDto> caseNoteDtoList = new ArrayList<>();
        for (CaseNote caseNote : caseNotes) {
            caseNoteDtoList.add(caseNoteMapper.mapToCaseNoteDto(caseNote));
        }
        return caseNoteDtoList;
    }

    @Override
    public List<AttachedDocumentDto> retrieveAttachmentsForCase(RetrieveCaseQuery retrieveCaseQuery) {
        Case caseEntity = caseRepository.findOne(retrieveCaseQuery.getCaseKey().id());
        if (caseEntity != null) {
            return caseEntity.getAttachments().stream()
                    .map(caseAttachment -> {
                        return caseAttachmentMapper.mapCaseAttachmentDto(caseAttachment);
                    })
                    .collect(Collectors.toList());
        } else {
            return new ArrayList<>();
        }
    }

    @Override
    public List<DocumentInspectionDto> retrieveDocumentInspectionsForCase(
            RetrieveCaseQuery retrieveCaseQuery) {

        Case caseEntity = caseRepository.findOne(retrieveCaseQuery.getCaseKey().id());
        if (caseEntity != null)
            return documentInspectionMapper.mapToDocumentInspectionList(caseEntity.getDocumentInspections());
        else {
            return new ArrayList<>();
        }
    }

    /**
     * List of Case Association against Case
     *
     * @param retrieveCaseQuery
     * @return List of case association dto
     */
    @Override
    public List<CaseAssociationDto> retrieveAssociationsForCase(RetrieveCaseQuery retrieveCaseQuery) {
        Predicate predicate = QCaseAssociation.caseAssociation.caseReference.id.eq(retrieveCaseQuery.getCaseKey().id());
        Iterable<CaseAssociation> caseAssociations = caseAssociationRepository.findAll(predicate);
        List<CaseAssociationDto> caseAssociationDtos = new ArrayList<>();
        for (CaseAssociation caseAssociation : caseAssociations) {
            caseAssociationDtos.add(caseAssociationMapper.mapCaseAssociationDto(caseAssociation));
        }

        return caseAssociationDtos;
    }

    /**
     * Arrest Incidents Assigned To Current User
     *
     * @param query
     * @return
     */
    @Override
    public CasePageBuilder retrieveCasesAssignedToUser(
            RetrieveCasesWithOwnerDetailQuery query) {
        Predicate predicate = CasePredicates.getCaseByOwnerDetails(query);

        int start = query.getCasePageBuilder().getStart() != 0 ? query.getCasePageBuilder().getStart() + 1 : 0;
        int currentPage = (start % query.getCasePageBuilder().getLength()) + 1;

        Pageable
                pageable =
                new PageBuilder<>(currentPage, query.getCasePageBuilder().getLength(), query.getCasePageBuilder().getStart(),
                        new Sort(Sort.Direction.DESC, query.getCasePageBuilder().getSortColumns()));

        Page<Case> cases = caseRepository.findAll(predicate, pageable);

        return new CasePageBuilder(cases.getTotalElements(),
                caseMapper.mapEntityToDTOList(cases.getContent()));
    }

    /**
     * Method which validates whether a party is associated with any existing active cases.
     *
     * @param validateActiveCaseForPartyQuery the query object with list of party ids to be
     *                                        validated.
     */
    @Override
    public Notification validateActiveCaseForParty(
            ValidateActiveCaseForPartyQuery validateActiveCaseForPartyQuery) {

        // Create Predicate to retrieve Active Case instances for list of party identifiers.
        Predicate predicate =
                CasePredicates.getActiveCaseForParty(validateActiveCaseForPartyQuery.getPartyIdList());
        OrderSpecifier orderSpecifier = CasePredicates.getOrderSpecifier();
        Iterable<Case> activeCaseForUDBList = caseRepository.findAll(predicate,orderSpecifier);

        if (activeCaseForUDBList.iterator().hasNext()) {
            NotificationBuilder notificationBuilder = notificationBus.getBuilder();
            CaseDto caseDto = caseMapper.mapToCaseDto(activeCaseForUDBList.iterator().next());
            notificationBuilder.add(CaseNotificationCode.CASE_EXISTS_FOR_PARTY,
                    caseDto.getCaseNumber());
            return notificationBuilder.createNotification();
        }
        return null;
    }

    /**
     * Method is to fetch all transferred case details
     * @param casePageBuilder
     * @return
     */
    @Override
    public CasePageBuilder retrieveAllTransferredCases(CasePageBuilder casePageBuilder) {
        Predicate predicate = QCaseTransferDetail.caseTransferDetail.transferStatus.eq(CaseStatus.NOTRECEIVED.id());
        int start = casePageBuilder.getStart() != 0 ? casePageBuilder.getStart() + 1 : 0;
        int currentPage = (start % casePageBuilder.getLength()) + 1;

        Pageable
                pageable =
                new PageBuilder<>(currentPage, casePageBuilder.getLength(), casePageBuilder.getStart(),
                        new Sort(Sort.Direction.DESC, casePageBuilder.getSortColumns()));

        Page<CaseTransferDetail> cases = caseTransferDetailRepository.findAll(predicate, pageable);
        return new CasePageBuilder(cases.getTotalElements(),
                caseTransferDetailMapper.mapEntityToDTOList(cases.getContent()));
    }

    /**
     * Retrieves Case Transfer Details
     * @param caseTransferKey
     * @return
     */
    @Override
    public CaseTransferDetailDto retreiveCaseTransferDetail(CaseTransferKey caseTransferKey) {

        CaseTransferDetail caseTransferDetail = caseTransferDetailRepository.findOne(caseTransferKey.id());
        return caseTransferDetailMapper.mapToDto(caseTransferDetail);

    }

    /**
     * Retrieves Case Transfer Details
     * @param caseKey CaseKey
     * @return CaseTransferDetailDto object
     */
    @Override
    public CaseTransferDetailDto retreiveCaseTransferDetail(CaseKey caseKey) {
        Predicate predicate = QCaseTransferDetail.caseTransferDetail.caseId.eq(caseKey.id());
        CaseTransferDetail caseTransferDetail = caseTransferDetailRepository.findOne(predicate);
        return caseTransferDetailMapper.mapToDto(caseTransferDetail);

    }

    /**
     * Retrieves Case Transfer Details
     * @param caseKey CaseKey
     * @return CaseTransferDetailDto object
     * @since 1.01.012
     */
    @Override
    public CaseTransferDetailDto retrieveTransferredCaseTransferDetail(CaseKey caseKey) {
        Predicate predicate = QCaseTransferDetail.caseTransferDetail.transferredCaseId.eq(caseKey.id());
        CaseTransferDetail caseTransferDetail = caseTransferDetailRepository.findOne(predicate);
        return caseTransferDetailMapper.mapToDto(caseTransferDetail);

    }

    /**
     * Method is to retreive Cases which are transferred from Sea port to Aircontrol
     * @param query
     * @return CasePageBuilder
     * @since 1.01.017
     */
    @Override
    public CasePageBuilder retrieveCasesForwardToInternalSection(RetrieveCasesWithOwnerDetailQuery query) {
        BooleanExpression predicate = QCase.case$.latestSection.eq(
                query.getLatestSectionId()).and(QCase.case$.owner.section.notIn(query.getLatestSectionId())).and(QCase.case$.statusId.eq(CaseStatus.FORWARD.id()));


        int start = query.getCasePageBuilder().getStart() != 0 ? query.getCasePageBuilder().getStart() + 1 : 0;
        int currentPage = (start % query.getCasePageBuilder().getLength()) + 1;

        Pageable
                pageable =
                new PageBuilder<>(currentPage, query.getCasePageBuilder().getLength(), query.getCasePageBuilder().getStart(),
                        new Sort(Sort.Direction.DESC, query.getCasePageBuilder().getSortColumns()));

        Page<Case> cases = caseRepository.findAll(predicate, pageable);

        return new CasePageBuilder(cases.getTotalElements(),
                caseMapper.mapEntityToDTOList(cases.getContent()));
    }
}
