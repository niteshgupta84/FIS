package ae.emaratech.uaevision.crm.domain;


import ae.emaratech.uaevision.crm.infrastructure.HibernateCaseStatusHistoryRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository which manages the  persistence and retrieval of Case history Report domain entity.
 * Created by Nitesh.Gupta on 6/7/2016.
 */
@Repository
public interface CaseStatusHistoryRepository extends HibernateCaseStatusHistoryRepository {

}
