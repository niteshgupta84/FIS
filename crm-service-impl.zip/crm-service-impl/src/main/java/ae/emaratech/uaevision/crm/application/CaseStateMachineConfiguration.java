package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.crm.domain.CaseAction;
import ae.emaratech.uaevision.crm.domain.CaseStatus;

import java.util.*;


/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
public class CaseStateMachineConfiguration {


    private final static Map<CaseStatus, List<CaseAction>> stateMachineConfigForIcm;


    static {

        stateMachineConfigForIcm = new HashMap<>(CaseStatus.values().length);

        // State Machine Configuration for ICM
        //Status NEW
        List<CaseAction> nextActionsForNew = new ArrayList<>();
        nextActionsForNew.add(CaseAction.OPEN);
        stateMachineConfigForIcm
                .put(CaseStatus.NEW, Collections.unmodifiableList(nextActionsForNew));

        //Status OPENED
        List<CaseAction> nextActionsForOpen = new ArrayList<>();

        nextActionsForOpen.add(CaseAction.UPDATE);
        nextActionsForOpen.add(CaseAction.CLOSE);
        nextActionsForOpen.add(CaseAction.FORWARD_TO_SUPERVISOR);
        nextActionsForOpen.add(CaseAction.MANUAL_TRANSFER);
        nextActionsForOpen.add(CaseAction.TRANSFERRED_TO);
        nextActionsForOpen.add(CaseAction.FORWARD);
        stateMachineConfigForIcm
                .put(CaseStatus.OPENED, Collections.unmodifiableList(nextActionsForOpen));

        //Status PENDING_DECISION
        List<CaseAction> nextActionsForPendingDecision = new ArrayList<>();

        nextActionsForPendingDecision.add(CaseAction.APPROVE);
        nextActionsForPendingDecision.add(CaseAction.REJECT);


        stateMachineConfigForIcm.put(CaseStatus.PENDING_DECISION,
                Collections.unmodifiableList(nextActionsForPendingDecision));

        // After CLOSED
        List<CaseAction> nextActionsForClosed = new ArrayList<>();
        nextActionsForClosed.add(CaseAction.REOPEN);

        stateMachineConfigForIcm
                .put(CaseStatus.CLOSED, Collections.unmodifiableList(nextActionsForClosed));

        // After TRANSFERRED
        List<CaseAction> nextActionsForForward = new ArrayList<>();

        nextActionsForForward.add(CaseAction.UPDATE);
        nextActionsForForward.add(CaseAction.CLOSE);
        nextActionsForForward.add(CaseAction.FORWARD_TO_SUPERVISOR);


        stateMachineConfigForIcm
                .put(CaseStatus.APPROVED, Collections.unmodifiableList(nextActionsForForward));

        // AfteTRANSFERREDED
        List<CaseAction> nextActionsForManualTransfer = new ArrayList<>();
        nextActionsForManualTransfer.add(CaseAction.MANUAL_RECEIVE);
        nextActionsForManualTransfer.add(CaseAction.DOWNLOAD_MANUAL_TRANSFER_REPORT);

        stateMachineConfigForIcm
                .put(CaseStatus.MANUALTRANSFERRED,
                        Collections.unmodifiableList(nextActionsForManualTransfer));

        List<CaseAction> nextActionsForTransfer = new ArrayList<>();
        stateMachineConfigForIcm
                .put(CaseStatus.TRANSFERRED, Collections.unmodifiableList(nextActionsForTransfer));

        List<CaseAction> nextActionsForForwardInternal = new ArrayList<>();
        nextActionsForForwardInternal.add(CaseAction.RETURN);
        nextActionsForForwardInternal.add(CaseAction.CLOSE);
        stateMachineConfigForIcm
                .put(CaseStatus.FORWARD, Collections.unmodifiableList(nextActionsForForwardInternal));


        //Status OPENED
        List<CaseAction> nextActionsForManuallyTransferred = new ArrayList<>();

        nextActionsForManuallyTransferred.add(CaseAction.UPDATE);
        nextActionsForManuallyTransferred.add(CaseAction.CLOSE);
        nextActionsForManuallyTransferred.add(CaseAction.FORWARD_TO_SUPERVISOR);
        nextActionsForManuallyTransferred.add(CaseAction.MANUAL_TRANSFER);
        nextActionsForManuallyTransferred.add(CaseAction.TRANSFERRED_TO);
        nextActionsForManuallyTransferred.add(CaseAction.FORWARD);
        stateMachineConfigForIcm
                .put(CaseStatus.MANUALRECEIVED, Collections.unmodifiableList(nextActionsForTransfer));

    }

    public static Map<CaseStatus, List<CaseAction>> getStateMachineConfigForIcm() {
        return stateMachineConfigForIcm;
    }

}
