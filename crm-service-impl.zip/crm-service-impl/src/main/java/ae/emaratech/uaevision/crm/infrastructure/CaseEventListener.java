package ae.emaratech.uaevision.crm.infrastructure;

import ae.emaratech.uaevision.arrest.application.ArrestReportApplicationService;
import ae.emaratech.uaevision.arrest.application.CreateArrestReportResult;
import ae.emaratech.uaevision.arrest.application.dto.ArrestPartyDto;
import ae.emaratech.uaevision.arrest.application.dto.CreateTransferArrestDto;
import ae.emaratech.uaevision.crm.ahwal.remote.AhwalCaseRequestMessage;
import ae.emaratech.uaevision.crm.ahwal.remote.ObjectFactory;
import ae.emaratech.uaevision.crm.ahwal.service.AhwalCaseService;
import ae.emaratech.uaevision.crm.application.CreateCaseResult;
import ae.emaratech.uaevision.crm.application.TransferCaseCommand;
import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.crm.domain.CaseApplicationService;
import ae.emaratech.uaevision.crm.domain.CaseTransferredToCRMEvent;
import ae.emaratech.uaevision.crm.query.CaseQueryService;
import ae.emaratech.uaevision.crm.query.RetrieveCaseQuery;
import ae.emaratech.uaevision.deportation.domain.DeportationCompletedEvent;
import ae.emaratech.uaevision.fis.common.domain.TrackerKeyProvider;
import ae.emaratech.uaevision.fis.common.exception.BusinessException;
import ae.emaratech.uaevision.fis.common.infrastructure.DomainEventListener;
import ae.emaratech.uaevision.fis.common.key.*;
import ae.emaratech.uaevision.fis.common.util.JAXBUtil;
import ae.emaratech.uaevision.fis.gateway.api.QueueMessageRecordingService;
import ae.emaratech.uaevision.fis.gateway.domain.QueueMessage;
import ae.emaratech.uaevision.fis.gateway.message.QueueConstants;
import ae.emaratech.uaevision.fis.order.domain.OrderType;
import ae.emaratech.uaevision.fis.order.query.OrderQueryService;
import ae.emaratech.uaevision.fis.order.query.RetrieveOrderFromModuleQuery;
import ae.emaratech.uaevision.fis.order.service.dto.OrderDto;
import ae.emaratech.uaevision.fis.party.application.CreatePartyResult;
import ae.emaratech.uaevision.fis.party.application.PartyService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import javax.jms.Message;
import javax.xml.bind.JAXBElement;
import java.util.ArrayList;
import java.util.List;

/**
 * Event listener component for case module which listens to domain events that concern the Created
 * by Nitesh.Gupta on 6/15/2016.
 */
@Component
public class CaseEventListener implements DomainEventListener {

    /**
     * Static containing logger for the class.
     */

    private static final Logger LOGGER = LogManager.getLogger();

    @Autowired
    private QueueMessageRecordingService queueMessageRecordingService;

    @Autowired
    AhwalCaseService ahwalCaseService;

    @Autowired
    OrderQueryService orderQueryService;

    @Autowired
    CaseQueryService caseQueryService;

    @Autowired
    CaseApplicationService caseApplicationService;

    @Autowired
    PartyService partyService;
    @Autowired
    ArrestReportApplicationService arrestReportApplicationService;

    @Autowired
    private TrackerKeyProvider trackerKeyProvider;


    private ObjectFactory objectFactory = new ObjectFactory();

    /**
     * caseTransferredEvent which will be listening CaseTransferredToCRMEvent event
     * @param event CaseTransferredToCRMEvent
     * @throws JsonProcessingException
     */
    @EventListener
    public void caseTransferredEvent(CaseTransferredToCRMEvent event) throws JsonProcessingException {

        CaseKey caseKey = event.getCaseKey();
        TrackerKey trackerKey;
        List<ArrestPartyDto> transferredArrestPartyDtoList = new ArrayList<>();
        List<CasePartyDto> transferredCasePartyDtoList = new ArrayList<>();
        CaseDto caseDto = caseQueryService.retrieveCase(new RetrieveCaseQuery(caseKey));
        List<CasePartyDto> casePartyDtoList = caseDto.getCasePartyDtoList();
        trackerKey = trackerKeyProvider.next();
        for (CasePartyDto casePartyDto : casePartyDtoList){
            CreatePartyResult result = partyService.createTransferredParty(new PartyKey(casePartyDto.getPartyId()),trackerKey);
            CasePartyDto transferredCasePartyDto = new CasePartyDto();
            transferredCasePartyDto.setPartyId(result.getPartyKey().id());
            transferredCasePartyDto.setIsDeleted(0L);
            transferredCasePartyDto.setPartyType(casePartyDto.getPartyType());
            casePartyDto.getChargeDtoList().forEach(chargeDto -> chargeDto.setChargeId(0));
            transferredCasePartyDto.setChargeDtoList(casePartyDto.getChargeDtoList());
            transferredCasePartyDtoList.add(transferredCasePartyDto);

            ArrestPartyDto transferredArrestPartyDto = new ArrestPartyDto();
            transferredArrestPartyDto.setPartyId(result.getPartyKey().id());
            transferredArrestPartyDto.setIsDeleted(0L);
            transferredArrestPartyDto.setPartyType(casePartyDto.getPartyType());
            transferredArrestPartyDtoList.add(transferredArrestPartyDto);
        }
        //Creating Arrest
        CreateTransferArrestDto createTransferArrestDto = new CreateTransferArrestDto(new ArrestReportKey(caseDto.getArrestId()),trackerKey,transferredArrestPartyDtoList);
        CreateArrestReportResult createArrestResult = arrestReportApplicationService.createTransferredArrest(createTransferArrestDto);

        //Cloning case
        TransferCaseCommand command = new TransferCaseCommand(caseKey,createArrestResult.getArrestReportKey(),trackerKey,transferredCasePartyDtoList);
        CreateCaseResult result = caseApplicationService.createTransferredCase(command);

        LOGGER.info("Case Cloned with Id", result.getCaseKey().id());

    }


    @EventListener
    public void deportationCompletedEvent(DeportationCompletedEvent deportationCompletedEvent) {
        LOGGER.debug("Handling deportation completed event.");
        try{

            ModuleKey moduleKey = new ModuleKey( deportationCompletedEvent.getDeportationKey().id());
            RetrieveOrderFromModuleQuery retrieveOrderFromModuleQuery = new RetrieveOrderFromModuleQuery(OrderType.DEPORTATION,moduleKey);
            OrderDto orderDto = orderQueryService.retrieveOrderByTypeAndModuleId(retrieveOrderFromModuleQuery);

            Long caseId = orderDto.getParentIncidentId();

            CaseKey caseKey = new CaseKey(caseId);
            RetrieveCaseQuery retrieveCaseQuery = new RetrieveCaseQuery(caseKey);
            CaseDto caseDto = caseQueryService.retrieveCase(retrieveCaseQuery);

            if(null != caseDto.getVisionCaseNumber() && caseDto.getVisionCaseNumber().length()>0){
                ahwalCaseService.sendDeportResultToVision(caseDto.getVisionCaseNumber(), caseDto.getCaseNumber());
            }

        }catch(BusinessException ex){
            LOGGER.error("Error while trying to send deportation result to vision." + ex);
        }
    }

   //@JmsListener(destination = QueueConstants.QUEUE_AHWAL_INCIDENT_REQUEST)
    public boolean processAhwalMessageFomVision(Message message) throws BusinessException {

        boolean success = true;

        QueueMessage queueMessage = null;
        AhwalCaseRequestMessage newAhwalIncidentRequestMessage = null;

        try{
            //STEP 1: Reading incoming message on queue..
            queueMessage = queueMessageRecordingService.recordNewInboundMessage("AHWAL INCIDENT REQUEST QUEUE",message);
            String messageFromQueue = queueMessage.getMessage();

            //STEP 2: Converting Request XML to Request Object.
            newAhwalIncidentRequestMessage = prepareRequestObjectFromXML(messageFromQueue);

            //STEP 3: Create the Ahwal Incident in FIS
            CreateCaseResult createCaseResult = ahwalCaseService.createAhwalIncident(newAhwalIncidentRequestMessage);

            //STEP 4: Persist message success history in database
            queueMessageRecordingService.recordInboundMessageProcessingSuccessful(queueMessage);

            //STEP 5: Send Acknowledgement to Vision
            ahwalCaseService.sendSuccessAcknowledgement(newAhwalIncidentRequestMessage, createCaseResult.getCaseNumber());

        }catch(BusinessException ex){

            //STEP 1: Log the error message
            LOGGER.error("Failed to create Incident in FIS for the Ahwal Request. Error: "+ex);

            //STEP 2: Update queue message history
            queueMessageRecordingService.recordInboundMessageProcessingFailed(queueMessage, ex.getMessage());

            //STEP 3: Send Fail Acknowledgement to Vision
            ahwalCaseService.sendFailureAcknowledgement(newAhwalIncidentRequestMessage,ex.getMessage());

            success = false;

        }

        return success;
    }

    private AhwalCaseRequestMessage prepareRequestObjectFromXML(String message)throws BusinessException{

        AhwalCaseRequestMessage newAhwalIncidentRequestMessage;

        LOGGER.info("Unmarshal of Request XML into NewAhwalIncidentRequestObject Started");

        try{
            JAXBElement jaxbElement = (JAXBElement) JAXBUtil.getObjectFromXML(message, objectFactory.getClass());
            newAhwalIncidentRequestMessage = (AhwalCaseRequestMessage) jaxbElement.getValue();
            return newAhwalIncidentRequestMessage;
        }catch(BusinessException ex){
            LOGGER.error("Error while trying to umnarshall the incoming request XML into Ahwal Incident Request Object. " + ex.getMessage());
            throw  ex;
        }
    }
}
