package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceDefinition;
import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceService;
import ae.emaratech.uaevision.fis.common.key.CasePartyChargeKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by Nitesh.Gupta on 8/1/2016.
 */
@Component
public class CasePartyChargeKeyProvider {

    @Autowired
    private SequenceService sequenceService;

    public CasePartyChargeKey next() {
        Long nextSequenceNumber = sequenceService.nextValue(SequenceDefinition.CASE_PARTY_CHARGE);
        return new CasePartyChargeKey(nextSequenceNumber);
    }
}
