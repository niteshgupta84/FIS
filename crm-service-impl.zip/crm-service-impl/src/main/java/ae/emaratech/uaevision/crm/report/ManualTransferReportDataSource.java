package ae.emaratech.uaevision.crm.report;

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;
import ae.emaratech.uaevision.arrest.query.ArrestQueryService;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestQuery;
import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.crm.query.CaseQueryService;
import ae.emaratech.uaevision.crm.query.RetrieveCaseQuery;
import ae.emaratech.uaevision.document.service.api.DocumentService;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.common.util.DateUtils;
import ae.emaratech.uaevision.fis.gateway.incident.UserManagementServiceClient;
import ae.emaratech.uaevision.fis.gateway.usermanagementservice.EmployeeDetail;
import ae.emaratech.uaevision.fis.gateway.usermanagementservice.EmployeeDetails;
import ae.emaratech.uaevision.fis.party.application.PartyTypeEnum;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import ae.emaratech.uaevision.fis.party.query.RetrievePartyQuery;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperDataSource;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.jasperreports.JasperReportsUtils;
import org.springframework.util.CollectionUtils;

import java.io.ByteArrayInputStream;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by Deep.Gupta on 4/30/2017.
 */
@Component
public class ManualTransferReportDataSource implements JasperDataSource {

    @Autowired
    private ArrestQueryService arrestQueryService;

    @Autowired
    private CaseQueryService caseQueryService;

    @Autowired
    private UserManagementServiceClient userManagementServiceClient;

    @Autowired
    private PartyQueryService partyQueryService;

    @Autowired
    private DocumentService documentService;

    private static final Logger LOGGER = LogManager.getLogger();
    @Override
    public JRDataSource getDataSource(ReportParameters parameters) {

        Long caseId = Long.valueOf(parameters.getParameter("CASE_ID").toString());
        CaseKey caseKey = new CaseKey(caseId);
        RetrieveCaseQuery retrieveCaseQuery = new RetrieveCaseQuery(caseKey);
        CaseDto caseDto = caseQueryService.retrieveCase(retrieveCaseQuery);

        LOGGER.info("Fetched case details for the case id " + caseId);

        ArrestReportDto arrestReportDto = null;
        Long arrestId = caseDto.getArrestId();
        List<ArrestTeamDto> arrestTeamDtos = new ArrayList<>();
        if(null != arrestId){
            ArrestReportKey arrestReportKey = new ArrestReportKey(arrestId);
            RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(arrestReportKey);
            arrestReportDto = arrestQueryService.retrieveArrestReport(retrieveArrestQuery);
            arrestTeamDtos = arrestQueryService.retrieveArrestTeamsForArrest(retrieveArrestQuery);
        }


        LOGGER.info("Fetched arrest details for the case id " + caseId);

        EmployeeDetails employeeDetails = userManagementServiceClient.getAllEmployeeDetails();
        List<EmployeeDetail> employeeDetailList = employeeDetails.getEmployeeDetail();

        List<Map> objects = new ArrayList<>();

        List<PartyDto> parties = new ArrayList<>();

        byte[] partyPhoto = null;

        if (CollectionUtils.isEmpty(caseDto.getCasePartyDtoList())) {
            return new JRBeanCollectionDataSource(objects);
        }

        for (CasePartyDto casePartyDto : caseDto.getCasePartyDtoList()) {

            RetrievePartyQuery retrievePartyQuery = new RetrievePartyQuery(new PartyKey(casePartyDto.getPartyId()));
            PartyDto partyDto = partyQueryService.retrieveParty(retrievePartyQuery);


            partyDto.setListofCharges(casePartyDto.getChargeDtoList());

            if(Objects.equals(partyDto.getIsDeleted(), 0L)) {
                if (partyDto.getAttachmentId() != null) {
                    partyPhoto = documentService.downloadDocument(partyDto.getAttachmentId()).getAttachment();
                }
                if (partyPhoto != null) {
                    ByteArrayInputStream bais = new ByteArrayInputStream(partyPhoto);
                    partyDto.setReportProfilePhoto(bais);
                }
                partyDto.setPartytype(casePartyDto.getPartyType());

                if (casePartyDto.getPartyType().getId().equals(PartyTypeEnum.ACCUSED.getId())) {
                    parties.add(0, partyDto);
                } else {
                    parties.add(partyDto);
                }
            }
        }

        LOGGER.info("Fetched party details for the case id " + caseId);

        Comparator<PartyDto> byPartyId = (currentParty, nextParty) -> Long.compare(currentParty.getId(), nextParty.getId());
        parties.sort(byPartyId);

        for (PartyDto party : parties) {

            Map<String, Object> resultSet = new HashMap<>();

            List<PartyDto> partyList = new ArrayList();
            partyList.add(party);
            resultSet.put("party", partyList);
            resultSet.put("cdeptName", caseDto.getDepartment().getName());
            resultSet.put("csectionName", caseDto.getSection().getName());
            resultSet.put("incidentCreator", caseDto.getCreatedBy());
            resultSet.put("incidentNumber", caseDto.getCaseNumber());
            resultSet.put("incidentCreationDateTime", DateUtils.getDateToDisplay(caseDto.getCreatedDate()));
            resultSet.put("incidentStatus", caseDto.getStatus().getName());
            resultSet.put("deptName", caseDto.getDepartment().getName());
            resultSet.put("sectionName", caseDto.getSection().getName());

            // Arrest Details

            if(null != arrestReportDto){

                if (Checks.isNotNull(arrestReportDto.getArrestLocation())) {
                    resultSet.put("arrestLoc", arrestReportDto.getArrestLocation());
                }
                if (Checks.isNotNull(arrestReportDto.getEmirateLk())) {
                    resultSet.put("arrestEmirate", arrestReportDto.getEmirateLk().getName());
                }
                if (Checks.isNotNull(arrestReportDto.getCityLk())) {
                    resultSet.put("arrestCity", arrestReportDto.getCityLk().getName());
                }
                if (Checks.isNotNull(arrestReportDto.getAreaLk())) {
                    resultSet.put("arrestArea", arrestReportDto.getAreaLk().getName());
                }
                if (Checks.isNotNull(arrestReportDto.getArrestLocation())) {
                    resultSet.put("arrestLocDesc", arrestReportDto.getArrestLocation());
                }
                resultSet.put("arrestDate", DateUtils.getDateToDisplay(arrestReportDto.getArrestDate()));
                resultSet.put("arrestReport", arrestReportDto.getArrestReportDescription() + "<p>&nbsp;</p>");

                // Arrest team details
                JRDataSource jrArrestTeamLstDataSource ;
                if (CollectionUtils.isEmpty(arrestTeamDtos)) {
                    jrArrestTeamLstDataSource = new JRBeanCollectionDataSource(arrestTeamDtos);
                    resultSet.put("arrestTeamLst", jrArrestTeamLstDataSource);
                } else {

                    //Iterating EmployeeDetails and filter with EMployee Id to get the name of Arrest team
                    for (ArrestTeamDto arrestTeamDto : arrestTeamDtos) {
                        List<EmployeeDetail> employeeDetailListFiltered = employeeDetailList.stream().filter(empObj -> empObj.getEmployeeId() == Long.parseLong(arrestTeamDto.getEmployeeId())).
                                collect(Collectors.toList());
                        if (employeeDetailListFiltered.size() == 1) {
                            EmployeeDetail employeeDetail = employeeDetailListFiltered.get(0);
                            arrestTeamDto.setOfficerName(employeeDetail.getNameEn());
                            arrestTeamDto.setOfficerNameAr(employeeDetail.getNameAr());
                            employeeDetailListFiltered.clear();
                        }
                    }

                    jrArrestTeamLstDataSource = JasperReportsUtils.convertReportData(arrestTeamDtos);
                    resultSet.put("arrestTeamLst", jrArrestTeamLstDataSource);
                }
            }


            objects.add(resultSet);
        }

        LOGGER.info("Dataset prepared successfully for the manual transfer report");
        return new JRBeanCollectionDataSource(objects);
    }

}
