package ae.emaratech.uaevision.crm.report;

import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;
import ae.emaratech.uaevision.arrest.query.ArrestQueryService;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestTeamByEmployeeIdQuery;
import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.crm.query.CaseQueryService;
import ae.emaratech.uaevision.crm.query.RetrieveCaseQuery;
import ae.emaratech.uaevision.document.service.api.DocumentService;
import ae.emaratech.uaevision.fis.common.exception.BusinessException;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.common.key.OrderKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.order.query.OrderQueryService;
import ae.emaratech.uaevision.fis.order.query.ReleaseOrderQueryService;
import ae.emaratech.uaevision.fis.order.query.RetrieveOrderQuery;
import ae.emaratech.uaevision.fis.order.query.RetrieveReleaseOrderQuery;
import ae.emaratech.uaevision.fis.order.service.dto.OrderDto;
import ae.emaratech.uaevision.fis.order.service.dto.ReleaseOrderDto;
import ae.emaratech.uaevision.fis.party.application.dto.ChargeDto;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import ae.emaratech.uaevision.fis.party.query.RetrievePartyQuery;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperDataSource;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.util.*;


/**
 * This class is use for generating the release reports. <p/> Created by Wasib.Khan on 24/05/2016.
 */


@Component
public class ReleaseReportDataSource implements JasperDataSource {

    /**
     * Static containing the logger for the class.
     */
    private static final Logger LOGGER = LogManager.getLogger();

    @Autowired
    private ReleaseOrderQueryService releaseOrderQueryService;

    @Autowired
    private PartyQueryService partyQueryService;

    @Autowired
    private OrderQueryService orderQueryService;

    @Autowired
    private CaseQueryService caseQueryService;

    @Autowired
    private ArrestQueryService arrestQueryService;

    @Autowired
    private DocumentService documentService;


    public JRDataSource getDataSource(ReportParameters parameters) throws BusinessException {

        LOGGER.entry();
        LOGGER.info("method  getDataSource() start");

        //Fetching Party Details
        OrderKey
                orderKey =
                new OrderKey(Long.parseLong(parameters.getParameter("ORDER_ID").toString()));

        RetrieveReleaseOrderQuery retrieveReleaseOrderQuery = new RetrieveReleaseOrderQuery(orderKey);

        OrderDto
                orderDto =
                orderQueryService.retrieveOrder(new RetrieveOrderQuery(orderKey));

        CaseKey caseKey = new CaseKey(orderDto.getParentIncidentId());
        RetrieveCaseQuery retrieveCaseQuery = new RetrieveCaseQuery(caseKey);
        CaseDto caseDto = caseQueryService.retrieveCase(retrieveCaseQuery);

        ReleaseOrderDto releaseOrderDto = releaseOrderQueryService.retrieveReleaseOrderDetails(
                retrieveReleaseOrderQuery);
        PartyKey partyKey = new PartyKey(releaseOrderDto.getPartyId());
        PartyDto partyDto = partyQueryService.retrieveParty(new RetrievePartyQuery(partyKey));

        //Get Party Photo
        byte[] partyPhoto = null;
        if (partyDto.getAttachmentId() != null) {
            partyPhoto = documentService.downloadDocument(partyDto.getAttachmentId()).getAttachment();
        }

        //Get List of Charges
        List<String> charge = new ArrayList<>();
        List<CasePartyDto> casePartyDtoList = caseDto.getCasePartyDtoList();
        casePartyDtoList.stream()
                .filter(casePartyDto -> Objects.equals(casePartyDto.getPartyId(), partyKey.id()))
                .forEach(casePartyDto -> {
                    List<ChargeDto> listOfCharges = partyDto.getListofCharges();

                    if (Checks.isNotNull(listOfCharges)) {
                        for (ChargeDto chargeDto : listOfCharges) {
                            String chargeName = chargeDto.getCharge().getName();
                            charge.add(chargeName + ' ');
                        }
                    }
                });

        String charges = org.apache.commons.lang3.StringUtils.join(charge, ',');

        String approvedByName = "";
        String approvedByRank = "";
        if (releaseOrderDto.getApprovedBy() != null ){
            List<ArrestTeamDto> employeeDetails = arrestQueryService.retrieveArrestTeam(
                    new RetrieveArrestTeamByEmployeeIdQuery(Department.DETECTIVE, String.valueOf(
                            releaseOrderDto.getApprovedBy())));
            if (CollectionUtils.isNotEmpty(employeeDetails)) {
                approvedByName = employeeDetails.get(0).getOfficerNameAr();
                approvedByRank = employeeDetails.get(0).getRankAr();
            }
        }



        List<Map> objects = new ArrayList<>();
        Map<String, Object> resultSet = new HashMap<>();

        //Release Information

        String[] fromDate = String.valueOf(releaseOrderDto.getFromDate()).split(" ");
        String[] toDate = String.valueOf(releaseOrderDto.getToDate()).split(" ");

        resultSet.put("createdDate", String.valueOf(releaseOrderDto.getCreatedDate()));
        resultSet.put("createdBy", String.valueOf(releaseOrderDto.getCreatedBy()));
        resultSet.put("status", String.valueOf(releaseOrderDto.getStatus()));
        if (releaseOrderDto.getReason() != null) {
            resultSet.put("reason", String.valueOf(releaseOrderDto.getReason()));
        }
        resultSet.put("releaseType", String.valueOf(releaseOrderDto.getReleaseTypeName()));
        if (releaseOrderDto.getFromDate() != null) {
            resultSet.put("fromDate", String.valueOf(fromDate[0]));
        }
        if (releaseOrderDto.getToDate() != null) {
            resultSet.put("toDate", String.valueOf(toDate[0]));
        }
        resultSet.put("dateOfIssue", String.valueOf(releaseOrderDto.getDateOfIssue()));
        resultSet.put("orderId", String.valueOf(orderDto.getOrderNumber()));
        resultSet.put("incidentId", String.valueOf(caseDto.getCaseNumber()));
        if (approvedByName != null) {
            resultSet.put("approvedByName", String.valueOf(approvedByName));
        }
        if (approvedByRank != null) {
            resultSet.put("approvedByRank", String.valueOf(approvedByRank));
        }
        resultSet.put("releaseComments", String.valueOf(orderDto.getOrderCreationComments()));
        resultSet.put("isReleasePermanent", releaseOrderDto.getIsReleasePermanent());

        //Party Information
        resultSet.put("nameEn", String.valueOf(partyDto.getNameEn()));
        resultSet.put("nameAr", String.valueOf(partyDto.getNameAr()));
        resultSet.put("nationality", String.valueOf(partyDto.getNationality().getName()));

        if (CollectionUtils.isNotEmpty(partyDto.getPassports())) {
            resultSet.put("passport", String.valueOf(partyDto.getPassports().get(0).getPassportNo()));
        }
        resultSet.put("gender", String.valueOf(partyDto.getGender().getName()));
        resultSet.put("listOfCharges", String.valueOf(charges));
        if (null == partyDto.getPersonNo() || "".equals(partyDto.getPersonNo()) || "0".equals(partyDto.getPersonNo())) {
            resultSet.put("personNumber", "  --  ");
        } else {
            resultSet.put("personNumber", String.valueOf(partyDto.getPersonNo()));
        }
        resultSet.put("udbNo", String.valueOf(partyDto.getUdbNo()));
        resultSet.put("personType", String.valueOf(partyDto.getPersonType().getName()));
        resultSet.put("age", String.valueOf(partyDto.getAge()));
        resultSet.put("placeOfBirth", partyDto.getGetBirthplaceAr());
        resultSet.put("nameOfMotherAr", partyDto.getMotherNameAr());
        resultSet.put("age", String.valueOf(partyDto.getAge()));
        resultSet.put("occupation", partyDto.getProfession().getName());
        resultSet.put("country_city", partyDto.getCountry().getName());
        resultSet.put("nameOfMother", partyDto.getMotherNameEn());
        if (partyDto.getPhoneNumber() != null) {
            resultSet.put("phoneNumber", partyDto.getPhoneNumber());
        } else {
            resultSet.put("phoneNumber", "     --   ");
        }
        if (partyDto.getHomePhone() != null) {
            resultSet.put("homePhone", partyDto.getHomePhone());
        } else {
            resultSet.put("homePhone", "     --   ");
        }
        if (partyDto.getWorkPhone() != null) {
            resultSet.put("workPhone", partyDto.getWorkPhone());
        } else {
            resultSet.put("workPhone", "     --   ");
        }

        if (partyDto.getAddress() != null) {
            resultSet.put("address", partyDto.getAddress());
        } else {
            resultSet.put("address", "     --   ");
        }

        //Party Information
        if (partyPhoto != null) {
            ByteArrayInputStream bais = new ByteArrayInputStream(partyPhoto);
            resultSet.put("partyPhoto", bais);
        }

        //Department and Section Name
        resultSet.put("departmentName", String.valueOf(caseDto.getDepartment().getName()));
        resultSet.put("sectionName", String.valueOf(caseDto.getSection().getName()));
        resultSet.put("incidentStatus", String.valueOf(caseDto.getStatus().getName()));

        objects.add(resultSet);

        JRBeanCollectionDataSource source = new JRBeanCollectionDataSource(objects);

        LOGGER.info("method  getDataSource() stop");
        return source;
    }

    // This method is use for set JRDataset
    private JRDataSource getDataSource(List li) {
        JRDataSource jrDataSource = null;

        if (!CollectionUtils.isEmpty(li)) {
            jrDataSource = new JRBeanCollectionDataSource(li);
        } else {
            jrDataSource = new JRBeanCollectionDataSource(new ArrayList<>());
        }
        return jrDataSource;
    }

}
