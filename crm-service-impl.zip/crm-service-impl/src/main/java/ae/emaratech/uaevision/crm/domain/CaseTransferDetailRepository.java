package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.infrastructure.HibernateCaseTransferDetailRepository;

/**
 * Created by Nitesh.Gupta on 3/29/2017.
 */
public interface CaseTransferDetailRepository extends HibernateCaseTransferDetailRepository {
}
