package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.entitylistener.*;
import ae.emaratech.uaevision.lookup.service.annotation.LookupField;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * The persistent class for the CASE_TRANSFER_DETAILS database table.
 * Created by Nitesh.Gupta on 3/29/2017.
 */

@Entity
@EntityListeners({
        CreatedDateListener.class,
        CreatedByListener.class,
        ModifiedDateListener.class,
        ModifiedByListener.class

})
@Table(name = "CASE_TRANSFER_DETAILS")
public class CaseTransferDetail implements Creatable, Updatable, Serializable{

    @Id
    @SequenceGenerator(name = "CASE_TRANSFER_DETAILS_ID_GENERATOR", sequenceName = "SEQ_CASE_TRANSFER_DETAILS", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CASE_TRANSFER_DETAILS_ID_GENERATOR")
    @Column(name = "ID", unique = true, nullable = false, precision = 22, scale = 0)
    private Long id;

    @LookupField(LookupDefinition.DEPARTMENT)
    @Column(name = "TRANSFERRED_FROM_DEPT_ID", nullable = false)
    private Long transferredDeptId;

    @LookupField(LookupDefinition.SECTION)
    @Column(name = "TRANSFERRED_FROM_SECT_ID", nullable = false)
    private Long transferredSectionId;

    @Column(name = "CASE_ID", nullable = false)
    private Long caseId;

    @Column(name = "CREATED_BY", length = 20, nullable = false)
    private String createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE", nullable = false)
    private Date createdDate;

    @Column(name = "MODIFIED_BY", length = 20, nullable = false)
    private String modifiedBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFIED_DATE", nullable = false)
    private Date modifiedDate;

    @Column(name = "RECEIVED_BY", length = 20, nullable = false)
    private String receivedBy;

    @LookupField(LookupDefinition.CASE_STATUS)
    @Column(name = "TRANSFER_STATUS", length = 20, nullable = false)
    private Long transferStatus;


    @Column(name = "TRANSFERRED_CASE_ID", length = 20, nullable = false)
    private Long transferredCaseId;

    @Version
    private Long version;

    private CaseTransferDetail (){

    }

    protected Long getId() {
        return id;
    }

    protected Long getTransferredDeptId() {
        return transferredDeptId;
    }

    protected Long getTransferredSectionId() {
        return transferredSectionId;
    }

    protected Long getCaseId() {
        return caseId;
    }

    protected Date getCreatedDate() {
        return createdDate;
    }

    protected String getModifiedBy() {
        return modifiedBy;
    }

    protected Date getModifiedDate() {
        return modifiedDate;
    }

    protected Long getVersion() {
        return version;
    }

    protected String getReceivedBy() {
        return receivedBy;
    }

    protected Long getTransferStatus() {
        return transferStatus;
    }



    @Override
    public void setCreatedDate(Date date) {
        this.createdDate = date;
    }

    @Override
    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Override
    public void setModifiedDate(Date date) {
        this.modifiedDate = date;
    }

    @Override
    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Long getTransferredCaseId() {
        return transferredCaseId;
    }

    public CaseTransferDetail(Builder builder) {
        this.caseId = builder.caseId;
        this.transferredDeptId = builder.transferredDeptId;
        this.transferredSectionId = builder.transferredSectId;
        this.transferStatus = builder.transferStatus;
    }

    /**
     * Static method to prepare DeportationActionHistory object using Builder design pattern.
     */
    public static class Builder {

        private Long caseId;
        private Long transferredDeptId;
        private Long transferredSectId;
        private Long transferStatus;

        public Builder(Long caseId, Long transferredDeptId, Long transferredSectId,Long transferStatus) {
            this.caseId = caseId;
            this.transferredDeptId = transferredDeptId;
            this.transferredSectId = transferredSectId;
            this.transferStatus = transferStatus;
        }

        public CaseTransferDetail build() {
            return new CaseTransferDetail(this);
        }
    }

    public CaseTransferDetail withReceivedBy(String receivedBy){
        this.receivedBy = receivedBy;
        return this;
    }
    public CaseTransferDetail withReceivedStatus(Long transferStatus){
        this.transferStatus = transferStatus;
        return this;
    }
    public CaseTransferDetail withTransferredCaseId(Long transferredCaseId){
        this.transferredCaseId = transferredCaseId;
        return this;
    }
}
