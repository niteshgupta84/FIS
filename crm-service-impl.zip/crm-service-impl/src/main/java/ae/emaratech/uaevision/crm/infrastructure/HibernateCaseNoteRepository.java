package ae.emaratech.uaevision.crm.infrastructure;

import ae.emaratech.uaevision.crm.domain.CaseNote;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;

/**
 * Created by Nitesh.Gupta on 6/18/2016.
 */
public interface HibernateCaseNoteRepository extends JpaRepository<CaseNote, Long>,
        QueryDslPredicateExecutor<CaseNote> {

}
