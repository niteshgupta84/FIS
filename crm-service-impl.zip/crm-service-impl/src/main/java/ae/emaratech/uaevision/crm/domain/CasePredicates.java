package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.query.RetrieveCasesBySearchQuery;
import ae.emaratech.uaevision.crm.query.RetrieveCasesWithOwnerDetailQuery;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.common.type.Section;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.common.util.DateUtils;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import org.apache.commons.lang.StringUtils;
import org.springframework.data.querydsl.QSort;

import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/19/2016.
 */
public class CasePredicates {

    public static BooleanExpression hasNoPredicate() {
        return null;
    }

    /**
     * Order By Created Date
     */
    public static OrderSpecifier getOrderSpecifier() {

        QCase qCase = QCase.case$;
        QSort qsort = new QSort(qCase.createdDate.desc());
        return qsort.getOrderSpecifiers().get(0);
    }

    /**
     * Where clause for getting all history for case
     */
    public static Predicate getHistoryByCaseId(CaseKey caseKey) {

        return QCaseActionHistory.caseActionHistory.caseId
                .eq(caseKey.id());
    }

    public static OrderSpecifier getActionHistoryOrderSpecifier() {

        QCaseActionHistory
                qCaseActionHistory =
                QCaseActionHistory.caseActionHistory;
        QSort qsort = new QSort(qCaseActionHistory.createdDate.desc());
        return qsort.getOrderSpecifiers().get(0);
    }

    public static Predicate getCasesBySearchCriteria(RetrieveCasesBySearchQuery query) {

        BooleanExpression queryExpression =  QCase.case$.owner.section.eq(query.getSection().getId());

        if(null == query.getNonCRMSection()){
            queryExpression = queryExpression.or(QCase.case$.latestSection.eq(Section.DETENTION.id()));
        }

        if (query.getSectionUnit() != null && !Checks
                .isNotValidLookUpId(query.getSectionUnit().getId())) {
            queryExpression = queryExpression.and(
                    QCase.case$.owner.sectionUnit
                            .eq(query.getSectionUnit().getId()));
        }

        if (StringUtils.isNotBlank(query.getCaseNumber())) {
            queryExpression =
                    queryExpression.and(QCase.case$.caseNumber.like("%" + query.getCaseNumber() + "%"));

        }
        if (StringUtils.isNotBlank(query.getCreatedBy())) {
            queryExpression =
                    queryExpression.and(QCase.case$.createdBy.eq(query.getCreatedBy()));
        }

        if (query.getDepartment() != null && !Checks
                .isNotValidLookUpId(query.getDepartment().getId())) {
            queryExpression =
                    queryExpression.or(QCase.case$.owner.department
                            .eq(query.getDepartment().getId()));
        }

        if (query.getStatus() != null) {
            if (!Checks
                    .isNotValidLookUpId(query.getStatus().getId())) {
                queryExpression =
                        queryExpression.and(QCase.case$.statusId
                                .eq(query.getStatus().getId()));
            } else {
                queryExpression =
                        queryExpression.and(QCase.case$.statusId
                                .notIn(CaseStatus.CLOSED.id()));
            }
        } else {
            queryExpression =
                    queryExpression.and(QCase.case$.statusId
                            .notIn(CaseStatus.CLOSED.id()));
        }
        if (query.getCreatedDate() != null) {
            queryExpression =
                    queryExpression.and(
                            QCase.case$.createdDate
                                    .after(DateUtils.getDateBefore(query.getCreatedDate())));

            queryExpression =
                    queryExpression.and(
                            QCase.case$.createdDate
                                    .before(DateUtils.getDateAfter(query.getCreatedDate())));
        }

        return queryExpression;
    }

    public static Predicate getCaseByOwnerDetails(RetrieveCasesWithOwnerDetailQuery query) {

        BooleanExpression predicate = QCase.case$.latestSection.eq(
                query.getSectionId());

        if (Checks.isNotNull(query.getUserId())) {
            predicate = predicate.and(QCase.case$.assignedUser.eq(
                    query.getUserId()));
        }
        return predicate;
    }

    public static Predicate getActiveCaseForParty(List<Long> partyIdList) {

        return QCase.case$.statusId.eq(CaseStatus.OPENED.id()).and(
                QCase.case$.parties.any().partyId.in(partyIdList));
    }

    public static OrderSpecifier getCaseTransferSpecifier() {

        QCaseTransferDetail
                qCaseTransferDetail =
                QCaseTransferDetail.caseTransferDetail;
        QSort qsort = new QSort(qCaseTransferDetail.createdDate.desc());
        return qsort.getOrderSpecifiers().get(0);
    }
}
