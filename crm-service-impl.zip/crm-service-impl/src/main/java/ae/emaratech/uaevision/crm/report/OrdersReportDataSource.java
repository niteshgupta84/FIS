package ae.emaratech.uaevision.crm.report;
/**
 * Created by Satya K on 26/4/2016.
 */

import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.crm.query.CaseQueryService;
import ae.emaratech.uaevision.crm.query.RetrieveCaseQuery;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.util.ApplicationConstants;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.common.util.DateUtils;
import ae.emaratech.uaevision.fis.order.query.OrderQueryService;
import ae.emaratech.uaevision.fis.order.query.RetrieveOrderListQuery;
import ae.emaratech.uaevision.fis.order.service.dto.OrderDto;
import ae.emaratech.uaevision.fis.party.application.PartyTypeEnum;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import ae.emaratech.uaevision.fis.party.query.RetrievePartyQuery;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperDataSource;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.jasperreports.JasperReportsUtils;

import java.util.*;

@Component
public class OrdersReportDataSource implements JasperDataSource {

    private static final Logger LOGGER = LogManager.getLogger();

    @Autowired
    private OrderQueryService orderQueryService;

    @Autowired
    private PartyQueryService partyQueryService;

    @Autowired
    private CaseQueryService caseQueryService;

    public JRDataSource getDataSource(ReportParameters parameters) {
        LOGGER.info("Inside IncidentOrdersReportDataSource ");
        Long
                parentIncidentIdLong =
                Long.valueOf(
                        parameters.getParameter(ApplicationConstants.REPORT_PARAM_CASE_ID).toString());
        CaseKey caseKey = new CaseKey(parentIncidentIdLong);
        RetrieveOrderListQuery retrieveOrderListQuery = new RetrieveOrderListQuery(caseKey);
        List<OrderDto> orderDtos = orderQueryService.retrieveOrderList(retrieveOrderListQuery);
        CaseDto caseDto = caseQueryService.retrieveCase(new RetrieveCaseQuery(caseKey));

        LOGGER.info("Inside IncidentOrdersReportDataSource Report data Source all objects received");
        // No, Order number, Order type, Order Status, Party Status, Party name in Arabic, Order comments, Created by, and Creation date.

        List<Map> objects = new ArrayList<>();
        Map<String, Object> resultSet = new HashMap<>();
        List<PartyDto> parentIncidentDtoPartyDto = new ArrayList<>();
        PartyDto accusedParty = new PartyDto();
        if (Checks.isNotNull(caseDto.getCasePartyDtoList())) {

            for (CasePartyDto casePartyDto : caseDto.getCasePartyDtoList()) {
                PartyKey partyKey = new PartyKey(casePartyDto.getPartyId());
                RetrievePartyQuery retrievePartyQuery = new RetrievePartyQuery(partyKey);
                PartyDto partyDto = partyQueryService.retrieveParty(retrievePartyQuery);
                if (Objects.equals(casePartyDto.getPartyType().getId(), PartyTypeEnum.ACCUSED.getId())) {
                    parentIncidentDtoPartyDto.add(partyDto);

                }
            }

            if (CollectionUtils.isNotEmpty(parentIncidentDtoPartyDto)) {
                // Get the first Accused Object into PartyDTO
                accusedParty = parentIncidentDtoPartyDto.get(0);
            }
        }

        LOGGER.info("Inside IncidentOrdersReportDataSource data source ");
        // Incident details
        resultSet.put("incidentCreator", caseDto.getCreatedBy());
        resultSet.put("incidentNumber", caseDto.getCaseNumber());

        resultSet.put("incidentCreationDateTime", DateUtils.getDateToDisplay(caseDto.getCreatedDate()));
        resultSet.put("deptName", caseDto.getDepartment().getName());
        resultSet.put("sectionName", caseDto.getSection().getName());
        resultSet.put("incidentStatus", caseDto.getStatus().getName());
        if (Checks.isNotNull(caseDto.getArrestReason())) {
            resultSet.put("ordersArrestReportReason", caseDto.getArrestReason().getName());
        }

        if (Checks.isNotNull(caseDto.getTransferredFrom())) {
            resultSet.put("transferedfrom", caseDto.getTransferredFrom().getName());
        }

        //Setting Party details in report properties inside OrderDTO
        for (OrderDto orderDto : orderDtos) {

            // order Type 8 is update arrest order. update arrest order has party id as null
            if(orderDto.getOrderType().getId().longValue() != 8){

                PartyKey partyKey = new PartyKey(orderDto.getPartyId());
                PartyDto partyDto = partyQueryService.retrieveParty(new RetrievePartyQuery(partyKey));
                orderDto.setReportPartyNameAr(partyDto.getNameAr());
                orderDto.setReportPartyNameEn(partyDto.getNameEn());
                orderDto.setReportPartyStatus(partyDto.getPartyStatus());

            }

        }
        // Order details
        JRDataSource jrDataSource = null;
        if (CollectionUtils.isEmpty(orderDtos)) {
            jrDataSource = new JRBeanCollectionDataSource(new ArrayList<>());
            resultSet.put("lstOrders", jrDataSource);
            LOGGER.info("Inside IncidentOrdersReportDataSource lstOrders  NOT Available");
        } else {
            jrDataSource = JasperReportsUtils.convertReportData(orderDtos);
            resultSet.put("lstOrders", jrDataSource);
            LOGGER.info("Inside IncidentOrdersReportDataSources lstOrders Available");
        }

        // Charges details
        JRDataSource jrDataSourceCharges = null;
        if (Checks.isNotNull(accusedParty)) {
            if (CollectionUtils.isEmpty(accusedParty.getListofCharges())) {
                jrDataSourceCharges = new JRBeanCollectionDataSource(new ArrayList<>());
                resultSet.put("lstChrges", jrDataSourceCharges);
            } else {
                jrDataSourceCharges =
                        JasperReportsUtils.convertReportData(accusedParty.getListofCharges());
                resultSet.put("lstChrges", jrDataSourceCharges);
            }
        }
        objects.add(resultSet);
        return new JRBeanCollectionDataSource(objects);
    }
}
