package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.application.dto.CaseTrackDto;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
@Component
public class CaseActionHistoryMapper {


    /**
     * Reference to the lookup service.
     */
    @Autowired
    private LookupService lookupService;


    @Autowired
    private UserService userService;

    /**
     * Method which copies the relevant state information from Interrogation History entity to dto.
     *
     * @param caseActionHistory the arrest history entity bean.
     * @return arrest track transfer object
     */
    public CaseTrackDto mapCaseTrackDto(
            CaseActionHistory caseActionHistory) {

        CaseTrackDto caseTrackDto = new CaseTrackDto();

        caseTrackDto.setId(caseActionHistory.getId());
        caseTrackDto.setComments(caseActionHistory.getComments());
        caseTrackDto.setCreatedBy(userService.getUserFirstNameByUserLogin(caseActionHistory.getCreatedBy()));
        caseTrackDto.setCreatedDate(caseActionHistory.getCreatedDate());
        caseTrackDto.setAction(
                lookupService.getLookupEntry(
                        LookupDefinition.CASE_ACTION,
                        LocaleContextHolder
                                .getLocale(),
                        caseActionHistory.getCaseActionId()).get());

        return caseTrackDto;
    }
}
