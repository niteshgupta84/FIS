package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.fis.common.notification.NotificationCode;
import ae.emaratech.uaevision.fis.common.notification.NotificationType;

/**
 * Notification code for case module.
 *
 * @author Haroon.Subair
 */
public enum CaseNotificationCode implements NotificationCode {

    CASE_EXISTS_FOR_PARTY("CA0001", "case.warn.party.case.exists", NotificationType.WARNING),

    CASE_EXISTS_FOR_ARRESTED_PARTY("CA0002", "case.error.party.case.exists", NotificationType.ERROR),

    NO_PARTY_SELECTED("CA0003", "case.error.party.partySelect", NotificationType.ERROR),

    CASE_CREATE_SUCCESS("CA0004", "case.create.success", NotificationType.SUCCESS),
    PARTY_IMPORT_SUCCESS("CA0005", "incident.message.success.info.import", NotificationType.ERROR),
    COMMENTS_MANDATORY("CA0006", "arrestReport.error.required.rejectComments", NotificationType.ERROR),
    PARTY_REMOVED_SUCCESSFUL("CA0007", "profile.label.note.delete", NotificationType.SUCCESS),
    ARREST_EXISTS_FOR_PARTY_SAME_INCIDENT("CA0008", "case.warn.party.case.exists.same.incident", NotificationType.WARNING),
    ARREST_REASON_MANDATORY("CA0009", "arrestReport.error.required.arrestReason", NotificationType.ERROR),
    PARTY_DETAIL_MISSING("CA0010", "arrestReport.error.required.party", NotificationType.ERROR),
    PARTY_MANDATORY("CA0011", "incident.party.error.notNull", NotificationType.ERROR),
    ACCUSED_CHARGE_MANDATORY("CA0012", "arrestReport.party.accused.charge.mandatory", NotificationType.ERROR),
    PARTY_TYPE_MANDATORY("CA0013", "incident.party.partyType.warn.notNull", NotificationType.ERROR),
    NO_ARREST_FOUND_FORGIVEN_ID("CA0014", "arrestReport.error.noRecordFound", NotificationType.ERROR),
    TRANSFER_DEPARTMENT_MANDATORY("CA0015", "case.manualTransfer.department.error.mandatory", NotificationType.ERROR),
    OPEN_ORDER_AVAILABLE("CA0016", "case.close.pendingOrders", NotificationType.ERROR),
    PENDING_ORDERS("CA0017", "case.close.pendingOrders", NotificationType.ERROR),
    CASE_RECEIVED("CA0018","case.transfer.receive.success",NotificationType.SUCCESS),
    PARTY_EMAIL_MANDATORY("CA0019", "case.party.email.mandatory", NotificationType.ERROR),
    PARTY_PHONE_MANDATORY("CA0020", "case.party.phone.mandatory", NotificationType.ERROR),
    UNIT_MANDATORY("CA0021", "case.terminal.mandatory", NotificationType.ERROR),
    TRANSFERRED_FROM_MANDATORY("CA0022", "arrestReport.error.required.transferredFrom", NotificationType.ERROR),
    PARTY_PASSPORT_MANDATORY("CA0023", "case.party.passport.mandatory", NotificationType.ERROR),
    NO_DEPORTATION_ORDER_FOUND("CA0024", "case.close.pending.deportation.order", NotificationType.ERROR),
    CASE_CLOSED_CAN_NOT_BE_RETURNED("CA0025", "case.deportation.close.return.error", NotificationType.ERROR),
    MULTIPLE_PARTIES_FOUND("CA0026", "case.deportation.close.return.error.multiple.parties", NotificationType.ERROR),
    NOT_ELIGIBLE_FOR_FORWARD("CA0027", "case.deportation.close.return.error.samePort", NotificationType.ERROR);


    /**
     * Code passed to the user interface.
     */
    private String displayCode;

    /**
     * Code used to resolve the message from the bundle.
     */
    private String messageCode;

    /**
     * Defines the type of notification.
     */
    private NotificationType notificationType;

    CaseNotificationCode(String displayCode, String messageCode,
                         NotificationType notificationType) {
        this.displayCode = displayCode;
        this.messageCode = messageCode;
        this.notificationType = notificationType;
    }

    @Override
    public String getDisplayCode() {
        return displayCode;
    }

    @Override
    public String getMessageCode() {
        return messageCode;
    }

    @Override
    public NotificationType getType() {
        return notificationType;
    }

}
