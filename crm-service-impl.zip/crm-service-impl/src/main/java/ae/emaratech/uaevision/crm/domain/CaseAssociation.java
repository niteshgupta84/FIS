package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.entitylistener.Creatable;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedByListener;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedDateListener;
import ae.emaratech.uaevision.fis.common.key.AssociatedCaseKey;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@Entity
@Table(name = "CASE_ASSOCIATION")
@EntityListeners({
        CreatedDateListener.class,
        CreatedByListener.class,
})
public class CaseAssociation implements Creatable, Serializable {

    /**
     * Holds Unique key for Arrest Association.
     */
    @Id
    @SequenceGenerator(name = "CASE_ASSOC_ID_GENERATOR", sequenceName = "SEQ_CASE_ASSOCIATION", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CASE_ASSOC_ID_GENERATOR")
    @Column(name = "ID", unique = true, nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "CASE_ID", nullable = false)
    private Case caseReference;

    @Column(name = "LINKED_CASE_ID", nullable = false)
    private Long associatedCaseId;

    @Column(name = "CREATED_BY", length = 30, nullable = false)
    private String createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE", nullable = false)
    private Date createdDate;

    private CaseAssociation() {

    }

    public CaseAssociation(AssociatedCaseKey associatedCaseKey) {

        this.associatedCaseId = associatedCaseKey.id();
    }

    protected Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    protected Case getCaseReference() {
        return caseReference;
    }

    public void setCaseReference(Case caseReference) {
        this.caseReference = caseReference;
    }

    protected Long getAssociatedCaseId() {
        return associatedCaseId;
    }

    public void setAssociatedCaseId(Long associatedCaseId) {
        this.associatedCaseId = associatedCaseId;
    }

    protected Long id() {
        return id;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    protected Date getCreatedDate() {
        return createdDate;
    }

    @Override
    public void setCreatedDate(Date date) {
        this.createdDate = date;
    }
}
