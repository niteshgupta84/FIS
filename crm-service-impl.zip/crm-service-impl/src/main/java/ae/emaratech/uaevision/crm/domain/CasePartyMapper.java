package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.party.application.dto.ChargeDto;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Attribute;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Mapper class for mapping Arrest Party from Entity and DTO Created by Nitesh.Gupta on 6/6/2016.
 */
@Component
public class CasePartyMapper {

    private static final Logger LOGGER = LogManager.getLogger();

    @Autowired
    private LookupService lookupService;


    @Autowired
    private UserService userService;

    /**
     * Mapping Case Party Entity To Dto
     */

    public CasePartyDto mapToCasePartyDto(CaseParty caseParty) {

        CasePartyDto casePartyDto = new CasePartyDto();
        casePartyDto.setId(caseParty.id());
        casePartyDto.setCaseId(caseParty.getCaseReference().id());
        casePartyDto.setPartyId(caseParty.getPartyId());
        casePartyDto.setCreatedBy(userService.getUserFirstNameByUserLogin(caseParty.getCreatedBy()));
        casePartyDto.setCreatedDate(caseParty.getCreatedDate());
        casePartyDto.setIsDeleted(caseParty.getIsDeleted());
        if (Checks.isNotNull(caseParty.getPartyTypeId())) {
            List<Attribute> listOfAttributes = new ArrayList<>();
            listOfAttributes.add(new Attribute("IS_CHARGABLE"));
            Entry entry = lookupService.getLookupAttributes(LookupDefinition.PARTY_TYPE,
                    LocaleContextHolder.getLocale(),
                    caseParty.getPartyTypeId(), listOfAttributes).get();
            casePartyDto.setPartyType(entry);
        }
        //Mapping Case Party Charges
        Set<CasePartyCharge> casePartyChargeSet = caseParty.getCasePartyCharges();
        List<ChargeDto> casePartyChargeDtoList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(casePartyChargeSet)) {

            for (CasePartyCharge chargeEntity : casePartyChargeSet) {
                ChargeDto chargeDto = new ChargeDto();
                chargeDto.setChargeId(chargeEntity.getChargeId());
                chargeDto.setId(chargeEntity.id());

                chargeDto.setCharge(
                        lookupService.getLookupEntry(LookupDefinition.CHARGE,
                                LocaleContextHolder.getLocale(),
                                chargeEntity.getChargeId()).get());

                chargeDto.setPartyfileno(chargeEntity.id());
                chargeDto.setCreatedBy(chargeEntity.getCreatedBy());
                chargeDto.setCreatedDate(chargeEntity.getCreatedDate());
                chargeDto.setIsDeleted(chargeEntity.getIsDeleted());
                casePartyChargeDtoList.add(chargeDto);
            }
        }
        casePartyDto.setChargeDtoList(casePartyChargeDtoList);
        return casePartyDto;
    }

    /**
     * Map Seizure Entity to Dto List
     */
    public List<CasePartyDto> mapToDtoList(Set<CaseParty> casePartySet) {
        List<CasePartyDto> casePartyDtoList = new LinkedList<>();
        if (CollectionUtils.isNotEmpty(casePartySet)) {
            casePartyDtoList
                    .addAll(casePartySet.stream().map(this::mapToCasePartyDto).collect(Collectors.toList()));
        }

        return casePartyDtoList;
    }

    /**
     * Preparing EntitySet for Guarantee Period
     */
    //TODO - This method will be uncommented if Case is being create from Queue Message
    /*public PartyDto getPartyDtoFromAhwalRequest(AhwalCaseRequestMessage newAhwalIncidentRequestMessage) throws BusinessException {


        PartyDto partyDto = new PartyDto();

        String errorMessage = "";
        boolean passed = true;


        LOGGER.info("Preparing unknown profile object");

        // ---------------------    POPULATING MANDATORY FIELDS    -----------------------------------------------

        String nameEn = "";
        String nameAr = "";

        // populating first name in english
        String firstNameInEnglish = newAhwalIncidentRequestMessage.getProfileInfo().getFirstNameEnglish();
        if (null == firstNameInEnglish || firstNameInEnglish.trim().length() == 0) {
            errorMessage = "ERROR: First Name in English is mandatory for unknown UDB number";

            passed = false;
        } else {
            partyDto.setFirstNameEn(firstNameInEnglish.trim());
            nameEn = firstNameInEnglish.trim();
        }

        // populating middle name in english
        String middleNameInEnglish = newAhwalIncidentRequestMessage.getProfileInfo().getMiddleNameEnglish();
        if (StringUtils.isNotBlank(middleNameInEnglish)) {
            partyDto.setMiddleNameEn(middleNameInEnglish.trim());
            nameEn = nameEn + " " + middleNameInEnglish.trim();
        }
        // populating last name in english
        String lastNameInEnglish = newAhwalIncidentRequestMessage.getProfileInfo().getLastNameEnglish();
        if (null == lastNameInEnglish || lastNameInEnglish.trim().length() == 0) {
            errorMessage += "ERROR: Last Name in English is mandatory for unknown UDB number";

            passed = false;
        } else {
            partyDto.setLastNameEn(lastNameInEnglish.trim());
            nameEn = nameEn + " " + lastNameInEnglish.trim();
        }

        // populating first name in arabic
        String firstNameInArabic = newAhwalIncidentRequestMessage.getProfileInfo().getFirstNameArabic();
        if (null == firstNameInArabic || firstNameInArabic.trim().length() == 0) {
            errorMessage += "ERROR: First Name in Arabic is mandatory for unknown UDB number";

            passed = false;
        } else {
            partyDto.setFirstNameAr(firstNameInArabic.trim());
            nameAr = firstNameInArabic.trim();
        }

        //populating middle name in arabic
        String middleNameInArabic = newAhwalIncidentRequestMessage.getProfileInfo().getMiddleNameArabic();
        if (StringUtils.isNotBlank(middleNameInArabic)) {
            partyDto.setMiddleNameAr(middleNameInArabic.trim());
            nameAr = nameAr + " " + middleNameInArabic.trim();
        }

        // populating last name in arabic
        String lastNameInArabic = newAhwalIncidentRequestMessage.getProfileInfo().getLastNameArabic();
        if (null == lastNameInArabic || lastNameInArabic.trim().length() == 0) {
            errorMessage += "ERROR: Last Name in Arabic is mandatory for unknown UDB number";

            passed = false;
        } else {
            partyDto.setLastNameAr(lastNameInArabic.trim());
            nameAr = nameAr + " " + lastNameInArabic.trim();
        }

        // populating mother's name in english
        String motherNameInEnglish = newAhwalIncidentRequestMessage.getProfileInfo().getMotherNameEnglish();
        if (null == motherNameInEnglish || motherNameInEnglish.trim().length() == 0) {
            errorMessage += "ERROR: Mother's name in English is mandatory for unknown UDB number";

            passed = false;
        } else {
            partyDto.setMotherNameEn(motherNameInEnglish);
        }

        // populating mother's name in english
        String motherNameInArabic = newAhwalIncidentRequestMessage.getProfileInfo().getMotherNameArabic();
        if (null == motherNameInArabic || motherNameInArabic.trim().length() == 0) {
            errorMessage += "ERROR: Mother's name in Arabic is mandatory for unknown UDB number";

            passed = false;
        } else {
            partyDto.setMotherNameAr(motherNameInArabic);
        }

        // populating date of birth
        Date dateOfBirth;
        if (null == newAhwalIncidentRequestMessage.getProfileInfo().getDateOfBirth() ||
                null == newAhwalIncidentRequestMessage.getProfileInfo().getDateOfBirth().toGregorianCalendar()) {
            errorMessage += "ERROR: Date Of Birth in Arabic is mandatory for unknown UDB number.";

            passed = false;
        } else {
            dateOfBirth = newAhwalIncidentRequestMessage.getProfileInfo().getDateOfBirth().toGregorianCalendar().getTime();
            partyDto.setDateofbirth(dateOfBirth);
        }

        // populating gender
        if (null == newAhwalIncidentRequestMessage.getProfileInfo().getGender() || newAhwalIncidentRequestMessage.getProfileInfo().getGender().getId() == 0L) {
            errorMessage += "ERROR: Gender is mandatory for unknown UDB number.";

            passed = false;
        } else {
            long genderId = newAhwalIncidentRequestMessage.getProfileInfo().getGender().getId();
            try {
                Entry gender = lookupService.getLookupEntry(LookupDefinition.GENDER, LocaleContextHolder.getLocale(), genderId).get();
                partyDto.setGender(gender);
            } catch (Exception ex) {
                LOGGER.catching(ex);
                errorMessage += "ERROR: No lookup value found for the Gender: " + genderId;

                passed = false;
            }
        }

        // populating nationality
        if (null == newAhwalIncidentRequestMessage.getProfileInfo().getNationality() || newAhwalIncidentRequestMessage.getProfileInfo().getNationality().getId() == 0L) {
            errorMessage += "ERROR: Nationality is mandatory for unknown UDB number.";

            passed = false;
        } else {
            long nationalityId = newAhwalIncidentRequestMessage.getProfileInfo().getNationality().getId();
            partyDto.setNationality(getCountryEntryFromId(nationalityId));
        }

        partyDto.setNameEn(nameEn);
        partyDto.setNameAr(nameAr);

        Entry personType = lookupService.getLookupEntry(LookupDefinition.PERSON_TYPE, LocaleContextHolder.getLocale(), 8L).get();
        partyDto.setPersonType(personType);

        // ---------------------    POPULATING NON MANDATORY FIELDS    -----------------------------------------------

        partyDto.setMiddleNameEn(newAhwalIncidentRequestMessage.getProfileInfo().getMiddleNameEnglish());
        partyDto.setMiddleNameAr(newAhwalIncidentRequestMessage.getProfileInfo().getMiddleNameArabic());
        partyDto.setAddress(newAhwalIncidentRequestMessage.getProfileInfo().getAddress());
        partyDto.setBuilding(newAhwalIncidentRequestMessage.getProfileInfo().getBuilding());
        partyDto.setStreet(newAhwalIncidentRequestMessage.getProfileInfo().getStreet());
        partyDto.setPhoneNumber(newAhwalIncidentRequestMessage.getProfileInfo().getPhoneNumber());

        // populating social status
        if (null != newAhwalIncidentRequestMessage.getProfileInfo().getSocialStatusId() && newAhwalIncidentRequestMessage.getProfileInfo().getSocialStatusId().getId() != 0L) {
            long socialStatusId = newAhwalIncidentRequestMessage.getProfileInfo().getSocialStatusId().getId();
            try {
                Entry socialStatus = lookupService.getLookupEntry(LookupDefinition.SOCIAL_STATUS, LocaleContextHolder.getLocale(), socialStatusId).get();
                partyDto.setSocialStatus(socialStatus);
            } catch (Exception ex) {
                LOGGER.catching(ex);
                errorMessage += "ERROR: No lookup value found for social status: " + socialStatusId;

                passed = false;
            }
        }

        // populating country of residence
        if (null != newAhwalIncidentRequestMessage.getProfileInfo().getResidingCountry() && newAhwalIncidentRequestMessage.getProfileInfo().getResidingCountry().getId() != 0L) {
            long countryId = newAhwalIncidentRequestMessage.getProfileInfo().getResidingCountry().getId();
            partyDto.setCountry(getCountryEntryFromId(countryId));
        }

        // populating city of residence
        if (null != newAhwalIncidentRequestMessage.getProfileInfo().getCity() && newAhwalIncidentRequestMessage.getProfileInfo().getCity().getId() != 0L) {
            long cityId = newAhwalIncidentRequestMessage.getProfileInfo().getCity().getId();
            try {
                Entry city = lookupService.getLookupEntry(LookupDefinition.CITY, LocaleContextHolder.getLocale(), cityId).get();
                partyDto.setCity(city);
            } catch (Exception ex) {
                LOGGER.catching(ex);
                errorMessage += "ERROR: No lookup value found for the City: " + cityId;

                passed = false;
            }
        }

        // populating religion
        if (null != newAhwalIncidentRequestMessage.getProfileInfo().getReligion() && newAhwalIncidentRequestMessage.getProfileInfo().getReligion().getId() != 0L) {
            long religionId = newAhwalIncidentRequestMessage.getProfileInfo().getReligion().getId();
            try {
                Entry religion = lookupService.getLookupEntry(LookupDefinition.RELIGION, LocaleContextHolder.getLocale(), religionId).get();
                partyDto.setReligion(religion);
            } catch (Exception ex) {
                LOGGER.catching(ex);
                errorMessage += "ERROR: No lookup value found for the Religion: " + religionId;

                passed = false;
            }
        }

        partyDto.setEmailAddress(newAhwalIncidentRequestMessage.getProfileInfo().getEmail());

        // populating profession
        if (null != newAhwalIncidentRequestMessage.getProfileInfo().getProfession() && newAhwalIncidentRequestMessage.getProfileInfo().getProfession().getId() != 0L) {
            long professionId = newAhwalIncidentRequestMessage.getProfileInfo().getProfession().getId();
            try {
                Entry profession = lookupService.getLookupEntry(LookupDefinition.PROFESSION, LocaleContextHolder.getLocale(), professionId).get();
                partyDto.setProfession(profession);
            } catch (Exception ex) {
                LOGGER.catching(ex);
                errorMessage += "ERROR: No lookup value found for the Profession: " + professionId;

                passed = false;
            }
        }

        // populating education degree
        if (null != newAhwalIncidentRequestMessage.getProfileInfo().getEducation() && newAhwalIncidentRequestMessage.getProfileInfo().getEducation().getId() != 0L) {
            long educationId = newAhwalIncidentRequestMessage.getProfileInfo().getEducation().getId();
            try {
                Entry education = lookupService.getLookupEntry(LookupDefinition.EDUCATION, LocaleContextHolder.getLocale(), educationId).get();
                partyDto.setEducationDegree(education);
            } catch (Exception ex) {
                LOGGER.catching(ex);
                errorMessage += "ERROR: No lookup value found for the Education Degree: " + educationId;

                LOGGER.catching(ex);
                passed = false;
            }
        }

        partyDto.setBirthplaceEn(newAhwalIncidentRequestMessage.getProfileInfo().getBirthLocation());
        partyDto.setGetBirthplaceAr(newAhwalIncidentRequestMessage.getProfileInfo().getBirthLocation());
        partyDto.setFaxNumber(newAhwalIncidentRequestMessage.getProfileInfo().getFaxNumber());
        partyDto.setPhoto(newAhwalIncidentRequestMessage.getProfileInfo().getProfilePhoto());

        if (Checks.isNotNull(newAhwalIncidentRequestMessage.getProfileInfo().getProfilePhoto())) {
            partyDto.setPhoto(newAhwalIncidentRequestMessage.getProfileInfo().getProfilePhoto());
        }

        LOGGER.info("Profile Details Populated Successfully");

        LOGGER.info("Populating Party Passport Details from the ahwal request..");
        if (null != newAhwalIncidentRequestMessage.getProfileInfo().getPassports()) {
            LOGGER.info("Found Passport Details in Party Profile.");

        } else {
            LOGGER.warn("No Passport information provided by Ahwal in case of Unknown UDB Number");
            if (!passed) {
                throw new BusinessException(errorMessage);
            }
            return partyDto;
        }

        List<PassportDto> partyPassports = new ArrayList<PassportDto>();
        PassportDto passportDto;

        for (Passport passportRequest : newAhwalIncidentRequestMessage.getProfileInfo().getPassports().getPassport()) {

            passportDto = new PassportDto();

            // populating passport number
            String passportNumber = passportRequest.getPassportNo();
            if (null == passportNumber || passportNumber.trim().length() == 0) {
                errorMessage = "ERROR: Passport Number is blank";
                throw new BusinessException(errorMessage);
            } else {
                passportDto.setPassportNo(passportNumber.trim());
            }

            // populating passport type id
            if (null == passportRequest.getPassportType()) {
                errorMessage += "ERROR: Passport Type Id cannot be blank";

                passed = false;
            } else {
                long passportTypeId = passportRequest.getPassportType().getId();
                Entry passportType = lookupService.getLookupEntry(LookupDefinition.ID_DOC_TYPE, LocaleContextHolder.getLocale(), passportTypeId).get();
                passportDto.setPassportType(passportType);
            }

            // populating passport nationality
            Long passportNationalityId = passportRequest.getNationality().getId();
            if (null == passportNationalityId) {
                errorMessage += "ERROR: Passport Nationality cannot be blank";

                passed = false;
            } else {
                passportDto.setNationality(getCountryEntryFromId(passportNationalityId));
            }

            // populating passport issue country
            Long issueCountryId = passportRequest.getIssueCountry().getId();
            if (null == issueCountryId) {
                errorMessage += "ERROR: Passport Issue Country cannot be blank";

                passed = false;
            } else {
                passportDto.setIssueCountry(getCountryEntryFromId(issueCountryId));
            }

            // populating passport issue country government
            Long issueGovernmentId = passportRequest.getIssueCountryGov().getId();
            if (null == issueGovernmentId) {
                errorMessage += "ERROR: Passport Issue Country Government cannot be blank";

                passed = false;
            } else {
                passportDto.setIssueGovCountry(getCountryEntryFromId(issueCountryId));
            }

            // populating place of issue english
            if (null == passportRequest.getIssuePlaceEn() || passportRequest.getIssuePlaceEn().trim().length() == 0) {
                errorMessage += "ERROR: Passport Issue Place English cannot be blank";

                passed = false;
            } else {
                passportDto.setIssuePlaceEn(passportRequest.getIssuePlaceEn().trim());
            }

            // populating place of issue arabic
            if (null == passportRequest.getIssuePlaceAr() || passportRequest.getIssuePlaceAr().trim().length() == 0) {
                errorMessage += "ERROR: Passport Issue Place Arabic cannot be blank";

                passed = false;
            } else {
                passportDto.setIssuePlaceAr(passportRequest.getIssuePlaceAr().trim());
            }

            // populating date of issue
            Date dateOfIssue;
            if (null == passportRequest.getIssueDate() || null == passportRequest.getIssueDate().toGregorianCalendar()) {
                errorMessage += "ERROR: Passport Issue Date cannot be blank";

                passed = false;
            } else {
                dateOfIssue = passportRequest.getIssueDate().toGregorianCalendar().getTime();
                passportDto.setIssueDate(dateOfIssue);
            }

            // populating date of expiry
            Date dateOfExpiry;
            if (null == passportRequest.getExpiryDate() || null == passportRequest.getExpiryDate().toGregorianCalendar()) {
                errorMessage += "ERROR: Passport Expiry Date cannot be blank";

                passed = false;
            } else {
                dateOfExpiry = passportRequest.getExpiryDate().toGregorianCalendar().getTime();
                passportDto.setExpiryDate(dateOfExpiry);
            }

            partyPassports.add(passportDto);
        }

        partyDto.setPassports(partyPassports);


        if (!passed) {

            throw new BusinessException(errorMessage);
        }

        return partyDto;
    }*/

   /* private Entry getCountryEntryFromId(Long id) throws BusinessException {
        try {
            Entry country = lookupService.getLookupEntry(LookupDefinition.COUNTRY, LocaleContextHolder.getLocale(), id).get();
            return country;
        } catch (Exception ex) {
            String errorMessage = "ERROR: No lookup value found for the Country: " + id;
            LOGGER.catching(ex);
            throw new BusinessException(errorMessage);
        }
    }
*/
}
