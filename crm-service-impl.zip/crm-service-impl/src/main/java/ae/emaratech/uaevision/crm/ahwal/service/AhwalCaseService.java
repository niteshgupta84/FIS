package ae.emaratech.uaevision.crm.ahwal.service;

import ae.emaratech.uaevision.arrest.application.ArrestReportApplicationService;
import ae.emaratech.uaevision.arrest.application.CreateArrestReportCommand;
import ae.emaratech.uaevision.arrest.application.CreateArrestReportResult;
import ae.emaratech.uaevision.arrest.application.dto.ArrestPartyDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;
import ae.emaratech.uaevision.arrest.domain.ArrestDescription;
import ae.emaratech.uaevision.arrest.domain.ArrestReason;
import ae.emaratech.uaevision.crm.ahwal.remote.AhwalCaseRequestMessage;
import ae.emaratech.uaevision.crm.ahwal.remote.Attachment;
import ae.emaratech.uaevision.crm.application.CreateCaseCommand;
import ae.emaratech.uaevision.crm.application.CreateCaseResult;
import ae.emaratech.uaevision.crm.application.UpdateCaseCommand;
import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.crm.domain.CaseApplicationService;
import ae.emaratech.uaevision.crm.domain.CasePartyMapper;
import ae.emaratech.uaevision.document.application.AttachedDocumentDto;
import ae.emaratech.uaevision.document.application.PersistAttachmentCommand;
import ae.emaratech.uaevision.document.service.api.DocumentService;
import ae.emaratech.uaevision.document.service.dto.ContentType;
import ae.emaratech.uaevision.document.service.dto.DocumentDto;
import ae.emaratech.uaevision.document.service.dto.DocumentInfoDto;
import ae.emaratech.uaevision.fis.common.domain.TrackerKeyProvider;
import ae.emaratech.uaevision.fis.common.exception.BusinessException;
import ae.emaratech.uaevision.fis.common.key.AttachmentReferenceKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.key.TrackerKey;
import ae.emaratech.uaevision.fis.common.query.RetrieveByUDBQueryCommon;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.common.util.DateUtils;
import ae.emaratech.uaevision.fis.common.util.Enums;
import ae.emaratech.uaevision.fis.gateway.incident.UserManagementServiceClient;
import ae.emaratech.uaevision.fis.gateway.usermanagementservice.EmployeeDetail;
import ae.emaratech.uaevision.fis.party.application.*;
import ae.emaratech.uaevision.fis.party.application.dto.ChargeDto;
import ae.emaratech.uaevision.fis.party.application.dto.IRISDto;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.Base64Utils;
import sun.misc.BASE64Decoder;

import javax.transaction.Transactional;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by Deep.Gupta on 11/28/2016.
 */
@Component
public class AhwalCaseService {

    @Autowired
    private CaseApplicationService caseApplicationService;
    @Autowired
    private PartyQueryService partyQueryService;
    @Autowired
    private PartyService partyService;
    @Autowired
    private LookupService lookupService;
    @Autowired
    private UserManagementServiceClient userManagementServiceClient;
    @Autowired
    private ArrestReportApplicationService arrestReportApplicationService;
    @Autowired
    private DocumentService documentService;
    @Autowired
    private CasePartyMapper casePartyMapper;

    @Autowired
    private AhwalIncidentMQClient ahwalIncidentMQClient;

    @Autowired
    private TrackerKeyProvider trackerKeyProvider;

    private static final Logger LOGGER = LogManager.getLogger();

    @Transactional
    public CreateCaseResult createAhwalIncident(AhwalCaseRequestMessage newAhwalIncidentRequestMessage) throws BusinessException{

        LOGGER.info("------------------Creating Ahwal Incident in FIS-----------------------------");


        // find createdBy.
        String createdBy = "";

        if(null == newAhwalIncidentRequestMessage.getAhwalOfficerEmployeeId()){
            throw new BusinessException("Ahwal Officer Employee Id cannot be null");
        }else{
            Long employeeId = newAhwalIncidentRequestMessage.getAhwalOfficerEmployeeId();

                createdBy = userManagementServiceClient.getEmployeeByEmployeeId(employeeId).getUserLogin().get(0);

        }

        PartyDto partyDto = getPatyDtoFromAhwalRequest(newAhwalIncidentRequestMessage);
        partyDto.setCreatedBy(createdBy);

        prepareListOfCharges(newAhwalIncidentRequestMessage, partyDto);

        IRISDto irisDto = getPartyIrisDto(newAhwalIncidentRequestMessage);

        ArrestReason arrestReason = getArrestReason(newAhwalIncidentRequestMessage);
        Date arrestDateTime = getArrestDateTime(newAhwalIncidentRequestMessage);
        Entry shift = getEmployeeShift(newAhwalIncidentRequestMessage);
        Entry unit = getEmployeeUnit(newAhwalIncidentRequestMessage);
        Entry arrestLocation = getArrestLocation(newAhwalIncidentRequestMessage);
        List<ArrestTeamDto> arrestTeamList = prepareArrestTeam(newAhwalIncidentRequestMessage);

        String firNumber = newAhwalIncidentRequestMessage.getFirNumber();

        CreatePartyResult result = saveAhwalPartyDetails(partyDto);
        List<ArrestPartyDto> arrestPartyList = prepareArrestPartyList(result, createdBy);
        List<CasePartyDto> casePartyDtoList = prepareCasePartyList(result,partyDto, createdBy);

        List<PartyKey> partyKeyList = new LinkedList<>();
        partyKeyList.add(result.getPartyKey());
        TrackerKey trackerKey = trackerKeyProvider.next();
        CreateArrestReportResult createArrestReportResult = createAhwalArrestReport(newAhwalIncidentRequestMessage,arrestReason,arrestLocation,arrestDateTime,
                arrestPartyList,arrestTeamList,unit,shift,partyKeyList,createdBy, trackerKey);

        CreateCaseResult createCaseResult = createAhwalCase(newAhwalIncidentRequestMessage,createArrestReportResult,unit,casePartyDtoList,arrestReason,firNumber,createdBy, trackerKey);

        LOGGER.info("Case Created Successfully. Case ID: "+ createCaseResult.getCaseKey().id());

        saveCaseAttachements(newAhwalIncidentRequestMessage, createCaseResult, partyKeyList, createdBy,firNumber);

        LOGGER.info("------------------Ahwal Incident Created Successfully in FIS-------------------------------------");

        return createCaseResult;
    }

    private List<ChargeDto> prepareListOfCharges(AhwalCaseRequestMessage newAhwalIncidentRequestMessage, PartyDto partyDto) throws BusinessException{

        //Setting Charges in the Party
        LOGGER.info("Preparing the list of Charges for the Party");
        List<ChargeDto> listOfCharges = new ArrayList<>();
        String[] chargeIds = newAhwalIncidentRequestMessage.getCharges().split(",");
        for (String chargeId : chargeIds) {
            ChargeDto chargeDto = new ChargeDto();
            listOfCharges.add(chargeDto);
            Optional<Entry> chargeEntry = lookupService.getLookupEntry(LookupDefinition.CHARGE, Long.parseLong(chargeId));
            chargeDto.setCharge(chargeEntry.get());
            chargeDto.setCreatedBy(partyDto.getCreatedBy());
        }
        if(listOfCharges.size()==0){
            throw new BusinessException("Charge list cannot be empty. Atleast one charge is required.");
        }else{
            LOGGER.info("List of Charges Prepared Successfully..");
            partyDto.setListofCharges(listOfCharges);
        }
        return listOfCharges;
    }

    private IRISDto getPartyIrisDto(AhwalCaseRequestMessage newAhwalIncidentRequestMessage){

        LOGGER.info("Setting profile IRIS details.");
        //Setting IRIS Details of party
        IRISDto irisDto = new IRISDto();
        irisDto.setId(0L);
        Optional<Entry> locChangedEntry = lookupService.getLookupEntry(LookupDefinition.IRIS_LOCATION, 1L);
        irisDto.setLocationId(locChangedEntry.get());
        irisDto.setIrisNumber("0");

        Optional<Entry> nameChangedEntry = lookupService.getLookupEntry(LookupDefinition.IRIS_NAME_CHANGED, 1L);
        irisDto.setNameChangedId(nameChangedEntry.get());
        irisDto.setIrisEncodedPhotoString("");
        LOGGER.info("IRIS details set successfully..");
        return irisDto;
    }

    private List<ArrestTeamDto> prepareArrestTeam(AhwalCaseRequestMessage newAhwalIncidentRequestMessage) throws BusinessException{
        LOGGER.info("Preparing arrest team.");
        //Arrest team preparation
        ArrestTeamDto ahwalOfficer = new ArrestTeamDto();

        EmployeeDetail employeeDetails = null;

        if(null == newAhwalIncidentRequestMessage.getAhwalOfficerEmployeeId()){
            throw new BusinessException("Ahwal Officer Employee Id cannot be null");
        }else{
            ahwalOfficer.setEmployeeId(newAhwalIncidentRequestMessage.getAhwalOfficerEmployeeId().toString());
            employeeDetails = userManagementServiceClient.getEmployeeByEmployeeId(Long.parseLong(ahwalOfficer.getEmployeeId()));
            ahwalOfficer.setOfficerName(employeeDetails.getNameEn());
            ahwalOfficer.setOfficerNameAr(employeeDetails.getNameAr());
        }

        ArrestTeamDto entryOfficer = new ArrestTeamDto();
        if(null == newAhwalIncidentRequestMessage.getEntryOfficerEmployeeId()){
            throw new BusinessException("Entry Officer Employee Id cannot be null");
        }else{
            entryOfficer.setEmployeeId(newAhwalIncidentRequestMessage.getEntryOfficerEmployeeId().toString());
            employeeDetails = userManagementServiceClient.getEmployeeByEmployeeId(Long.parseLong(entryOfficer.getEmployeeId()));
            entryOfficer.setOfficerName(employeeDetails.getNameEn());
            entryOfficer.setOfficerNameAr(employeeDetails.getNameAr());
        }

        List<ArrestTeamDto> arrestTeamList = new ArrayList<>();
        arrestTeamList.add(ahwalOfficer);
        arrestTeamList.add(entryOfficer);

        LOGGER.info("Arrest team prepared successfully.");
        return arrestTeamList;
    }

    private List<AttachedDocumentDto> prepareAhwalCaseAttachments(AhwalCaseRequestMessage newAhwalIncidentRequestMessage, String createdBy)throws BusinessException{

        List<AttachedDocumentDto> attachedDocumentDtos = new ArrayList<>();

        Integer i=1;

        for(Attachment attachment : newAhwalIncidentRequestMessage.getAttachments().getAttachment()) {

            if (attachment.getMimeType().getId() == 1L) {
                if(!attachment.getAttachmentDescription().endsWith(".pdf")){
                    String description = attachment.getAttachmentDescription() + ".pdf";
                    description = description.replace(" ","_");
                    attachment.setAttachmentDescription(description);
                }
            }

            DocumentInfoDto documentInfoDto = new DocumentInfoDto(attachment.getAttachmentDescription(), Enums.constant(ContentType.class, attachment.getMimeType().getId()));


            String base64content = Base64Utils.encodeToString(attachment.getAttachmentFile());
            byte[] decodedContent = new byte[0];
            try {
                decodedContent = new BASE64Decoder().decodeBuffer(base64content);
            } catch (IOException e) {
                LOGGER.info("Received Exception ",e);
                throw new BusinessException(e.getMessage());

            }
            DocumentDto documentDto = new DocumentDto(documentInfoDto,decodedContent);

            LOGGER.info("Uploading the documents in db.");
            DocumentInfoDto documentKey = documentService.upload(documentDto);
            LOGGER.info("Document Uploaded.");

            AttachedDocumentDto attachedDocumentDto = new AttachedDocumentDto();
            attachedDocumentDto.setDescription(attachment.getAttachmentDescription());
            attachedDocumentDto.setCreatedBy(createdBy);
            Entry documentTypeLookupEntry = lookupService.getLookupEntry(LookupDefinition.IDENTIFICATION_DOC_TYPE, LocaleContextHolder.getLocale(), 13L).get();attachedDocumentDto.setDocumentTypeId(13L);
            LOGGER.printf(Level.DEBUG, "Uploaded document key = %s ", documentKey);

            attachedDocumentDto.setViewId(documentKey.getKey().getKey());
            i++;

            attachedDocumentDto.setIncidentType(lookupService.getLookupEntry(LookupDefinition.INCIDENT_TYPE, LocaleContextHolder.getLocale(), ModuleTypes.CRM.id()).get());
            attachedDocumentDto.setIsDeleted(false);


            PersistAttachmentCommand persistAttachmentCommand = new PersistAttachmentCommand(attachedDocumentDto);
            attachedDocumentDto = documentService.persist(persistAttachmentCommand);

            attachedDocumentDtos.add(attachedDocumentDto);

        }
        return attachedDocumentDtos;
    }

    private List<AttachmentReferenceKey> getActiveAttachments(
            List<AttachedDocumentDto> attachedDocumentList) {
        if (attachedDocumentList != null) {
            return attachedDocumentList.stream()
                    .filter(attachedDocument -> org.apache.commons.lang.StringUtils.isBlank(attachedDocument.getDeletionComments()))
                    .map(attachedDocument -> {
                        AttachmentReferenceKey attachmentKey =
                                new AttachmentReferenceKey(attachedDocument.getAttachmentReferenceId());
                        return attachmentKey;
                    })
                    .collect(Collectors.toList());
        } else {
            return null;
        }

    }

    private PartyDto getPatyDtoFromAhwalRequest(AhwalCaseRequestMessage newAhwalIncidentRequestMessage) throws BusinessException{

        PartyDto partyDto = new PartyDto();

        //Find Parties from UDB Number received
        Long udbNumber = newAhwalIncidentRequestMessage.getProfileInfo().getUdbNo();

        if(udbNumber !=null){
            LOGGER.info("Received UDB number from vision for Ahwal Case. Fetching rest of the party details from vision. UDB Number: " +  udbNumber);
            List<PartyDto> partyDtoList = partyQueryService.retrieveProfile(new RetrieveByUDBQueryCommon(udbNumber));
            if(partyDtoList.size()>0){
                LOGGER.info("Profile Information Fetched successfully From Vision..");
                partyDto = partyDtoList.get(0);
            }else{
                String message = "ERROR: Found Zero records for the UDB Number : " + udbNumber;
                throw new BusinessException(message);
            }
        }else{
            LOGGER.info("No UDB Number received from Vision for Ahwal Case. Creating case as unknown profile");
            //TODO - This call be uncommented if case created from Queue Message
           // partyDto = casePartyMapper.getPartyDtoFromAhwalRequest(newAhwalIncidentRequestMessage);
            LOGGER.info("Unknown Party profile object prepared successfully..");
        }

        return partyDto;
    }

    private void saveCaseAttachements(AhwalCaseRequestMessage newAhwalIncidentRequestMessage,CreateCaseResult createCaseResult, List<PartyKey> partyKeyList, String createdBy, String firNumber) throws BusinessException{

        if(null != newAhwalIncidentRequestMessage.getAttachments() && null != newAhwalIncidentRequestMessage.getAttachments().getAttachment() &&
                newAhwalIncidentRequestMessage.getAttachments().getAttachment().size() > 0) {

            LOGGER.info("Found attachments with the ahwal incident.");

            List<AttachedDocumentDto> documents = prepareAhwalCaseAttachments(newAhwalIncidentRequestMessage, createdBy);

            LOGGER.info("Updating case attachments to store the case and attachment mapping");

            UpdateCaseCommand caseUpdateCommand = new UpdateCaseCommand.Builder(createCaseResult.getCaseKey(), partyKeyList)
                    .withAttachmentList(getActiveAttachments(documents)).withFirNumber(firNumber).withCreatedBy(createdBy).build();

            caseApplicationService.update(caseUpdateCommand);

            LOGGER.info("Case attachment mapping done successfully.");
        }

    }

    private ArrestReason getArrestReason(AhwalCaseRequestMessage newAhwalIncidentRequestMessage)throws BusinessException{

        Long arrestReasonId = newAhwalIncidentRequestMessage.getArrestReasonId();
        if(null == arrestReasonId){
            throw new BusinessException("Arrest Reason Id cannot be blank");
        }else{
            // confirm if this is a valid lookup value. If no, this method will throw an error and the corresponding error message will be sent to vision.
            try{
                Entry arrestLookupEntry = lookupService.getLookupEntry(LookupDefinition.ARREST_REASON, LocaleContextHolder.getLocale(), arrestReasonId).get();
            }catch(BusinessException ex){
                LOGGER.info("Received Exception",ex);
                throw new BusinessException("No lookup value found for arrest reason: "+ newAhwalIncidentRequestMessage.getShiftId());
            }

        }
        ArrestReason arrestReason = new ArrestReason(arrestReasonId);
        return arrestReason;
    }

    private Entry getEmployeeShift(AhwalCaseRequestMessage newAhwalIncidentRequestMessage)throws BusinessException{
        Entry shift = null;
        if(null != newAhwalIncidentRequestMessage.getShiftId()){
            try{
                shift = lookupService.getLookupEntry(LookupDefinition.SHIFT, LocaleContextHolder.getLocale(), newAhwalIncidentRequestMessage.getShiftId()).get();
            }catch(BusinessException ex){
                LOGGER.info("received Exception ",ex);
                throw new BusinessException("No lookup value found for shift id: "+ newAhwalIncidentRequestMessage.getShiftId());
            }
        }
        return shift;
    }

    private Entry getEmployeeUnit(AhwalCaseRequestMessage newAhwalIncidentRequestMessage)throws BusinessException{

        Entry unit = null;
        Long unitId = newAhwalIncidentRequestMessage.getUnitid();

        if(null != unitId && unitId != 0L){
            try{
                unit = lookupService.getLookupEntry(LookupDefinition.SECTION_UNITS, LocaleContextHolder.getLocale(), newAhwalIncidentRequestMessage.getUnitid()).get();
            }catch(BusinessException ex){
                LOGGER.info("Received Exception",ex);
                throw new BusinessException("No lookup value found for unit id: "+ newAhwalIncidentRequestMessage.getUnitid());
            }
        }
        return unit;
    }

    private Entry getArrestLocation(AhwalCaseRequestMessage newAhwalIncidentRequestMessage)throws BusinessException{
        Entry arrestLocation = null;
        if(null == newAhwalIncidentRequestMessage.getArrestLocationId()){
            throw new BusinessException("Arrest location cannot be empty");
        }else{
            try{
                arrestLocation = lookupService.getLookupEntry(LookupDefinition.ARREST_LOCATION_LK, LocaleContextHolder.getLocale(), newAhwalIncidentRequestMessage.getArrestLocationId()).get();
            }catch(BusinessException ex){
                LOGGER.info("Received Exception",ex);
                throw new BusinessException("No lookup value found for the arrest location: " + newAhwalIncidentRequestMessage.getArrestLocationId());
            }
        }
        return arrestLocation;
    }

    private List<ArrestPartyDto> prepareArrestPartyList(CreatePartyResult result, String createdBy){
        LOGGER.info("Preparing the arrest party object");
        List<ArrestPartyDto> arrestPartyList = new LinkedList<>();
        ArrestPartyDto arrestPartyDto = new ArrestPartyDto();
        arrestPartyDto.setPartyId(result.getPartyKey().id());
        arrestPartyDto.setPartyType(lookupService.getLookupEntry(LookupDefinition.PARTY_TYPE, LocaleContextHolder.getLocale(), PartyTypeEnum.ACCUSED.getId()).get());
        arrestPartyDto.setIsDeleted(0L);
        arrestPartyDto.setCreatedBy(createdBy);
        arrestPartyList.add(arrestPartyDto);
        return arrestPartyList;
    }

    private List<CasePartyDto> prepareCasePartyList(CreatePartyResult result, PartyDto partyDto, String createdBy){
        LOGGER.info("Preparing the case party object");
        List<CasePartyDto> casePartyDtoList = new LinkedList<>();
        CasePartyDto casePartyDto = new CasePartyDto();
        casePartyDto.setPartyId(result.getPartyKey().id());
        casePartyDto.setPartyType(lookupService.getLookupEntry(LookupDefinition.PARTY_TYPE, LocaleContextHolder.getLocale(), PartyTypeEnum.ACCUSED.getId()).get());
        casePartyDto.setIsDeleted(0L);
        casePartyDto.setCreatedBy(createdBy);
        casePartyDto.setChargeDtoList(partyDto.getListofCharges());
        casePartyDtoList.add(casePartyDto);
        return casePartyDtoList;
    }

    private Date getArrestDateTime(AhwalCaseRequestMessage newAhwalIncidentRequestMessage) throws BusinessException {
        Date arrestDateTime;
        if(null == newAhwalIncidentRequestMessage.getArrestDatetime() || null ==newAhwalIncidentRequestMessage.getArrestDatetime().toGregorianCalendar()){
            throw new BusinessException("Arrest DateTime cannot be empty");
        }else{
            arrestDateTime = newAhwalIncidentRequestMessage.getArrestDatetime().toGregorianCalendar().getTime();
        }
        return arrestDateTime;
    }

    private CreatePartyResult saveAhwalPartyDetails(PartyDto partyDto) throws BusinessException {

        if (Checks.isNotNull(partyDto.getPhoto())) {
            LOGGER.info("Persisting party photo in database..");
            partyService.savePartyPhoto(partyDto);
            LOGGER.info("party photo persisted successfully.");
        }

        LOGGER.info("Persisting Party Details in Database..");
        CreatePartyCommand partyCommand = new CreatePartyCommand(partyDto);
        CreatePartyResult result = partyService.createParty(partyCommand);
        LOGGER.info("Party details persisted in database successfully. Party Id : "+ result.getPartyKey().id());

        return result;
    }

    private CreateArrestReportResult createAhwalArrestReport(
        AhwalCaseRequestMessage newAhwalIncidentRequestMessage, ArrestReason arrestReason,
        Entry arrestLocation, Date arrestDateTime,
        List<ArrestPartyDto> arrestPartyList, List<ArrestTeamDto> arrestTeamList, Entry unit,
        Entry shift, List<PartyKey> partyKeyList, String createdBy, TrackerKey trackerKey){
        LOGGER.info("Creating Arrest Report for the ahwal incident.");
        CreateArrestReportCommand command = new CreateArrestReportCommand.Builder(
                partyKeyList, arrestReason, new ArrestDescription(newAhwalIncidentRequestMessage.getArrestReport()),
                Section.AIRPORT_CONTROL, Department.BORDER_CONTROL)
                .withTerminalLocation(arrestLocation)
                .withArrestDate(arrestDateTime).withArrestPartyList(arrestPartyList).withArrestTeamList(arrestTeamList)
                .withArrestTime(DateUtils.getHHMMFromDate(arrestDateTime)).withArrestDateTime(arrestDateTime)
                .withIsCreatedByAhwal(true).withUnit(unit).withShift(shift).withCreatedBy(createdBy)
                .withTrackerKey(trackerKey)
                .build();

        CreateArrestReportResult createArrestReportResult = arrestReportApplicationService.create(command);
        LOGGER.info("Arrest Report created successfully..");
        return createArrestReportResult;
    }

    private CreateCaseResult createAhwalCase(AhwalCaseRequestMessage newAhwalIncidentRequestMessage,
                                             CreateArrestReportResult createArrestReportResult,
                                             Entry unit,
                                             List<CasePartyDto> casePartyDtoList,
                                             ArrestReason arrestReason, String firNumber,
                                             String createdBy, TrackerKey trackerKey){
        LOGGER.info("Creating Case for the ahwal incident.");
        CreateCaseCommand createCaseCommand = new CreateCaseCommand.Builder(
                createArrestReportResult.getArrestReportKey(), Section.AIRPORT_CONTROL, Department.BORDER_CONTROL, Section.AIRPORT_CONTROL).
                withUnit(unit).withCasePartyList(casePartyDtoList).withArrestReason(arrestReason)
                .withVisionCaseNumber(String.valueOf(newAhwalIncidentRequestMessage.getVisionReferenceNumber())).withFirNumber(firNumber).withCreatedBy(createdBy)
                .withTrackerKey(trackerKey)
            .build();

        CreateCaseResult createCaseResult = caseApplicationService.createCase(createCaseCommand);

        return createCaseResult;

    }


    public void sendSuccessAcknowledgement(AhwalCaseRequestMessage newAhwalIncidentRequestMessage, String fisReferenceNumber) {
        ahwalIncidentMQClient.sendSuccessAcknowledgement(newAhwalIncidentRequestMessage,fisReferenceNumber);
    }

    public void sendFailureAcknowledgement(AhwalCaseRequestMessage newAhwalIncidentRequestMessage, String message) {
        ahwalIncidentMQClient.sendFailureAcknowledgement(newAhwalIncidentRequestMessage,message);
    }

    public void sendDeportResultToVision(String visionReferenceNumber, String fisReferenceNumber){
        ahwalIncidentMQClient.sendDeportResultToVision(visionReferenceNumber, fisReferenceNumber);
    }

}
