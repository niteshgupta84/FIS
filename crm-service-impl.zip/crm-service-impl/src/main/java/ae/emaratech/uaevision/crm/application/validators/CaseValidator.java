package ae.emaratech.uaevision.crm.application.validators;

import ae.emaratech.uaevision.crm.application.CaseNotificationCode;
import ae.emaratech.uaevision.crm.application.CreateCaseCommand;
import ae.emaratech.uaevision.crm.application.UpdateCaseCommand;
import ae.emaratech.uaevision.crm.application.dto.CaseAssociationDto;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.util.Checks;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by Nitesh.Gupta on 7/3/2016.
 */
@Component
public class CaseValidator {
    @Autowired
    private NotificationBus notificationBus;

    public boolean checkDuplicateAssociation(List<CaseAssociationDto> associationDtoList,
                                             Long caseId) {
        boolean isAlreadyAssociated = false;
        for (CaseAssociationDto associationDto : associationDtoList) {
            if (associationDto.getLinkedCaseId() == caseId.longValue()) {
                isAlreadyAssociated = true;
            }
        }
        return isAlreadyAssociated;
    }

    public void validate(CreateCaseCommand command) {
        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        if (Checks.isNull(command.getArrestReason())) {
            notificationBuilder.add(CaseNotificationCode.ARREST_REASON_MANDATORY);
        }
        if (CollectionUtils.isEmpty(command.getCasePartyDtoList())) {
            notificationBuilder.add(CaseNotificationCode.PARTY_DETAIL_MISSING);
        }
        if (Checks.isNull(command.getTransferredFrom()) || Checks.isNotValidLookUpId(command.getTransferredFrom().getId())) {
            notificationBuilder.add(CaseNotificationCode.TRANSFERRED_FROM_MANDATORY);
        }
        if (notificationBuilder.hasNotifications()) {
            notificationBus.send(notificationBuilder);
        }
    }
    public void validate(UpdateCaseCommand command) {
        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        if (Checks.isNull(command.getArrestReason())) {
            notificationBuilder.add(CaseNotificationCode.ARREST_REASON_MANDATORY);
        }

        if (CollectionUtils.isEmpty(command.getCasePartyDtoList())) {
            notificationBuilder.add(CaseNotificationCode.PARTY_DETAIL_MISSING);
        }
        if (Checks.isNull(command.getTransferredFromId()) || Checks.isNotValidLookUpId(command.getTransferredFromId().getId())) {
            notificationBuilder.add(CaseNotificationCode.TRANSFERRED_FROM_MANDATORY);
        }
        if (notificationBuilder.hasNotifications()) {
            notificationBus.send(notificationBuilder);
        }
    }
}
