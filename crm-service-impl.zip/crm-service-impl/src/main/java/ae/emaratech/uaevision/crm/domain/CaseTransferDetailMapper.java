package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.application.dto.CaseTransferDetailDto;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Mapper class to map Entity to Dto and vice versa
 * Created by Nitesh.Gupta on 3/29/2017.
 */
@Component
public class CaseTransferDetailMapper {
    @Autowired
    private LookupService lookupService;

    /**
     * Method which copies the relevant state information from CaseTransferDetail  entity to dto.
     *
     * @param caseTransferDetail the case transfer detail entity bean.
     * @return case Transfer Dto object
     */
    public CaseTransferDetailDto mapToDto(CaseTransferDetail caseTransferDetail) {

        if (caseTransferDetail != null) {
            CaseTransferDetailDto caseTransferDetailDto = new CaseTransferDetailDto();
            caseTransferDetailDto.setId(caseTransferDetail.getId());
            caseTransferDetailDto.setCreatedDate(caseTransferDetail.getCreatedDate());
            caseTransferDetailDto.setCreatedBy(caseTransferDetail.getCreatedBy());
            caseTransferDetailDto.setVersion(caseTransferDetail.getVersion());
            caseTransferDetailDto.setCaseId(caseTransferDetail.getCaseId());
            caseTransferDetailDto.setTransferredCaseId(caseTransferDetail.getTransferredCaseId());
            if (!Checks.isNotValidLookUpId(caseTransferDetail.getTransferredDeptId())) {
                caseTransferDetailDto.setTransferredDeptId(lookupService.getLookupEntry(
                        LookupDefinition.DEPARTMENT,
                        LocaleContextHolder
                                .getLocale(),
                        caseTransferDetail.getTransferredDeptId()).get());
            }
            if (!Checks.isNotValidLookUpId(caseTransferDetail.getTransferredSectionId())) {
                caseTransferDetailDto.setTransferredSectionId(lookupService.getLookupEntry(
                        LookupDefinition.SECTION,
                        LocaleContextHolder
                                .getLocale(),
                        caseTransferDetail.getTransferredSectionId()).get());
            }
            if (!Checks.isNotValidLookUpId(caseTransferDetail.getTransferStatus())) {
                caseTransferDetailDto.setTransferStatus(lookupService.getLookupEntry(
                        LookupDefinition.CASE_STATUS,
                        LocaleContextHolder
                                .getLocale(),
                        caseTransferDetail.getTransferStatus()).get());
            }
            caseTransferDetailDto.setReceivedBy(caseTransferDetail.getReceivedBy());
            return caseTransferDetailDto;
        }
        return null;
    }

    /**
     * Mapping Case Transfer Detail object set into List
     *
     * @param caseEntities  CaseTransferDetail
     * @return Map of CaseTransferDto
     */
    public Map mapEntityToDTOList(List<CaseTransferDetail> caseEntities) {
        Map<Long, CaseTransferDetailDto> caseTransferDetailDtoMap = new LinkedHashMap<>();
        long seqNo = 0;
        for (CaseTransferDetail caseEntity : caseEntities) {
            seqNo = seqNo + 1;
            CaseTransferDetailDto caseDto = mapToDto(caseEntity);
            caseTransferDetailDtoMap.put(caseEntity.getId(), caseDto);
        }
        return caseTransferDetailDtoMap;
    }
}
