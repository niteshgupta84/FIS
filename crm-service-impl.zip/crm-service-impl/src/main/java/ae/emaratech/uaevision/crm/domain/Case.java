package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.arrest.domain.ArrestReason;
import ae.emaratech.uaevision.crm.application.utils.CaseConstants;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.entity.AbstractEntityBase;
import ae.emaratech.uaevision.fis.common.key.*;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.party.application.ModuleTypes;
import ae.emaratech.uaevision.lookup.service.annotation.LookupField;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.FetchProfile;

import javax.persistence.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Business object representing the Case domain. The state of the object provides the contextual
 * data for the domain and serves as the entity bean for persistence.
 *
 * @author Nitesh.Gupta
 */
@Entity
@Table(name = "CASE")
@FetchProfile(name = CaseConstants.CASE_DB_PROFILE, fetchOverrides = {
        @FetchProfile.FetchOverride(entity = Case.class, association = "parties", mode = FetchMode.JOIN),
        @FetchProfile.FetchOverride(entity = Case.class, association = "notes", mode = FetchMode.JOIN)
        ,@FetchProfile.FetchOverride(entity = Case.class, association = "attachments", mode = FetchMode.JOIN)
        ,@FetchProfile.FetchOverride(entity = Case.class, association = "caseAssociations", mode = FetchMode.JOIN)
        ,@FetchProfile.FetchOverride(entity = Case.class, association = "documentInspections", mode = FetchMode.JOIN)
})
public class Case extends AbstractEntityBase{

    @Column(name = "ARREST_REPORT_ID")
    Long arrestId;

    @Embedded
    private Owner owner;

    @Column(name = "REPORT_YEAR", nullable = false)
    private Long year;

    @LookupField(LookupDefinition.ARREST_STATUS)
    @Column(name = "STATUS_ID", nullable = false)
    private Long statusId;

    @LookupField(LookupDefinition.ARREST_REASON)
    @Column(name = "ARREST_REASON_ID", nullable = false, insertable = true)
    private Long arrestReasonId;

    @Column(name = "TRANSFERRED_FROM_DEPT_ID", nullable = false)
    private Long transferredFromDeptId;

    @Column(name = "ASSIGNED_USER", nullable = false)
    private String assignedUser;

    @Column(name = "MANUAL_TRANSFER_TO_DEPT", nullable = false)
    private Long manualTransferDeptId;

    @Column(name = "LATEST_ASSIGNED_SECTION_ID", nullable = false)
    private Long latestSection;
    @Column(name = "FIR_NO", nullable = false)
    private String firNo;
    @Column(name = "VISION_CASE_NUMBER", nullable = false)
    private String visionCaseNumber;

    @Column(name = "TRACKER_ID", nullable = false)
    private Long trackerId;

    @Column(name = "CASE_NUMBER", nullable = false)
    private String caseNumber;

    @Column(name = "NON_CRM_SECTION_ID", nullable = true)
    private Long nonCRMSectionId;

    @OneToMany(mappedBy = "caseReference", fetch = FetchType.LAZY, orphanRemoval = true, cascade = CascadeType.ALL)
    @OrderBy("createdDate DESC")
    private Set<CaseNote> notes = new HashSet<>();

    @OneToMany(mappedBy = "caseReference", fetch = FetchType.EAGER, orphanRemoval = true, cascade = CascadeType.ALL)
    @OrderBy("partyId ASC")
    private Set<CaseParty> parties = new LinkedHashSet<>();

    @OneToMany(mappedBy = "caseReference", fetch = FetchType.LAZY, orphanRemoval = true, cascade = CascadeType.ALL)
    @OrderBy("createdDate DESC")
    private Set<CaseAttachment> attachments = new HashSet<>();

    @OneToMany(mappedBy = "caseReference", fetch = FetchType.LAZY, orphanRemoval = true, cascade = CascadeType.ALL)
    @OrderBy("createdDate DESC")
    private Set<CaseAssociation> caseAssociations = new HashSet<>();

    @OneToMany(mappedBy = "caseReference", fetch = FetchType.LAZY, orphanRemoval = true, cascade = CascadeType.ALL)
    @OrderBy("createdDate DESC")
    private Set<DocumentInspectionResult> documentInspections = new HashSet<>();

    private Case() {

    }

    public Case(CaseKey caseKey, ArrestReportKey arrestReportKey, Owner owner,
                Set<CaseParty> parties, Section latestAssignedSection, Entry transferredFrom,
                ArrestReason arrestReason, String visionCaseNumber, String createdBy,
                TrackerKey trackerKey, String caseNumber) {

        this(caseKey, arrestReportKey,owner,parties,latestAssignedSection,transferredFrom,arrestReason,visionCaseNumber,createdBy,
                trackerKey,caseNumber,null);
    }

    public Case(CaseKey caseKey, ArrestReportKey arrestReportKey, Owner owner,
                Set<CaseParty> parties, Section latestAssignedSection, Entry transferredFrom,
                ArrestReason arrestReason, String visionCaseNumber, String createdBy,
                TrackerKey trackerKey, String caseNumber, Section nonCRMSection) {

        this.setId(caseKey.id());
        if (arrestReportKey != null)
            this.arrestId = arrestReportKey.id();
        this.owner = owner;
        this.statusId = CaseStatus.OPENED.id();
        this.latestSection = latestAssignedSection.id();
        this.arrestReasonId = arrestReason.id();
        if (Checks.isNotNull(transferredFrom) && !Checks.isNotValidLookUpId(transferredFrom.getId())) {
            this.transferredFromDeptId = transferredFrom.getId();
        }
        this.visionCaseNumber = visionCaseNumber;
        setCreatedBy(createdBy);
        this.trackerId = trackerKey.id();
        this.caseNumber = caseNumber;

        if(null != nonCRMSection){
            this.nonCRMSectionId = nonCRMSection.id();
        }

    }

    protected Long getTrackerId() {
        return trackerId;
    }

    protected Long getArrestId() {
        return arrestId;
    }

    protected Owner getOwner() {
        return owner;
    }

    protected Long getYear() {
        return year;
    }

    public void setYear(Long year) {
        this.year = year;
    }

    protected Long getStatusId() {
        return statusId;
    }

    public Set<CaseNote> getNotes() {
        return notes;
    }

    public Set<CaseParty> getParties() {
        return parties;
    }

    protected Long getArrestReasonId() {
        return arrestReasonId;
    }

    protected Long getTransferredFromDeptId() {
        return transferredFromDeptId;
    }

    protected String getAssignedUser() {
        return assignedUser;
    }

    public Set<CaseAttachment> getAttachments() {
        return attachments;
    }

    public Set<CaseAssociation> getCaseAssociations() {
        return caseAssociations;
    }

    protected Long getLatestSection() {
        return latestSection;
    }

    public Set<DocumentInspectionResult> getDocumentInspections() {
        return documentInspections;
    }

    protected String getFirNo() {
        return firNo;
    }

    protected Long getManualTransferDeptId() {
        return manualTransferDeptId;
    }

    protected String getVisionCaseNumber() {
        return visionCaseNumber;
    }

    protected String getCaseNumber() {
        return caseNumber;
    }

    protected Long getNonCRMSectionId() {
        return nonCRMSectionId;
    }

    public CaseCreatedEvent create(ArrestReportKey arrestReportKey, Set<CaseParty> caseParties,
                                   String firNumber) {

        this.year = (long) Calendar.getInstance().get(Calendar.YEAR);
        this.firNo = firNumber;
        updateCaseParties(caseParties);

        return new CaseCreatedEvent.Builder(
            new EventContext(ModuleTypes.CRM, trackerId), new CaseKey(super.id()),
            new ArrestReportKey(this.arrestId))
            .withArrestReason(this.arrestReasonId)
            .withLatestSection(this.latestSection)
            .withTransferredFrom(this.transferredFromDeptId)
            .withCaseStatus(this.statusId)
            .withVisionCaseNumber(this.visionCaseNumber)
            .withFirNumber(this.firNo)
            .withCaseNumber(this.caseNumber)
            .build();
    }

    /**
     * Review Method for sending arrest to supervisor.
     *
     * @param reviewComments the comments for the supervisor before reviewing the case.
     * @return the case sent for review event
     */
    public CaseReviewedEvent review(String reviewComments) {

        this.statusId = CaseStatus.PENDING_DECISION.id();

        return new CaseReviewedEvent.Builder(
            new EventContext(ModuleTypes.CRM, trackerId),
            new CaseKey(this.id()), new ArrestReportKey(this.arrestId))
            .withCaseStatus(this.statusId)
            .withReviewComments(reviewComments)
            .build();

    }

    /**
     * Review Method for sending arrest to supervisor.
     *
     * @param rejectComments the comments provided by the supervisor while rejecting the case
     *                       submitted for review.
     * @return the case review rejected event
     */
    public CaseRejectedEvent reject(String rejectComments) {

        this.statusId = CaseStatus.OPENED.id();

        return new CaseRejectedEvent.Builder(
            new EventContext(ModuleTypes.CRM, trackerId),
            new CaseKey(this.id()), new ArrestReportKey(this.arrestId))
            .withCaseStatus(this.statusId)
            .withRejectComments(rejectComments)
                .build();

    }

    /**
     * Review Method for sending arrest to supervisor.
     *
     * @param approveComments the approval comments from supervisor after reviewing the arrest
     *                        report.
     * @return the case review approved event.
     */
    public CaseApprovedEvent approve(String approveComments) {

        this.statusId = CaseStatus.APPROVED.id();

        return new CaseApprovedEvent.Builder(
            new EventContext(ModuleTypes.CRM, trackerId),
            new CaseKey(this.id()), new ArrestReportKey(this.arrestId))
            .withCaseStatus(this.statusId)
            .withApproveComments(approveComments)
                .build();
    }


    /**
     * Method to manual transfer to other department
     *
     * @param transferComments the transfer comments
     * @param manualTransferTo the manual transfer to department id.
     * @return the case manual tranfereed event.
     */
    public CaseManualTransferEvent manualTransfer(String transferComments,
                                                  Long manualTransferTo) {

        this.statusId = CaseStatus.MANUALTRANSFERRED.id();
        this.manualTransferDeptId = manualTransferTo;

        return new CaseManualTransferEvent.Builder(
            new EventContext(ModuleTypes.CRM, trackerId),
            new CaseKey(this.id()),
            new ArrestReportKey(this.arrestId))
            .withCaseStatus(this.statusId)
            .withTransferComments(transferComments)
            .withManualTransferTo(manualTransferTo)
            .build();

    }

    /**
     * Method to manual Receive from other department
     *
     * @param receiveComments   the transfer comments
     * @param manualReceiveFrom the manual Receive from department id.
     * @return the case manual tranfereed event.
     */
    public CaseManualReceiveEvent manualReceive(String receiveComments, Entry manualReceiveFrom) {

        this.statusId = CaseStatus.MANUALRECEIVED.id();

        return new CaseManualReceiveEvent.Builder(
            new EventContext(ModuleTypes.CRM, trackerId),
            new CaseKey(this.id()), new ArrestReportKey(this.arrestId))
            .withCaseStatus(this.statusId)
            .withReceivedFrom(manualReceiveFrom.getId())
                .withReceiveComments(receiveComments)
                .build();

    }

    /**
     * Close Method for case
     *
     * @param closeComments the closing comments.
     * @return the case closed event.
     */
    public CaseClosedEvent close(String closeComments) {

        this.statusId = CaseStatus.CLOSED.id();

        return new CaseClosedEvent.Builder(
            new EventContext(ModuleTypes.CRM, trackerId),
            new CaseKey(this.id()), new ArrestReportKey(this.arrestId))
            .withCaseStatus(this.statusId)
                .withCloseComments(closeComments)
                .build();

    }

    /**
     * Method to reopen a case
     *
     * @return the  case reopened event.
     */
    public CaseReopenedEvent reopen() {

        this.statusId = CaseStatus.OPENED.id();

        return new CaseReopenedEvent.Builder(
            new EventContext(ModuleTypes.CRM, trackerId),
            new CaseKey(this.id()), new ArrestReportKey(this.arrestId))
            .withCaseStatus(this.statusId)
                .build();

    }
    public Case withLatestSection(Long sectionId){
        this.latestSection = sectionId;
        return this;
    }
    public Case withCreatedBy(String createdBy){
        setCreatedBy(createdBy);
        return this;
    }
    /**
     * Method to Case Assign
     */
    public CaseAssignedEvent assignUser(String userId) {

        this.assignedUser = userId;
        return new CaseAssignedEvent.Builder(
            new EventContext(ModuleTypes.CRM, trackerId),
            new CaseKey(this.id()))
            .withAssignedUser(this.assignedUser)
                .build();
    }

    public CaseUpdatedEvent update(Set<CaseParty> updatedCaseParties,
                                   List<AttachmentReferenceKey> updatedCaseAttachments,
                                   Set<AssociatedCaseKey> updatedCaseAssociations,
                                   Set<CaseNote> updatedCaseNotes,
                                   Entry transferredFromId, ArrestReason arrestReason,
                                   Set<DocumentInspectionResult> updatedDocumentInspections,
                                   String firNo,Long version, String createdBy, Owner owner) {

        this.setVersion(version);
        this.owner = owner;
        if (transferredFromId != null && !Checks.isNotValidLookUpId(transferredFromId.getId())) {
            this.transferredFromDeptId = transferredFromId.getId();
        }
        if (arrestReason != null) {
            this.arrestReasonId = arrestReason.id();
        }
        // Update party list
        updateCaseParties(updatedCaseParties);
        // Update attachment list
        if (CollectionUtils.isNotEmpty(updatedCaseAttachments)) {
            updateCaseAttachments(updatedCaseAttachments,createdBy);
        }
        this.firNo = firNo;
        // Update arrest notes
        if (CollectionUtils.isNotEmpty(updatedDocumentInspections)) {
            updateDocumentInspections(updatedDocumentInspections);
        }

        // Update arrest notes
        if (CollectionUtils.isNotEmpty(updatedCaseNotes)) {
            updateCaseNotes(updatedCaseNotes);
        }

        // Update association list
        if (CollectionUtils.isNotEmpty(updatedCaseAssociations)) {
            updatedCaseAssociations(updatedCaseAssociations);
        }
        return new CaseUpdatedEvent.Builder(new EventContext(ModuleTypes.CRM, trackerId),
                                            new CaseKey(id()), new ArrestReportKey(this.arrestId))
            .withArrestReason(arrestReasonId)
            .withTransferredFrom(transferredFromDeptId)
            .withFirNo(this.firNo)
            .withStatus(statusId)
            .withNotes(getNotesIdList())
            .withAttachments(getCaseAttachmentReferenceIdList())
            .withCaseAssociations(getCaseAssociationIdList())
            .build();
    }

    /**
     * Method is to Transfer the border control case to CRM for further processing.
     * @param department Department where record is being forwarded
     * @param section section where record needs to be transferred
     * @param transferComments
     * @return
     */
    public CaseTransferredToCRMEvent transferTo(Department department, Section section,
                                                String transferComments) {


        this.statusId = CaseStatus.TRANSFERRED.id();

        return new CaseTransferredToCRMEvent.Builder(
                new EventContext(ModuleTypes.CRM, trackerId), new CaseKey(this.id()),
                new ArrestReportKey(this.arrestId), department.id(), section.id())
                .withTransferComments(transferComments)
                .build();
    }

    /**
     * CaseClonedEvent for cloning Case
     * @param caseNumber
     * @param owner
     * @param caseParties
     * @param arrestReportKey
     * @return
     */
    public TransferredCaseCreatedEvent transferredCaseCreate(CaseKey oldCaseKey, TrackerKey trackerKey,
                                                             CaseKey caseKey, String caseNumber, Owner owner,
                                                             Set<CaseParty> caseParties, ArrestReportKey arrestReportKey) {
        this.statusId = CaseStatus.OPENED.id();
        this.setId(caseKey.id());
        this.caseNumber = caseNumber;
        this.owner = owner;
        this.arrestId = arrestReportKey.id();
        this.latestSection = null;
        this.parties = new HashSet<>();
        this.assignedUser = null;
        this.year = (long) Calendar.getInstance().get(Calendar.YEAR);
        updateCaseParties(caseParties);
        List<PartyKey> partyKeys = caseParties.stream().map(caseParty -> new PartyKey(caseParty.getPartyId())).collect(Collectors.toList());
        return new TransferredCaseCreatedEvent.Builder(
                new EventContext(ModuleTypes.CRM, trackerKey.id()),
                new CaseKey(caseKey.id()),caseNumber)
                .withDepartment(owner.getDepartment())
                .withSection(owner.getSection())
                .withOldCaseKey(oldCaseKey)
                .withPartyKeyList(partyKeys)
                .build();

    }
    /**
     * Method is for transfering record from one section to another
     * @param id
     * @param transferComments
     * @return
     */
    public CaseTransferredToSectionEvent transferToSection(Long id, String transferComments) {
        this.statusId = CaseStatus.FORWARD.id();
        this.latestSection = id;

        return new CaseTransferredToSectionEvent.Builder(new EventContext(ModuleTypes.CRM, trackerId),
                new CaseKey(this.id()),id).withTransferComments(transferComments).build();
    }
    /**
     * Method is for transfering record from one section to another
     * @param transferComments
     * @return
     */
    public CaseTransferredToSectionEvent transferToOriginalSection(String transferComments) {
        this.statusId = CaseStatus.OPENED.id();
        this.latestSection = this.owner.getSection();

        return new CaseTransferredToSectionEvent.Builder(new EventContext(ModuleTypes.CRM, trackerId),
                new CaseKey(this.id()),this.owner.getSection()).withTransferComments(transferComments).withCaseStatus(this.statusId).build();
    }
    private List<Long> getNotesIdList() {

        return notes.stream().filter(note -> Objects.equals(note.getIsDeleted(), 0L))
                .map(note -> note.id()).collect(Collectors.toList());
    }

    private List<Long> getCaseAttachmentReferenceIdList() {

        return attachments.stream()
                .map(attachment -> attachment.getAttachmentReferenceId())
            .collect(Collectors.toList());
    }

    private List<Long> getCaseAssociationIdList() {

        return caseAssociations.stream()
            .map(arrestAssociation -> arrestAssociation.getAssociatedCaseId())
            .collect(Collectors.toList());
    }

    private void updateCaseNotes(Set<CaseNote> updateCaseNotes) {

        for (CaseNote updatedNote : updateCaseNotes) {
            boolean isNoteExists = false;
            for (CaseNote existingNote : notes) {
                if (existingNote.id().longValue() == updatedNote.id().longValue()) {
                    isNoteExists = true;
                    existingNote.setIsDeleted(updatedNote.getIsDeleted());
                    existingNote.setNote(updatedNote.getNote());
                    break;
                }
            }
            if (!isNoteExists) {
                updatedNote.setCaseReference(this);
                notes.add(updatedNote);
            }
        }

    }

    private void updateDocumentInspections(Set<DocumentInspectionResult> updateDocumentInspection) {

        for (DocumentInspectionResult documentInspectionResult : updateDocumentInspection) {
            boolean isInspectionExists = false;
            for (DocumentInspectionResult existingInspection : documentInspections) {
                if (documentInspectionResult.getId() != null && Objects
                        .equals(existingInspection.getId(), documentInspectionResult
                                .getId())) {
                    isInspectionExists = true;
                    existingInspection.setNote(documentInspectionResult.getNote());
                    existingInspection.setDocumentTypeId(documentInspectionResult.getDocumentTypeId());
                    existingInspection
                            .setDocumentInspResultTypeId(documentInspectionResult.getDocumentInspResultTypeId());
                    break;
                }
            }
            if (!isInspectionExists) {
                documentInspectionResult.setCaseReference(this);
                documentInspections.add(documentInspectionResult);
            }
        }
        // Remove notes from arrest domain if the updatedArrestNotes doesn't contain any of the
        // existing notes.
        documentInspections
                .removeIf(existingInspection -> !updateDocumentInspection.contains(existingInspection));
    }


    private void updateCaseAttachments(List<AttachmentReferenceKey> updatedCaseAttachments, String createdBy) {

        for (AttachmentReferenceKey attachmentReferenceKey : updatedCaseAttachments) {
            boolean isAttachmentAdded = false;
            for (CaseAttachment arrestAttachment : attachments) {
                if (attachmentReferenceKey.id().longValue() == arrestAttachment.getAttachmentReferenceId()
                        .longValue()) {
                    isAttachmentAdded = true;
                    break;
                }
            }
            if (!isAttachmentAdded) {
                CaseAttachment newArrestAttachment = new CaseAttachment(attachmentReferenceKey);
                newArrestAttachment.setCaseReference(this);
                if(null != createdBy){
                    newArrestAttachment.withCreatedBy(createdBy);
                }

                attachments.add(newArrestAttachment);
            }
        }
        // Remove attachments from arrest domain if the updatedArrestAttachments doesn't contain any of
        // the existing attachment identifiers.
        attachments.removeIf(
                existingAttachment -> !updatedCaseAttachments
                        .contains(new AttachmentReferenceKey(existingAttachment.getAttachmentReferenceId())));

    }

    private void updateCaseParties(Set<CaseParty> updatedCaseParties) {

        if(CollectionUtils.isNotEmpty(updatedCaseParties)){
            for (CaseParty updatedCaseParty : updatedCaseParties) {
                boolean isPartyAdded = false;
                for (CaseParty caseParty : parties) {
                    if (updatedCaseParty.getPartyId().longValue() == caseParty.getPartyId().longValue()) {
                        caseParty.setPartyTypeId(updatedCaseParty.getPartyTypeId());
                        caseParty.setIsDeleted(updatedCaseParty.getIsDeleted());
                        isPartyAdded = true;
                        Set<CasePartyCharge> existingCharges = caseParty.getCasePartyCharges();
                        for (CasePartyCharge updatedCasePartyCharge : updatedCaseParty.getCasePartyCharges()) {
                            boolean isChargeAdded = false;
                            for (CasePartyCharge existingCharge : existingCharges) {
                                if (Objects.equals(updatedCasePartyCharge.id(), existingCharge.id())) {
                                    existingCharge.setIsDeleted(updatedCasePartyCharge.getIsDeleted());
                                    isChargeAdded = true;
                                    break;
                                }
                            }
                            if (!isChargeAdded) {
                                updatedCasePartyCharge.setCasePartyReference(caseParty);
                                existingCharges.add(updatedCasePartyCharge);
                            }
                        }

                        break;
                    }
                }
                if (!isPartyAdded) {
                    updatedCaseParty.setCaseReference(this);
                    parties.add(updatedCaseParty);
                }
            }
        }

    }

    private void updatedCaseAssociations(
            Set<AssociatedCaseKey> updatedCaseAssociations) {

        for (AssociatedCaseKey associatedCaseKey : updatedCaseAssociations) {
            boolean isArrestAssociated = false;
            for (CaseAssociation caseAssociation : caseAssociations) {
                if (associatedCaseKey.id().longValue() == caseAssociation
                        .getAssociatedCaseId().longValue()) {
                    isArrestAssociated = true;
                    break;
                }
            }
            if (!isArrestAssociated) {
                CaseAssociation newArrestAssociation = new CaseAssociation(associatedCaseKey);
                newArrestAssociation.setCaseReference(this);
                caseAssociations.add(newArrestAssociation);
            }
        }
        // Remove associations from arrest domain if the updatedArrestAssociations doesn't contain any
        // of the existing associated arrest report identifiers.
        caseAssociations.removeIf(
                existingAssociation ->
                        !updatedCaseAssociations.contains(
                                new AssociatedCaseKey(existingAssociation.getAssociatedCaseId())));

    }


}
