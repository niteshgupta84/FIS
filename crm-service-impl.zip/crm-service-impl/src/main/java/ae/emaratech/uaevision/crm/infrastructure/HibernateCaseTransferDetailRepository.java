package ae.emaratech.uaevision.crm.infrastructure;

import ae.emaratech.uaevision.crm.domain.CaseTransferDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;

/**
 * Created by Nitesh.Gupta on 3/29/2017.
 */
public interface HibernateCaseTransferDetailRepository extends JpaRepository<CaseTransferDetail, Long>,
        QueryDslPredicateExecutor<CaseTransferDetail> {

}

