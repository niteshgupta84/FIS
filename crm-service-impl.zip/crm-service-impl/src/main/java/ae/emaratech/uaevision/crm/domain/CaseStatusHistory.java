package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.entitylistener.Creatable;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedByListener;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedDateListener;
import ae.emaratech.uaevision.fis.common.key.CaseKey;

import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the CASE_STATUS_HISTORY database table.
 */
@Entity
@EntityListeners({
        CreatedDateListener.class,
        CreatedByListener.class
})
@Table(name = "CASE_STATUS_HISTORY")
public class CaseStatusHistory implements Creatable {

    private static final Long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "SEQ_CASE_STATUS_HIST_ID_GENERATOR", sequenceName = "SEQ_CASE_STATUS_HIST", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_CASE_STATUS_HIST_ID_GENERATOR")
    @Column(name = "ID", unique = true, nullable = false)
    private Long id;

    @Column(name = "CASE_ID", nullable = false)
    private Long caseId;

    @Column(name = "CREATED_BY", length = 30, nullable = false)
    private String createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE", nullable = false)
    private Date createdDate;

    @Column(name = "CASE_STATUS_ID", nullable = false)
    private Long caseStatusId;


    private CaseStatusHistory() {

    }

    public CaseStatusHistory(CaseKey caseKey, Long statusId) {

        this.caseStatusId = statusId;
        this.caseId = caseKey.id();
    }

    private CaseStatusHistory(Builder builder) {
        this.caseStatusId = builder.caseStatusId;
        this.caseId = builder.caseId;

    }

    public Long getCaseId() {
        return caseId;
    }

    public Long getCaseStatusId() {
        return caseStatusId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    @Override
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Long getId() {
        return id;
    }


    public static class Builder {

        private Long caseStatusId;
        private Long caseId;

        public Builder(Long caseId) {
            this.caseId = caseId;
        }

        public Builder withStatusId(Long statusId) {
            this.caseStatusId = statusId;
            return this;
        }

        public CaseStatusHistory build() {
            return new CaseStatusHistory(this);
        }

    }
}
