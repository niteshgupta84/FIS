package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.entitylistener.*;
import ae.emaratech.uaevision.lookup.service.annotation.LookupField;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by Khan.Ahmad on 5/3/2016.
 */
@Entity
@EntityListeners({
        CreatedDateListener.class,
        ModifiedDateListener.class,
        CreatedByListener.class,
        ModifiedByListener.class
})
@Table(name = "DOCUMENT_INSPECTION_RESULT")
public class DocumentInspectionResult implements Serializable, Creatable, Updatable {

    private static final Long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "DOC_INSPEC_RES_ID_GENERATOR", sequenceName = "SEQ_DOC_INSPECTION_RESULT", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOC_INSPEC_RES_ID_GENERATOR")
    @Column(name = "ID", unique = true, nullable = false, precision = 22, scale = 0)
    private Long id;

    @Column(name = "NOTE", length = 1000, nullable = false)
    private String note;

    @Column(name = "CREATED_BY", length = 30, nullable = false)
    private String createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE", nullable = false)
    private Date createdDate;

    @Column(name = "MODIFIED_BY", length = 30, nullable = false)
    private String modifiedBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFIED_DATE", nullable = false)
    private Date modifiedDate;

    @Version
    private Long version;

    //bi-directional many-to-one association to Deportation
    @ManyToOne
    @JoinColumn(name = "CASE_ID", nullable = false)
    private Case caseReference;


    @LookupField(LookupDefinition.ID_DOC_TYPE)
    @Column(name = "DOCUMENT_TYPE_ID", nullable = false)
    private Long documentTypeId;

    @LookupField(LookupDefinition.DOC_INSPECTION_RESULT)
    @Column(name = "DOCUMENT_RESULT_ID", nullable = false)
    private Long documentInspResultTypeId;

    public DocumentInspectionResult(Long documentTypeId, Long documentInspResultTypeId, String note) {
        this.documentTypeId = documentTypeId;
        this.documentInspResultTypeId = documentInspResultTypeId;
        this.note = note;

    }


    public DocumentInspectionResult() {
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    @Override
    public String getCreatedBy() {
        return this.createdBy;
    }
    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return this.createdDate;
    }
    @Override
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getModifiedBy() {
        return this.modifiedBy;
    }
    @Override
    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Date getModifiedDate() {
        return this.modifiedDate;
    }
    @Override
    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getNote() {
        return this.note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Long getVersion() {
        return this.version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public Long getDocumentTypeId() {
        return documentTypeId;
    }

    public void setDocumentTypeId(Long documentTypeId) {
        this.documentTypeId = documentTypeId;
    }

    public Long getDocumentInspResultTypeId() {
        return documentInspResultTypeId;
    }

    public void setDocumentInspResultTypeId(Long documentInspResultTypeId) {
        this.documentInspResultTypeId = documentInspResultTypeId;
    }

    public Case getCaseReference() {
        return caseReference;
    }

    public void setCaseReference(Case caseReference) {
        this.caseReference = caseReference;
    }

    /**
     * Overriding Equals method to check if Document Inspection Ids are same or not.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof DocumentInspectionResult)) {
            return false;
        }

        DocumentInspectionResult that = (DocumentInspectionResult) o;

        if (!id.equals(that.id)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
