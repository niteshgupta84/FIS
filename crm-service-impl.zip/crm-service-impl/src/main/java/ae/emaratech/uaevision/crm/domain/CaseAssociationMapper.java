package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.application.dto.CaseAssociationDto;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@Component
public class CaseAssociationMapper {


    @Autowired
    private UserService userService;

    /**
     * Mapping Dto from Entity
     */
    public CaseAssociationDto mapCaseAssociationDto(CaseAssociation caseAssociation) {

        CaseAssociationDto caseAssociationDto = new CaseAssociationDto();
        caseAssociationDto.setCreatedDate(caseAssociation.getCreatedDate());
        caseAssociationDto.setCreatedBy(userService.getUserFirstNameByUserLogin(caseAssociation.getCreatedBy()));
        caseAssociationDto.setId(caseAssociation.id());
        caseAssociationDto.setAssociationId(caseAssociation.id());
        caseAssociationDto.setCaseId(caseAssociation.getCaseReference().id());
        caseAssociationDto.setLinkedCaseId(caseAssociation.getAssociatedCaseId());
        return caseAssociationDto;
    }

    /**
     * Mapping arrest association dto list
     */
    public List<CaseAssociationDto> mapCaseAssociationDtoList(
            Set<CaseAssociation> caseAssociationSet) {
        List<CaseAssociationDto> caseAssociationDtoList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(caseAssociationSet)) {
            caseAssociationDtoList.addAll(caseAssociationSet.stream().map(this::mapCaseAssociationDto)
                    .collect(Collectors.toList()));
        }
        return caseAssociationDtoList;
    }

}
