package ae.emaratech.uaevision.crm.ahwal.service;

import ae.emaratech.uaevision.crm.ahwal.remote.AhwalCaseRequestMessage;

import ae.emaratech.uaevision.fis.gateway.message.Client.GenericMessageProducerClient;
import ae.emaratech.uaevision.fis.gateway.message.response.NewAhwalIncidentAcknowledgementMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.jms.Queue;
import javax.xml.bind.JAXBException;

/**
 * Created by Deep.Gupta on 16-Jun-16.
 */
@Component
public class AhwalIncidentMQClient {

    private static final Logger LOGGER = LogManager.getLogger();

    @Autowired
    GenericMessageProducerClient genericMessageProducerClient;

    /*@Autowired
    Queue ahwalIncidentResponseQueue;*/

    public void sendSuccessAcknowledgement(AhwalCaseRequestMessage newAhwalIncidentRequestMessage, String fisReferenceNumber) {

        NewAhwalIncidentAcknowledgementMessage newAhwalIncidentAcknowledgementMessage = new NewAhwalIncidentAcknowledgementMessage("0", "Success", Long.toString(newAhwalIncidentRequestMessage.getVisionReferenceNumber()), fisReferenceNumber);


        try {

            LOGGER.info("Preparing Response XML to be sent to Vision for Ahwal Incident request.");

            String responseXML = newAhwalIncidentAcknowledgementMessage.getXML();

            LOGGER.info("Response XML Prepared Successfully");

            deliverMessageToVision(responseXML);

        } catch (JAXBException ex) {

            LOGGER.error("Unable to send Acknowledgement Message to Vision for Ahwal Incident. Reason: " + ex);
        }

    }


    public void sendFailureAcknowledgement(AhwalCaseRequestMessage newAhwalIncidentRequestMessage, String message) {

        NewAhwalIncidentAcknowledgementMessage newAhwalIncidentAcknowledgementMessage = null;


        if (null != newAhwalIncidentRequestMessage) {
            newAhwalIncidentAcknowledgementMessage = new NewAhwalIncidentAcknowledgementMessage("1", message, Long.toString(newAhwalIncidentRequestMessage.getVisionReferenceNumber()), "");
        } else {
            newAhwalIncidentAcknowledgementMessage = new NewAhwalIncidentAcknowledgementMessage("1", message, "", "");
        }

        try {

            LOGGER.info("Preparing Response XML to be sent to Vision for Ahwal Incident request.");

            String responseXML = newAhwalIncidentAcknowledgementMessage.getXML();

            LOGGER.info("Response XML Prepared Successfully");

            deliverMessageToVision(responseXML);

        } catch (Exception ex) {

            LOGGER.error("Unable to send Acknowledgement Message to Vision for Ahwal Incident. Reason: " + ex);
        }

    }

    public void sendDeportResultToVision(String visionReferenceNumber, String fisReferenceNumber) {


        NewAhwalIncidentAcknowledgementMessage newAhwalIncidentAcknowledgementMessage = new NewAhwalIncidentAcknowledgementMessage(visionReferenceNumber, fisReferenceNumber, "DEPORT");


        try {
            LOGGER.info("Preparing Response XML to be sent to Vision for Ahwal Incident Result.");

            String responseXML = newAhwalIncidentAcknowledgementMessage.getXML();

            LOGGER.info("Response XML Prepared Successfully");

            deliverMessageToVision(responseXML);

        } catch (Exception ex) {
            LOGGER.error("Unable to send Deportation Result to Vision for Ahwal Incident. Reason: " + ex);
        }
    }

    private void deliverMessageToVision(String responseXML) {

        try {

            //genericMessageProducerClient.sendMessage(ahwalIncidentResponseQueue, responseXML);

        } catch (Exception ex) {

            LOGGER.error("Unable to send Success Acknowledgement to Vision for Ahwal Incident. Reason: " + ex);

        }
    }

}
