package ae.emaratech.uaevision.crm.report;

/**
 * Created by Wasib.Khan on 6/5/2016.
 *
 *
 */

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;
import ae.emaratech.uaevision.arrest.query.ArrestQueryService;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestQuery;
import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.crm.application.dto.CaseTrackDto;
import ae.emaratech.uaevision.crm.domain.CaseAction;
import ae.emaratech.uaevision.crm.query.CaseQueryService;
import ae.emaratech.uaevision.crm.query.RetrieveCaseHistoryQuery;
import ae.emaratech.uaevision.crm.query.RetrieveCaseQuery;
import ae.emaratech.uaevision.fis.common.exception.BusinessException;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.util.ApplicationConstants;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.gateway.incident.UserManagementServiceClient;
import ae.emaratech.uaevision.fis.gateway.usermanagementservice.EmployeeDetail;
import ae.emaratech.uaevision.fis.gateway.usermanagementservice.EmployeeDetails;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import ae.emaratech.uaevision.fis.party.query.RetrievePartyQuery;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperDataSource;
import ae.emaratech.uaevision.fis.user.service.dto.UserShiftDetail;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;


import java.util.*;
import java.util.stream.Collectors;

/**
 * This class is use for generating the party transfer report. <p/> Created by Wasib.Khan on
 * 6/5/2016.
 */
@Component
public class PartyTransferReportDataSource implements JasperDataSource {

    /**
     * Static containing the logger for the class.
     */
    private static final Logger LOGGER = LogManager.getLogger();
    @Autowired
    private CaseQueryService caseQueryService;
    @Autowired
    private PartyQueryService partyQueryService;
    @Autowired
    private ArrestQueryService arrestQueryService;
    @Autowired
    private UserManagementServiceClient userManagementServiceClient;

    public JRDataSource getDataSource(ReportParameters parameters) throws BusinessException {

        LOGGER.info("method  getDataSource() start");

        LOGGER.info("Inside PartyTransferReportDataSource ");
        Long
                parentIncidentIdLong =
                Long.valueOf(
                        parameters.getParameter(ApplicationConstants.REPORT_PARAM_PARENT_INCIDENT_ID).toString());
        String userName = parameters.getParameter("USER_NAME").toString();

        CaseKey caseKey = new CaseKey(parentIncidentIdLong);
        RetrieveCaseQuery retrieveCaseQuery = new RetrieveCaseQuery(caseKey);

        CaseDto caseDto = caseQueryService.retrieveCase(retrieveCaseQuery);
        //Get PartyList
        List<PartyDto> incidentPartyList = new ArrayList<>();


        if (Checks.isNotNull(caseDto.getCasePartyDtoList())) {

            int sequencePartyNo = 1;
            for (CasePartyDto casePartyDto : caseDto.getCasePartyDtoList()) {
                PartyKey partyKey = new PartyKey(casePartyDto.getPartyId());
                PartyDto partyDto = partyQueryService.retrieveParty(new RetrievePartyQuery(partyKey));
                partyDto.setSequenceNo(Integer.toUnsignedLong(sequencePartyNo++));
                if (CollectionUtils.isNotEmpty(partyDto.getPassports())) {
                    partyDto.setPassportNo(partyDto.getPassports().get(0).getPassportNo());
                }
                if (Checks.isNotNull(casePartyDto.getChargeDtoList())) {
                    List<String> charge = new ArrayList<>();
                    casePartyDto.getChargeDtoList().stream().filter(chargeDto -> Objects.equals(chargeDto.getIsDeleted(), 0L)).forEach(chargeDto -> {
                        String chargeName = chargeDto.getCharge().getName();
                        charge.add(chargeName + ' ');
                        String charges = org.apache.commons.lang3.StringUtils.join(charge, ',');
                        partyDto.setCharges(charges);

                    });

                }
                incidentPartyList.add(partyDto);
            }

        }

        ArrestReportKey arrestReportKey = new ArrestReportKey(caseDto.getArrestId());
        ArrestReportDto
                arrestReportDto =
                arrestQueryService.retrieveArrestReport(new RetrieveArrestQuery(arrestReportKey));


        //Get Arrest Team Details
        List<ArrestTeamDto> arrestTeamDtos =  arrestQueryService.retrieveArrestTeamsForArrest(new RetrieveArrestQuery(arrestReportKey));
        List<ArrestTeamDto> arrestTeamList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(arrestTeamDtos)) {
            EmployeeDetails employeeDetails = userManagementServiceClient.getAllEmployeeDetails();
            List<EmployeeDetail> employeeDetailList = employeeDetails.getEmployeeDetail();

            int sequenceArrestNo = 1;
            for (ArrestTeamDto arrestTeamDto : arrestTeamDtos) {
                arrestTeamDto.setSequenceNo(Integer.toUnsignedLong(sequenceArrestNo++));

                List<EmployeeDetail> employeeDetailListFiltered = employeeDetailList.stream()
                        .filter(empObj -> empObj.getEmployeeId().longValue() == Long
                                .parseLong(arrestTeamDto.getEmployeeId()))
                        .collect(Collectors.toList());

                if (employeeDetailListFiltered.size() == 1) {
                    EmployeeDetail employeeDetail = employeeDetailListFiltered.get(0);
                    arrestTeamDto.setOfficerName(employeeDetail.getNameEn());
                    arrestTeamDto.setOfficerNameAr(employeeDetail.getNameAr());
                    arrestTeamDto.setRankAr(employeeDetail.getRankAr());
                    if (employeeDetail.getShiftDetail() != null) {
                        UserShiftDetail userShiftDetail = new UserShiftDetail();
                        userShiftDetail.setId(employeeDetail.getShiftDetail().getId());
                        userShiftDetail.setShiftEndTime(employeeDetail.getShiftDetail().getShiftEndTime());
                        userShiftDetail.setShiftNameAr(employeeDetail.getShiftDetail().getShiftNameAr());
                        userShiftDetail.setShiftNameEn(employeeDetail.getShiftDetail().getShiftNameAr());
                        userShiftDetail.setShiftStartTime(employeeDetail.getShiftDetail().getShiftStartTime());
                        arrestTeamDto.setUserShiftDetail(userShiftDetail);
                    }

                    employeeDetailListFiltered.clear();
                }

                arrestTeamList.add(arrestTeamDto);
            }
        }

        RetrieveCaseHistoryQuery retrieveCaseHistoryQuery = new RetrieveCaseHistoryQuery(caseKey);
        List<CaseTrackDto>
                caseTrackDtoList =
                caseQueryService.retrieveCaseHistory(retrieveCaseHistoryQuery);
        CaseTrackDto caseTrackInfo =
                caseTrackDtoList.stream().filter(
                        caseTrackDto -> (Objects.equals(caseTrackDto.getAction().getId()
                                , CaseAction.TRANSFERRED_TO.id()) || Objects.equals(caseTrackDto.getAction().getId()
                                , CaseAction.FORWARD.id())))
                                .findAny().get();
        //Need to populate comments.
        String comments = caseTrackInfo.getComments();

        List<Map> objects = new ArrayList<>();
        Map<String, Object> resultSet = new HashMap<>();

        //Department and Section Name
        if (caseDto.getSectionUnit() != null) {
            resultSet.put("unit", String.valueOf(caseDto.getSectionUnit().getName()));
        }
        resultSet.put("incidentId", String.valueOf(caseDto.getCaseNumber()));
        resultSet.put("departmentName", String.valueOf(caseDto.getDepartment().getName()));
        resultSet.put("sectionName", String.valueOf(caseDto.getSection().getName()));
        resultSet.put("incidentStatus", String.valueOf(caseDto.getStatus().getName()));
        resultSet.put("createdDate", String.valueOf(caseDto.getCreatedDate()));
        resultSet.put("createdBy", String.valueOf(caseDto.getCreatedBy()));
        resultSet.put("userName", userName);
        resultSet.put("incidentPartyList", getDataSource(incidentPartyList));
        resultSet.put("arrestTeamList", getDataSource(arrestTeamList));
        resultSet.put("comments", comments);

        boolean localeLang = false;
        if ("en".equals(LocaleContextHolder.getLocale().getLanguage())) {
            localeLang = true;
        }
        resultSet.put("localeLang", localeLang);

        objects.add(resultSet);
        JRBeanCollectionDataSource source = new JRBeanCollectionDataSource(objects);

        LOGGER.info("method  getDataSource() stop");
        return source;
    }

    // This method is use for set JRDataset
    private JRDataSource getDataSource(List li) {
        JRDataSource jrDataSource = null;

        if (!CollectionUtils.isEmpty(li)) {
            jrDataSource = new JRBeanCollectionDataSource(li);
        } else {
            jrDataSource = new JRBeanCollectionDataSource(new ArrayList<>());
        }
        return jrDataSource;
    }

}

