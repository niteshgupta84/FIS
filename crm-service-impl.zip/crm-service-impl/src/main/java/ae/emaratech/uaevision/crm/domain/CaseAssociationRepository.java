package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.infrastructure.HibernateCaseAssociationRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by Nitesh.Gupta on 7/22/2016.
 */
@Repository
public interface CaseAssociationRepository extends HibernateCaseAssociationRepository {

}
