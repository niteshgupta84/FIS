package ae.emaratech.uaevision.crm.infrastructure;

import ae.emaratech.uaevision.crm.domain.Case;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;

/**
 * Created by Nitesh.Gupta on 6/15/2016.
 */
public interface HibernateCaseRepository extends JpaRepository<Case, Long>,
        QueryDslPredicateExecutor<Case> {

}
