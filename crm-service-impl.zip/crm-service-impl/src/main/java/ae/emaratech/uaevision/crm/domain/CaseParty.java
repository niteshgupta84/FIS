package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.entitylistener.*;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.lookup.service.annotation.LookupField;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Business object representing the Arrest Party entity.
 *
 * @author Nitesh.Gupta
 */
@Entity
@EntityListeners({
        CreatedDateListener.class,
        ModifiedDateListener.class,
        CreatedByListener.class,
        ModifiedByListener.class
})
@Table(name = "CASE_PARTY")
public class CaseParty implements Creatable,
        Updatable, Serializable {

    /**
     * Holds Unique key for Arrest Attachment.
     */
    @Id
    @SequenceGenerator(name = "CASE_PARTY_ID_GENERATOR", sequenceName = "SEQ_CASE_PARTY", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CASE_PARTY_ID_GENERATOR")
    @Column(name = "ID", unique = true, nullable = false)
    private Long id;

    @Column(name = "PARTY_ID", nullable = false)
    private Long partyId;

    @ManyToOne
    @JoinColumn(name = "CASE_ID", nullable = false)
    private Case caseReference;

    @Column(name = "CREATED_BY", length = 30, nullable = false)
    private String createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE", nullable = false)
    private Date createdDate;

    @LookupField(LookupDefinition.PARTY_TYPE)
    @Column(name = "PARTY_TYPE_ID", nullable = false)
    private Long partyTypeId;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFIED_DATE", nullable = true)
    private Date modifiedDate;

    @Column(name = "MODIFIED_BY", nullable = true)
    private String modifiedBy;

    @Column(name = "IS_DELETED", nullable = false)
    private Long isDeleted;


    @Version
    private Long version;

    @OneToMany(mappedBy = "casePartyReference", fetch = FetchType.LAZY, orphanRemoval = true, cascade = CascadeType.ALL)
    @OrderBy("createdDate DESC")
    private Set<CasePartyCharge> casePartyCharges = new HashSet<>();

    private CaseParty() {

    }

    public CaseParty(PartyKey partyKey) {
        this.partyId = partyKey.id();
    }

    public CaseParty(PartyKey partyKey, Long partyTypeId, Long isDeleted) {
        this.partyId = partyKey.id();
        this.partyTypeId = partyTypeId;
        this.isDeleted = isDeleted;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Long id() {
        return id;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    @Override
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Long getPartyId() {
        return partyId;
    }

    public Case getCaseReference() {
        return caseReference;
    }

    public void setCaseReference(Case caseReference) {
        this.caseReference = caseReference;
    }

    public Long getPartyTypeId() {
        return partyTypeId;
    }

    public void setPartyTypeId(Long partyTypeId) {
        this.partyTypeId = partyTypeId;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public Long getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Long isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Set<CasePartyCharge> getCasePartyCharges() {
        return casePartyCharges;
    }

    public CaseParty withPartyCharges(Set<CasePartyCharge> partyCharges) {

        for (CasePartyCharge updatedPartyCharge : partyCharges) {
            boolean isChargeExist = false;
            for (CasePartyCharge existingCharge : casePartyCharges) {
                if (existingCharge.id().longValue() == updatedPartyCharge.id().longValue()) {
                    isChargeExist = true;
                    existingCharge.setIsDeleted(updatedPartyCharge.getIsDeleted());
                    updatedPartyCharge.setChargeId(updatedPartyCharge.getChargeId());
                    break;
                }
            }
            if (!isChargeExist) {
                updatedPartyCharge.setCasePartyReference(this);
                casePartyCharges.add(updatedPartyCharge);
            }
        }
        this.casePartyCharges = partyCharges;
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
