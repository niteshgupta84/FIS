package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportTrackDto;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@Component
public class CaseReportHistoryMapper {

    /**
     * Reference to the lookup service.
     */
    @Autowired
    private LookupService lookupService;


    @Autowired
    private UserService userService;

    /**
     * Method which copies the relevant state information from Deportation History entity to dto.
     *
     * @param caseActionHistory the arrest history entity bean.
     * @return deportation track transfer object
     */
    public ArrestReportTrackDto mapArrestReportTrackDto(
            CaseActionHistory caseActionHistory) {

        ArrestReportTrackDto arrestReportTrackDto = new ArrestReportTrackDto();

        arrestReportTrackDto.setId(caseActionHistory.getId());
        arrestReportTrackDto.setComments(caseActionHistory.getComments());
        arrestReportTrackDto.setCreatedBy(userService.getUserFirstNameByUserLogin(caseActionHistory.getCreatedBy()));
        arrestReportTrackDto.setCreatedDate(caseActionHistory.getCreatedDate());
        arrestReportTrackDto.setAction(
                lookupService.getLookupEntry(
                        LookupDefinition.ARREST_ACTION,
                        LocaleContextHolder
                                .getLocale(),
                        caseActionHistory.getCaseActionId()).get());

        return arrestReportTrackDto;
    }
}
