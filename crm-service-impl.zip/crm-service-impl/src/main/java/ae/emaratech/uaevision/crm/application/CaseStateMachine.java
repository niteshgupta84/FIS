package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.crm.domain.CaseAction;
import ae.emaratech.uaevision.crm.domain.CaseStatus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * For managing state and transitions of Arrest.
 * <p/>
 * Concept and terms are based on that of FSM (Finite State Machine)
 */
public class CaseStateMachine {
    private static final Logger LOGGER = LogManager.getLogger();

    /**
     * prevent instantiation
     */
    private CaseStateMachine() {
    }

    public static List<CaseAction> nextPossibleActions(CaseStatus currentState,
                                                       boolean lockAcquired) {

        Map<CaseStatus, List<CaseAction>> stateMachineConfig =
                CaseStateMachineConfiguration.getStateMachineConfigForIcm();

        List<CaseAction> configuredActions = stateMachineConfig.get(currentState);

        List<CaseAction> possibleActions = new ArrayList<>();
        if (configuredActions != null) {
            for (CaseAction configuredAction : configuredActions) {
                if (configuredAction.requiresLock() && !lockAcquired) {
                    possibleActions.add(CaseAction.ACQUIRE);
                    return possibleActions;
                }
            }
        } else {
            return possibleActions;
        }
        return configuredActions;
    }


}
