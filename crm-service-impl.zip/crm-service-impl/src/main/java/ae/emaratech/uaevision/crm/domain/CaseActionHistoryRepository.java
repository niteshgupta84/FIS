package ae.emaratech.uaevision.crm.domain;


import ae.emaratech.uaevision.crm.infrastructure.HibernateCaseActionHistoryRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository which manages the  persistence and retrieval of Arrest history Report domain entity.
 * Created by Nitesh.Gupta on 6/7/2016.
 */
@Repository
public interface CaseActionHistoryRepository extends HibernateCaseActionHistoryRepository {

}
