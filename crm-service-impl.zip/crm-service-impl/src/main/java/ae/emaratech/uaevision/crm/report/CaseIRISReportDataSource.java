package ae.emaratech.uaevision.crm.report;


import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.crm.query.CaseQueryService;
import ae.emaratech.uaevision.crm.query.RetrieveCaseQuery;
import ae.emaratech.uaevision.deportation.application.dto.DeportationDto;
import ae.emaratech.uaevision.deportation.query.DeportationQueryService;
import ae.emaratech.uaevision.deportation.query.RetrieveDeportationFromDeporteeQuery;
import ae.emaratech.uaevision.document.service.api.DocumentService;
import ae.emaratech.uaevision.fis.common.exception.BusinessException;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.common.key.DeporteeKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.gateway.deportation.resource.DeportationResourceGateway;
import ae.emaratech.uaevision.fis.party.application.PartyStatus;
import ae.emaratech.uaevision.fis.party.application.dto.ChargeDto;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import ae.emaratech.uaevision.fis.party.query.RetrievePartyQuery;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperDataSource;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.util.*;

/**
 * This class is use for generating the party iris report. <p/> Created by Satya K on 10/06/2016
 * Update By Nitesh Gupta on 04/07/2016
 */
@Component
public class CaseIRISReportDataSource implements JasperDataSource {

    /**
     * Static containing the logger for the class.
     */
    private static final Logger LOGGER = LogManager.getLogger();

    @Autowired
    private PartyQueryService partyQueryService;


    @Autowired
    private DocumentService documentService;
    @Autowired
    private DeportationResourceGateway deportationResourceGateway;

    @Autowired
    private CaseQueryService caseQueryService;

    public JRDataSource getDataSource(ReportParameters parameters) throws BusinessException {

        LOGGER.info("Inside IRISReportDataSource.getDataSource() ");

        List<Map> objects = new ArrayList<>();
        Map<String, Object> resultSet = new HashMap<>();
        Long
                parentIncidentIdLong =
                Long.valueOf(
                        parameters.getParameter("CASE_ID").toString());
        Long partyIdLong = Long.valueOf(parameters.getParameter("PARTY_ID_IRIS").toString());
        RetrieveCaseQuery
                retrieveCaseForArrestQuery =
                new RetrieveCaseQuery(new CaseKey(parentIncidentIdLong));

        CaseDto caseDto = caseQueryService.retrieveCase(retrieveCaseForArrestQuery);

        //Get party details
        PartyKey partyKey = new PartyKey(partyIdLong);
        PartyDto partyDto = partyQueryService.retrieveParty(new RetrievePartyQuery(partyKey));
        //Get Party Photo
        byte[] partyPhoto = null;
        if (partyDto.getAttachmentId() != null) {
            partyPhoto = documentService.downloadDocument(partyDto.getAttachmentId()).getAttachment();
        }

        if (partyPhoto != null) {
            ByteArrayInputStream partyPhotoObj = new ByteArrayInputStream(partyPhoto);
            resultSet.put("partyPhoto", partyPhotoObj);
        }
        //Get List of Charges
        List<String> charge = new ArrayList<>();
        List<CasePartyDto> casePartyDtoList = caseDto.getCasePartyDtoList();
        casePartyDtoList.stream()
                .filter(casePartyDto -> Objects.equals(casePartyDto.getPartyId(), partyIdLong))
                .forEach(casePartyDto -> {
                    List<ChargeDto> listOfCharges = partyDto.getListofCharges();

                    if (Checks.isNotNull(listOfCharges)) {
                        for (ChargeDto chargeDto : listOfCharges) {
                            String chargeName = chargeDto.getCharge().getName();
                            charge.add(chargeName + ' ');
                        }
                    }
                });

        String charges = org.apache.commons.lang3.StringUtils.join(charge, ',');
        resultSet.put("personType", String.valueOf(partyDto.getPersonType().getName()));
        resultSet.put("age", String.valueOf(partyDto.getAge()));
        if (partyDto.getAge() == 0) {
            resultSet.put("age", "  --  ");
        }
        resultSet.put("nameEn", String.valueOf(partyDto.getNameEn()));
        resultSet.put("nameAr", String.valueOf(partyDto.getNameAr()));
        resultSet.put("nationality", String.valueOf(partyDto.getNationality().getName()));

        resultSet.put("listOfCharges", String.valueOf(charges));
        resultSet.put("gender", String.valueOf(partyDto.getGender().getName()));
        resultSet.put("dateOfBirth", String.valueOf(partyDto.getDateofbirth()));
        resultSet.put("udbNo", String.valueOf(partyDto.getUdbNo()));
        if (null == partyDto.getPersonNo() || "".equals(partyDto.getPersonNo()) || "0".equals(partyDto.getPersonNo())) {
            resultSet.put("personNumber", "  --  ");
        } else {
            resultSet.put("personNumber", String.valueOf(partyDto.getPersonNo()));
        }
        if (partyDto.getCountry() != null) {
            resultSet.put("country_city", partyDto.getCountry().getName());
        } else {
            resultSet.put("country_city", "     --    ");
        }

        //Department and Section Name
        if (caseDto != null) {
            resultSet.put("incidentId", String.valueOf(caseDto.getCaseNumber()));
            resultSet.put("departmentName", String.valueOf(caseDto.getDepartment().getName()));
            resultSet.put("sectionName", String.valueOf(caseDto.getSection().getName()));
            resultSet.put("incidentStatus", String.valueOf(caseDto.getStatus().getName()));
            resultSet.put("createdDate", String.valueOf(caseDto.getCreatedDate()));
            resultSet.put("createdBy", String.valueOf(caseDto.getCreatedBy()));
        }

        //IRIS Information
        byte[] irisPhoto = null;
        if (Checks.isNotNull(partyDto.getIrisDto())) {
            if (partyDto.getIrisDto().getIrisAttachmentId() != null) {
                irisPhoto =
                        documentService.downloadDocument(partyDto.getIrisDto().getIrisAttachmentId())
                                .getAttachment();
            }
            if (irisPhoto != null) {
                ByteArrayInputStream iphoto = new ByteArrayInputStream(irisPhoto);
                resultSet.put("irisPhoto", iphoto);
            }
            if (partyDto.getIrisDto().getIrisNumber() != null) {
                resultSet.put("irisNumber", String.valueOf(partyDto.getIrisDto().getIrisNumber()));
            } else {
                resultSet.put("irisNumber", "     --    ");
            }
            if (partyDto.getIrisDto().getNameChangedId() != null) {
                resultSet.put("irisNameChanged",
                        String.valueOf(partyDto.getIrisDto().getNameChangedId().getName()));
            } else {
                resultSet.put("irisNameChanged", "     --    ");
            }
            if (partyDto.getIrisDto().getLocationId() != null) {
                resultSet
                        .put("irisLocation", String.valueOf(partyDto.getIrisDto().getLocationId().getName()));
            } else {
                resultSet.put("irisLocation", "     --    ");
            }
        }

        //Arrival and Depart Info only when deportation order exists
        DeportationDto deportationDto = null;
        if (Checks.isNotNull(partyDto.getPartyStatusLk())) {
            if (Objects.equals(partyDto.getPartyStatusLk().getId()
                    ,Long.toString(PartyStatus.DEPORTED.id()))
                    || Objects.equals(partyDto.getPartyStatusLk().getId()
                   ,PartyStatus.UNDER_DEPORTATION.id())
                    || Objects.equals(partyDto.getPartyStatusLk().getId(),Long.toString(PartyStatus.TRANSFERRED_TO_DEPORTATION.id()))) {
                deportationDto = deportationResourceGateway.getDeportation(partyDto.getId());
            }
        }

        if (deportationDto !=null) {
            if (deportationDto.getArrivalCountry() != null) {
                resultSet.put("arrivedFrom", String.valueOf(deportationDto.getArrivalCountry().getName()));
            } else {
                resultSet.put("arrivedFrom", "     --    ");
            }

            if (deportationDto.getCountry() != null) {
                resultSet.put("departedTo", String.valueOf(deportationDto.getCountry().getName()));
            } else {
                resultSet.put("departedTo", "     --    ");
            }
        }
        objects.add(resultSet);

        JRBeanCollectionDataSource source = new JRBeanCollectionDataSource(objects);
        LOGGER.info("method getDataSource() stop");
        return source;
    }


}

