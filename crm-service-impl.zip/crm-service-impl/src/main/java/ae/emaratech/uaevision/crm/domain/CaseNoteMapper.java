package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.application.dto.CaseNoteDto;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@Component
public class CaseNoteMapper {


    @Autowired
    private UserService userService;
    /**
     * Mapping Note Dto from Entity
     */
    public CaseNoteDto mapToCaseNoteDto(CaseNote caseNoteEntity) {
        CaseNoteDto caseNoteDto = new CaseNoteDto();

        caseNoteDto.setCreatedDate(caseNoteEntity.getCreatedDate());
        caseNoteDto.setCreatedBy(userService.getUserFirstNameByUserLogin(caseNoteEntity.getCreatedBy()));
        caseNoteDto.setId(caseNoteEntity.id());
        caseNoteDto.setTextNote(caseNoteEntity.getNote());
        caseNoteDto.setViewId(caseNoteEntity.id());
        caseNoteDto.setIsDeleted(caseNoteEntity.getIsDeleted());
        return caseNoteDto;
    }

    /**
     * Preparing Note List from Set
     */
    public List<CaseNoteDto> mapToCaseNoteDtList(Set<CaseNote> caseNoteSet) {
        List<CaseNoteDto> caseNoteDtoList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(caseNoteSet)) {
            caseNoteDtoList
                    .addAll(caseNoteSet.stream().map(this::mapToCaseNoteDto).collect(Collectors.toList()));
        }
        return caseNoteDtoList;

    }


}
