package ae.emaratech.uaevision.crm.report;

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportDto;
import ae.emaratech.uaevision.arrest.query.ArrestQueryService;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestQuery;
import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.crm.query.CaseQueryService;
import ae.emaratech.uaevision.crm.query.RetrieveCaseQuery;
import ae.emaratech.uaevision.document.application.AttachedDocumentDto;
import ae.emaratech.uaevision.document.service.api.DocumentService;
import ae.emaratech.uaevision.document.service.dto.DocumentReferenceDto;
import ae.emaratech.uaevision.fis.common.exception.BusinessException;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperDataSource;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Deep.Gupta on 29-Jun-16.
 */
@Component
public class AttachmentReportDataSource implements JasperDataSource {

    @Autowired
    CaseQueryService caseQueryService;

    @Autowired
    DocumentService documentService;

    @Autowired
    ArrestQueryService arrestQueryService;

    public JRDataSource getDataSource(ReportParameters parameters) throws BusinessException {

        List<Map> objects = new ArrayList<>();

        Long caseID = Long.parseLong(parameters.getParameter("CASE_ID").toString());

        CaseKey caseKey = new CaseKey(caseID);
        RetrieveCaseQuery retrieveCaseQuery = new RetrieveCaseQuery(caseKey);
        CaseDto caseDto = caseQueryService.retrieveCase(retrieveCaseQuery);

        Long arrestId = caseDto.getArrestId();
        if (arrestId != null) {
            ArrestReportKey arrestReportKey = new ArrestReportKey(arrestId);
            RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(arrestReportKey);
            ArrestReportDto arrestReportDto = arrestQueryService.retrieveArrestReport(retrieveArrestQuery);

            List<AttachedDocumentDto> arrestAttachments = arrestReportDto.getArrestAttachmentDtoList();
            if (arrestAttachments != null) {
                for (AttachedDocumentDto documentDto : arrestAttachments) {


                    if (documentDto.getAttachmentReferenceId() != null) {
                        Map<String, Object> resultSet = new HashMap<>();
                        DocumentReferenceDto
                                documentReferenceDto =
                                documentService.downloadDocument(documentDto.getAttachmentReferenceId());
                        if (isDocumentOfTypeImage(documentReferenceDto)) {
                            ByteArrayInputStream
                                    bais =
                                    new ByteArrayInputStream(documentReferenceDto.getAttachment());
                            resultSet.put("attachment", bais);
                            objects.add(resultSet);
                        }
                    }
                }
            }
        }


        List<AttachedDocumentDto> caseAttachments = caseDto.getCaseAttachmentDtoList();

        if (CollectionUtils.isNotEmpty(caseAttachments)) {

            for (AttachedDocumentDto documentDto : caseAttachments) {


                if (documentDto.getAttachmentReferenceId() != null) {
                    Map<String, Object> resultSet = new HashMap<>();
                    DocumentReferenceDto
                            documentReferenceDto =
                            documentService.downloadDocument(documentDto.getAttachmentReferenceId());
                    if (isDocumentOfTypeImage(documentReferenceDto)) {
                        ByteArrayInputStream
                                bais =
                                new ByteArrayInputStream(documentReferenceDto.getAttachment());
                        resultSet.put("attachment", bais);
                        objects.add(resultSet);
                    }
                }
            }
        }

        return new JRBeanCollectionDataSource(objects);

    }

    private boolean isDocumentOfTypeImage(DocumentReferenceDto documentReferenceDto) {

        String fileName = documentReferenceDto.getFileName();

        return fileName.contains("jpg") || fileName.contains("jpeg") || fileName.contains("bmp") ||
                fileName.contains("JPG") || fileName.contains("JPEG") || fileName.contains("BMP");

    }
}
