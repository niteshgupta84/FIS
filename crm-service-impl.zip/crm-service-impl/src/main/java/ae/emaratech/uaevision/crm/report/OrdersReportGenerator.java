package ae.emaratech.uaevision.crm.report;
/**
 * Created by Satya K on 26/4/2016.
 */

import ae.emaratech.uaevision.fis.common.exception.BusinessException;
import ae.emaratech.uaevision.fis.report.core.FISReport;
import ae.emaratech.uaevision.fis.report.core.FISReportFormat;
import ae.emaratech.uaevision.fis.report.core.FISReportGenerator;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperReportGenerator;
import net.sf.jasperreports.engine.JRDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;

@Component
public class OrdersReportGenerator implements FISReportGenerator {

    private static final String CRM_ORDERS_REQUESTS_REPORT = "crm-orders-requests-report";

    @Autowired
    private OrdersReportDataSource ordersReportDataSource;
    @Autowired
    private JasperReportGenerator jasperReportGenerator;

    public FISReport generateReport(ReportParameters parameters, FISReportFormat fisReportFormat)
            throws BusinessException {
        JRDataSource dataSource = ordersReportDataSource.getDataSource(parameters);
        FISReport report = new FISReport();
        report.setContent(
                jasperReportGenerator
                        .generateReport(CRM_ORDERS_REQUESTS_REPORT, new HashMap(), dataSource));
        return report;
    }
}
