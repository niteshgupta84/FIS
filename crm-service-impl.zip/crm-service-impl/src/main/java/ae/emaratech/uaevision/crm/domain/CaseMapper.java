package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.common.util.PreCondition;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Mapper class to map Case entity to dto and vice versa Created by Nitesh.Gupta on 6/19/2016.
 */
@Component
public class CaseMapper {

    @Autowired
    private LookupService lookupService;

    @Autowired
    private CasePartyMapper casePartyMapper;


    @Autowired
    private UserService userService;


    public CaseDto mapToCaseDto(Case caseEntity) {

        if (caseEntity != null) {
            CaseDto caseDto = new CaseDto();
            caseDto.setId(caseEntity.id());
            caseDto.setTrackerId(caseEntity.getTrackerId());
            caseDto.setCreatedBy(userService.getUserFirstNameByUserLogin(caseEntity.getCreatedBy()));
            caseDto.setCreatedDate(caseEntity.getCreatedDate());
            caseDto.setArrestId(caseEntity.getArrestId());
            caseDto.setAssignedUser(caseEntity.getAssignedUser());
            caseDto.setFirNo(caseEntity.getFirNo());
            caseDto.setVersion(caseEntity.getVersion());
            caseDto.setVisionCaseNumber(caseEntity.getVisionCaseNumber());
            if (caseEntity.getTransferredFromDeptId() != null) {
                caseDto.setTransferredFrom(
                        lookupService.getLookupEntry(
                                LookupDefinition.TRANSFERREDFROM, LocaleContextHolder.getLocale(),
                                caseEntity.getTransferredFromDeptId()).get());
            }

            if (Checks.isNotNull(caseEntity.getStatusId())) {
                caseDto.setStatus(
                        lookupService.getLookupEntry(
                                LookupDefinition.CASE_STATUS, LocaleContextHolder.getLocale(),
                               caseEntity.getStatusId()).get());
            }
            if (Checks.isNotNull(caseEntity.getOwner().getDepartment())) {
                Entry departmentEntry = lookupService.getLookupEntry(
                        LookupDefinition.DEPARTMENT, LocaleContextHolder.getLocale(),
                        caseEntity.getOwner().getDepartment()).get();
                caseDto.setDepartment(departmentEntry);
            }

            if (Checks.isNotNull(caseEntity.getOwner().getSection())) {
                caseDto.setSection(
                        lookupService.getLookupEntry(
                                LookupDefinition.SECTION, LocaleContextHolder.getLocale(),
                                caseEntity.getOwner().getSection()).get());
            }

            if (Checks.isNotNull(caseEntity.getNonCRMSectionId())) {
                caseDto.setNonCRMSection(
                        lookupService.getLookupEntry(
                                LookupDefinition.SECTION, LocaleContextHolder.getLocale(),
                                caseEntity.getNonCRMSectionId()).get());
            }


            if (Checks.isNotNull(caseEntity.getOwner().getSectionUnit())) {
                caseDto.setSectionUnit(
                        lookupService.getLookupEntry(
                                LookupDefinition.SECTION_UNITS, LocaleContextHolder.getLocale(),
                                caseEntity.getOwner().getSectionUnit()).get());
            }
            if (Checks.isNotNull(caseEntity.getLatestSection())) {
                caseDto.setLatestSection(
                        lookupService.getLookupEntry(
                                LookupDefinition.SECTION, LocaleContextHolder.getLocale(),
                                caseEntity.getLatestSection()).get());
            }
            if (Checks.isNotNull(caseEntity.getTransferredFromDeptId())) {
                caseDto.setTransferredFrom(
                        lookupService.getLookupEntry(
                                LookupDefinition.TRANSFERREDFROM, LocaleContextHolder.getLocale(),
                                caseEntity.getTransferredFromDeptId()).get());
            }
            if (Checks.isNotNull(caseEntity.getManualTransferDeptId())) {
                caseDto.setManualTransferTo(
                        lookupService.getLookupEntry(
                                LookupDefinition.TRANSFERREDFROM, LocaleContextHolder.getLocale(),
                                caseEntity.getManualTransferDeptId()).get());
            }
            if (Checks.isNotNull(caseEntity.getArrestReasonId())) {
                caseDto.setArrestReason(
                        lookupService.getLookupEntry(
                                LookupDefinition.ARREST_REASON, LocaleContextHolder.getLocale(),
                                caseEntity.getArrestReasonId()).get());
            }
            caseDto.setCaseNumber(getCaseNumberForDisplay(caseEntity));
            caseDto.setCasePartyDtoList(casePartyMapper.mapToDtoList(caseEntity.getParties()));


            return caseDto;
        }
        return null;
    }

    /**
     * Returning map of Arrest for given search Criteria
     */
    public Map mapEntityToDTOList(List<Case> caseEntities) {
        Map<Long, CaseDto> caseDtoMap = new LinkedHashMap<>();
        long seqNo = 0;
        for (Case caseEntity : caseEntities) {
            seqNo = seqNo + 1;
            CaseDto caseDto = mapToCaseDto(caseEntity);
            caseDtoMap.put(caseEntity.id(), caseDto);
        }
        return caseDtoMap;
    }

    private String getCaseNumberForDisplay(Case caseEntity){

        String caseNumber = caseEntity.getCaseNumber()!=null ? caseEntity.getCaseNumber() : "";

        Long departmentId = caseEntity.getOwner().getDepartment();

        Long departmentDisplayId = Department.getDepartmentCodeByDepartmentId(departmentId);

        String number = departmentDisplayId + PreCondition.SEPARATOR + caseNumber + PreCondition.SEPARATOR + caseEntity.getYear();

        return number;
    }
}
