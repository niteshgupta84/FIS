package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.infrastructure.HibernateCaseAttachmentRepository;
import org.springframework.stereotype.Repository;


/**
 * Created by Nitesh.Gupta on 6/18/2016.
 */
@Repository
public interface CaseAttachmentRepository extends HibernateCaseAttachmentRepository {

}
