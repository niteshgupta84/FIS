package ae.emaratech.uaevision.crm.infrastructure;

import ae.emaratech.uaevision.crm.domain.CaseAssociation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;

/**
 * Created by Nitesh.Gupta on 7/22/2016.
 */
public interface HibernateCaseAssociationRepository extends JpaRepository<CaseAssociation, Long>,
        QueryDslPredicateExecutor<CaseAssociation> {

}
