package ae.emaratech.uaevision.crm.report;
/**
 * Created by Satya K on 26/4/2016.
 */

import ae.emaratech.uaevision.fis.common.exception.BusinessException;
import ae.emaratech.uaevision.fis.report.core.FISReport;
import ae.emaratech.uaevision.fis.report.core.FISReportFormat;
import ae.emaratech.uaevision.fis.report.core.FISReportGenerator;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperReportGenerator;
import net.sf.jasperreports.engine.JRDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;

@Component
public class CaseIRISReportGenerator implements FISReportGenerator {

    private static final String IRIS_REPORT_NAME = "party-iris-report";

    @Autowired
    private CaseIRISReportDataSource caseIrisReportDataSource;
    @Autowired
    private JasperReportGenerator jasperReportGenerator;

    public FISReport generateReport(ReportParameters parameters, FISReportFormat fisReportFormat)
            throws BusinessException {
        JRDataSource dataSource = caseIrisReportDataSource.getDataSource(parameters);
        FISReport report = new FISReport();
        report.setContent(
                jasperReportGenerator.generateReport(IRIS_REPORT_NAME, new HashMap(), dataSource));
        return report;
    }
}
