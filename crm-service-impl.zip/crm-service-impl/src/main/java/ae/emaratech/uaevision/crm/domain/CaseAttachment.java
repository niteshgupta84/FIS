package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.entitylistener.*;
import ae.emaratech.uaevision.fis.common.key.AttachmentReferenceKey;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the INCIDENT_ATTACHMENT database table.
 */
@Entity
@EntityListeners({
        CreatedDateListener.class,
        ModifiedDateListener.class,
        CreatedByListener.class,
        ModifiedByListener.class
})
@Table(name = "CASE_ATTACHMENT")
public class CaseAttachment implements Creatable, Serializable {

    /**
     * Holds Unique key for Arrest Attachment.
     */
    @Id
    @SequenceGenerator(name = "CASE_ATTACHMENT_ID_GENERATOR", sequenceName = "SEQ_CASE_ATTACHMENT", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CASE_ATTACHMENT_ID_GENERATOR")
    @Column(name = "ID", unique = true, nullable = false)
    private Long id;

    @Column(name = "ATTACHMENT_REF_ID", nullable = false)
    private Long attachmentReferenceId;

    //bi-directional many-to-one association to Incident

    @ManyToOne
    @JoinColumn(name = "CASE_ID", nullable = false)
    private Case caseReference;
    /**
     * Created By
     */
    @Column(name = "CREATED_BY", length = 30, nullable = false)
    private String createdBy;

    /**
     * Created Date field
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE", nullable = false)
    private Date createdDate;

    private CaseAttachment() {

    }

    public CaseAttachment(AttachmentReferenceKey attachmentReferenceKey) {
        this.attachmentReferenceId = attachmentReferenceKey.id();
    }

    protected Long id() {
        return this.id;
    }

    protected Long getAttachmentReferenceId() {
        return attachmentReferenceId;
    }

    public void setAttachmentReferenceId(Long attachmentReferenceId) {
        this.attachmentReferenceId = attachmentReferenceId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    protected Date getCreatedDate() {
        return createdDate;
    }

    @Override
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Case getCaseReference() {
        return caseReference;
    }

    public void setCaseReference(Case caseReference) {
        this.caseReference = caseReference;
    }

    public CaseAttachment withCreatedBy(String createdBy){
        this.createdBy = createdBy;
        return this;
    }
}
