package ae.emaratech.uaevision.crm.application.utils;

import java.io.Serializable;

/**
 * Created by Nitesh.Gupta on 6/5/2016.
 */
public class CaseConstants implements Serializable{

    public static final Long DEFAULT_ID = 0L;

    public static final String ARREST_MODEL = "arrestModel";
    public static final String CURRENT_SECTION = "currentSection";
    public static final String ATTACHMENT_ID = "attachmentId";
    public static final String DOCUMENT_INSPECTION_DTO = "documentInspectionDto";
    public static final String SUCCESS = "success";
    public static final String PARTY_DTO = "partyDto";
    public static final String PARTY_CHARGE_DTO = "partyChargeDto";
    public static final String PARTY_PROFILE_VIEW_MODEL_OBJ = "partyProfileViewModelObj";
    public static final String Unknown_Party_Add = "Add";
    public static final String Party_Update = "Update";
    public static final String PASSPORT_DTO = "passportViewModel";
    public static final String DOCUMENT_DTO = "documentViewModel";
    public static final String IRIS_DATA_SESSION_KEY = "irisPartyDtoPhotoAddDetails";
    public static final String PARTY_PROFILE_PICTURE = "profilePicture";
    public static final String PARTY_IRIS_PICTURE = "irisPicture";
    public static final Long LONG_VALUE_ONE = 1L;
    public static final long NUMBER_ZERO = 0L;
    public static final String PARTY_IRIS_PICTURE_DESCRIPTION = "Party IRIS Picture";
    public static final Long SELECT_NONE_KEY = -1L;
    public static final Long DEFAULT_EMIRATE = 2L; // DUBAI
    public static final Long DEFAULT_ENTRY_EXIT = 1L; // DUBAI
    public static final String BORDER_INCIDENT_URL = "borderControl/BorderIncident";
    public static final String EMPTY_STRING = "";
    public static final String ATTACHMENT_REF_DTO = "attachmentReferecneDTO";
    public static final String CURRENT_UNIT = "currentUnit";
    public static final String CURRENT_SECTION_NAME = "currentNameOfSection";
    public static final String CURRENT_DEPARTMENT_NAME = "currentNameOfDepartment";
    public static final String DETECTIVE_SECTIONNAME_KEY = "landingpage.label.detectiveSection";
    public static final String CRIMINAL_SECTIONNAME_KEY = "landingpage.label.criminalRecordsSection";
    public static final String DEFAULT_ASSOCIATION_TYPE = "1"; // Incident

    public static final String REPORT_PARAM_IRIS_PARTYID = "PARTY_ID_IRIS";
    public static final String CASE_MODEL = "caseModel";
    public static final String CASES_IN_SESSION = "casesInSession";
    public static final String CASE_DIALOG_PATH = "/case/dialog/";
    public static final String CASE_DETAILS_URL = "case/CaseDetails";
    public static final String CASE_DTO = "caseDto";
    public static final String CASE_NOTE_DTO = "caseNoteDto";
    public static final String CASE_ATTACHMENT_UPLOAD_DTO = "caseAttachmentDto";
    public static final String LANDING_CASES_SESSION_KEY = "casesSessionList";
    public static final String ORDER_DTO = "orderDto";

    public static final String REPORT_PARAM_CASE_ID = "CASE_ID";

    public static final String RETRIEVE_CASES_BY_SEARCH_QUERY = "retrieveCasesBySearchQuery";

    public static final String REPORT_PARAM_PARENT_CASE_ID = "CASE_ID";

    public static final Integer DEFAULT_LENGTH = 10;
    public static final Integer DEFAULT_START = 0;

    public static final String CASE_SEARCH_URL = "case/SearchCase";
    public static final String BORDER_CONTROL_LANDING = "borderControl/BCLanding";
    public static final String BORDER_CONTROL_DETAIL = "borderControl/BorderIncident";
    public static final String CASE_DIALOG_VIEW = "case/dialog/CaseView";
    public static final String CASE_NOTE_ADD = "case/dialog/AddCaseNote";
    public static final String CASE_NOTE_VIEW = "/case/dialog/ViewNote";
    public static final String CASE_ATTACHMENT_COMMENT_DELETE = "case/dialog/DeleteAttachmentComment";
    public static final String CASE_ATTACHMENT_EDIT = "/case/dialog/EditAttachment";
    public static final String CASE_ISSUE_ORDER_INTERROGATION = "interrogation/dialog/IssueInterrogationOrders";
    public static final String CASE_ISSUE_ORDER_ARREST = "case/dialog/IssueArrestOrders";
    public static final String CASE_ISSUE_ORDER_DETENTION = "detention/dialog/IssueDetentionOrder";
    public static final String CASE_COMMENTS = "/case/dialog/CaseComment";
    public static final String CASE_DOCUMENT_INSPECTION_ADD = "case/dialog/AddDocumentInspection";
    public static final String CASE_DOCUMENT_INSPECTION_NOTE_VIEW = "/case/dialog/ViewDocumentInspectionNote";
    public static final String CASE_DOWNLOAD = "/case/dialog/DownloadCase";
    public static final String CASE_PARTY_PROFILE = "case/dialog/CasePartyProfile";
    public static final String CASE_PARTY_CHARGE = "case/dialog/CasePartyCharge";
    public static final String CASE_PARTY_PROFILE_EDIT = "case/dialog/EditPartyProfile";
    public static final String CASE_IRIS_PHOTO_ADD = "case/dialog/AddIRISPhoto";
    public static final String IRIS_PHOTO_ADD = "case/dialog/AddCaseIRISPhoto";
    public static final String CASE_PARTY_PROFILE_COMPARE = "case/dialog/CasePartyProfileCompare";
    public static final String CASE_PARTY_DELETE_COMMENT = "case/dialog/DeletePartyWithComment";
    public static final String PRIVIOUS_VISITED = "previousVisited";
    public static final String CURRENTLY_VISITED = "currentlyVisited";
    public static final String CASE_DB_PROFILE = "case-clone";
    public static final String IGNORE_LOCK="ignoreLock";
    public static final String TRUE="true";
    public static final String SELECTED_TERMINAL="selectedTerminal";
    public static final String SELECTED_UNIT="selectedUnit";



}
