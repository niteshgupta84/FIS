package ae.emaratech.uaevision.crm.application.validators;

import ae.emaratech.uaevision.crm.application.CaseNotificationCode;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.party.application.CreatePartyCommand;
import ae.emaratech.uaevision.fis.party.application.UpdatePartyCommand;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.application.dto.PartyTypeChargeEnum;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Created by Nitesh.Gupta on 6/19/2016.
 */
@Component
public class CasePartyValidator {

    @Autowired
    private NotificationBus notificationBus;
    @Autowired
    private LookupService lookupService;

    public void validate(CreatePartyCommand command) {
        StringBuilder udbForEmail = new StringBuilder();
        StringBuilder udbForPhone = new StringBuilder();
        StringBuilder udbForPassport = new StringBuilder();
        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        String unknownName = lookupService.getLookupEntry(LookupDefinition.PERSON_TYPE, LocaleContextHolder.getLocale(),8L).get().getName();
        List<PartyDto> listOfParty = command.getPartyList();
        if (listOfParty.isEmpty()) {
            notificationBuilder.add(CaseNotificationCode.PARTY_MANDATORY);

        } else {
            List<PartyDto>
                    validPartyList = listOfParty.stream().filter(party -> Objects.equals(
                    party.getIsDeleted(), 0L)).collect(
                    Collectors.toList());
            if (validPartyList.isEmpty()) {
                notificationBuilder.add(CaseNotificationCode.PARTY_MANDATORY);
            } else {

                for (PartyDto partyDto : listOfParty) {
                    Entry partyType = partyDto.getPartytype();
                    String partyTypeChargeName = null;
                    String partyTypeCharge = null;
                    String udbNumber = partyDto.getUdbNo() != null ? String.valueOf(partyDto.getUdbNo()) : unknownName;
                    if (partyType != null) {
                        partyTypeCharge = partyType.getSelectedAttributes().get(0).getValue();
                        partyTypeChargeName = partyType.getName();
                    }
                    if (partyTypeCharge != null) {
                        if (partyTypeCharge.equalsIgnoreCase(PartyTypeChargeEnum.MANDATORY.getId())
                                && Objects.equals(partyDto.getIsDeleted(), 0L)) {

                            if (CollectionUtils.isEmpty(partyDto.getListofCharges()) && Objects.equals(partyDto.getId(), command.getPartyDto().getId())) {
                                // Charges for Accused
                                notificationBuilder.add(CaseNotificationCode.ACCUSED_CHARGE_MANDATORY,
                                        partyTypeChargeName);
                            }
                        }
                    } else {
                        // Party Type mandatory
                        notificationBuilder.add(CaseNotificationCode.PARTY_TYPE_MANDATORY);

                    }
                    if (!Checks.isValidString(partyDto.getEmailAddress())){
                        udbForEmail.append(udbNumber);
                        udbForEmail.append(",");
                    }
                    if (!Checks.isValidString(partyDto.getPhoneNumber())){
                        udbForPhone.append(udbNumber);
                        udbForPhone.append(",");

                    }
                    if (CollectionUtils.isEmpty(partyDto.getPassports())){
                        udbForPassport.append(udbNumber);
                        udbForPassport.append(",");

                    }
                }
                if (udbForEmail.toString().length()>0){
                    notificationBuilder.add(CaseNotificationCode.PARTY_EMAIL_MANDATORY,udbForEmail.toString());
                }
                if (udbForPhone.toString().length()>0){

                    notificationBuilder.add(CaseNotificationCode.PARTY_PHONE_MANDATORY,udbForPhone.toString());
                }
                if (udbForPassport.toString().length()>0){

                    notificationBuilder.add(CaseNotificationCode.PARTY_PASSPORT_MANDATORY,udbForPhone.toString());
                }
            }
        }

        if (notificationBuilder.hasNotifications()) {
            notificationBus.send(notificationBuilder);
        }
    }

    public void validate(UpdatePartyCommand command) {
        StringBuilder udbForEmail = new StringBuilder();
        StringBuilder udbForPhone = new StringBuilder();
        StringBuilder udbForPassport = new StringBuilder();
        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        List<PartyDto> listOfParty = command.getPartyList();
        String unknownName = lookupService.getLookupEntry(LookupDefinition.PERSON_TYPE, LocaleContextHolder.getLocale(),8L).get().getName();

        if (listOfParty.isEmpty()) {
            notificationBuilder.add(CaseNotificationCode.PARTY_MANDATORY);

        } else {
            List<PartyDto>
                    validPartyList = listOfParty.stream().filter(
                    party -> Objects.equals(party.getIsDeleted(), 0L)).collect(
                    Collectors.toList());
            if (validPartyList.isEmpty()) {
                notificationBuilder.add(CaseNotificationCode.PARTY_MANDATORY);
            } else {

                boolean isPartyTypeExists = true;
                for (PartyDto partyDto : listOfParty) {
                    Entry partyType = partyDto.getPartytype();
                    String udbNumber = partyDto.getUdbNo() != null ? String.valueOf(partyDto.getUdbNo()) : unknownName;
                    if (null != partyType) {
                        String partyTypeChargeName = partyType.getName();
                        if (partyType.getSelectedAttributes() != null && CollectionUtils.isNotEmpty(partyType.getSelectedAttributes())) {
                            String partyTypeCharge = partyType.getSelectedAttributes().get(0).getValue();
                            if (partyTypeCharge != null) {
                                if (partyTypeCharge.equalsIgnoreCase(PartyTypeChargeEnum.MANDATORY.getId())
                                        && Objects.equals(partyDto.getIsDeleted(), 0L)) {

                                    if (CollectionUtils.isEmpty(partyDto.getListofCharges()) && Objects.equals(partyDto.getPartyId(), command.getPartyDto().getId())) {
                                        // Charges for Accused
                                        notificationBuilder.add(CaseNotificationCode.ACCUSED_CHARGE_MANDATORY, partyTypeChargeName);
                                    }
                                }
                            } else {
                                isPartyTypeExists = false;
                            }
                        } else {
                            isPartyTypeExists = false;
                        }
                    } else {
                        isPartyTypeExists = false;
                    }
                    // Party Type mandatory
                    if (!isPartyTypeExists) {
                        notificationBuilder.add(CaseNotificationCode.PARTY_TYPE_MANDATORY);
                    }
                    if (!Checks.isValidString(partyDto.getEmailAddress())){
                        udbForEmail.append(udbNumber);
                        udbForEmail.append(",");

                    }
                    if (!Checks.isValidString(partyDto.getPhoneNumber())){
                        udbForPhone.append(udbNumber);
                        udbForPhone.append(",");

                    }
                    if (CollectionUtils.isEmpty(partyDto.getPassports())){
                        udbForPassport.append(udbNumber);
                        udbForPassport.append(",");

                    }
                }

                if (udbForEmail.toString().length()>0){
                    notificationBuilder.add(CaseNotificationCode.PARTY_EMAIL_MANDATORY,udbForEmail.toString());
                }
                if (udbForPhone.toString().length()>0){

                    notificationBuilder.add(CaseNotificationCode.PARTY_PHONE_MANDATORY,udbForPhone.toString());
                }
                if (udbForPassport.toString().length()>0){

                    notificationBuilder.add(CaseNotificationCode.PARTY_PASSPORT_MANDATORY,udbForPhone.toString());
                }

            }
        }
        if (notificationBuilder.hasNotifications()) {
            notificationBus.send(notificationBuilder);
        }
    }
}
