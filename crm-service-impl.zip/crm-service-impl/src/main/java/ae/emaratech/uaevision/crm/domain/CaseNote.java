package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.entity.AbstractEntityBase;
import ae.emaratech.uaevision.fis.common.key.NoteKey;

import javax.persistence.*;


/**
 * The persistent class for the ARREST_NOTE table.
 */
@Entity
@Table(name = "CASE_NOTE")
public class CaseNote extends AbstractEntityBase {

    private static final long serialVersionUID = 1L;

    @Column(name = "NOTE")
    private String note;

    @Column(name = "IS_DELETED")
    private Long isDeleted;

    //bi-directional many-to-one association to Deportation
    @ManyToOne
    @JoinColumn(name = "CASE_ID", nullable = false)
    private Case caseReference;

    private CaseNote() {

    }

    public CaseNote(NoteKey noteKey, String note, Long isDeleted) {

        setId(noteKey.id());
        this.note = note;
        this.isDeleted = isDeleted;
    }

    protected String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    protected Long getIsDeleted() {
        return isDeleted;
    }

    protected void setIsDeleted(Long isDeleted) {
        this.isDeleted = isDeleted;
    }

    protected CaseNote withNote(String note) {
        this.note = note;
        return this;
    }

    public Case getCaseReference() {
        return caseReference;
    }

    public void setCaseReference(Case caseReference) {
        this.caseReference = caseReference;
    }
}