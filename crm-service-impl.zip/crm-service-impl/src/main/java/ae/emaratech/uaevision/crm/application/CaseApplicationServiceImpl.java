package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.crm.application.dto.CaseNoteDto;
import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.crm.application.dto.CaseTransferDetailDto;
import ae.emaratech.uaevision.crm.application.utils.CaseConstants;
import ae.emaratech.uaevision.crm.domain.*;
import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.IncidentNumberProvider;
import ae.emaratech.uaevision.fis.common.domain.TrackerKeyProvider;
import ae.emaratech.uaevision.fis.common.infrastructure.EventBus;
import ae.emaratech.uaevision.fis.common.key.*;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.common.util.Enums;
import ae.emaratech.uaevision.fis.common.util.PersistentUtil;
import ae.emaratech.uaevision.fis.common.util.ReflectionUtil;
import ae.emaratech.uaevision.fis.order.domain.OrderStatus;
import ae.emaratech.uaevision.fis.order.query.OrderQueryService;
import ae.emaratech.uaevision.fis.order.query.RetrieveOrderListQuery;
import ae.emaratech.uaevision.fis.order.service.dto.OrderDto;
import ae.emaratech.uaevision.fis.party.application.ModuleTypes;
import ae.emaratech.uaevision.fis.party.application.dto.ChargeDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mysema.query.types.expr.BooleanExpression;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by Nitesh.Gupta on 6/15/2016.
 */
@Service
@Transactional
public class CaseApplicationServiceImpl implements CaseApplicationService {

    /**
     * Static containing Logger for the class.
     */
    private static final Logger LOGGER = LogManager.getLogger();

    @Autowired
    private CaseRepository caseRepository;

    @Autowired
    private EventBus<DomainEvent> eventBus;

    @Autowired
    private CaseKeyProvider caseKeyProvider;

    @Autowired
    private TrackerKeyProvider trackerKeyProvider;

    @Autowired
    private CaseActionHistoryRepository caseActionHistoryRepository;

    @Autowired
    private CaseNoteKeyProvider caseNoteKeyProvider;

    @Autowired
    private NotificationBus notificationBus;

    @Autowired
    private CasePartyChargeKeyProvider casePartyChargeKeyProvider;

    @Autowired
    private OrderQueryService orderQueryService;

    @Autowired
    private IncidentNumberProvider incidentNumberProvider;
    @Autowired
    private PersistentUtil persistentUtil;

    /**
     * Reference to JSON-Object jsonMapper.
     */
    @Autowired
    @Qualifier("jsonMapper")
    private ObjectMapper jsonMapper;

    @Autowired
    private CaseMapper caseMapper;

    @Autowired
    private CaseTransferDetailRepository caseTransferDetailRepository;

    @Autowired
    private CaseTransferDetailMapper caseTransferDetailMapper;


    /**
     * Service method to create Case
     */
    @Override
    public CreateCaseResult createCase(CreateCaseCommand command) {


        CaseKey caseKey = caseKeyProvider.next();
        Owner owner = new Owner(command.getDepartment(), command.getSection(), command.getUnit());

        Set<CaseParty> caseParties = getCaseParties(command.getCasePartyDtoList());

        TrackerKey trackerKey = command.getTrackerKey();
        if (trackerKey == null) {
            // For BorderControl flow, use the tracker key set within the command object.
            trackerKey = trackerKeyProvider.next();
        }

        @SuppressWarnings("UnusedAssignment") String caseNumber = command.getCaseNumber();
        Long year = (long) Calendar.getInstance().get(Calendar.YEAR);
        BooleanExpression predicate;
        do {

            if(null != command.getNonCRMSection() && command.getDepartment().id().longValue() == Department.DETECTIVE.id()){
                caseNumber = incidentNumberProvider.next(command.getDepartment().id(), Section.CRM.id(), ModuleTypes.CRM.name());
            }else{
                caseNumber = incidentNumberProvider.next(command.getDepartment().id(), command.getSection().id(), ModuleTypes.CRM.name());
            }


            predicate = QCase.case$.caseNumber.eq(caseNumber).and(QCase.case$.year.eq(year)
                    .and(QCase.case$.owner.department.eq(command.getDepartment().id())).and(QCase.case$.owner.section.eq(command.getSection().id())));
        }
        while (Checks.isNotNull(caseRepository.findOne(predicate)));

        Case newCase =
                new Case(caseKey, command.getArrestReportKey(), owner, caseParties,
                        command.getLatestAssignedSection(), command.getTransferredFrom(),
                        command.getArrestReason(), command.getVisionCaseNumber(),
                        command.getCreatedBy(), trackerKey, caseNumber,command.getNonCRMSection());



        CaseCreatedEvent event =
                newCase.create(command.getArrestReportKey(), caseParties, command.getFirNumber());

        caseRepository.save(newCase);
        trackAction(newCase, CaseAction.OPEN.id(), null);

        event.withCasePartiesJson(getCasePartyListJson(newCase.getParties()));
        eventBus.publish(event);

        return new CreateCaseResult(caseKey, caseNumber);
    }


    public String getCasePartyListJson(Set<CaseParty> casePartySet) {

        String casePartyListJson = null;
        List<Map<String, Object>> casePartyValueMap =
                casePartySet.stream()
                        .filter(caseParty -> Objects.equals(caseParty.getIsDeleted(), 0L))
                        .map(caseParty -> {
                            Map<String, Object> valueMap = new TreeMap<>();
                            valueMap.put("id", caseParty.id());
                            valueMap.put("partyId", caseParty.getPartyId());
                            valueMap.put("partyType", caseParty.getPartyTypeId());
                            List<Long> casePartyChargesList = caseParty.getCasePartyCharges().stream()
                                    .filter(casePartyCharge ->
                                            Objects.equals(casePartyCharge.getIsDeleted(), 0L))
                                    .map(CasePartyCharge::getChargeId)
                                    .collect(Collectors.toList());
                            valueMap.put("partyCharges", casePartyChargesList);
                            return valueMap;

                        }).collect(Collectors.toList());
        try {
            casePartyListJson = jsonMapper.writeValueAsString(casePartyValueMap);
        } catch (JsonProcessingException jsonProcessingException) {
            LOGGER.error("JsonProcessingException occurred while reading getCasePartyListJson. ",
                    jsonProcessingException);
        }
        return casePartyListJson;
    }

    /**
     * Modifying Notes in session
     */
    @Override
    public List<CaseNoteDto> modifyNote(EditNoteCommand command) {
        List<CaseNoteDto> noteDtosInSession = command.getCaseNoteDtoList();
        noteDtosInSession.stream().filter(
                caseNoteDtoFromSession -> Objects
                        .equals(caseNoteDtoFromSession.getViewId(), command.getNoteKey().id())
        )
                .forEach(caseNoteDtoFromSession -> {
                    caseNoteDtoFromSession.setTextNote(command.getNoteText());
                    caseNoteDtoFromSession.setDisplayTextNote(command.getNoteText());
                });

        return noteDtosInSession;
    }

    /**
     * Removing Notes from Session
     */
    @Override
    public List<CaseNoteDto> removeNote(DeleteNoteCommand command) {
        List<CaseNoteDto> caseNoteDtoList = command.getCaseNoteDtoList();

        caseNoteDtoList.stream()
                .filter(
                        caseNoteDto -> Objects.equals(caseNoteDto.getViewId(), command.getNoteKey().id())
                                && caseNoteDto.getId() != 0L)
                .forEach(caseNoteDto -> caseNoteDto.setIsDeleted(1L));
        caseNoteDtoList.removeIf(
                caseNoteDto -> Objects.equals(caseNoteDto.getViewId(), command.getNoteKey().id())
                        && caseNoteDto.getId() == 0L);
        return caseNoteDtoList;
    }

    /**
     * Adding notes in the session list
     */
    @Override
    public List<CaseNoteDto> addNote(AddNoteCommand addNoteCommand) {
        List<CaseNoteDto> notesList = addNoteCommand.getCaseNoteDtoList();
        Long lastSavedMaxNoteIdInSession = 0L;

        for (CaseNoteDto noteDto : notesList) {
            if (noteDto.getId() > lastSavedMaxNoteIdInSession) {
                lastSavedMaxNoteIdInSession = noteDto.getViewId();
            }
        }
        CaseNoteDto caseNoteDto = new CaseNoteDto();
        lastSavedMaxNoteIdInSession += 1;
        caseNoteDto.setViewId(lastSavedMaxNoteIdInSession);

        caseNoteDto.setIsDeleted(0L);
        caseNoteDto.setTextNote(addNoteCommand.getNoteText());
        caseNoteDto.setDisplayTextNote(addNoteCommand.getNoteText());

        notesList.add(caseNoteDto);
        return notesList;
    }

    @Override
    public void addTrack(AddTrackCommand command) {
        Case caseEntity = caseRepository.findOne(command.getCaseKey().id());
        trackAction(caseEntity, command.getCaseAction().id(), command.getComments(),command.getUser_login_id());
    }

    @Override
    public void update(UpdateCaseCommand command) {

        Case caseEntity = caseRepository.findOne(command.getCaseKey().id());
        if (caseEntity == null) {
            return;
        }
        CaseDto caseDto = caseMapper.mapToCaseDto(caseEntity);
        Owner owner = new Owner(Enums.constant(Department.class,caseDto.getDepartment().getId()),
                                Enums.constant(Section.class, caseDto.getSection().getId()), command.getUnit());
        Set<CaseParty> caseParties = getCaseParties(command.getCasePartyDtoList());

        Set<CaseNote> caseNotes = getUpdatedArrestNotes(command);
        Set<DocumentInspectionResult> documentInspectionResults = getUpdatedDocumentInspection(command);

        CaseUpdatedEvent event = caseEntity.update(caseParties, command.getAttachmentList(),
                command.getAssociatedCaseList(), caseNotes,
                command.getTransferredFromId(),
                command.getArrestReason(),
                documentInspectionResults, command.getFirNo(), command.getVersion(), command.getCreatedBy(),owner);
        caseRepository.save(caseEntity);

        event.withCasePartiesJson(getCasePartyListJson(caseEntity.getParties()));
        eventBus.publish(event);
    }

    /**
     * Preparing Set of Case Parties with Charges
     *
     * @param casePartyDtoList
     * @return
     */
    private Set<CaseParty> getCaseParties(List<CasePartyDto> casePartyDtoList) {
        Set<CaseParty> caseParties = null;
        if (CollectionUtils.isNotEmpty(casePartyDtoList)) {
            caseParties = casePartyDtoList.stream()
                    .map(casePartyDto -> {
                        Set<CasePartyCharge> casePartyChargeSet = getUpdatedChargesForParty(casePartyDto.getChargeDtoList());
                        CaseParty newCaseParty = new CaseParty(new PartyKey(casePartyDto.getPartyId()), casePartyDto.getPartyType().getId(),
                                casePartyDto.getIsDeleted());
                        newCaseParty.setCreatedBy(casePartyDto.getCreatedBy());
                        if (CollectionUtils.isNotEmpty(casePartyChargeSet)) {
                            newCaseParty.withPartyCharges(casePartyChargeSet);
                        }
                        return newCaseParty;

                    })
                    .collect(Collectors.toSet());
        }
        return caseParties;
    }


    @Override
    public void close(CloseCaseCommand command) {


        NotificationBuilder notificationBuilder = notificationBus.getBuilder();

        if (!Checks.isNotNull(command.getCloseComments()) || command.getCloseComments().isEmpty()) {
            notificationBuilder.add(CaseNotificationCode.COMMENTS_MANDATORY);
            notificationBus.send(notificationBuilder);
        }

        boolean pendingOrders = false;

        RetrieveOrderListQuery retrieveOrderListQuery = new RetrieveOrderListQuery(command.getCaseKey());
        List<OrderDto> orderDtoList = orderQueryService.retrieveOrderList(retrieveOrderListQuery);

        for (OrderDto orderDto : orderDtoList) {
            if (orderDto.getStatus().getId().longValue() == OrderStatus.COMPLETED.id() || orderDto.getStatus().getId().longValue() == OrderStatus.CANCELLED.id()) {
                pendingOrders = false;
            } else {
                pendingOrders = true;
                break;
            }
        }

        if (pendingOrders) {
            notificationBuilder.add(CaseNotificationCode.PENDING_ORDERS);
            notificationBus.send(notificationBuilder);
        }

        Case caseEntity = caseRepository.findOne(command.getCaseKey().id());




        if (caseEntity == null) {
            LOGGER.error("Arrest Report Not found for Given Id ", command.getCaseKey().id());
            notificationBuilder.add(CaseNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
            notificationBus.send(notificationBuilder);
        } else {
            CaseClosedEvent event = caseEntity.close(command.getCloseComments());
            // Persist the arrest report domain
            caseRepository.save(caseEntity);

            //Storing Action in History table.
            trackAction(caseEntity, CaseAction.CLOSE.id(), command.getCloseComments());

            eventBus.publish(event);
        }

    }

    @Override
    public void reOpen(ReOpenCaseCommand command) {

        Case caseEntity = caseRepository.findOne(command.getCaseKey().id());

        if (caseEntity == null) {
            LOGGER.error("Arrest Report Not found for Given Id ", command.getCaseKey().id());

            notificationBus.send(CaseNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
        } else {
            CaseReopenedEvent event = caseEntity.reopen();
            // Persist the arrest report domain
            caseRepository.save(caseEntity);

            //Storing Action in History table.
            trackAction(caseEntity, CaseAction.REOPEN.id(), null);

            eventBus.publish(event);
        }

    }

    @Override
    public void approve(ApproveCaseCommand command) {
        NotificationBuilder notificationBuilder = notificationBus.getBuilder();


        Case caseEntity = caseRepository.findOne(command.getCaseKey().id());

        if (caseEntity == null) {
            LOGGER.error("Arrest Report Not found for Given Id ", command.getCaseKey().id());
            notificationBuilder.add(CaseNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
            notificationBus.send(notificationBuilder);
        } else {
            CaseApprovedEvent event = caseEntity.approve(command.getApproveComments());
            // Persist the arrest report domain
            caseRepository.save(caseEntity);

            //Storing Action in History table.
            trackAction(caseEntity, CaseAction.APPROVE.id(), command.getApproveComments());

            eventBus.publish(event);
        }

    }

    @Override
    public void reject(RejectCaseCommand command) {
        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        if (!Checks.isNotNull(command.getRejectComments()) || command.getRejectComments().isEmpty()) {
            notificationBuilder.add(CaseNotificationCode.COMMENTS_MANDATORY);
            notificationBus.send(notificationBuilder);
        }

        Case caseEntity = caseRepository.findOne(command.getCaseKey().id());

        if (caseEntity == null) {
            LOGGER.error("Arrest Report Not found for Given Id ", command.getCaseKey().id());
            notificationBuilder.add(CaseNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
            notificationBus.send(notificationBuilder);
        } else {
            CaseRejectedEvent event = caseEntity.reject(command.getRejectComments());
            // Persist the arrest report domain
            caseRepository.save(caseEntity);

            //Storing Action in History table.
            trackAction(caseEntity, CaseAction.REJECT.id(), command.getRejectComments());

            eventBus.publish(event);
        }

    }

    @Override
    public void review(ReviewCaseCommand command) {
        NotificationBuilder notificationBuilder = notificationBus.getBuilder();

        Case caseEntity = caseRepository.findOne(command.getCaseKey().id());

        if (caseEntity == null) {
            LOGGER.error("Arrest Report Not found for Given Id ", command.getCaseKey().id());
            notificationBuilder.add(CaseNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
            notificationBus.send(notificationBuilder);
        } else {
            CaseReviewedEvent event = caseEntity.review(command.getReviewComments());
            // Persist the arrest report domain
            caseRepository.save(caseEntity);

            //Storing Action in History table.
            trackAction(caseEntity, CaseAction.FORWARD_TO_SUPERVISOR.id(), command.getReviewComments());
            eventBus.publish(event);
        }


    }

    /**
     * Case Manual Transfer Method for manually transferring to another department
     */
    @Override
    public void manualTransfer(ManualTransferCaseCommand command) {
        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        if (Checks.isNotValidLookUpId(command.getManualTransferTo())) {
            notificationBuilder.add(CaseNotificationCode.TRANSFER_DEPARTMENT_MANDATORY);
            notificationBus.send(notificationBuilder);
        }
        if (command.getTransferComments() == null) {
            notificationBuilder.add(CaseNotificationCode.COMMENTS_MANDATORY);
            notificationBus.send(notificationBuilder);
        }

        Case caseEntity = caseRepository.findOne(command.getCaseKey().id());

        if (caseEntity == null) {
            LOGGER.error("Arrest Report Not found for Given Id ", command.getCaseKey().id());
            notificationBuilder.add(CaseNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
            notificationBus.send(notificationBuilder);
        } else {
            CaseManualTransferEvent event = caseEntity.manualTransfer(command.getTransferComments(),
                    command.getManualTransferTo());
            // Persist the arrest report domain
            caseRepository.save(caseEntity);

            //Storing Action in History table.
            trackAction(caseEntity, CaseAction.MANUAL_TRANSFER.id(), command.getTransferComments());
            eventBus.publish(event);
        }


    }

    @Override
    public void transferToCRM(TransferToCaseCommand command) {
        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        if (command.getTransferComments() == null) {
            notificationBuilder.add(CaseNotificationCode.COMMENTS_MANDATORY);
            notificationBus.send(notificationBuilder);
        }
        if (command.getDepartment() == null) {
            notificationBuilder.add(CaseNotificationCode.COMMENTS_MANDATORY);
            notificationBus.send(notificationBuilder);
        } else {
            Case caseEntity = caseRepository.findOne(command.getCaseKey().id());
            CaseTransferredToCRMEvent event =
                    caseEntity.transferTo(command.getDepartment(), command.getSection(),
                            command.getTransferComments());
            // Persist the arrest report domain
            caseRepository.save(caseEntity);

            //Storing Action in History table.
            trackAction(caseEntity, CaseAction.TRANSFERRED_TO.id(), command.getTransferComments());
            eventBus.publish(event);
        }

    }

    /**
     * Method to recieve Case Manually
     *
     * @param command
     */
    @Override
    public void caseAssignment(AssignCaseCommand command) {
        Case caseEntity = caseRepository.findOne(command.getCaseKey().id());
        CaseAssignedEvent event = caseEntity.assignUser(command.getUserId());
        caseRepository.save(caseEntity);
        eventBus.publish(event);
    }

    @Override
    public void manualReceive(ManualReceiveCaseCommand command) {
        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        if (Checks.isNotValidLookUpId(command.getManualReceivedFrom().getId())) {
            notificationBuilder.add(CaseNotificationCode.TRANSFER_DEPARTMENT_MANDATORY);
            notificationBus.send(notificationBuilder);
        }
        if (command.getReceiveComments() == null) {
            notificationBuilder.add(CaseNotificationCode.COMMENTS_MANDATORY);
            notificationBus.send(notificationBuilder);
        }

        Case caseEntity = caseRepository.findOne(command.getCaseKey().id());

        if (caseEntity == null) {
            LOGGER.error("Arrest Report Not found for Given Id ", command.getCaseKey().id());
            notificationBuilder.add(CaseNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
            notificationBus.send(notificationBuilder);
        } else {
            CaseManualReceiveEvent event = caseEntity.manualReceive(command.getReceiveComments(),
                    command.getManualReceivedFrom());
            // Persist the arrest report domain
            caseRepository.save(caseEntity);

            //Storing Action in History table.
            trackAction(caseEntity, CaseAction.MANUAL_RECEIVE.id(), command.getReceiveComments());
            eventBus.publish(event);
        }

    }

    /**
     * Method is to create Transferred Case to Detective Section, It will fetch case which needs to be transferred to Detective Department and create
     * new case by doing deep cloning the case. After cloning Case, all child entities id will be set to null, so that Hibernate will be considering cloned
     * object as new and create new CASE.
     * Case Track will not be cloned and initial state of Case will be transferred.
     * Method will also store transfer details in Database and mark it Not received
     * @ command TransferCaseCommand
     * @return CreateCaseResult which hold new CaseKey
     */
    @Override
    public CreateCaseResult createTransferredCase(TransferCaseCommand command) {

        LOGGER.entry();

        Case oldCase = (Case) persistentUtil.retrieveFullFetchedEntity(CaseConstants.CASE_DB_PROFILE,
                Case.class,
                command.getOldCaseKey().id());
        // Cloning Case which needs to be transferred, so that existing case is not touched.
        Case aCase = (Case) ReflectionUtil.deepClone(oldCase);

        if (aCase != null ){
            //Setting null for Id of Case Party so that hibernate consider this as new record
            Set<CaseParty> caseParties = getCaseParties(command.getTransferredCasePartyDtoList());
            //Setting null for Id of Case Attachment so that hibernate consider this as new record
            aCase.getAttachments().forEach(attachment -> attachment.setId(null));
            //Setting null for Id of Case Notes so that hibernate consider this as new record
            aCase.getNotes().forEach(note -> {
                NoteKey noteKey = caseNoteKeyProvider.next();
                note.setId(noteKey.id());
            });
            //Setting null for Id of Case Association so that hibernate consider this as new record
            aCase.getCaseAssociations().forEach(caseAssociation -> caseAssociation.setId(null));
            //Setting null for Id of document inspection so that hibernate consider this as new record
            aCase.getDocumentInspections().forEach(documentInspection -> documentInspection.setId(null));


            CaseKey newCaseKey = caseKeyProvider.next();
            Owner owner = new Owner(Department.DETECTIVE, Section.CRM, null);
            TrackerKey trackerKey = command.getTrackerKey();
            if (trackerKey == null) {
                // For BorderControl flow, use the tracker key set within the command object.
                trackerKey = trackerKeyProvider.next();
            }

            String caseNumber;
            Long year = (long) Calendar.getInstance().get(Calendar.YEAR);
            BooleanExpression predicate;
            do {
                caseNumber = incidentNumberProvider.next(Department.DETECTIVE.id(), Section.CRM.id(), ModuleTypes.CRM.name());
                predicate = QCase.case$.caseNumber.eq(caseNumber).and(QCase.case$.year.eq(year)
                        .and(QCase.case$.owner.department.eq(Department.DETECTIVE.id())).and(QCase.case$.owner.section.eq(Section.CRM.id())));
            }
            while (Checks.isNotNull(caseRepository.findOne(predicate)));
            // Creating Transferred Case Created Event
            TransferredCaseCreatedEvent event = aCase.transferredCaseCreate(command.getOldCaseKey(), trackerKey, newCaseKey,
                    caseNumber, owner,caseParties,command.getArrestReportKey());


            caseRepository.save(aCase);
            //SEtting track
            trackAction(aCase, CaseAction.TRANSFERRED_TO.id(), null);
            //Setting Transfer Details
            CaseDto caseDto = caseMapper.mapToCaseDto(oldCase);
            // Storing Case Transfer Details information in newly Created table.
            CaseTransferDetail caseTransferDetail = new CaseTransferDetail.Builder(
                    aCase.id(),caseDto.getDepartment().getId(),caseDto.getSection().getId(),CaseStatus.NOTRECEIVED.id()
            ).build().withTransferredCaseId(command.getOldCaseKey().id());
            caseTransferDetailRepository.save(caseTransferDetail);
            //Throwing Event
            eventBus.publish(event);

            return new CreateCaseResult(newCaseKey, caseNumber);
        }


        return null;
    }

    /**
     * Method is for receiving Transferred Case
     * @param receivedBy
     * @param caseTransferKey
     */
    @Override
    public void receiveTransferredCase (String receivedBy, CaseTransferKey caseTransferKey){
        CaseTransferDetail caseTransferDetail = caseTransferDetailRepository.findOne(caseTransferKey.id());
        caseTransferDetail.withReceivedBy(receivedBy);
        caseTransferDetail.withReceivedStatus(CaseStatus.RECEIVED.id());
        //Updating Case Transfer Detail
        caseTransferDetailRepository.save(caseTransferDetail);

        CaseTransferDetailDto dto = caseTransferDetailMapper.mapToDto(caseTransferDetail);
        //Updating Case  Detail
        Case aCase = caseRepository.findOne(dto.getCaseId());
        aCase.withLatestSection(Section.CRM.id());
        aCase.withCreatedBy(receivedBy);
        caseRepository.save(aCase);
        trackAction(aCase, CaseAction.RECEIVE.id(), null);
        //Updating Track
    }

    /**
     * Method is to transfer case to internal department in border control
     * @param command wrapper providing information for Transfer
     */
    @Override
    public void forwardToInternalSection(TransferToCaseCommand command) {
        LOGGER.entry();
        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        if (command.getTransferComments() == null) {
            LOGGER.info("Transfer Comments not found");
            notificationBuilder.add(CaseNotificationCode.COMMENTS_MANDATORY);
            notificationBus.send(notificationBuilder);
        }

        Case caseEntity = caseRepository.findOne(command.getCaseKey().id());

        if (caseEntity == null) {
            LOGGER.error("Arrest Report Not found for Given Id ", command.getCaseKey().id());
            notificationBuilder.add(CaseNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
            notificationBus.send(notificationBuilder);
        } else {
            CaseTransferredToSectionEvent event = caseEntity.transferToSection(command.getSection().id(), command.getTransferComments());
            // Persist the arrest report domain
            caseRepository.save(caseEntity);

            //Storing Action in History table.
            trackAction(caseEntity, CaseAction.FORWARD.id(), command.getTransferComments());
            eventBus.publish(event);
        }
        LOGGER.exit();
    }

    /**
     * Method is to return the case to section from where it came for processing
     * @param command wrapper providing information for Transfer
     */
    @Override
    public void returnToOriginalSection(ReturnCaseCommand command) {
        LOGGER.info("Returning case " + command.getCaseKey().id());
        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        if (command.getReturnComments() == null) {
            LOGGER.info("Transfer Comments not found");
            notificationBuilder.add(CaseNotificationCode.COMMENTS_MANDATORY);
            notificationBus.send(notificationBuilder);
        }

        Case caseEntity = caseRepository.findOne(command.getCaseKey().id());

        if (caseEntity == null) {
            LOGGER.error("Case Not found for Given Id ", command.getCaseKey().id());
            notificationBuilder.add(CaseNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
            notificationBus.send(notificationBuilder);
        } else {
            CaseTransferredToSectionEvent event = caseEntity.transferToOriginalSection(command.getReturnComments());
            // Persist the arrest report domain
            caseRepository.save(caseEntity);

            //Storing Action in History table.
            trackAction(caseEntity, CaseAction.RETURN.id(), command.getReturnComments());
            eventBus.publish(event);
        }
        LOGGER.exit();
    }

    /**
     * Method to save Case Actions
     *
     * @param caseEntity
     * @param actionId
     * @param comments
     */
    private void trackAction(Case caseEntity, Long actionId, String comments) {

        //Storing Status in History Table.
        CaseActionHistory caseActionHistory =
                new CaseActionHistory.Builder(caseEntity.id())
                        .withActionId(actionId)
                        .withComments(comments)
                        .build();
        caseActionHistoryRepository.save(caseActionHistory);
    }
    private void trackAction(Case caseEntity, Long actionId, String comments, String userLoginId) {

        //Storing Status in History Table.
        CaseActionHistory caseActionHistory =
                new CaseActionHistory.Builder(caseEntity.id())
                        .withActionId(actionId)
                        .withComments(comments)
                        .withUserId(userLoginId)
                        .build();
        caseActionHistoryRepository.save(caseActionHistory);
    }

    private Set<CaseNote> getUpdatedArrestNotes(UpdateCaseCommand command) {

        Set<CaseNote> caseNotes = null;
        if (CollectionUtils.isNotEmpty(command.getCaseNoteDtoList())) {

            caseNotes = command.getCaseNoteDtoList().stream()
                    .map(caseNoteDto -> {
                        if (caseNoteDto.getId() == 0L) {
                            NoteKey newNoteKey = caseNoteKeyProvider.next();
                            return new CaseNote(newNoteKey, caseNoteDto.getTextNote(),
                                    0L);
                        } else {
                            NoteKey noteKey = new NoteKey(caseNoteDto.getId());
                            return new CaseNote(noteKey, caseNoteDto.getTextNote(), caseNoteDto.getIsDeleted());
                        }
                    })
                    .collect(Collectors.toSet());
        }
        return caseNotes;
    }

    private Set<DocumentInspectionResult> getUpdatedDocumentInspection(UpdateCaseCommand command) {
        Set<DocumentInspectionResult> documentInspectionResults = null;
        if (CollectionUtils.isNotEmpty(command.getDocumentInspectionDtoList())) {

            documentInspectionResults = command.getDocumentInspectionDtoList().stream()
                    .map(documentInspectionDto -> {
                        if (documentInspectionDto.getId() == 0L) {

                            return new DocumentInspectionResult(
                                    documentInspectionDto.getDocumentType().getId(),
                                    documentInspectionDto.getDocumentInspectionResultType().getId(),
                                    documentInspectionDto.getTextNote());
                        } else {

                            DocumentInspectionResult result = new DocumentInspectionResult(
                                    documentInspectionDto.getDocumentType().getId(),
                                    documentInspectionDto
                                            .getDocumentInspectionResultType()
                                            .getId(),
                                    documentInspectionDto.getTextNote());
                            result.setId(documentInspectionDto.getId());
                            return result;
                        }
                    })
                    .collect(Collectors.toSet());
        }
        return documentInspectionResults;
    }

    private Set<CasePartyCharge> getUpdatedChargesForParty(List<ChargeDto> chargeDtoList) {

        Set<CasePartyCharge> casePartyCharges = null;
        if (CollectionUtils.isNotEmpty(chargeDtoList)) {

            casePartyCharges = chargeDtoList.stream()
                    .map(casePartyChargeDto -> {
                        if (casePartyChargeDto.getChargeId() == 0L) {
                            CasePartyChargeKey newPartyChargeKey = casePartyChargeKeyProvider.next();
                            return new CasePartyCharge(newPartyChargeKey,
                                    casePartyChargeDto.getCharge().getId(),
                                    casePartyChargeDto.getIsDeleted());
                        } else {
                            CasePartyChargeKey chargeKey = new CasePartyChargeKey(casePartyChargeDto.getId());
                            return new CasePartyCharge(chargeKey, casePartyChargeDto.getCharge().getId(), casePartyChargeDto.getIsDeleted());
                        }
                    })
                    .collect(Collectors.toSet());
        }
        return casePartyCharges;
    }
}
