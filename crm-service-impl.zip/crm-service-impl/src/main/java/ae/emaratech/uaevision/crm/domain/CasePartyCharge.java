package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.entity.AbstractEntityBase;
import ae.emaratech.uaevision.fis.common.key.CasePartyChargeKey;
import ae.emaratech.uaevision.lookup.service.annotation.LookupField;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;

import javax.persistence.*;

/**
 * Created by Nitesh.Gupta on 7/31/2016.
 */
@Entity
@Table(name = "CASE_PARTY_CHARGE")
public class CasePartyCharge extends AbstractEntityBase {

    private static final long serialVersionUID = 1L;

    @LookupField(LookupDefinition.CHARGE)
    @Column(name = "CHARGE_ID")
    private Long chargeId;

    @Column(name = "IS_DELETED", nullable = false)
    private Long isDeleted;

    @ManyToOne
    @JoinColumn(name = "PARTY_ID", referencedColumnName = "PARTY_ID", nullable = true)

    private CaseParty casePartyReference;

    public CasePartyCharge() {

    }

    public CasePartyCharge(CasePartyChargeKey key, long chargeId, Long isDeleted) {
        setId(key.id());
        this.chargeId = chargeId;
        this.isDeleted = isDeleted;
    }


    public CaseParty getCasePartyReference() {
        return casePartyReference;
    }

    public void setCasePartyReference(CaseParty casePartyReference) {
        this.casePartyReference = casePartyReference;
    }

    public Long getChargeId() {
        return chargeId;
    }

    public void setChargeId(Long chargeId) {
        this.chargeId = chargeId;
    }


    public Long getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Long isDeleted) {
        this.isDeleted = isDeleted;
    }


}
