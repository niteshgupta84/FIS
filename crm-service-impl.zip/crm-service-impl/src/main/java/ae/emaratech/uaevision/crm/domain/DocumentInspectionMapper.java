package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.application.dto.DocumentInspectionDto;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by Nitesh.Gupta on 7/3/2016.
 */
@Component
public class DocumentInspectionMapper {

    @Autowired
    private LookupService lookupService;


    @Autowired
    private UserService userService;

    public DocumentInspectionDto mapToDocumentInspectionDto(
            DocumentInspectionResult documentInspectionResult) {
        DocumentInspectionDto documentInspectionDto = new DocumentInspectionDto();

        documentInspectionDto.setViewId(documentInspectionResult.getId());
        documentInspectionDto.setId(documentInspectionResult.getId());
        documentInspectionDto.setCreatedBy(userService.getUserFirstNameByUserLogin(documentInspectionResult.getCreatedBy()));
        documentInspectionDto.setTextNote(documentInspectionResult.getNote());
        documentInspectionDto.setCreatedDate(documentInspectionResult.getCreatedDate());
        if (Checks.isNotNull(documentInspectionResult.getDocumentTypeId())) {
            documentInspectionDto.setDocumentType(
                    lookupService.getLookupEntry(LookupDefinition.ID_DOC_TYPE,
                            LocaleContextHolder.getLocale(),
                            documentInspectionResult.getDocumentTypeId())
                            .get()
            );
        }
        if (Checks.isNotNull(documentInspectionResult.getDocumentInspResultTypeId())) {
            documentInspectionDto.setDocumentInspectionResultType(
                    lookupService.getLookupEntry(LookupDefinition.DOC_INSPECTION_RESULT,
                            LocaleContextHolder.getLocale(),

                                    documentInspectionResult.getDocumentInspResultTypeId())
                            .get()
            );
        }
        return documentInspectionDto;
    }

    /**
     * Preparing Note List from Set
     */
    public List<DocumentInspectionDto> mapToDocumentInspectionList(
            Set<DocumentInspectionResult> documentInspectionResults) {
        List<DocumentInspectionDto> documentInspectionResultsList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(documentInspectionResults)) {
            documentInspectionResultsList.addAll(
                    documentInspectionResults.stream().map(this::mapToDocumentInspectionDto)
                            .collect(Collectors.toList()));
        }
        return documentInspectionResultsList;

    }

}
