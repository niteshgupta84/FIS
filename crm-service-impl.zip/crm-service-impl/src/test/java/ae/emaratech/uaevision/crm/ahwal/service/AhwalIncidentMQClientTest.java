package ae.emaratech.uaevision.crm.ahwal.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.jms.Queue;

import ae.emaratech.uaevision.crm.ahwal.remote.AhwalCaseRequestMessage;
import ae.emaratech.uaevision.fis.gateway.message.Client.GenericMessageProducerClient;

import static org.mockito.Mockito.mock;

/**
 * Test class providing unit test cases for {@link AhwalIncidentMQClient}
 *
 * @author Haroon.Subair
 */
@RunWith(MockitoJUnitRunner.class)
public class AhwalIncidentMQClientTest {

  @InjectMocks
  private AhwalIncidentMQClient _test;

  @Mock
  private GenericMessageProducerClient genericMessageProducerClient;

  /*@Mock
  private Queue ahwalIncidentResponseQueue;*/

  @Test
  public void shouldSendSuccessAcknowledgement() {

    AhwalCaseRequestMessage requestMessage = mock(AhwalCaseRequestMessage.class);
    _test.sendSuccessAcknowledgement(requestMessage, "123");
  }

  @Test
  public void shouldSendFailureAcknowledgement() {

    AhwalCaseRequestMessage requestMessage = mock(AhwalCaseRequestMessage.class);
    _test.sendFailureAcknowledgement(requestMessage, "ERROR_MESSAGE");
  }

  @Test
  public void shouldSendFailureAcknowledgementForNullRequest() {

    _test.sendFailureAcknowledgement(null, "ERROR_MESSAGE");
  }

  @Test
  public void shouldSendDeportResultToVision() {

    AhwalCaseRequestMessage requestMessage = mock(AhwalCaseRequestMessage.class);
    _test.sendDeportResultToVision("123", "123");
  }

}
