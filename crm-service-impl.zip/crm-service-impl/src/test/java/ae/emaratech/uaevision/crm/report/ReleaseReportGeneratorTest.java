package ae.emaratech.uaevision.crm.report;

/**
 * Created by Wasib.Khan on 5/28/2016.
 */

import ae.emaratech.uaevision.fis.report.core.FISReportFormat;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperReportGenerator;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.doReturn;


@RunWith(MockitoJUnitRunner.class)
public class ReleaseReportGeneratorTest {

    @InjectMocks
    ReleaseReportGenerator releaseReportGenerator;
    @Mock
    private ReleaseReportDataSource releaseReportDataSource;
    @Mock
    private JasperReportGenerator jasperReportGenerator;

    static void setFinalStatic(Field field, Object newValue) throws Exception {
        field.setAccessible(true);

        // remove final modifier from field
        Field modifiersField = Field.class.getDeclaredField("modifiers");
        modifiersField.setAccessible(true);
        modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);

        field.set(null, newValue);
    }

    @Before
    public void setup() throws Exception {

        //setFinalStatic(InterrogationReportGenerator.class.getField("JASPER_TEMPLATE"), "interrogation-report"); // For a String
        MockitoAnnotations.initMocks(this);


    }

    @Test
    public void shouldGenerateReportIfReportParameterPassed() throws Exception {
        List<Map> objects = new ArrayList<>();
        Map<String, String> resultSet = new HashMap<>();

        objects.add(resultSet);
        ReportParameters reportParameters = new ReportParameters();
        JRBeanCollectionDataSource source = new JRBeanCollectionDataSource(objects);
        byte[] content = new byte[1];

        doReturn(source).when(releaseReportDataSource).getDataSource(reportParameters);
        doReturn(content).when(jasperReportGenerator).generateReport("Wasib", new HashMap(), source);
        releaseReportGenerator.generateReport(reportParameters, FISReportFormat.PDF);
    }
}
