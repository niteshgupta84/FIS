package ae.emaratech.uaevision.crm.report;

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportDto;
import ae.emaratech.uaevision.arrest.query.ArrestQueryService;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestQuery;
import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.crm.query.CaseQueryService;
import ae.emaratech.uaevision.document.application.AttachedDocumentDto;
import ae.emaratech.uaevision.document.service.api.DocumentService;
import ae.emaratech.uaevision.document.service.dto.ContentType;
import ae.emaratech.uaevision.document.service.dto.DocumentInfoDto;
import ae.emaratech.uaevision.document.service.dto.DocumentReferenceDto;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;

/**
 * Created by Nitesh.Gupta on 8/10/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class AttachmentReportDataSourceTest {

    @Mock
    CaseQueryService caseQueryService;

    @Mock
    DocumentService documentService;

    @Mock
    ArrestQueryService arrestQueryService;
    @InjectMocks
    private AttachmentReportDataSource _test;

    @Test
    public void shouldGenerateReport() {
        ReportParameters reportParameters = new ReportParameters();
        reportParameters.addParameter("CASE_ID", 12);

        CaseDto caseDto = new CaseDto();
        caseDto.setId(1L);
        caseDto.setCaseNumber("incident number");
        caseDto.setCreatedBy("incident number");
        caseDto.setCreatedDate(new Date());
        caseDto.setDepartment(new Entry(1L, "Investigation"));
        caseDto.setSection(new Entry(1L, "Section"));
        caseDto.setStatus(new Entry(1L, "Status"));
        AttachedDocumentDto attachedDocumentDto = new AttachedDocumentDto();
        List<AttachedDocumentDto> list = new ArrayList<>();
        attachedDocumentDto.setDocumentTypeId(1L);
        attachedDocumentDto.setDocumentType("1");
        attachedDocumentDto.setDocumentInfo(new DocumentInfoDto("Test", ContentType.PDF));
        list.add(attachedDocumentDto);
        caseDto.setCaseAttachmentDtoList(list);
        ArrestReportDto arrestReportDto = new ArrestReportDto();
        arrestReportDto.setId(1L);
        arrestReportDto.setArrestReportNumber("incident number");
        arrestReportDto.setCreatedBy("incident number");
        arrestReportDto.setCreatedDate(new Date());
        arrestReportDto.setDepartment(new Entry(1L, "Investigation"));
        arrestReportDto.setSection(new Entry(1L, "Section"));
        arrestReportDto.setStatus(new Entry(1L, "Status"));
        arrestReportDto.setArrestDate(new Date());
        arrestReportDto.setArrestAttachmentDtoList(list);
        byte[] photo = new byte[1];
        DocumentReferenceDto documentReferenceDto = new DocumentReferenceDto();
        documentReferenceDto.setAttachment(photo);
        doReturn(documentReferenceDto).when(documentService).downloadDocument(any());
        doReturn(arrestReportDto).when(arrestQueryService)
                .retrieveArrestReport(any(RetrieveArrestQuery.class));


    }
}
