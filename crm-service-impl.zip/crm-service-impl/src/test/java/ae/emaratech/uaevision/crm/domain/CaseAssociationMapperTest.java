package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.key.AssociatedCaseKey;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Nitesh.Gupta on 7/12/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class CaseAssociationMapperTest {

    @InjectMocks
    CaseAssociationMapper _test;
    @Mock
    protected UserService userDetailsService;

    @Test
    public void shouldReturnAssociationDto() {
        Case caseData = CaseDataConstants.getCaseData();
        CaseAssociation caseAssociation = new CaseAssociation(new AssociatedCaseKey(1L));
        caseAssociation.setId(1L);
        caseAssociation.setCaseReference(caseData);
        caseAssociation.setCreatedDate(new Date());
        caseAssociation.setCreatedBy("Nitesh");
        assertThat(_test.mapCaseAssociationDto(caseAssociation)).isNotNull();
        assertThat(caseAssociation.getCaseReference()).isNotNull();
        assertThat(caseAssociation.getCreatedDate()).isNotNull();
        assertThat(caseAssociation.getCreatedBy()).isNotNull();
        assertThat(caseAssociation.getAssociatedCaseId()).isNotNull();
    }

    @Test
    public void shouldReturnAssociationDtoList() {
        Case caseData = CaseDataConstants.getCaseData();
        CaseAssociation caseAssociation = new CaseAssociation(new AssociatedCaseKey(1L));
        caseAssociation.setCaseReference(caseData);
        caseAssociation.setCreatedDate(new Date());
        caseAssociation.setId(1L);
        caseAssociation.setCreatedBy("Nitesh");
        Set<CaseAssociation> caseAssociations = new HashSet<>();
        caseAssociations.add(caseAssociation);
        assertThat(_test.mapCaseAssociationDtoList(caseAssociations)).isNotNull();
    }
}
