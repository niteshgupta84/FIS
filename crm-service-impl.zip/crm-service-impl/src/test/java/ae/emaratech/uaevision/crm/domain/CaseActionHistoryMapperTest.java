package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.application.dto.CaseTrackDto;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static org.assertj.core.api.StrictAssertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;

/**
 * Created by Nitesh.Gupta on 4/2/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class CaseActionHistoryMapperTest {

    @Mock
    LookupService lookupService;
    @InjectMocks
    CaseActionHistoryMapper caseActionHistoryMapper;

    @Mock
    protected UserService userDetailsService;

    /**
     * Testing if Dto is mapped by providing Entity
     */
    @Test
    public void shouldReturnDtoFromEntity() {

        Entry entry = new Entry(1L, "lk_key");
        Optional option = Optional.of(entry);
        doReturn(option).when(lookupService).getLookupEntry(any(), any(), any());

        CaseActionHistory caseActionHistory = new CaseActionHistory.Builder(1L)
                .withActionId(1L).withComments("Nitesh").build();

        CaseTrackDto
                caseTrackDto =
                caseActionHistoryMapper.mapCaseTrackDto(caseActionHistory);
        assertThat(caseTrackDto).isNotNull();

    }
}
