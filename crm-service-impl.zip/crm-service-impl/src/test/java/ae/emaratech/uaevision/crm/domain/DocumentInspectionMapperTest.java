package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

/**
 * Created by Nitesh.Gupta on 6/20/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentInspectionMapperTest {

    @Mock
    private LookupService lookupService;
    @Mock
    private UserService userService;

    @InjectMocks
    DocumentInspectionMapper _test;

    @Test
     public void shouldMapToDocumentInspectionDto(){
        Optional<Entry> entry = Optional.of(new Entry(1L, "Test"));
        doReturn(entry).when(lookupService).getLookupEntry(any(), any(), any());
        DocumentInspectionResult documentInspectionResult = mock(DocumentInspectionResult.class);
        doReturn(1L).when(documentInspectionResult).getDocumentTypeId();
        doReturn(1L).when(documentInspectionResult).getDocumentInspResultTypeId();
        doReturn("test").when(userService).getUserFirstNameByUserLogin(anyString());
        assertThat(_test.mapToDocumentInspectionDto(documentInspectionResult)).isNotNull();
    }
    @Test
    public void shouldMapToDocumentInspectionList(){
        Optional<Entry> entry = Optional.of(new Entry(1L, "Test"));
        doReturn(entry).when(lookupService).getLookupEntry(any(), any(), any());
        DocumentInspectionResult documentInspectionResult = mock(DocumentInspectionResult.class);
        Set<DocumentInspectionResult> set = new HashSet<>();
        set.add(documentInspectionResult);
        doReturn(1L).when(documentInspectionResult).getDocumentTypeId();
        doReturn(1L).when(documentInspectionResult).getDocumentInspResultTypeId();
        doReturn("test").when(userService).getUserFirstNameByUserLogin(anyString());
        assertThat(_test.mapToDocumentInspectionList(set)).isNotNull();
    }
}
