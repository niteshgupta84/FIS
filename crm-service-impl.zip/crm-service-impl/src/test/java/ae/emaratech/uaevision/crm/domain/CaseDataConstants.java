package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.arrest.domain.ArrestReason;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.key.TrackerKey;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;
import ae.emaratech.uaevision.lookup.service.model.Entry;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by Nitesh.Gupta on 7/10/2016.
 */
public class CaseDataConstants {

  public static Case getCaseData() {

    CaseKey caseKey = new CaseKey(1L);
    Set<CaseParty> caseParties = new HashSet<>();
    CaseParty caseParty = new CaseParty(new PartyKey(1L));
    ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
    caseParties.add(caseParty);
    ArrestReason arrestReason = new ArrestReason(9999L);

    Owner owner = new Owner(Department.DETECTIVE, Section.CRM, null);
    Case caseEntity =
        new Case(caseKey, arrestReportKey, owner, caseParties, Section.CRM, new Entry(1L),
                 arrestReason, "111", "test", new TrackerKey(1022L),"");
    return caseEntity;
  }


}
