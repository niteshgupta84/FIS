package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.arrest.domain.ArrestAction;
import org.junit.Test;

import static org.assertj.core.api.StrictAssertions.assertThat;

/**
 * Created by Nitesh.Gupta on 6/29/2016.
 */

public class CaseActionHistoryTest {

    @Test
    public void shouldReturnArrestHistoryBuilder() {
        CaseActionHistory caseActionHistory =
                new CaseActionHistory.Builder(1L)
                        .withActionId(ArrestAction.CLOSE.id())
                        .withComments("closeComment")
                        .build();
        caseActionHistory.getId();
        caseActionHistory.getCreatedBy();
        caseActionHistory.getCreatedDate();
        caseActionHistory.getCaseActionId();
        caseActionHistory.getCaseId();
        caseActionHistory.getComments();
        assertThat(caseActionHistory).isNotNull();

    }
}
