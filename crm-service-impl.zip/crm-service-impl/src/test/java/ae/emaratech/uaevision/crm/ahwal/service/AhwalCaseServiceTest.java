package ae.emaratech.uaevision.crm.ahwal.service;

import ae.emaratech.uaevision.fis.common.query.RetrieveByUDBQueryCommon;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.i18n.LocaleContextHolder;

import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Optional;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import ae.emaratech.uaevision.arrest.application.ArrestReportApplicationService;
import ae.emaratech.uaevision.arrest.application.CreateArrestReportCommand;
import ae.emaratech.uaevision.arrest.application.CreateArrestReportResult;
import ae.emaratech.uaevision.crm.ahwal.remote.AhwalCasePartyRequestMessage;
import ae.emaratech.uaevision.crm.ahwal.remote.AhwalCaseRequestMessage;
import ae.emaratech.uaevision.crm.ahwal.remote.Attachment;
import ae.emaratech.uaevision.crm.ahwal.remote.MimeType;
import ae.emaratech.uaevision.crm.application.CreateCaseCommand;
import ae.emaratech.uaevision.crm.application.CreateCaseResult;
import ae.emaratech.uaevision.crm.domain.CaseApplicationService;
import ae.emaratech.uaevision.crm.domain.CasePartyMapper;
import ae.emaratech.uaevision.document.application.AttachedDocumentDto;
import ae.emaratech.uaevision.document.application.PersistAttachmentCommand;
import ae.emaratech.uaevision.document.service.api.DocumentService;
import ae.emaratech.uaevision.document.service.dto.DocumentDto;
import ae.emaratech.uaevision.document.service.dto.DocumentInfoDto;
import ae.emaratech.uaevision.document.service.dto.DocumentKeyDto;
import ae.emaratech.uaevision.fis.common.domain.TrackerKeyProvider;
import ae.emaratech.uaevision.fis.common.exception.BusinessException;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.gateway.api.query.RetrieveByUDBQuery;
import ae.emaratech.uaevision.fis.gateway.incident.UserManagementServiceClient;
import ae.emaratech.uaevision.fis.gateway.usermanagementservice.EmployeeDetail;
import ae.emaratech.uaevision.fis.party.application.CreatePartyCommand;
import ae.emaratech.uaevision.fis.party.application.CreatePartyResult;
import ae.emaratech.uaevision.fis.party.application.ModuleTypes;
import ae.emaratech.uaevision.fis.party.application.PartyService;
import ae.emaratech.uaevision.fis.party.application.PartyTypeEnum;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Test class providing unit test cases for {@link ae.emaratech.uaevision.crm.ahwal.service.AhwalCaseService}
 *
 * @author Haroon.Subair
 */
@RunWith(MockitoJUnitRunner.class)
public class AhwalCaseServiceTest {

  @InjectMocks
  private AhwalCaseService _test;
  @Mock
  private CaseApplicationService caseApplicationService;
  @Mock
  private PartyQueryService partyQueryService;
  @Mock
  private PartyService partyService;
  @Mock
  private LookupService lookupService;
  @Mock
  private UserManagementServiceClient userManagementServiceClient;
  @Mock
  private ArrestReportApplicationService arrestReportApplicationService;
  @Mock
  private DocumentService documentService;
  @Mock
  private CasePartyMapper casePartyMapper;
  @Mock
  private AhwalIncidentMQClient ahwalIncidentMQClient;
  @Mock
  private TrackerKeyProvider trackerKeyProvider;

  @Before
  public void init() {

    EmployeeDetail employeeDetail = mock(EmployeeDetail.class);
    doReturn(Arrays.asList("CreatedByUserName")).when(employeeDetail).getUserLogin();

    doReturn(employeeDetail).when(userManagementServiceClient).getEmployeeByEmployeeId(anyLong());

    PartyDto partyDto = mock(PartyDto.class);
    doReturn("STRING".getBytes()).when(partyDto).getPhoto();
    doReturn(Arrays.asList(partyDto)).when(partyQueryService).retrieveProfile(
        any(RetrieveByUDBQueryCommon.class));

    /*doReturn(partyDto).when(casePartyMapper)
        .getPartyDtoFromAhwalRequest(any(AhwalCaseRequestMessage.class));*/

    doReturn(Optional.of(new Entry("21", "ARREST_REASON1", "0")))
        .when(lookupService).getLookupEntry(LookupDefinition.ARREST_REASON,
                                            LocaleContextHolder.getLocale(),
                                            0L);
    doReturn(Optional.of(new Entry("21", "CHARGE1", "0")))
        .when(lookupService).getLookupEntry(LookupDefinition.CHARGE, 1L);

    doReturn(Optional.of(new Entry("21", "IRIS_LOCATION1", "0"))).when(lookupService)
        .getLookupEntry(LookupDefinition.IRIS_LOCATION, 1L);
    doReturn(Optional.of(new Entry("21", "IRIS_NAME1", "0"))).when(lookupService)
        .getLookupEntry(LookupDefinition.IRIS_NAME_CHANGED, 1L);
    doReturn(Optional.of(new Entry("21", "SHIFT1", "0"))).when(lookupService)
        .getLookupEntry(LookupDefinition.SHIFT, LocaleContextHolder.getLocale(), 1L);
    doReturn(Optional.of(new Entry("21", "ARREST_LOCATION_1", "0"))).when(lookupService)
        .getLookupEntry(LookupDefinition.ARREST_LOCATION_LK, LocaleContextHolder.getLocale(), 1L);
    doReturn(Optional.of(new Entry("21", "PARTY_TYPE_1", "0"))).when(lookupService)
        .getLookupEntry(LookupDefinition.PARTY_TYPE, LocaleContextHolder.getLocale(),
                        PartyTypeEnum.ACCUSED.getId());
    doReturn(Optional.of(new Entry("21", "ID_DOC_TYPE_1", "0"))).when(lookupService)
        .getLookupEntry(LookupDefinition.IDENTIFICATION_DOC_TYPE, LocaleContextHolder.getLocale(),
                        13L);
    doReturn(Optional.of(new Entry("21", "INCIDENT_TYPE_1", "0"))).when(lookupService)
        .getLookupEntry(LookupDefinition.INCIDENT_TYPE, LocaleContextHolder.getLocale(),
                        ModuleTypes.CRM.id());

    CreatePartyResult result = new CreatePartyResult(new PartyKey(1L));
    doReturn(result).when(partyService).createParty(any(CreatePartyCommand.class));
    CreateArrestReportResult createArrestReportResult =
        new CreateArrestReportResult(new ArrestReportKey(1L));
    doReturn(createArrestReportResult).when(arrestReportApplicationService)
        .create(any(CreateArrestReportCommand.class));
    CreateCaseResult createCaseResult = new CreateCaseResult(new CaseKey(1L), "CASE_NUMBER");
    doReturn(createCaseResult).when(caseApplicationService)
        .createCase(any(CreateCaseCommand.class));

    DocumentInfoDto documentInfoDto = mock(DocumentInfoDto.class);
    DocumentKeyDto documentKeyDto = mock(DocumentKeyDto.class);
    doReturn(documentKeyDto).when(documentInfoDto).getKey();
    doReturn(documentInfoDto).when(documentService).upload(any(DocumentDto.class));
    doReturn(mock(AttachedDocumentDto.class)).when(documentService)
        .persist(any(PersistAttachmentCommand.class));

  }

  @Test(expected = BusinessException.class)
  public void shouldFailCreateAhwalIncidentForEmptyAhwalOfficerEmployeeId() {

    // Prepare test data.
    AhwalCaseRequestMessage requestMessage = mock(AhwalCaseRequestMessage.class);
    doReturn(null).when(requestMessage).getAhwalOfficerEmployeeId();
    //Invoke operation createAhwalIncident on the _test.
    _test.createAhwalIncident(requestMessage);
  }

  @Test(expected = BusinessException.class)
  public void shouldFailCreateAhwalIncidentForInvalidUDBNumber() {

    // Prepare test data.
    AhwalCaseRequestMessage requestMessage = mock(AhwalCaseRequestMessage.class);
    AhwalCasePartyRequestMessage profileInfo = mock(AhwalCasePartyRequestMessage.class);
    doReturn(profileInfo).when(requestMessage).getProfileInfo();
    doReturn(Arrays.asList()).when(partyQueryService).retrieveProfile(
        any(RetrieveByUDBQueryCommon.class));
    //Invoke operation createAhwalIncident on the _test.
    _test.createAhwalIncident(requestMessage);
  }

  @Test(expected = BusinessException.class)
  public void shouldFailCreateAhwalIncidentForInvalidProfile() {

    // Prepare test data.
    AhwalCaseRequestMessage requestMessage = mock(AhwalCaseRequestMessage.class);
    AhwalCasePartyRequestMessage profileInfo = mock(AhwalCasePartyRequestMessage.class);
    doReturn(profileInfo).when(requestMessage).getProfileInfo();
    doReturn(Arrays.asList()).when(partyQueryService).retrieveProfile(
        any(RetrieveByUDBQueryCommon.class));
    //Invoke operation createAhwalIncident on the _test.
    _test.createAhwalIncident(requestMessage);
  }

  @Test(expected = BusinessException.class)
  public void shouldFailCreateAhwalIncidentForEmptyArrestReason() {

    // Prepare test data.
    AhwalCaseRequestMessage requestMessage = mock(AhwalCaseRequestMessage.class);
    doReturn("1").when(requestMessage).getCharges();
    doReturn(null).when(requestMessage).getArrestReasonId();

    AhwalCasePartyRequestMessage profileInfo = mock(AhwalCasePartyRequestMessage.class);
    doReturn(profileInfo).when(requestMessage).getProfileInfo();

    doReturn(Optional.of(new Entry("21", "CHARGE1", "0"))).when(lookupService)
        .getLookupEntry(any(LookupDefinition.class), anyLong());
    //Invoke operation createAhwalIncident on the _test.
    _test.createAhwalIncident(requestMessage);
  }

  @Test(expected = BusinessException.class)
  public void shouldFailCreateAhwalIncidentForInvalidArrestReason() {

    // Prepare test data.
    AhwalCaseRequestMessage requestMessage = mock(AhwalCaseRequestMessage.class);
    doReturn("1").when(requestMessage).getCharges();
    doReturn(1L).when(requestMessage).getArrestReasonId();

    AhwalCasePartyRequestMessage profileInfo = mock(AhwalCasePartyRequestMessage.class);
    doReturn(profileInfo).when(requestMessage).getProfileInfo();

    doReturn(Optional.of(new Entry("21", "CHARGE1", "0"))).when(lookupService)
        .getLookupEntry(any(LookupDefinition.class), anyLong());

    doThrow(BusinessException.class)
        .when(lookupService).getLookupEntry(LookupDefinition.ARREST_REASON,
                                            LocaleContextHolder.getLocale(),
                                            1L);
    //Invoke operation createAhwalIncident on the _test.
    _test.createAhwalIncident(requestMessage);
  }

  @Test(expected = BusinessException.class)
  public void shouldFailCreateAhwalIncidentForEmptyArrestDateTime() {

    // Prepare test data.
    AhwalCaseRequestMessage requestMessage = mock(AhwalCaseRequestMessage.class);
    doReturn("1").when(requestMessage).getCharges();

    AhwalCasePartyRequestMessage profileInfo = mock(AhwalCasePartyRequestMessage.class);
    doReturn(profileInfo).when(requestMessage).getProfileInfo();

    //Invoke operation createAhwalIncident on the _test.
    _test.createAhwalIncident(requestMessage);
  }

  @Test(expected = BusinessException.class)
  public void shouldFailCreateAhwalIncidentForEmptyShift() throws DatatypeConfigurationException {

    // Prepare test data.
    AhwalCaseRequestMessage requestMessage = mock(AhwalCaseRequestMessage.class);
    doReturn("1").when(requestMessage).getCharges();
    doReturn(1L).when(requestMessage).getShiftId();
    GregorianCalendar gregorianCalendar = new GregorianCalendar();
    gregorianCalendar.setTime(Calendar.getInstance().getTime());
    XMLGregorianCalendar xmlGregorianCalendar =
        DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
    doReturn(xmlGregorianCalendar).when(requestMessage).getArrestDatetime();

    AhwalCasePartyRequestMessage profileInfo = mock(AhwalCasePartyRequestMessage.class);
    doReturn(profileInfo).when(requestMessage).getProfileInfo();

    doThrow(BusinessException.class).when(lookupService)
        .getLookupEntry(LookupDefinition.SHIFT, LocaleContextHolder.getLocale(), 1L);

    //Invoke operation createAhwalIncident on the _test.
    _test.createAhwalIncident(requestMessage);
  }

  @Test(expected = BusinessException.class)
  public void shouldFailCreateAhwalIncidentForEmptyArrestLocation()
      throws DatatypeConfigurationException {

    // Prepare test data.
    AhwalCaseRequestMessage requestMessage = mock(AhwalCaseRequestMessage.class);
    doReturn("1").when(requestMessage).getCharges();
    doReturn(1L).when(requestMessage).getShiftId();
    doReturn(null).when(requestMessage).getArrestLocationId();

    GregorianCalendar gregorianCalendar = new GregorianCalendar();
    gregorianCalendar.setTime(Calendar.getInstance().getTime());
    XMLGregorianCalendar xmlGregorianCalendar =
        DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
    doReturn(xmlGregorianCalendar).when(requestMessage).getArrestDatetime();

    AhwalCasePartyRequestMessage profileInfo = mock(AhwalCasePartyRequestMessage.class);
    doReturn(profileInfo).when(requestMessage).getProfileInfo();

    //Invoke operation createAhwalIncident on the _test.
    _test.createAhwalIncident(requestMessage);
  }

  @Test(expected = BusinessException.class)
  public void shouldFailCreateAhwalIncidentForInvalidArrestLocation()
      throws DatatypeConfigurationException {

    // Prepare test data.
    AhwalCaseRequestMessage requestMessage = mock(AhwalCaseRequestMessage.class);
    doReturn("1").when(requestMessage).getCharges();
    doReturn(1L).when(requestMessage).getShiftId();
    doReturn(1L).when(requestMessage).getArrestLocationId();

    GregorianCalendar gregorianCalendar = new GregorianCalendar();
    gregorianCalendar.setTime(Calendar.getInstance().getTime());
    XMLGregorianCalendar xmlGregorianCalendar =
        DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
    doReturn(xmlGregorianCalendar).when(requestMessage).getArrestDatetime();

    AhwalCasePartyRequestMessage profileInfo = mock(AhwalCasePartyRequestMessage.class);
    doReturn(profileInfo).when(requestMessage).getProfileInfo();

    doThrow(BusinessException.class).when(lookupService)
        .getLookupEntry(LookupDefinition.ARREST_LOCATION_LK, LocaleContextHolder.getLocale(), 1L);

    //Invoke operation createAhwalIncident on the _test.
    _test.createAhwalIncident(requestMessage);
  }

  @Test(expected = BusinessException.class)
  public void shouldFailCreateAhwalIncidentForInvalidUnit()
      throws DatatypeConfigurationException {

    // Prepare test data.
    AhwalCaseRequestMessage requestMessage = mock(AhwalCaseRequestMessage.class);
    doReturn("1").when(requestMessage).getCharges();
    doReturn(1L).when(requestMessage).getShiftId();
    doReturn(1L).when(requestMessage).getArrestLocationId();
    doReturn(1L).when(requestMessage).getUnitid();

    GregorianCalendar gregorianCalendar = new GregorianCalendar();
    gregorianCalendar.setTime(Calendar.getInstance().getTime());
    XMLGregorianCalendar xmlGregorianCalendar =
        DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
    doReturn(xmlGregorianCalendar).when(requestMessage).getArrestDatetime();

    AhwalCasePartyRequestMessage profileInfo = mock(AhwalCasePartyRequestMessage.class);
    doReturn(profileInfo).when(requestMessage).getProfileInfo();

    doThrow(BusinessException.class).when(lookupService)
        .getLookupEntry(LookupDefinition.SECTION_UNITS, LocaleContextHolder.getLocale(), 1L);

    //Invoke operation createAhwalIncident on the _test.
    _test.createAhwalIncident(requestMessage);
  }

  @Test
  public void shouldSuccessAcknowledgement() {

    _test.sendSuccessAcknowledgement(mock(AhwalCaseRequestMessage.class), "REF");

    verify(ahwalIncidentMQClient, times(1)).sendSuccessAcknowledgement(
        any(AhwalCaseRequestMessage.class),
        anyString());
  }

  @Test
  public void shouldFailureAcknowledgement() {

    _test.sendFailureAcknowledgement(mock(AhwalCaseRequestMessage.class), "MESSAGE");
    verify(ahwalIncidentMQClient, times(1)).sendFailureAcknowledgement(
        any(AhwalCaseRequestMessage.class),
        anyString());
  }

  @Test
  public void shouldDeportResultToVision() {

    _test.sendDeportResultToVision("VISION_REF", "FIS_REF");
    verify(ahwalIncidentMQClient, times(1)).sendDeportResultToVision(anyString(), anyString());
  }

  @Test
  public void shouldCreateAhwalIncidentForKnownProfile() throws DatatypeConfigurationException {

    // Prepare test data.
    AhwalCaseRequestMessage requestMessage = mock(AhwalCaseRequestMessage.class);
    doReturn("1").when(requestMessage).getCharges();
    doReturn(1L).when(requestMessage).getShiftId();
    doReturn(1L).when(requestMessage).getArrestLocationId();

    AhwalCaseRequestMessage.Attachments attachmentWrapper =
        mock(AhwalCaseRequestMessage.Attachments.class);
    Attachment firstAttachment = mock(Attachment.class);
    MimeType firstMimeType = mock(MimeType.class);
    doReturn(1L).when(firstMimeType).getId();
    doReturn(firstMimeType).when(firstAttachment).getMimeType();
    doReturn(".pdf").when(firstAttachment).getAttachmentDescription();
    doReturn("FIRST".getBytes()).when(firstAttachment).getAttachmentFile();

    Attachment secondAttachment = mock(Attachment.class);
    MimeType secondMimeType = mock(MimeType.class);
    doReturn(2L).when(secondMimeType).getId();
    doReturn(secondMimeType).when(secondAttachment).getMimeType();
    doReturn(".doc").when(secondAttachment).getAttachmentDescription();
    doReturn("SECOND".getBytes()).when(secondAttachment).getAttachmentFile();

    Attachment thirdAttachment = mock(Attachment.class);
    MimeType thirdMimeType = mock(MimeType.class);
    doReturn(1L).when(thirdMimeType).getId();
    doReturn(thirdMimeType).when(thirdAttachment).getMimeType();
    doReturn("doc").when(thirdAttachment).getAttachmentDescription();
    doReturn("THIRDS".getBytes()).when(thirdAttachment).getAttachmentFile();

    doReturn(Arrays.asList(firstAttachment, secondAttachment, thirdAttachment))
        .when(attachmentWrapper).getAttachment();
    doReturn(attachmentWrapper).when(requestMessage).getAttachments();

    GregorianCalendar gregorianCalendar = new GregorianCalendar();
    gregorianCalendar.setTime(Calendar.getInstance().getTime());
    XMLGregorianCalendar xmlGregorianCalendar =
        DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
    doReturn(xmlGregorianCalendar).when(requestMessage).getArrestDatetime();

    AhwalCasePartyRequestMessage profileInfo = mock(AhwalCasePartyRequestMessage.class);
    doReturn(profileInfo).when(requestMessage).getProfileInfo();

    //Invoke operation createAhwalIncident on the _test.
    assertThat(_test.createAhwalIncident(requestMessage)).isNotNull();
  }

  @Test
  public void shouldCreateAhwalIncidentForUnknownProfile() throws DatatypeConfigurationException {

    // Prepare test data.
    AhwalCaseRequestMessage requestMessage = mock(AhwalCaseRequestMessage.class);
    doReturn("1").when(requestMessage).getCharges();
    doReturn(1L).when(requestMessage).getShiftId();
    doReturn(1L).when(requestMessage).getArrestLocationId();

    GregorianCalendar gregorianCalendar = new GregorianCalendar();
    gregorianCalendar.setTime(Calendar.getInstance().getTime());
    XMLGregorianCalendar xmlGregorianCalendar =
        DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
    doReturn(xmlGregorianCalendar).when(requestMessage).getArrestDatetime();

    AhwalCasePartyRequestMessage profileInfo = mock(AhwalCasePartyRequestMessage.class);
    doReturn(null).when(profileInfo).getUdbNo();
    doReturn(profileInfo).when(requestMessage).getProfileInfo();

    //Invoke operation createAhwalIncident on the _test.
    assertThat(_test.createAhwalIncident(requestMessage)).isNotNull();
  }
}
