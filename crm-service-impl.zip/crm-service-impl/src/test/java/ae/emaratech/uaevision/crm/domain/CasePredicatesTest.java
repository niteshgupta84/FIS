package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.query.RetrieveCasesWithOwnerDetailQuery;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.assertj.core.api.StrictAssertions.assertThat;

/**
 * Created by Nitesh.Gupta on 7/19/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class CasePredicatesTest {
    /**
     * Predicate Test which will return Null
     */
    @Test
    public void shouldReturnNoPredicateOrNull() {
        BooleanExpression booleanExpression = CasePredicates.hasNoPredicate();
        assertThat(booleanExpression).isEqualTo(null);
    }

    /**
     * Predicate Test which will return Order Specifier desc by CreatedDate
     */
    @Test
    public void shouldReturnOrderSpecifier() {
        OrderSpecifier orderSpecifier = CasePredicates.getOrderSpecifier();
        assertThat(orderSpecifier).isInstanceOf(OrderSpecifier.class);
    }

    /**
     * Checks if Predicate returned is having where criteria to find out history
     */
    @Test
    public void shouldReturnCaseHistoryIfIdProvided() {
        CaseKey caseKey = new CaseKey(1L);
        Predicate predicate = CasePredicates.getHistoryByCaseId(caseKey);
        assertThat(predicate).isNotNull();
    }

    /**
     * Predicate which having a criteria to build Order Specifier
     */
    @Test
    public void shouldReturnCaseHistoryOrderSpecifier() {
        OrderSpecifier orderSpecifier = CasePredicates.getActionHistoryOrderSpecifier();
        assertThat(orderSpecifier).isInstanceOf(OrderSpecifier.class);
        assertThat(orderSpecifier).isNotNull();
    }

    @Test
    public void shouldReturnCaseByOwnerDetailsIfSectionOnlyProvided() {
        RetrieveCasesWithOwnerDetailQuery query = new RetrieveCasesWithOwnerDetailQuery(1L);
        Predicate predicate = CasePredicates.getCaseByOwnerDetails(query);
        assertThat(predicate).isNotNull();
    }

    @Test
    public void shouldReturnArrestByOwnerDetailsIfUserProvided() {
        RetrieveCasesWithOwnerDetailQuery query = new RetrieveCasesWithOwnerDetailQuery(1L);
        query.withUser("Test");
        Predicate predicate = CasePredicates.getCaseByOwnerDetails(query);
        assertThat(predicate).isNotNull();
    }

}
