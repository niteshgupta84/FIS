package ae.emaratech.uaevision.crm.query;

import ae.emaratech.uaevision.crm.application.CasePageBuilder;
import ae.emaratech.uaevision.crm.application.dto.*;
import ae.emaratech.uaevision.crm.domain.*;
import ae.emaratech.uaevision.document.application.AttachedDocumentDto;
import ae.emaratech.uaevision.fis.common.key.*;
import ae.emaratech.uaevision.fis.common.notification.Notification;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.*;

import static org.assertj.core.api.StrictAssertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

/**
 * Test class for methods defined in CaseQueryService.
 *
 * @author Haroon.Subair
 */
@RunWith(MockitoJUnitRunner.class)
public class CaseQueryServiceImplTest {

    @InjectMocks
    private CaseQueryServiceImpl _test;

    @Mock
    private CaseActionHistoryRepository caseActionHistoryRepository;

    @Mock
    private CaseRepository mockCaseRepository;

    @Mock
    private NotificationBus mockNotificationBus;

    @Mock
    private DocumentInspectionMapper documentInspectionMapper;

    @Mock
    private CaseAssociationMapper caseAssociationMapper;

    @Mock
    private CaseNoteRepository caseNoteRepository;

    @Mock
    private CaseAssociationRepository caseAssociationRepository;

    @Mock
    private CaseNoteMapper caseNoteMapper;

    @Mock
    private NotificationBus notificationBus;

    @Mock
    private CaseAttachmentMapper caseAttachmentMapper;

    @Mock
    private CaseMapper caseMapper;
    @Mock
    private CaseActionHistoryMapper caseActionHistoryMapper;

    @Mock
    private CaseTransferDetailRepository caseTransferDetailRepository;

    @Mock
    private CaseTransferDetailMapper caseTransferDetailMapper;

    @Before
    public void init() {
        NotificationBuilder mockNotificationBuilder = mock(NotificationBuilder.class);
        doReturn(mock(Notification.class)).when(mockNotificationBuilder).createNotification();
        doReturn(mockNotificationBuilder).when(mockNotificationBus).getBuilder();
    }

    @Test
    public void shouldReturnCaseActionHistoryIfcaseIdGiven() {
        RetrieveCaseHistoryQuery retrieveHistoryQuery =
                new RetrieveCaseHistoryQuery(new CaseKey(1L));

        List<CaseActionHistory> caseActionHistories = new ArrayList<>();
        CaseActionHistory caseActionHistory =
                new CaseActionHistory.Builder(1L)
                        .withActionId(CaseAction.OPEN.id())
                        .withComments("CancelComments")
                        .build();

        caseActionHistories.add(caseActionHistory);
        doReturn(caseActionHistories).when(caseActionHistoryRepository)
                .findAll(any(Predicate.class), any(OrderSpecifier.class));

        List<CaseTrackDto> caseReportTrackDtos = new ArrayList<>();
        CaseTrackDto caseReportTrackDto = new CaseTrackDto();
        caseReportTrackDtos.add(caseReportTrackDto);
        doReturn(caseReportTrackDto).when(caseActionHistoryMapper).mapCaseTrackDto(
                any());

        Assertions.assertThat(_test.retrieveCaseHistory(retrieveHistoryQuery))
                .isNotNull();
    }

    @Test
    public void shouldNotValidateWhenActiveCaseExistsForParty() {

        // Mock Dependencies
        ValidateActiveCaseForPartyQuery mockQuery =
                new ValidateActiveCaseForPartyQuery(Arrays.asList(2L));

        Iterable<Case> activeCaseForUDBList = new Iterable<Case>() {
            @Override
            public Iterator<Case> iterator() {
                return new HashSet<Case>().iterator();
            }
        };

        doReturn(activeCaseForUDBList).when(mockCaseRepository).findAll(any(Predicate.class),any(OrderSpecifier.class));
        doReturn(new CaseDto()).when(caseMapper).mapToCaseDto(any(Case.class));

        // Invoke the operation on _test
        Notification notification = _test.validateActiveCaseForParty(mockQuery);
        assertThat(notification).isNull();
    }


    @Test
    public void shouldReturnEmptyNotesForCase() {
        RetrieveCaseQuery retrieveCaseQuery = new RetrieveCaseQuery(new CaseKey(1L));

        CaseNote caseNote = new CaseNote(new NoteKey(1L), "Test", 1L);
        Set<CaseNote> caseNotes = new HashSet<>();
        caseNotes.add(caseNote);
        CaseNoteDto dto = new CaseNoteDto();
        doReturn(caseNotes).when(caseNoteRepository).findAll(any(Predicate.class));

        doReturn(dto).when(caseNoteMapper).mapToCaseNoteDto(any(CaseNote.class));
        _test.retrieveNotesForCase(retrieveCaseQuery);
    }

    @Test
    public void shouldReturnAssociationsForArrest() {
        RetrieveCaseQuery retrieveCaseQuery = new RetrieveCaseQuery(new CaseKey(1L));

        CaseAssociation caseAssociation = new CaseAssociation(new AssociatedCaseKey(1L));
        Set<CaseAssociation> caseAssociations = new HashSet<>();
        caseAssociations.add(caseAssociation);
        CaseAssociationDto dto = new CaseAssociationDto();
        doReturn(caseAssociations).when(caseAssociationRepository).findAll(any(Predicate.class));

        doReturn(dto).when(caseAssociationMapper).mapCaseAssociationDto(any(CaseAssociation.class));
        _test.retrieveAssociationsForCase(retrieveCaseQuery);
    }

    @Test
    public void shouldReturnAttachmentsForArrest() {
        RetrieveCaseQuery retrieveCaseQuery = new RetrieveCaseQuery(new CaseKey(1L));
        Case caseData = CaseDataConstants.getCaseData();
        doReturn(caseData).when(mockCaseRepository).findOne(anyLong());


        doReturn(mock(AttachedDocumentDto.class)).when(caseAttachmentMapper).mapCaseAttachmentDto(
                any(CaseAttachment.class));
        _test.retrieveAttachmentsForCase(retrieveCaseQuery);
    }

    @Test
    public void shouldRetreiveArrestForCase() {
        RetrieveCaseForArrestQuery query = new RetrieveCaseForArrestQuery(new ArrestReportKey(1L));
        Case caseData = CaseDataConstants.getCaseData();
        Set<Case> list = new HashSet<>();
        list.add(caseData);
        CaseDto caseDto = new CaseDto();
        doReturn(list).when(mockCaseRepository).findAll(any(Predicate.class));
        doReturn(caseDto).when(caseMapper).mapToCaseDto(any(Case.class));
        _test.retrieveCaseForArrest(query);
    }

    @Test
    public void shouldReturnDocumentInspectionDto() {
        RetrieveCaseQuery retrieveCaseQuery = new RetrieveCaseQuery(new CaseKey(1L));
        Case caseData = CaseDataConstants.getCaseData();
        doReturn(caseData).when(mockCaseRepository).findOne(anyLong());


        doReturn(mock(DocumentInspectionDto.class)).when(documentInspectionMapper).mapToDocumentInspectionDto(
                any(DocumentInspectionResult.class));
        _test.retrieveDocumentInspectionsForCase(retrieveCaseQuery);
    }

    @Test
    public void shouldRetrieveArrestsToAssignedUser() {
        RetrieveCasesWithOwnerDetailQuery query = new RetrieveCasesWithOwnerDetailQuery(1L);
        query.withUser("Nitesh");

        List<String> sortColumns = new ArrayList();
        sortColumns.add("id");
        sortColumns.add("createdDate");
        CasePageBuilder
                arrestPageBuilder =
                new CasePageBuilder(0, 10, sortColumns);
        query.withCasePageBuilder(arrestPageBuilder);
        Case caseData = CaseDataConstants.getCaseData();
        List<Case> list = new ArrayList<>();
        list.add(caseData);

        doReturn(mock(Page.class)).when(mockCaseRepository).findAll(any(Predicate.class), any(Pageable.class));
        _test.retrieveCasesAssignedToUser(query);
    }

    @Test
    public void shouldRetreiveCaseForParty() {
        RetrieveCaseForPartyQuery query = new RetrieveCaseForPartyQuery(new PartyKey(1L));
        Case caseData = CaseDataConstants.getCaseData();
        Set<Case> list = new HashSet<>();
        list.add(caseData);
        CaseDto caseDto = new CaseDto();
        doReturn(list).when(mockCaseRepository).findAll(any(Predicate.class));
        doReturn(caseDto).when(caseMapper).mapToCaseDto(any(Case.class));
        _test.retrieveCaseForParty(query);
    }

    @Test
    public void shouldRetreiveCasesForParty() {
        List<Long> keys = new ArrayList<>();
        keys.add(100L);
        RetrieveCaseForPartyQuery query = new RetrieveCaseForPartyQuery(keys);
        Case caseData = CaseDataConstants.getCaseData();
        Set<Case> list = new HashSet<>();
        list.add(caseData);
        CaseDto caseDto = new CaseDto();
        doReturn(list).when(mockCaseRepository).findAll(any(BooleanExpression.class));
        doReturn(caseDto).when(caseMapper).mapToCaseDto(any(Case.class));
        _test.retrieveCasesForParty(query);
    }
    @Test
    public void shouldFindCaseByCriteria() {
        RetrieveCasesBySearchQuery retrieveArrestQuery = new RetrieveCasesBySearchQuery();
        retrieveArrestQuery.setSection(new Entry(1L));
        retrieveArrestQuery.setDepartment(new Entry(30L));
        List<String> sortColumns = new ArrayList();
        sortColumns.add("id");
        sortColumns.add("createdDate");
        CasePageBuilder
                arrestPageBuilder =
                new CasePageBuilder(0, 10, sortColumns);

        Case caseData = CaseDataConstants.getCaseData();
        List<Case> list = new ArrayList<>();
        list.add(caseData);

        doReturn(mock(Page.class)).when(mockCaseRepository).findAll(any(Predicate.class),
                any(Pageable.class));
        _test.retrieveCasesBySearchCriteria(arrestPageBuilder, retrieveArrestQuery);
    }

    @Test
    public void shouldRetrieveArrestsCreatedByUser() {
        RetrieveCasesWithOwnerDetailQuery retrieveArrestQuery = new RetrieveCasesWithOwnerDetailQuery(1L);
        retrieveArrestQuery.withUser("Nitesh");

        List<String> sortColumns = new ArrayList();
        sortColumns.add("id");
        sortColumns.add("createdDate");
        CasePageBuilder
                arrestPageBuilder =
                new CasePageBuilder(0, 10, sortColumns);
        retrieveArrestQuery.withCasePageBuilder(arrestPageBuilder);
        Case arrest = CaseDataConstants.getCaseData();
        List<Case> list = new ArrayList<>();
        list.add(arrest);

        doReturn(mock(Page.class)).when(mockCaseRepository).findAll(any(Predicate.class), any(Pageable.class));
        _test.retrieveCasesCreatedByUser(retrieveArrestQuery);
    }

    @Test
    public void shouldReturnCaseTransferDetail(){
        CaseTransferDetail caseTransferDetail = new CaseTransferDetail.Builder(1L,1L,1L,1L).build();

        doReturn(caseTransferDetail).when(caseTransferDetailRepository).findOne(anyLong());
        doReturn(mock(CaseTransferDetailDto.class)).when(caseTransferDetailMapper).mapToDto(caseTransferDetail);
        _test.retreiveCaseTransferDetail(mock(CaseTransferKey.class));
    }

    @Test
    public void shouldRetrieveAllTransferredCases(){
        List<String> sortColumns = new ArrayList();
        sortColumns.add("id");
        sortColumns.add("createdDate");
        CasePageBuilder
                arrestPageBuilder =
                new CasePageBuilder(0, 10, sortColumns);
        CaseTransferDetail caseTransferDetail = new CaseTransferDetail.Builder(1L,1L,1L,1L).build();
        List<CaseTransferDetail> list = new ArrayList<>();
        list.add(caseTransferDetail);
        doReturn(mock(Map.class)).when(caseTransferDetailMapper).mapEntityToDTOList(anyList());
        doReturn(mock(Page.class)).when(caseTransferDetailRepository).findAll(any(Predicate.class),
                any(Pageable.class));
        _test.retrieveAllTransferredCases(arrestPageBuilder);
    }

    @Test
    public void shouldRetreiveCaseTransferDetail(){
        CaseTransferDetail caseTransferDetail = new CaseTransferDetail.Builder(1L,1L,1L,1L).build();

        doReturn(caseTransferDetail).when(caseTransferDetailRepository).findOne(anyLong());
        doReturn(mock(CaseTransferDetailDto.class)).when(caseTransferDetailMapper).mapToDto(caseTransferDetail);
        _test.retreiveCaseTransferDetail(mock(CaseKey.class));
    }
}
