package ae.emaratech.uaevision.crm.report;

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportDto;
import ae.emaratech.uaevision.arrest.query.ArrestQueryService;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestQuery;
import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.crm.application.dto.CaseTrackDto;
import ae.emaratech.uaevision.crm.query.CaseQueryService;
import ae.emaratech.uaevision.crm.query.RetrieveCaseHistoryQuery;
import ae.emaratech.uaevision.crm.query.RetrieveCaseQuery;
/*import ae.emaratech.uaevision.fis.gateway.incident.UserManagementServiceClient;
import ae.emaratech.uaevision.fis.gateway.usermanagementservice.EmployeeDetails;*/
import ae.emaratech.uaevision.fis.party.application.dto.ChargeDto;
import ae.emaratech.uaevision.fis.party.application.dto.IRISDto;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import ae.emaratech.uaevision.fis.party.query.RetrievePartyQuery;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import net.sf.jasperreports.engine.JRDataSource;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.StrictAssertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

/**
 * Created by Nitesh.Gupta on 7/13/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class PartyTransferReportDataSourceTest {
    @InjectMocks
    private PartyTransferReportDataSource _test;
    @Mock
    private CaseQueryService caseQueryService;
    @Mock
    private PartyQueryService partyQueryService;
    @Mock
    private ArrestQueryService arrestQueryService;
/*
    @Mock
    private UserManagementServiceClient userManagementServiceClient;
*/

    @Test
    public void shouldGenerateTransferReport() throws ParseException {
        //Preparing input data
        ReportParameters reportParameters = new ReportParameters();
        reportParameters.addParameter("ARREST_ID", 12);
        reportParameters.addParameter("PARTY_ID", 2);
        reportParameters.addParameter("USER_NAME", "Niesh");
        ArrestReportDto arrestReportDto = new ArrestReportDto();
        arrestReportDto.setId(1L);
        arrestReportDto.setArrestReportNumber("incident number");
        arrestReportDto.setCreatedBy("incident number");
        arrestReportDto.setCreatedDate(new Date());
        arrestReportDto.setDepartment(new Entry(1L, "Investigation"));
        arrestReportDto.setSection(new Entry(1L, "Section"));
        arrestReportDto.setStatus(new Entry(1L, "Status"));
        arrestReportDto.setArrestDate(new Date());

        CaseDto caseDto = new CaseDto();
        caseDto.setId(1L);
        caseDto.setCaseNumber("incident number");
        caseDto.setCreatedBy("incident number");
        caseDto.setCreatedDate(new Date());
        caseDto.setDepartment(new Entry(1L, "Investigation"));
        caseDto.setSection(new Entry(1L, "Section"));
        caseDto.setStatus(new Entry(1L, "Status"));

        CasePartyDto casePartyDto = new CasePartyDto();
        casePartyDto.setPartyId(1L);
        casePartyDto.setCaseId(1L);
        List<CasePartyDto> list = new ArrayList();
        list.add(casePartyDto);
        caseDto.setCasePartyDtoList(list);
        caseDto.setId(1L);


        PartyDto partyDto = new PartyDto();
        List<ChargeDto> listOfCharges = new ArrayList<>();
        ChargeDto chargeDto = new ChargeDto();
        chargeDto.setCharge(new Entry(1L, "Test charge"));
        listOfCharges.add(chargeDto);

        IRISDto irisDto = new IRISDto();
        irisDto.setIrisNumber("Iris number");
        irisDto.setNameChangedId(new Entry(2L, "Changed"));
        irisDto.setLocationId(new Entry(3L, "Loc"));

        partyDto.setIrisDto(irisDto);
        partyDto.setNameEn("En Name");
        partyDto.setNameAr("AR Name");
        partyDto.setNationality(new Entry(2L, "Naitonality"));
        partyDto.setOriginalNationality(new Entry(2L, "oNaitonality"));
        partyDto.setDateofbirth(new Date());
        partyDto.setGender(new Entry(3L, "Male"));
        partyDto.setPersonType(new Entry(2L, "Visa"));
        partyDto.setIsBanned(true);
        partyDto.setIsOverstayed(true);
        partyDto.setIsBlackListed(true);
        partyDto.setAttachmentId(1L);

        doReturn(arrestReportDto).when(arrestQueryService).retrieveArrestReport(any(RetrieveArrestQuery.class));
        doReturn(caseDto).when(caseQueryService).retrieveCase(any(RetrieveCaseQuery.class));
        CaseTrackDto caseTrackDto = new CaseTrackDto();
        caseTrackDto.setAction(new Entry(22L, "TRANSFERREDTODEPARTMENT"));
        List<CaseTrackDto> caseTrackDtoList = Arrays.asList(caseTrackDto);
        doReturn(caseTrackDtoList).when(caseQueryService).retrieveCaseHistory(any(RetrieveCaseHistoryQuery.class));
        doReturn(partyDto).when(partyQueryService).retrieveParty(any(RetrievePartyQuery.class));
        /*EmployeeDetails employeeDetails = mock(EmployeeDetails.class);
        doReturn(employeeDetails).when(userManagementServiceClient).getAllEmployeeDetails();
        doReturn(new ArrayList<>()).when(employeeDetails).getEmployeeDetail();*/


        JRDataSource dataSource = _test.getDataSource(reportParameters);
        assertThat(dataSource).isInstanceOf(JRDataSource.class);
        assertThat(dataSource).isNotNull();
    }
}
