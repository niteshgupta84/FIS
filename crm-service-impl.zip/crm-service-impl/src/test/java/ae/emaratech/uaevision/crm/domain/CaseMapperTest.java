package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;

/**
 * Created by Nitesh.Gupta on 8/11/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class CaseMapperTest {
    @Mock
    private LookupService lookupService;

    @Mock
    private CasePartyMapper casePartyMapper;

    @InjectMocks
    private CaseMapper _test;
    @Mock
    protected UserService userDetailsService;

    @Test
    public void shouldMapCaseDto() {
        Optional<Entry> entry = Optional.of(new Entry(1L, "Test"));
        doReturn(entry).when(lookupService).getLookupEntry(any(), any(), any());
        Case caseData = CaseDataConstants.getCaseData();
        caseData.setYear(2016L);
        assertThat(_test.mapToCaseDto(caseData)).isNotNull();

    }

    @Test
    public void shouldMapCaseDtoList() {
        Optional<Entry> entry = Optional.of(new Entry(1L, "Test"));
        doReturn(entry).when(lookupService).getLookupEntry(any(), any(), any());
        Case caseData = CaseDataConstants.getCaseData();
        caseData.setYear(2016L);
        List<Case> caseList = new ArrayList<>();
        caseList.add(caseData);
        assertThat(_test.mapEntityToDTOList(caseList)).isNotNull();

    }
}
