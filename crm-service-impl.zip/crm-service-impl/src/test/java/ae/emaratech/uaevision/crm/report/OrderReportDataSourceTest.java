package ae.emaratech.uaevision.crm.report;

import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.crm.query.CaseQueryService;
import ae.emaratech.uaevision.crm.query.RetrieveCaseQuery;
import ae.emaratech.uaevision.document.service.dto.DocumentReferenceDto;
import ae.emaratech.uaevision.fis.order.query.OrderQueryService;
import ae.emaratech.uaevision.fis.order.query.RetrieveOrderListQuery;
import ae.emaratech.uaevision.fis.order.service.dto.OrderDto;
import ae.emaratech.uaevision.fis.party.application.dto.ChargeDto;
import ae.emaratech.uaevision.fis.party.application.dto.IRISDto;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import ae.emaratech.uaevision.fis.party.query.RetrievePartyQuery;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import net.sf.jasperreports.engine.JRDataSource;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.StrictAssertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;

/**
 * Created by Nitesh.Gupta on 7/24/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class OrderReportDataSourceTest {

    @InjectMocks
    private OrdersReportDataSource _test;
    @Mock
    private OrderQueryService orderQueryService;

    @Mock
    private PartyQueryService partyQueryService;

    @Mock
    private CaseQueryService caseQueryService;

    @Test
    public void shouldGenerateOrderReport() {

        ReportParameters reportParameters = new ReportParameters();
        reportParameters.addParameter("CASE_ID", 12);
        reportParameters.addParameter("PARTY_ID", 2);

        OrderDto orderDto = new OrderDto();
        orderDto.setId(1L);
        orderDto.setParentIncidentId(1L);
        List<OrderDto> orderDtoList = new ArrayList<>();
        CaseDto caseDto = new CaseDto();
        caseDto.setId(1L);
        caseDto.setCaseNumber("incident number");
        caseDto.setCreatedBy("incident number");
        caseDto.setCreatedDate(new Date());
        caseDto.setDepartment(new Entry(1L, "Investigation"));
        caseDto.setSection(new Entry(1L, "Section"));
        caseDto.setStatus(new Entry(1L, "Status"));

        // incidentDto.set

        PartyDto partyDto = new PartyDto();
        List<ChargeDto> listOfCharges = new ArrayList<>();
        ChargeDto chargeDto = new ChargeDto();
        chargeDto.setCharge(new Entry(1L, "Test charge"));
        listOfCharges.add(chargeDto);

        IRISDto irisDto = new IRISDto();
        irisDto.setIrisNumber("Iris number");
        irisDto.setNameChangedId(new Entry(2L, "Changed"));
        irisDto.setLocationId(new Entry(3L, "Loc"));

        partyDto.setIrisDto(irisDto);
        partyDto.setNameEn("En Name");
        partyDto.setNameAr("AR Name");
        partyDto.setNationality(new Entry(2L, "Naitonality"));
        partyDto.setOriginalNationality(new Entry(2L, "oNaitonality"));
        partyDto.setDateofbirth(new Date());
        partyDto.setGender(new Entry(3L, "Male"));
        partyDto.setPersonType(new Entry(2L, "Visa"));
        partyDto.setIsBanned(true);
        partyDto.setIsOverstayed(true);
        partyDto.setIsBlackListed(true);
        partyDto.setAttachmentId(1L);
        byte[] photo = new byte[1];
        DocumentReferenceDto documentReferenceDto = new DocumentReferenceDto();
        documentReferenceDto.setAttachment(photo);

        doReturn(partyDto).when(partyQueryService).retrieveParty(any(RetrievePartyQuery.class));
        doReturn(caseDto).when(caseQueryService).retrieveCase(
                any(RetrieveCaseQuery.class));
        doReturn(orderDtoList).when(orderQueryService)
                .retrieveOrderList(any(RetrieveOrderListQuery.class));

        // Invoking the getDataSource on _test
        JRDataSource dataSource = _test.getDataSource(reportParameters);
        assertThat(dataSource).isInstanceOf(JRDataSource.class);
        assertThat(dataSource).isNotNull();
    }
}
