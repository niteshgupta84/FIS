package ae.emaratech.uaevision.crm.application.validators;

import ae.emaratech.uaevision.arrest.domain.ArrestReason;
import ae.emaratech.uaevision.crm.application.CaseNotificationCode;
import ae.emaratech.uaevision.crm.application.CreateCaseCommand;
import ae.emaratech.uaevision.crm.application.UpdateCaseCommand;
import ae.emaratech.uaevision.crm.application.dto.CaseAssociationDto;
import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

/**
 * Test class providing unit test cases for {@link CaseValidator}
 *
 * @author Haroon.Subair
 */
@RunWith(MockitoJUnitRunner.class)
public class CaseValidatorTest {

  @InjectMocks
  private CaseValidator _test;
  @Mock
  private NotificationBus mockNotificationBus;
  @Spy
  private NotificationBuilder notificationBuilder;

  @Before
  public void init() {
    doReturn(notificationBuilder).when(mockNotificationBus).getBuilder();
  }

  @Test
  public void shouldFailValidateDuplicateAssociation() {

    CaseAssociationDto caseAssociationDto = mock(CaseAssociationDto.class);
    List<CaseAssociationDto> caseAssociationDtoList = Arrays.asList(caseAssociationDto);
    assertFalse(_test.checkDuplicateAssociation(caseAssociationDtoList, 1L));
  }

  @Test
  public void shouldValidateDuplicateAssociationSuccessfully() {

    CaseAssociationDto caseAssociationDto = mock(CaseAssociationDto.class);
    doReturn(2L).when(caseAssociationDto).getLinkedCaseId();
    List<CaseAssociationDto> caseAssociationDtoList = Arrays.asList(caseAssociationDto);
    assertTrue(_test.checkDuplicateAssociation(caseAssociationDtoList, 2L));
  }

  @Test
  public void shouldFailValidateCreateCaseForEmptyArrestReason() {

    CreateCaseCommand command = mock(CreateCaseCommand.class);
    _test.validate(command);
    verify(notificationBuilder, times(1)).add(CaseNotificationCode.ARREST_REASON_MANDATORY);
    verify(mockNotificationBus, times(1)).send(notificationBuilder);
  }

  @Test
  public void shouldFailValidateCreateCaseForEmptyCasePartyList() {

    CreateCaseCommand command = mock(CreateCaseCommand.class);
    doReturn(mock(ArrestReason.class)).when(command).getArrestReason();
    _test.validate(command);
    verify(notificationBuilder, times(1)).add(CaseNotificationCode.PARTY_DETAIL_MISSING);
    verify(mockNotificationBus, times(1)).send(notificationBuilder);
  }

  @Test
  public void shouldValidateCreateCaseSuccessfully() {

    CreateCaseCommand command = mock(CreateCaseCommand.class);
    doReturn(mock(ArrestReason.class)).when(command).getArrestReason();
    doReturn(Arrays.asList(new CasePartyDto())).when(command).getCasePartyDtoList();
    doReturn(new Entry(1L)).when(command).getTransferredFrom();
    doReturn(new Entry(1L)).when(command).getUnit();
    _test.validate(command);
    verify(notificationBuilder, times(0)).add(any(CaseNotificationCode.class));
    verify(mockNotificationBus, times(0)).send(notificationBuilder);
  }

  @Test
  public void shouldValidateUpdateCaseSuccessfully() {

    UpdateCaseCommand command = mock(UpdateCaseCommand.class);
    doReturn(mock(ArrestReason.class)).when(command).getArrestReason();
    doReturn(Arrays.asList(new CasePartyDto())).when(command).getCasePartyDtoList();
    doReturn(new Entry(1L)).when(command).getUnit();
    doReturn(new Entry(1L)).when(command).getTransferredFromId();
    _test.validate(command);
    verify(notificationBuilder, times(0)).add(any(CaseNotificationCode.class));
    verify(mockNotificationBus, times(0)).send(notificationBuilder);
  }
}
