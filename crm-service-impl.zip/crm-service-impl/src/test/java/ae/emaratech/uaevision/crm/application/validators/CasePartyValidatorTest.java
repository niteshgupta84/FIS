package ae.emaratech.uaevision.crm.application.validators;

import ae.emaratech.uaevision.crm.application.CaseNotificationCode;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.party.application.CreatePartyCommand;
import ae.emaratech.uaevision.fis.party.application.UpdatePartyCommand;
import ae.emaratech.uaevision.fis.party.application.dto.ChargeDto;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Attribute;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;

/**
 * Test class providing unit test cases for {@link ae.emaratech.uaevision.crm.application.validators.CasePartyValidator}
 *
 * @author Haroon.Subair
 */
@RunWith(MockitoJUnitRunner.class)
public class CasePartyValidatorTest {

  @InjectMocks
  private CasePartyValidator _test;
  @Mock
  private NotificationBus mockNotificationBus;
  @Spy
  private NotificationBuilder notificationBuilder;
  @Mock
  private LookupService lookupService;

  @Before
  public void init() {
    doReturn(notificationBuilder).when(mockNotificationBus).getBuilder();
    Entry entry = new Entry(1L, "lk_key");
    Optional option = Optional.of(entry);
    doReturn(option).when(lookupService).getLookupEntry(any(),any(),any());
  }

  @Test
  public void shouldFailValidateCreatePartyForEmptyPartyList() {

    // Prepare test data.
    CreatePartyCommand command = mock(CreatePartyCommand.class);

    _test.validate(command);
    verify(notificationBuilder, times(1)).add(CaseNotificationCode.PARTY_MANDATORY);
    verify(mockNotificationBus, times(1)).send(notificationBuilder);
  }

  @Test
  public void shouldFailValidateCreatePartyForNoPartyType() {

    // Prepare test data.
    CreatePartyCommand command = mock(CreatePartyCommand.class);
    PartyDto partyDto = mock(PartyDto.class);
    List<PartyDto> partyDtoList = Arrays.asList(partyDto);
    doReturn(partyDtoList).when(command).getPartyList();

    _test.validate(command);
    verify(notificationBuilder, times(1)).add(CaseNotificationCode.PARTY_TYPE_MANDATORY);
    verify(mockNotificationBus, times(1)).send(notificationBuilder);
  }

  @Test
  public void shouldFailValidateCreatePartyForMissingAccusedCharges() {

    // Prepare test data.
    CreatePartyCommand command = mock(CreatePartyCommand.class);
    PartyDto partyDto = mock(PartyDto.class);
    Entry partyTypeEntry = new Entry(1L, "PartyType");
    partyTypeEntry.getSelectedAttributes().add(new Attribute("PartyTypeCharge", "1"));
    doReturn(partyTypeEntry).when(partyDto).getPartytype();
    doReturn(1L).when(partyDto).getId();
    List<PartyDto> partyDtoList = Arrays.asList(partyDto);
    doReturn(partyDto).when(command).getPartyDto();
    doReturn(partyDtoList).when(command).getPartyList();
    partyDto.setEmailAddress("nitesh841@gmail.com");
    partyDto.setPhoneNumber("nitesh");
    _test.validate(command);
    verify(notificationBuilder, times(4)).add(any(CaseNotificationCode.class), anyString());
    verify(mockNotificationBus, times(1)).send(notificationBuilder);
  }

  @Test
  public void shouldValidateCreatePartySuccessfully() {

    // Prepare test data.
    CreatePartyCommand command = mock(CreatePartyCommand.class);
    PartyDto partyDto = mock(PartyDto.class);
    Entry partyTypeEntry = new Entry(1L, "PartyType");
    partyTypeEntry.getSelectedAttributes().add(new Attribute("PartyTypeCharge", "1"));
    doReturn(partyTypeEntry).when(partyDto).getPartytype();
    doReturn(1L).when(partyDto).getId();
    List<ChargeDto> chargesList = Arrays.asList(new ChargeDto());
    doReturn(chargesList).when(partyDto).getListofCharges();
    List<PartyDto> partyDtoList = Arrays.asList(partyDto);
    doReturn(partyDto).when(command).getPartyDto();
    doReturn(partyDtoList).when(command).getPartyList();
    partyDto.setEmailAddress("nitesh841@gmail.com");
    partyDto.setPhoneNumber("nitesh");
    _test.validate(command);
    verify(mockNotificationBus, times(1)).send(notificationBuilder);
  }

  @Test
  public void shouldFailValidateUpdatePartyForEmptyPartyList() {

    // Prepare test data.
    UpdatePartyCommand command = mock(UpdatePartyCommand.class);

    _test.validate(command);
    verify(notificationBuilder, times(1)).add(CaseNotificationCode.PARTY_MANDATORY);
    verify(mockNotificationBus, times(1)).send(notificationBuilder);
  }

  @Test
  public void shouldFailValidateUpdatePartyForNoPartyType() {

    // Prepare test data.
    UpdatePartyCommand command = mock(UpdatePartyCommand.class);
    PartyDto partyDto = mock(PartyDto.class);
    List<PartyDto> partyDtoList = Arrays.asList(partyDto);
    doReturn(partyDtoList).when(command).getPartyList();

    _test.validate(command);
    verify(notificationBuilder, times(1)).add(CaseNotificationCode.PARTY_TYPE_MANDATORY);
    verify(mockNotificationBus, times(1)).send(notificationBuilder);
  }

  @Test
  public void shouldFailValidateUpdatePartyForMissingAccusedCharges() {

    // Prepare test data.
    UpdatePartyCommand command = mock(UpdatePartyCommand.class);
    PartyDto partyDto = mock(PartyDto.class);
    Entry partyTypeEntry = new Entry(1L, "PartyType");
    partyTypeEntry.getSelectedAttributes().add(new Attribute("PartyTypeCharge", "1"));
    doReturn(partyTypeEntry).when(partyDto).getPartytype();
    doReturn(1L).when(partyDto).getId();
    doReturn(1L).when(partyDto).getPartyId();
    List<PartyDto> partyDtoList = Arrays.asList(partyDto);
    doReturn(partyDto).when(command).getPartyDto();
    doReturn(partyDtoList).when(command).getPartyList();
    partyDto.setEmailAddress("nitesh841@gmail.com");
    partyDto.setPhoneNumber("nitesh");

    _test.validate(command);
    verify(notificationBuilder, times(4)).add(any(CaseNotificationCode.class), anyString());
    verify(mockNotificationBus, times(1)).send(notificationBuilder);
  }

  @Test
  public void shouldValidateUpdatePartySuccessfully() {

    // Prepare test data.
    UpdatePartyCommand command = mock(UpdatePartyCommand.class);
    PartyDto partyDto = mock(PartyDto.class);
    Entry partyTypeEntry = new Entry(1L, "PartyType");
    partyTypeEntry.getSelectedAttributes().add(new Attribute("PartyTypeCharge", "1"));
    doReturn(partyTypeEntry).when(partyDto).getPartytype();
    doReturn(1L).when(partyDto).getId();
    partyDto.setEmailAddress("nitesh841@gmail.com");
    partyDto.setPhoneNumber("nitesh");
    List<ChargeDto> chargesList = Arrays.asList(new ChargeDto());
    doReturn(chargesList).when(partyDto).getListofCharges();
    List<PartyDto> partyDtoList = Arrays.asList(partyDto);
    doReturn(partyDto).when(command).getPartyDto();
    doReturn(partyDtoList).when(command).getPartyList();

    _test.validate(command);
    verify(notificationBuilder, times(3)).add(any(CaseNotificationCode.class), anyString());
    verify(mockNotificationBus, times(1)).send(notificationBuilder);
  }
}
