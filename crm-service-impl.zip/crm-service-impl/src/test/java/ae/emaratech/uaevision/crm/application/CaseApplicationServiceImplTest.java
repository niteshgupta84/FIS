package ae.emaratech.uaevision.crm.application;


import ae.emaratech.uaevision.arrest.domain.ArrestReason;
import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.crm.application.dto.CaseNoteDto;
import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.crm.application.dto.CaseTransferDetailDto;
import ae.emaratech.uaevision.crm.domain.*;
import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.IncidentNumberProvider;
import ae.emaratech.uaevision.fis.common.domain.TrackerKeyProvider;
import ae.emaratech.uaevision.fis.common.infrastructure.EventBus;
import ae.emaratech.uaevision.fis.common.key.*;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;
import ae.emaratech.uaevision.fis.common.util.PersistentUtil;
import ae.emaratech.uaevision.fis.order.query.OrderQueryService;
import ae.emaratech.uaevision.fis.order.query.RetrieveOrderListQuery;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.StrictAssertions.assertThat;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyList;
import static org.mockito.Mockito.anyObject;
import static org.mockito.Mockito.anySet;
import static org.mockito.Mockito.*;

/**
 * Unit Test cases for Case Module
 * Created by Nitesh.Gupta on 3/14/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class CaseApplicationServiceImplTest {

    @Mock
    private CaseRepository caseRepository;
    @Mock
    private PersistentUtil persistentUtil;

    @Mock
    private EventBus<DomainEvent> eventBus;

    @Mock
    private CaseKeyProvider caseKeyProvider;

    @Mock
    private TrackerKeyProvider trackerKeyProvider;

    @Mock
    private CaseActionHistoryRepository caseActionHistoryRepository;

    @Mock
    private CaseNoteKeyProvider caseNoteKeyProvider;

    @Mock
    private NotificationBus mockNotificationBus;

    @Mock
    private CasePartyChargeKeyProvider casePartyChargeKeyProvider;

    @Mock
    private OrderQueryService orderQueryService;

    @Mock
    private IncidentNumberProvider incidentNumberProvider;

    @Mock
    private CaseTransferDetailRepository caseTransferDetailRepository;

    @InjectMocks
    CaseApplicationServiceImpl _test;
    @Mock
    ObjectMapper jsonMapper;

    @Mock
    private CaseMapper caseMapper;

    @Mock
    private CaseTransferDetailMapper caseTransferDetailMapper;

    @Before
    public void init() {
        doReturn(mock(NotificationBuilder.class)).when(mockNotificationBus).getBuilder();
        doReturn(new TrackerKey(1L)).when(trackerKeyProvider).next();
        doReturn("test").when(incidentNumberProvider).next(anyLong(),anyLong(),anyString());
    }
    @Test
    public void shouldCloseCase() {

        // Preparing test data.
        CaseKey arrestReportKey = new CaseKey(1L);
        CloseCaseCommand closeArrestReportCommand =
                new CloseCaseCommand(arrestReportKey, "completionComments");
        Case arrest = mock(Case.class);
        CaseClosedEvent caseClosedEvent =
                mock(CaseClosedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(arrest).when(caseRepository).findOne(arrestReportKey.id());
        doReturn(caseClosedEvent).when(arrest)
                .close(anyString());

        doReturn(new ArrayList<>()).when(orderQueryService).retrieveOrderList(any(RetrieveOrderListQuery.class));

        // Invoking the complete operation on the _test
        _test.close(closeArrestReportCommand);

        // Verifies whether interrogation domain was saved.
        verify(caseRepository, times(1)).save(arrest);
        // Verifies whether interrogation action history was saved.
        verify(caseActionHistoryRepository, times(1)).save(isA(CaseActionHistory.class));

        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(CaseClosedEvent.class));
    }

    @Test
    public void shouldNotCloseCaseIfArrestCommentNotProvided() {

        // Preparing test data.
        CaseKey caseKey = new CaseKey(1L);
        CloseCaseCommand closeCaseCommand =
                new CloseCaseCommand(caseKey, "");
        Case aCase = mock(Case.class);
        CaseClosedEvent caseClosedEvent =
                mock(CaseClosedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(aCase).when(caseRepository).findOne(caseKey.id());
        doReturn(caseClosedEvent).when(aCase)
                .close(anyString());
        doReturn(new ArrayList<>()).when(orderQueryService).retrieveOrderList(any(RetrieveOrderListQuery.class));
        // Invoking the complete operation on the _test
        _test.close(closeCaseCommand);


        // Verifies whether interrogation action history was saved.
        verify(caseActionHistoryRepository, times(1)).save(isA(CaseActionHistory.class));

        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(CaseClosedEvent.class));
    }

    @Test
    public void shouldReviewCase() {

        // Preparing test data.
        CaseKey caseKey = new CaseKey(1L);
        ReviewCaseCommand reviewCaseCommand =
                new ReviewCaseCommand(caseKey, "completionComments");
        Case aCase = mock(Case.class);
        CaseReviewedEvent caseReviewedEvent =
                mock(CaseReviewedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(aCase).when(caseRepository).findOne(caseKey.id());
        doReturn(caseReviewedEvent).when(aCase)
                .review(anyString());

        // Invoking the complete operation on the _test
        _test.review(reviewCaseCommand);

        // Verifies whether interrogation domain was saved.
        verify(caseRepository, times(1)).save(aCase);
        // Verifies whether interrogation action history was saved.
        verify(caseActionHistoryRepository, times(1)).save(isA(CaseActionHistory.class));

        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(CaseReviewedEvent.class));
    }

    @Test
    public void shouldRejectCase() {

        // Preparing test data.
        CaseKey caseKey = new CaseKey(1L);
        RejectCaseCommand rejectCaseCommand =
                new RejectCaseCommand(caseKey, "completionComments");
        Case aCase = mock(Case.class);
        CaseRejectedEvent caseReviewedEvent =
                mock(CaseRejectedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(aCase).when(caseRepository).findOne(caseKey.id());
        doReturn(caseReviewedEvent).when(aCase)
                .reject(anyString());

        // Invoking the complete operation on the _test
        _test.reject(rejectCaseCommand);

        // Verifies whether interrogation domain was saved.
        verify(caseRepository, times(1)).save(aCase);
        // Verifies whether interrogation action history was saved.
        verify(caseActionHistoryRepository, times(1)).save(isA(CaseActionHistory.class));

        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(CaseRejectedEvent.class));
    }

    @Test
    public void shouldReOpenCase() {

        // Preparing test data.
        CaseKey caseKey = new CaseKey(1L);
        ReOpenCaseCommand reOpenCaseCommand =
                new ReOpenCaseCommand(caseKey);
        Case aCase = mock(Case.class);
        CaseReopenedEvent caseReopenedEvent =
                mock(CaseReopenedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(aCase).when(caseRepository).findOne(caseKey.id());
        doReturn(caseReopenedEvent).when(aCase)
                .reopen();

        // Invoking the complete operation on the _test
        _test.reOpen(reOpenCaseCommand);

        // Verifies whether interrogation domain was saved.
        verify(caseRepository, times(1)).save(aCase);
        // Verifies whether interrogation action history was saved.
        verify(caseActionHistoryRepository, times(1)).save(isA(CaseActionHistory.class));

        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(CaseReopenedEvent.class));
    }

    @Test
    public void shouldApproveCase() {

        // Preparing test data.
        CaseKey caseKey = new CaseKey(1L);
        ApproveCaseCommand approveCaseCommand =
                new ApproveCaseCommand(caseKey, "completionComments");
        Case aCase = mock(Case.class);
        CaseApprovedEvent caseApprovedEvent =
                mock(CaseApprovedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(aCase).when(caseRepository).findOne(caseKey.id());
        doReturn(caseApprovedEvent).when(aCase)
                .approve(anyString());

        // Invoking the complete operation on the _test
        _test.approve(approveCaseCommand);

        // Verifies whether interrogation domain was saved.
        verify(caseRepository, times(1)).save(aCase);
        // Verifies whether interrogation action history was saved.
        verify(caseActionHistoryRepository, times(1)).save(isA(CaseActionHistory.class));

        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(CaseApprovedEvent.class));
    }

    @Test
    public void shouldManualTranferCase() {

        // Preparing test data.
        CaseKey caseKey = new CaseKey(1L);
        ManualTransferCaseCommand manualTransferCaseCommand =
                new ManualTransferCaseCommand(caseKey, "completionComments",1L);
        Case aCase = mock(Case.class);
        CaseManualTransferEvent caseManualTransferEvent =
                mock(CaseManualTransferEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(aCase).when(caseRepository).findOne(caseKey.id());
        doReturn(caseManualTransferEvent).when(aCase)
                .manualTransfer(anyString(), anyLong());

        // Invoking the complete operation on the _test
        _test.manualTransfer(manualTransferCaseCommand);

        // Verifies whether interrogation domain was saved.
        verify(caseRepository, times(1)).save(aCase);
        // Verifies whether interrogation action history was saved.
        verify(caseActionHistoryRepository, times(1)).save(isA(CaseActionHistory.class));

        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(CaseManualTransferEvent.class));
    }

    @Test
    public void shouldManualReceiveCase() {

        // Preparing test data.
        CaseKey caseKey = new CaseKey(1L);
        ManualReceiveCaseCommand manualReceiveCaseCommand =
                new ManualReceiveCaseCommand(caseKey, "completionComments", new Entry(1L));
        Case aCase = mock(Case.class);
        CaseManualReceiveEvent caseManualReceiveEvent =
                mock(CaseManualReceiveEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(aCase).when(caseRepository).findOne(caseKey.id());
        doReturn(caseManualReceiveEvent).when(aCase)
                .manualReceive(anyString(), anyObject());

        // Invoking the complete operation on the _test
        _test.manualReceive(manualReceiveCaseCommand);

        // Verifies whether interrogation domain was saved.
        verify(caseRepository, times(1)).save(aCase);
        // Verifies whether interrogation action history was saved.
        verify(caseActionHistoryRepository, times(1)).save(isA(CaseActionHistory.class));

        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(CaseManualReceiveEvent.class));
    }

    @Test
    public void shouldTransferCase() {

        // Preparing test data.
        CaseKey caseKey = new CaseKey(1L);
        TransferToCaseCommand transferToCaseCommand =
                new TransferToCaseCommand(caseKey, Department.DETECTIVE, Section.CRM);
        Case aCase = mock(Case.class);
        CaseTransferredToCRMEvent caseTransferredToCRMEvent =
                mock(CaseTransferredToCRMEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(aCase).when(caseRepository).findOne(caseKey.id());
        doReturn(caseTransferredToCRMEvent).when(aCase)
                .transferTo(anyObject(), anyObject(), anyString());

        // Invoking the complete operation on the _test
        _test.transferToCRM(transferToCaseCommand);

        // Verifies whether interrogation domain was saved.
        verify(caseRepository, times(1)).save(aCase);
        // Verifies whether interrogation action history was saved.
        verify(caseActionHistoryRepository, times(1)).save(isA(CaseActionHistory.class));

        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(CaseTransferredToCRMEvent.class));
    }

    @Test
    public void shouldAssignCase() {

        // Preparing test data.
        CaseKey caseKey = new CaseKey(1L);
        AssignCaseCommand assignCaseCommand =
                new AssignCaseCommand(caseKey,"TEST");
        Case aCase = mock(Case.class);
        CaseAssignedEvent caseTransferEvent =
                mock(CaseAssignedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(aCase).when(caseRepository).findOne(caseKey.id());
        doReturn(caseTransferEvent).when(aCase)
                .assignUser(anyString());

        // Invoking the complete operation on the _test
        _test.caseAssignment(assignCaseCommand);

        // Verifies whether interrogation domain was saved.
        verify(caseRepository, times(1)).save(aCase);


        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(CaseAssignedEvent.class));
    }

    @Test
    public void shouldAddNoteInArrest() {
        AddNoteCommand command = new AddNoteCommand("Nitesh");
        List<CaseNoteDto> noteDtoList = new ArrayList<>();
        CaseNoteDto caseNoteDto = new CaseNoteDto();
        caseNoteDto.setId(1L);
        caseNoteDto.setViewId(1L);
        caseNoteDto.setDisplayTextNote("test");
        caseNoteDto.setIsDeleted(0L);
        noteDtoList.add(caseNoteDto);
        command.withNoteList(noteDtoList);
        assertThat(_test.addNote(command)).isNotNull();
    }

    @Test
    public void shouldEditNoteInArrest() {
       EditNoteCommand command = new EditNoteCommand(new NoteKey(1L), "Nitesh");
        List<CaseNoteDto> noteDtoList = new ArrayList<>();
        CaseNoteDto caseNoteDto = new CaseNoteDto();
        caseNoteDto.setId(1L);
        caseNoteDto.setDisplayTextNote("test");
        caseNoteDto.setIsDeleted(0L);
        caseNoteDto.setViewId(1L);
        noteDtoList.add(caseNoteDto);
        command.withNoteList(noteDtoList);
        assertThat(_test.modifyNote(command)).isNotNull();
    }

    @Test
    public void shouldRemoveNoteInArrest() {
       DeleteNoteCommand command = new DeleteNoteCommand(new NoteKey(1L));
        List<CaseNoteDto> noteDtoList = new ArrayList<>();
        CaseNoteDto caseNoteDto = new CaseNoteDto();
        caseNoteDto.setId(1L);
        caseNoteDto.setViewId(1L);
        caseNoteDto.setDisplayTextNote("test");
        caseNoteDto.setIsDeleted(0L);
        noteDtoList.add(caseNoteDto);
        command.withNoteList(noteDtoList);
        assertThat(_test.removeNote(command)).isNotNull();
    }

    @Test
    public void shouldCreateCase() throws JsonProcessingException {
        List<CasePartyDto> partyDtoList = new ArrayList<>();
        CasePartyDto casePartyDto = new CasePartyDto();
        casePartyDto.setPartyId(1L);
        casePartyDto.setPartyType(new Entry(1L));
        casePartyDto.setCaseId(1L);
        partyDtoList.add(casePartyDto);
        List<PartyKey> partyKeyList = new ArrayList<>();
        CaseNoteDto caseNoteDto = new CaseNoteDto();
        caseNoteDto.setId(0);
        caseNoteDto.setIsDeleted(1L);
        List<CaseNoteDto> noteList = new ArrayList<>();
        noteList.add(caseNoteDto);
        List<AssociatedCaseKey> caseAssociationDtoList = new ArrayList<>();
        AssociatedCaseKey caseAssociationDto = new AssociatedCaseKey(1L);
        caseAssociationDtoList.add(caseAssociationDto);

        List<AttachmentReferenceKey> attachmentReferenceKeys = new ArrayList<>();
        AttachmentReferenceKey attachmentReferenceKey = new AttachmentReferenceKey(1L);
        attachmentReferenceKeys.add(attachmentReferenceKey);
        CreateCaseCommand command = new CreateCaseCommand.Builder(new ArrestReportKey(1L),Section.CRM,Department.DETECTIVE,Section.CRM)
                .withVisionCaseNumber("201/2017")
                .withArrestReason(new ArrestReason(1L))
                .withCasePartyList(partyDtoList)
                .withCreatedBy("Mitesh")
                .withFirNumber("TEST").
                withTransferredFrom( new Entry(1L))
                .withUnit(new Entry(1L))
                .build();

        Case aCase = mock(Case.class);


        // Setting the behaviour of mocked dependencies.

        doReturn(new CaseKey(1L)).when(caseKeyProvider).next();
        doReturn(new String()).when(jsonMapper).writeValueAsString(anyObject());
        doReturn(new NoteKey(1L)).when(caseNoteKeyProvider).next();


        // Invoking the complete operation on the _test
        _test.createCase(command);

        // Verifies whether interrogation domain was saved.
        verify(caseRepository, times(0)).save(aCase);
        // Verifies whether interrogation action history was saved.
        verify(caseActionHistoryRepository, times(1)).save(isA(CaseActionHistory.class));
        // Verifies whether interrogation status history was saved.

        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(CaseCreatedEvent.class));

    }

    @Test
    public void shouldUpdateCase() throws JsonProcessingException {
        CaseKey caseKey = new CaseKey(1L);
        List<CasePartyDto> partyDtoList = new ArrayList<>();
        CasePartyDto casePartyDto = new CasePartyDto();
        casePartyDto.setPartyId(1L);
        casePartyDto.setPartyType(new Entry(1L));
        casePartyDto.setCaseId(1L);
        partyDtoList.add(casePartyDto);
        List<PartyKey> partyKeyList = new ArrayList<>();
        CaseNoteDto caseNoteDto = new CaseNoteDto();
        caseNoteDto.setId(0);
        caseNoteDto.setIsDeleted(1L);
        List<CaseNoteDto> noteList = new ArrayList<>();
        noteList.add(caseNoteDto);
        List<AssociatedCaseKey> caseAssociationDtoList = new ArrayList<>();
        AssociatedCaseKey caseAssociationDto = new AssociatedCaseKey(1L);
        caseAssociationDtoList.add(caseAssociationDto);

        List<AttachmentReferenceKey> attachmentReferenceKeys = new ArrayList<>();
        AttachmentReferenceKey attachmentReferenceKey = new AttachmentReferenceKey(1L);
        attachmentReferenceKeys.add(attachmentReferenceKey);
        UpdateCaseCommand command = new UpdateCaseCommand.Builder(new CaseKey(1L),partyKeyList)

                .withArrestReason(new ArrestReason(1L))
                .withCasePartyList(partyDtoList)
                .withCreatedBy("Mitesh")
                .withFirNumber("TEST").
                        withTransferredFrom(new Entry(1L))
                .withUnit(new Entry(1L))


                .build();

        Case aCase = mock(Case.class);
        CaseDto caseDto = new CaseDto();
        caseDto.setDepartment(new Entry(30L));
        caseDto.setSection(new Entry(298L));
        doReturn(aCase).when(caseRepository).findOne(caseKey.id());
        doReturn(caseDto).when(caseMapper).mapToCaseDto(any(Case.class));
        // Setting the behaviour of mocked dependencies.
        CaseUpdatedEvent event = mock(CaseUpdatedEvent.class);
        doReturn(new CaseKey(1L)).when(caseKeyProvider).next();
        doReturn(new String()).when(jsonMapper).writeValueAsString(anyObject());
        doReturn(new NoteKey(1L)).when(caseNoteKeyProvider).next();
        doReturn(event).when(aCase).update(anySet(),anyList(),anySet(),anySet(),anyObject(),any(ArrestReason.class),anySet(),anyString(),anyLong(),anyString(),anyObject());

        doNothing().when(event).withCasePartiesJson(anyString());

        // Invoking the complete operation on the _test
        _test.update(command);


        // Verifies whether interrogation domain was saved.
        verify(caseRepository, times(1)).save(aCase);
        // Verifies whether interrogation action history was saved.

        // Verifies whether interrogation status history was saved.

        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(CaseUpdatedEvent.class));

    }

    @Test
    public void shouldCreateTransferredCase() throws JsonProcessingException {
        List<CasePartyDto> partyDtoList = new ArrayList<>();
        CasePartyDto casePartyDto = new CasePartyDto();
        casePartyDto.setPartyId(1L);
        casePartyDto.setPartyType(new Entry(1L));
        casePartyDto.setCaseId(1L);
        partyDtoList.add(casePartyDto);
        List<PartyKey> partyKeyList = new ArrayList<>();
        CaseNoteDto caseNoteDto = new CaseNoteDto();
        caseNoteDto.setId(0);
        caseNoteDto.setIsDeleted(1L);
        List<CaseNoteDto> noteList = new ArrayList<>();
        noteList.add(caseNoteDto);
        List<AssociatedCaseKey> caseAssociationDtoList = new ArrayList<>();
        AssociatedCaseKey caseAssociationDto = new AssociatedCaseKey(1L);
        caseAssociationDtoList.add(caseAssociationDto);

        List<AttachmentReferenceKey> attachmentReferenceKeys = new ArrayList<>();
        AttachmentReferenceKey attachmentReferenceKey = new AttachmentReferenceKey(1L);
        attachmentReferenceKeys.add(attachmentReferenceKey);
        TransferCaseCommand command = new TransferCaseCommand(new CaseKey(1L),new ArrestReportKey(1L),new TrackerKey(1L)
                ,partyDtoList);

        Case aCase = mock(Case.class);
        CaseDto caseDto = mock(CaseDto.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(aCase).when(persistentUtil).retrieveFullFetchedEntity(anyString(),any(),anyLong());
        doReturn(caseDto).when(caseMapper).mapToCaseDto(any(Case.class));
        doReturn(new Entry(30L)).when(caseDto).getDepartment();
        doReturn(new Entry(296L)).when(caseDto).getSection();
        doReturn(new CaseKey(1L)).when(caseKeyProvider).next();
        doReturn(new String()).when(jsonMapper).writeValueAsString(anyObject());
        doReturn(new NoteKey(1L)).when(caseNoteKeyProvider).next();


        // Invoking the complete operation on the _test
        _test.createTransferredCase(command);

        // Verifies whether interrogation domain was saved.
        verify(caseRepository, times(0)).save(aCase);
        // Verifies whether interrogation action history was saved.
        verify(caseActionHistoryRepository, times(1)).save(isA(CaseActionHistory.class));
        verify(caseTransferDetailRepository, times(1)).save(isA(CaseTransferDetail.class));
        // Verifies whether interrogation status history was saved.

        // being published to the EventBus.
        verify(eventBus, times(0)).publish(isA(TransferredCaseCreatedEvent.class));
    }
    @Test
    public void shouldReceiveTransferredCase(){
        CaseTransferDetail caseTransferDetail = mock(CaseTransferDetail.class);
        CaseTransferDetailDto caseTransferDetailDto = mock(CaseTransferDetailDto.class);
        Case aCase = mock(Case.class);
        doReturn(caseTransferDetail).when(caseTransferDetailRepository).findOne(anyLong());
        doReturn(aCase).when(caseRepository).findOne(anyLong());
        doReturn(caseTransferDetailDto).when(caseTransferDetailMapper).mapToDto(any(CaseTransferDetail.class));

        _test.receiveTransferredCase("String",new CaseTransferKey(1L));
        verify(caseTransferDetailRepository, times(1)).save(isA(CaseTransferDetail.class));
        verify(caseRepository, times(1)).save(aCase);
        verify(caseActionHistoryRepository, times(1)).save(isA(CaseActionHistory.class));
    }

    @Test
    public void shouldTransferToInternalSectionCase() {

        // Preparing test data.
        CaseKey caseKey = new CaseKey(1L);
        TransferToCaseCommand transferToCaseCommand =
                new TransferToCaseCommand(caseKey, Department.DETECTIVE, Section.CRM);
        Case aCase = mock(Case.class);
        CaseTransferredToSectionEvent caseTransferredToSectionEvent =
                mock(CaseTransferredToSectionEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(aCase).when(caseRepository).findOne(caseKey.id());
        doReturn(caseTransferredToSectionEvent).when(aCase)
                .transferToSection(anyLong(), anyString());

        // Invoking the complete operation on the _test
        _test.forwardToInternalSection(transferToCaseCommand);

        // Verifies whether interrogation domain was saved.
        verify(caseRepository, times(1)).save(aCase);
        // Verifies whether interrogation action history was saved.
        verify(caseActionHistoryRepository, times(1)).save(isA(CaseActionHistory.class));

        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(CaseTransferredToSectionEvent.class));
    }

    @Test
    public void shouldReturnToInternalSectionCase() {

        // Preparing test data.
        CaseKey caseKey = new CaseKey(1L);
        ReturnCaseCommand transferToCaseCommand =
                new ReturnCaseCommand(caseKey);
        Case aCase = mock(Case.class);
        CaseTransferredToSectionEvent caseTransferredToSectionEvent =
                mock(CaseTransferredToSectionEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(aCase).when(caseRepository).findOne(caseKey.id());
        doReturn(caseTransferredToSectionEvent).when(aCase)
                .transferToOriginalSection(anyString());

        // Invoking the complete operation on the _test
        _test.returnToOriginalSection(transferToCaseCommand);

        // Verifies whether interrogation domain was saved.
        verify(caseRepository, times(1)).save(aCase);
        // Verifies whether interrogation action history was saved.
        verify(caseActionHistoryRepository, times(1)).save(isA(CaseActionHistory.class));

        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(CaseTransferredToSectionEvent.class));
    }
}
