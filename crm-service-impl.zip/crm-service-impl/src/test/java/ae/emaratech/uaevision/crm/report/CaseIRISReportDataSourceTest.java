package ae.emaratech.uaevision.crm.report;

import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.crm.query.CaseQueryService;
import ae.emaratech.uaevision.crm.query.RetrieveCaseQuery;
import ae.emaratech.uaevision.deportation.application.dto.DeportationDto;
import ae.emaratech.uaevision.deportation.query.DeportationQueryService;
import ae.emaratech.uaevision.deportation.query.RetrieveDeportationFromDeporteeQuery;
import ae.emaratech.uaevision.document.service.api.DocumentService;
import ae.emaratech.uaevision.document.service.dto.DocumentReferenceDto;
import ae.emaratech.uaevision.fis.gateway.deportation.resource.DeportationResourceGateway;
import ae.emaratech.uaevision.fis.party.application.dto.ChargeDto;
import ae.emaratech.uaevision.fis.party.application.dto.IRISDto;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import ae.emaratech.uaevision.fis.party.query.RetrievePartyQuery;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import net.sf.jasperreports.engine.JRDataSource;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.StrictAssertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.doReturn;

/**
 * Test class providing unit test cases for {IRISReportDataSource}
 *
 * @author Satya K
 */
@RunWith(MockitoJUnitRunner.class)
public class CaseIRISReportDataSourceTest {

    @InjectMocks
    private CaseIRISReportDataSource _test;

    @Mock
    private PartyQueryService partyQueryService;

    @Mock
    private DeportationResourceGateway deportationResourceGateway;

    @Mock
    private DocumentService documentServiceMock;

    @Mock
    private CaseQueryService caseQueryService;

    @Test
    public void shouldGetIRISDataSource() throws Exception {

        //Preparing input data
        ReportParameters reportParameters = new ReportParameters();
        reportParameters.addParameter("CASE_ID", 12);
        reportParameters.addParameter("PARTY_ID_IRIS", 2);

        CaseDto caseDto = new CaseDto();
        caseDto.setId(1L);
        caseDto.setCaseNumber("incident number");
        caseDto.setCreatedBy("incident number");
        caseDto.setCreatedDate(new Date());
        caseDto.setDepartment(new Entry(1L, "Investigation"));
        caseDto.setSection(new Entry(1L, "Section"));
        caseDto.setStatus(new Entry(1L, "Status"));

        CasePartyDto casePartyDto = new CasePartyDto();
        casePartyDto.setPartyId(1L);
        casePartyDto.setCaseId(1L);
        List<CasePartyDto> list = new ArrayList();
        list.add(casePartyDto);

        caseDto.setCasePartyDtoList(list);
        caseDto.setId(1L);
        // incidentDto.set

        DeportationDto deportationDto = new DeportationDto();
        deportationDto.setArrivalCountry(new Entry(1L, "ArrCountry"));
        deportationDto.setCountry(new Entry(2L, "DeptCountry"));

        Mockito.doReturn(deportationDto).when(deportationResourceGateway)
                .getDeportation(anyLong());

        PartyDto partyDto = new PartyDto();
        List<ChargeDto> listOfCharges = new ArrayList<>();
        ChargeDto chargeDto = new ChargeDto();
        chargeDto.setCharge(new Entry(1L, "Test charge"));
        listOfCharges.add(chargeDto);
        partyDto.setListofCharges(listOfCharges);

        IRISDto irisDto = new IRISDto();
        irisDto.setIrisNumber("Iris number");
        irisDto.setNameChangedId(new Entry(2L, "Changed"));
        irisDto.setLocationId(new Entry(3L, "Loc"));
        irisDto.setIrisAttachmentId(2L);

        partyDto.setIrisDto(irisDto);
        partyDto.setNameEn("En Name");
        partyDto.setNameAr("AR Name");
        partyDto.setNationality(new Entry(1L, "Test charge"));
        partyDto.setPersonType(new Entry(1L, "Test charge"));
        partyDto.setNameAr("AR Name");
        partyDto.setNationality(new Entry(2L, "Naitonality"));
        partyDto.setOriginalNationality(new Entry(2L, "oNaitonality"));
        partyDto.setDateofbirth(new Date());
        partyDto.setGender(new Entry(3L, "Male"));
        partyDto.setAttachmentId(1L);
        partyDto.setPartyStatusLk(new Entry(8L, "Deported"));

        byte[] photo = new byte[1];
        DocumentReferenceDto documentReferenceDto = new DocumentReferenceDto();
        documentReferenceDto.setAttachment(photo);
        doReturn(documentReferenceDto).when(documentServiceMock).downloadDocument(any());
        doReturn(caseDto).when(caseQueryService).retrieveCase(
                any(RetrieveCaseQuery.class));
        doReturn(partyDto).when(partyQueryService).retrieveParty(any(RetrievePartyQuery.class));
        // doReturn(incidentDto).when(incidentService).findById(any());

        // Invoking the getDataSource on _test
        JRDataSource dataSource = _test.getDataSource(reportParameters);
        assertThat(dataSource).isInstanceOf(JRDataSource.class);
        assertThat(dataSource).isNotNull();
    }

    @Test
    public void shouldProvideReportDataWithoutPhotoAndCharges() throws Exception {

        //Preparing input data
        ReportParameters reportParameters = new ReportParameters();
        reportParameters.addParameter("CASE_ID", 12);
        reportParameters.addParameter("PARTY_ID_IRIS", 2);

        CaseDto caseDto = new CaseDto();
        caseDto.setId(1L);
        caseDto.setCaseNumber("incident number");
        caseDto.setCreatedBy("incident number");
        caseDto.setCreatedDate(new Date());
        caseDto.setDepartment(new Entry(1L, "Investigation"));
        caseDto.setSection(new Entry(1L, "Section"));
        caseDto.setStatus(new Entry(1L, "Status"));

        CasePartyDto casePartyDto = new CasePartyDto();
        casePartyDto.setPartyId(1L);
        casePartyDto.setCaseId(1L);
        List<CasePartyDto> list = new ArrayList();
        list.add(casePartyDto);

        caseDto.setCasePartyDtoList(list);
        caseDto.setId(1L);
        // incidentDto.set

        DeportationDto deportationDto = new DeportationDto();
        deportationDto.setArrivalCountry(new Entry(1L, "ArrCountry"));
        deportationDto.setCountry(new Entry(2L, "DeptCountry"));

        Mockito.doReturn(deportationDto).when(deportationResourceGateway)
                .getDeportation(anyLong());

        PartyDto partyDto = new PartyDto();
        List<ChargeDto> listOfCharges = new ArrayList<>();
        ChargeDto chargeDto = new ChargeDto();
        chargeDto.setCharge(new Entry(1L, "Test charge"));
        listOfCharges.add(chargeDto);
        partyDto.setListofCharges(listOfCharges);

        IRISDto irisDto = new IRISDto();
        irisDto.setIrisNumber("Iris number");
        irisDto.setNameChangedId(new Entry(2L, "Changed"));
        irisDto.setLocationId(new Entry(3L, "Loc"));
        irisDto.setIrisAttachmentId(2L);

        partyDto.setIrisDto(irisDto);
        partyDto.setNameEn("En Name");
        partyDto.setNameAr("AR Name");
        partyDto.setNationality(new Entry(2L, "Naitonality"));
        partyDto.setOriginalNationality(new Entry(2L, "oNaitonality"));
        partyDto.setPersonType(new Entry(2L, "oNaitonality"));
        partyDto.setDateofbirth(new Date());
        partyDto.setGender(new Entry(3L, "Male"));
        partyDto.setAttachmentId(1L);
        partyDto.setPartyStatusLk(new Entry(8L, "Deported"));

        byte[] photo = new byte[1];
        DocumentReferenceDto documentReferenceDto = new DocumentReferenceDto();
        documentReferenceDto.setAttachment(photo);
        doReturn(documentReferenceDto).when(documentServiceMock).downloadDocument(any());
        doReturn(caseDto).when(caseQueryService).retrieveCase(
                any(RetrieveCaseQuery.class));
        doReturn(partyDto).when(partyQueryService).retrieveParty(any(RetrievePartyQuery.class));
        doReturn(documentReferenceDto).when(documentServiceMock).downloadDocument(any());

        // doReturn(incidentDto).when(incidentService).findById(any());

        // Invoking the getDataSource on _test
        JRDataSource dataSource = _test.getDataSource(reportParameters);
        assertThat(dataSource).isNotNull();
        assertThat(dataSource).isInstanceOf(JRDataSource.class);
    }

}
