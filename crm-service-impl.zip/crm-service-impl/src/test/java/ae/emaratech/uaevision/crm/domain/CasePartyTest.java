package ae.emaratech.uaevision.crm.domain;

/**
 * Created by Nitesh.Gupta on 7/10/2016.
 */

import ae.emaratech.uaevision.fis.common.key.PartyKey;
import org.junit.Test;

import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;

public class CasePartyTest {

    @Test
    public void shouldInitializeCaseParty() {
        CaseParty caseParty = new CaseParty(new PartyKey(1L));
        caseParty.setCaseReference(CaseDataConstants.getCaseData());
        caseParty.setCreatedBy("test");
        caseParty.setCreatedDate(new Date());
        assertThat(caseParty.getCaseReference()).isNotNull();
        assertThat(caseParty.getPartyId()).isNotNull();
        assertThat(caseParty.getCreatedDate()).isNotNull();
        assertThat(caseParty.getCreatedBy()).isNotNull();
        assertThat(caseParty.id()).isNull();
    }
}
