package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.crm.domain.CaseAction;
import ae.emaratech.uaevision.crm.domain.CaseStatus;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.List;

import static org.junit.Assert.assertNotNull;

/**
 * Test class providing unit test cases for {@link CaseStateMachine}
 *
 * @author Haroon.Subair
 */
@RunWith(MockitoJUnitRunner.class)
public class CaseStateMachineTest {

    @InjectMocks
    private CaseStateMachine _test;

    @Test
    public void shouldReturnNextActionList() {

        List<CaseAction> nextActionList = CaseStateMachine.nextPossibleActions(
                CaseStatus.OPENED, false);
        assertNotNull("nextActionList returned is null", nextActionList);

        nextActionList = CaseStateMachine.nextPossibleActions(
                CaseStatus.APPROVED, true);
        assertNotNull("nextActionList returned is null", nextActionList);

        nextActionList = CaseStateMachine.nextPossibleActions(
                CaseStatus.CLOSED, false);
        assertNotNull("nextActionList returned is null", nextActionList);

        nextActionList = CaseStateMachine.nextPossibleActions(
                CaseStatus.ENDED, true);
        assertNotNull("nextActionList returned is null", nextActionList);

        nextActionList = CaseStateMachine.nextPossibleActions(
                CaseStatus.PENDING_DECISION, false);
        assertNotNull("nextActionList returned is null", nextActionList);

        nextActionList = CaseStateMachine.nextPossibleActions(
                CaseStatus.TRANSFERRED, false);
        assertNotNull("nextActionList returned is null", nextActionList);
    }

}
