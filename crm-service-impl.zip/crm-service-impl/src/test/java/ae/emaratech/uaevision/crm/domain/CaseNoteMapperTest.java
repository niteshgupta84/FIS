package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.application.dto.CaseNoteDto;
import ae.emaratech.uaevision.fis.common.key.NoteKey;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashSet;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Nitesh.Gupta on 7/10/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class CaseNoteMapperTest {

    @InjectMocks
    private CaseNoteMapper _test;
    @Mock
    protected UserService userDetailsService;

    @Test
    public void shouldMapToNoteDto() {

        CaseNote caseNote = new CaseNote(new NoteKey(1L), "test", 0L);
        caseNote.setCaseReference(CaseDataConstants.getCaseData());
        caseNote.setIsDeleted(1L);
        caseNote.setNote("Note");
        CaseNoteDto dto = _test.mapToCaseNoteDto(caseNote);
        assertThat(dto).isNotNull();
        assertThat(caseNote.getCaseReference()).isNotNull();
        assertThat(caseNote.getNote()).isNotNull();
        assertThat(caseNote.getIsDeleted()).isNotNull();
    }

    @Test
    public void shouldMapNoteDtoList() {
        CaseNote caseNote = new CaseNote(new NoteKey(1L), "test", 0L);
        caseNote.setCaseReference(CaseDataConstants.getCaseData());
        caseNote.setIsDeleted(1L);
        caseNote.setNote("Note");
        Set<CaseNote> entities = new HashSet<>();
        entities.add(caseNote);
        assertThat(_test.mapToCaseNoteDtList(entities)).isNotNull().hasSize(1);
    }
}
