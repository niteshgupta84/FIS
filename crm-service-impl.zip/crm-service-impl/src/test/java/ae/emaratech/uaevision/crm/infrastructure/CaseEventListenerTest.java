package ae.emaratech.uaevision.crm.infrastructure;

import ae.emaratech.uaevision.arrest.application.ArrestReportApplicationService;
import ae.emaratech.uaevision.crm.ahwal.service.AhwalCaseService;
import ae.emaratech.uaevision.crm.ahwal.service.AhwalIncidentMQClient;
import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.crm.domain.CaseApplicationService;
import ae.emaratech.uaevision.crm.query.CaseQueryService;
import ae.emaratech.uaevision.crm.query.RetrieveCaseQuery;
import ae.emaratech.uaevision.deportation.domain.DeportationCompletedEvent;
import ae.emaratech.uaevision.document.service.api.DocumentService;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.DeportationKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.key.QueueMessageKey;
import ae.emaratech.uaevision.fis.gateway.api.QueueMessageRecordingService;
import ae.emaratech.uaevision.fis.gateway.domain.QueueMessage;
import ae.emaratech.uaevision.fis.gateway.domain.QueueMessageType;
import ae.emaratech.uaevision.fis.order.query.OrderQueryService;
import ae.emaratech.uaevision.fis.order.query.RetrieveOrderFromModuleQuery;
import ae.emaratech.uaevision.fis.order.service.dto.OrderDto;
import ae.emaratech.uaevision.fis.party.application.CreatePartyResult;
import ae.emaratech.uaevision.fis.party.application.ModuleTypes;
import ae.emaratech.uaevision.fis.party.application.PartyService;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.InputStream;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

/**
 * Created by Deep.Gupta on 11/23/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class CaseEventListenerTest {

    @InjectMocks
    private CaseEventListener caseEventListener;

    @Mock
    QueueMessageRecordingService queueMessageRecordingService;

    @Mock
    QueueMessage queueMessage;

    @Mock
    PartyService partyService;

    @Mock
    ArrestReportApplicationService arrestReportApplicationService;

    @Mock
    CaseApplicationService caseApplicationService;

    @Mock
    AhwalIncidentMQClient ahwalIncidentMQClient;

    @Mock
    OrderQueryService orderQueryService;

    @Mock
    DocumentService documentService;

    @Mock
    AhwalCaseService ahwalCaseService;

    @Mock
    CaseQueryService caseQueryService;


    @org.junit.Before
    public void init() throws Exception{
        PartyKey partyKey = new PartyKey(1L);
        CreatePartyResult createPartyResult = new CreatePartyResult(partyKey);
        doReturn(createPartyResult).when(partyService).createParty(any());
    }

    @Test
    public void shouldFailForBlankXML() throws Exception{
        QueueMessageKey queueMessageKey = new QueueMessageKey(1L);
        QueueMessage queueMessage = new QueueMessage(queueMessageKey, "", QueueMessageType.INBOUND,null);
        doReturn(queueMessage).when(queueMessageRecordingService).recordNewInboundMessage(any(),any());
        boolean success = caseEventListener.processAhwalMessageFomVision(null);
        Assert.assertEquals(success,false);
    }

    @Test
    public void shouldFailForUnknownUDBWithoutName() throws Exception{
        QueueMessageKey queueMessageKey = new QueueMessageKey(1L);
        QueueMessage queueMessage = new QueueMessage(queueMessageKey, getSampleXML("unknown_udb_blank_first_name.xml"), QueueMessageType.INBOUND,null);
        doReturn(queueMessage).when(queueMessageRecordingService).recordNewInboundMessage(any(),any());
        //boolean success = caseEventListener.processAhwalMessageFomVision(null);
    }

    @Test
    public void shouldSaveAttachment() throws Exception{
        QueueMessageKey queueMessageKey = new QueueMessageKey(1L);
        QueueMessage queueMessage = new QueueMessage(queueMessageKey, getSampleXML("unknown_udb_with_attachment.xml"), QueueMessageType.INBOUND,null);
        doReturn(queueMessage).when(queueMessageRecordingService).recordNewInboundMessage(any(),any());
        //boolean success = caseEventListener.processAhwalMessageFomVision(null);
    }

    @Test
    public void shouldDeportationCompletedEvent(){
        DeportationCompletedEvent deportationCompletedEvent =
                new DeportationCompletedEvent.Builder(
                        new EventContext(ModuleTypes.DEPORTATION, 1L),
                        new PartyKey(1L), new DeportationKey(1L))
                        .withDeportationStatus(1L)
                        .withDeporteeStatus(1L)
                        .withCompletionComments("Test")
                        .build();
        OrderDto orderDto = new OrderDto();
        orderDto.setParentIncidentId(1L);
        doReturn(orderDto).when(orderQueryService).retrieveOrderByTypeAndModuleId(any(RetrieveOrderFromModuleQuery.class));
        doReturn(mock(CaseDto.class)).when(caseQueryService).retrieveCase(any(RetrieveCaseQuery.class));
        doNothing().when(ahwalCaseService).sendDeportResultToVision(anyString(),anyString());
        caseEventListener.deportationCompletedEvent(deportationCompletedEvent);

    }

    private String getSampleXML(String xmlName) throws Exception{
        InputStream in = this.getClass().getResourceAsStream("/testxml/ahwal_messages/" + xmlName);
        String xml = IOUtils.toString(in);
        return xml;
    }


}
