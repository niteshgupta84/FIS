package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.StrictAssertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;

/**
 * Created by Nitesh.Gupta on 4/4/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class CaseTransferDetailMapperTest {

    @Mock
    private LookupService lookupService;

    @InjectMocks
    CaseTransferDetailMapper _test;

    @Test
     public void shouldMapToTransferDto(){
        Optional<Entry> entry = Optional.of(new Entry(1L, "Test"));
        doReturn(entry).when(lookupService).getLookupEntry(any(), any(), any());
        CaseTransferDetail caseTransferDetail = new CaseTransferDetail.Builder(1L,1L,1L,1L).build();

        assertThat(_test.mapToDto(caseTransferDetail)).isNotNull();
    }
    @Test
    public void shouldMapToTransferDtoWithoutValidIds(){
        Optional<Entry> entry = Optional.of(new Entry(1L, "Test"));
        doReturn(entry).when(lookupService).getLookupEntry(any(), any(), any());
        CaseTransferDetail caseTransferDetail = new CaseTransferDetail.Builder(1L,-1L,-1L,-1L).build();
        caseTransferDetail.withReceivedStatus(1L);
        caseTransferDetail.withReceivedBy("nitesh");
        caseTransferDetail.withTransferredCaseId(1L);
        assertThat(_test.mapToDto(caseTransferDetail)).isNotNull();

    }

    @Test
    public void shouldMapToTransferDtoDetails(){
        Optional<Entry> entry = Optional.of(new Entry(1L, "Test"));
        doReturn(entry).when(lookupService).getLookupEntry(any(), any(), any());
        CaseTransferDetail caseTransferDetail = new CaseTransferDetail.Builder(1L,-1L,-1L,-1L).build();
        List<CaseTransferDetail> details = new ArrayList<>();
        details.add(caseTransferDetail);
        assertThat(_test.mapEntityToDTOList(details)).isNotNull();
    }
}
