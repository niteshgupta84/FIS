package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doReturn;

/**
 * Created by Nitesh.Gupta on 7/11/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class CasePartyMapperTest {

    @InjectMocks
    private CasePartyMapper _test;
    @Mock
    private LookupService lookupService;
    @Mock
    protected UserService userDetailsService;
    @Before
    public void setup(){
        Optional<Entry> entry = Optional.of(new Entry(1L, "Test"));
        doReturn(entry).when(lookupService).getLookupEntry(any(), any(), any());
        doReturn(entry).when(lookupService).getLookupAttributes(any(), any(), any(), any());
        doReturn("test").when(userDetailsService).getUserFirstNameByUserLogin(anyString());
    }
    @Test
    public void shouldMapCasePartyDto() {
        CaseParty caseParty = new CaseParty(new PartyKey(1L));
        caseParty.setCreatedDate(new Date());
        caseParty.setCreatedBy("Nitesh");
        caseParty.setPartyTypeId(1L);
        caseParty.setCaseReference(CaseDataConstants.getCaseData());
        Set<CasePartyCharge> set = new HashSet<>();
        CasePartyCharge casePartyCharge = new CasePartyCharge();
        casePartyCharge.setChargeId(1L);
        casePartyCharge.setId(1L);
        set.add(casePartyCharge);
        caseParty.withPartyCharges(set);
        assertThat(_test.mapToCasePartyDto(caseParty)).isNotNull();
        assertThat(caseParty.getCreatedDate()).isNotNull();
        assertThat(caseParty.getCreatedBy()).isNotNull();
        assertThat(caseParty.getPartyId()).isNotNull();
        assertThat(caseParty.getCaseReference()).isNotNull();
        assertThat(caseParty.id()).isNull();
    }

    @Test
    public void shouldMapArrestPartyDtoList() {
        CaseParty caseParty = new CaseParty(new PartyKey(1L));
        caseParty.setCreatedDate(new Date());
        caseParty.setCreatedBy("Nitesh");
        caseParty.setCaseReference(CaseDataConstants.getCaseData());
        Set<CaseParty> caseParties = new HashSet<>();
        caseParties.add(caseParty);
        assertThat(_test.mapToDtoList(caseParties)).isNotNull().hasSize(1);
    }


    @Test
    public void shouldMapArrestPartyDtoListWithEmptySet() {

        assertThat(_test.mapToDtoList(null)).isNotNull().hasSize(0);
    }


}
