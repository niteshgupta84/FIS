package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.key.CaseKey;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Nitesh.Gupta on 7/10/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class CaseStatusHistoryTest {

    @Test
    public void shouldInitializeArrestStatusHistory() {
        CaseStatusHistory statusHistory = new CaseStatusHistory(new CaseKey(1l), 1L);
        statusHistory.setCreatedBy("Nitesh");
        statusHistory.setCreatedDate(new Date());
        assertThat(statusHistory.getCreatedDate()).isNotNull();
        assertThat(statusHistory.getCreatedBy()).isNotNull();
        assertThat(statusHistory.getCaseId()).isNotNull();
        assertThat(statusHistory.getId()).isNull();

        CaseStatusHistory history = new CaseStatusHistory.Builder(1L).withStatusId(1L).build();
        assertThat(history).isNotNull();

    }

}
