package ae.emaratech.uaevision.crm.report;

import ae.emaratech.uaevision.fis.order.query.OrderQueryService;
import ae.emaratech.uaevision.fis.order.query.ReleaseOrderQueryService;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.context.ApplicationContext;

import java.text.ParseException;

/**
 * Created by Wasib.Khan on 5/28/2016.
 */
public class ReleaseReportDataSourceDataSourceTest {


    @Mock
    private PartyQueryService partyQueryService;

    @Mock
    private OrderQueryService orderQueryService;


    @Mock
    private ApplicationContext ctx;

    @InjectMocks
    private ReleaseReportDataSource releaseReportDataSource;

    @Mock
    private ReleaseOrderQueryService releaseOrderQueryService;

    @Before
    public void setup() throws Exception {

        //setFinalStatic(InterrogationReportGenerator.class.getField("JASPER_TEMPLATE"), "interrogation-report"); // For a String
        MockitoAnnotations.initMocks(this);


    }

    @Test
    public void shouldReturnDataSource() throws ParseException {
       /* OrderDto orderDto = new OrderDto();
        orderDto.setId(1L);
        orderDto.setPartyId(1L);
        orderDto.setParentIncidentId(1L);
        doReturn(orderDto).when(orderQueryService).retrieveOrder(
                new RetrieveOrderQuery(new OrderKey(1L)));

        ReleaseOrderDto releaseOrderDto = new ReleaseOrderDto();
        Date date = new Date();
        releaseOrderDto.setCreatedBy("Wasib Ali Khan");
        releaseOrderDto.setCreatedDate(new Date());
        releaseOrderDto.setApprovedBy(1L);
        releaseOrderDto.setStatus(1L);
        releaseOrderDto.setReason("Due to bad health");
        releaseOrderDto.setDateOfIssue(new Date());
        releaseOrderDto.setIsReleasePermanent(true);
        releaseOrderDto.setFromDate(new Date());
        releaseOrderDto.setToDate(new Date());
        releaseOrderDto.setToDate(new Date());
        releaseOrderDto.setReleaseComments("DDDDDDDDDD");
        doReturn(releaseOrderDto).when(releaseOrderQueryService).retrieveReleaseOrderDetails(
                any(RetrieveReleaseOrderQuery.class));

        PartyKey partyKey = new PartyKey(orderDto.getPartyId());
        PartyDto partyDto = new PartyDto();

        partyDto.setAge(10L);
        partyDto.setGender(new Entry("1", "Male"));
        partyDto.setNationality(new Entry("1", "Indian"));
        partyDto.setProfession(new Entry("1", "Test"));
        partyDto.setCountry(new Entry("1", "country"));
        IncidentDto incidentDto = new IncidentDto();
        partyDto.setPassports(null);
        List<ChargeDto> lstCharges = new ArrayList<>();
        ChargeDto chargeDto = new ChargeDto();
        chargeDto.setNameEn("Set EN name");
        chargeDto.setNameAr("Set AR");
        chargeDto.setCharge(new Entry("1L", "Test na"));
        lstCharges.add(chargeDto);
        partyDto.setListofCharges(lstCharges);
        incidentDto.setIncidentNumber("DDD/00001/2016");
        doReturn(partyDto).when(partyQueryService).retrieveProfile(any(RetrievePartyQuery.class));
        doReturn(incidentDto).when(incidentService).findById(any());
        doReturn("Test").when(ctx).getMessage(any(), any(), any());
        ReportParameters reportParameters = new ReportParameters();
        reportParameters.addParameter("ORDER_ID", "1");
        reportParameters.addParameter("PARENT_INCIDENT_ID", "1");

        releaseReportDataSource.getDataSource(reportParameters);*/
    }
}
