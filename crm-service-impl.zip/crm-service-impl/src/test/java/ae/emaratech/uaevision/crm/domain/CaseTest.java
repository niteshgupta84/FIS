package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.arrest.domain.ArrestReason;
import ae.emaratech.uaevision.fis.common.key.AssociatedCaseKey;
import ae.emaratech.uaevision.fis.common.key.AttachmentReferenceKey;
import ae.emaratech.uaevision.fis.common.key.NoteKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.assertj.core.api.StrictAssertions.assertThat;

/**
 * Created by Nitesh.Gupta on 7/21/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class CaseTest {


    @Test
    public void shouldCloseArrest() {
        Case _test = CaseDataConstants.getCaseData();
        CaseClosedEvent event = _test.close("Close");
        assertThat(event).isNotNull();
    }

    @Test
    public void shouldForwardCase() {
        Case _test = CaseDataConstants.getCaseData();
        CaseTransferredToSectionEvent event = _test.transferToSection(1L, "Close");
        assertThat(event).isNotNull();
    }
    @Test
    public void shouldReOpenArrest() {
        Case _test = CaseDataConstants.getCaseData();
        CaseReopenedEvent event = _test.reopen();
        assertThat(event).isNotNull();
    }

    @Test
    public void shouldTransferToCaseArrest() {
        Case _test = CaseDataConstants.getCaseData();
        CaseTransferredToCRMEvent
                event =
                _test.transferTo(Department.BORDER_CONTROL, Section.AIRPORT_CONTROL, "Test");

        assertThat(event).isNotNull();
    }

    @Test
    public void shouldForwardToSuperVisorArrest() {
        Case _test = CaseDataConstants.getCaseData();
        CaseReviewedEvent event = _test.review("Test");
        assertThat(event).isNotNull();
    }

    @Test
    public void shouldFRejectArrest() {
        Case _test = CaseDataConstants.getCaseData();
        CaseRejectedEvent event = _test.reject("Test");
        assertThat(event).isNotNull();
    }

    @Test
    public void shouldApproveArrest() {
        Case _test = CaseDataConstants.getCaseData();

        CaseApprovedEvent event = _test.approve("Test");
        assertThat(event).isNotNull();
    }

    @Test
    public void shouldAssignArrest() {
        Case _test = CaseDataConstants.getCaseData();
        CaseAssignedEvent event = _test.assignUser("Test");
        assertThat(event).isNotNull();

    }

    @Test
    public void shouldUpdateCase() {
        Case _test = CaseDataConstants.getCaseData();

        CaseParty caseParty = new CaseParty(new PartyKey(1L), 1L, 0L);
        Set<CaseParty> caseParties = new HashSet<>();
        caseParties.add(caseParty);
        // Arrest Attachment Set
        CaseAttachment caseAttachment = new CaseAttachment(new AttachmentReferenceKey(1L));
        Set<CaseAttachment> attachmentSet = new HashSet<>();
        attachmentSet.add(caseAttachment);
        List<PartyKey> partyKeyList = new ArrayList<>();
        partyKeyList.add(new PartyKey(1L));

        //Arrest Note
        CaseNote caseNote = new CaseNote(new NoteKey(1L), "String", 1L);
        Set<CaseNote> caseNoteSet = new HashSet<>();
        caseNoteSet.add(caseNote);

        //Arrest Association
        CaseAssociation caseAssociation = new CaseAssociation(new AssociatedCaseKey(1L));
        Set<CaseAssociation> caseAssociations = new HashSet<>();
        caseAssociations.add(caseAssociation);

        Set<AssociatedCaseKey> caseKeyHashSet = new HashSet<>();
        caseKeyHashSet.add(new AssociatedCaseKey(1L));
//Attachment List
        Owner owner = new Owner(Department.DETECTIVE,Section.AIRPORT_CONTROL,new Entry(1L));
        List<AttachmentReferenceKey> attachmentReferenceKeys = new ArrayList<>();
        attachmentReferenceKeys.add(new AttachmentReferenceKey(1L));
        CaseUpdatedEvent
                event =
                _test.update(caseParties, attachmentReferenceKeys, caseKeyHashSet, caseNoteSet,
                        new Entry(1L),
                        new ArrestReason(1L), null, "Test",0L,null,owner);

        assertThat(event).isNotNull();

    }

    @Test
    public void shouldManualTransferTest() {
        Case _test = CaseDataConstants.getCaseData();

        CaseManualTransferEvent event = _test.manualTransfer("Test", 1L);
        assertThat(event).isNotNull();
    }

    @Test
    public void shouldManualReceiveTest() {
        Case _test = CaseDataConstants.getCaseData();
        Entry entry = new Entry(1L);
        CaseManualReceiveEvent event = _test.manualReceive("Test", entry);
        assertThat(event).isNotNull();
    }
}
