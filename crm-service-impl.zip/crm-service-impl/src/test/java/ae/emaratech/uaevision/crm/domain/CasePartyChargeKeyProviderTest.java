package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceDefinition;
import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceService;
import ae.emaratech.uaevision.fis.common.key.CasePartyChargeKey;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.assertj.core.api.StrictAssertions.assertThat;
import static org.mockito.Mockito.doReturn;

/**
 * Created by Nitesh.Gupta on 8/1/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class CasePartyChargeKeyProviderTest {
    @InjectMocks
    private CasePartyChargeKeyProvider _test;
    @Mock
    private SequenceService sequenceService;


    @Test
    public void shouldReturnInterrogationKey() {
        doReturn(1L).when(sequenceService).nextValue(SequenceDefinition.CASE_PARTY_CHARGE);
        CasePartyChargeKey casePartyChargeKey = _test.next();
        assertThat(casePartyChargeKey).isInstanceOf(CasePartyChargeKey.class);
        assertThat(casePartyChargeKey).isNotNull();
    }
}
