package ae.emaratech.uaevision.lookup.service.controller;

import ae.emaratech.uaevision.fis.common.type.Section;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.lookup.service.api.LookupQuery;
import ae.emaratech.uaevision.lookup.service.api.LookupQueryFilter;
import ae.emaratech.uaevision.lookup.service.api.LookupQueryService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.domain.*;
import ae.emaratech.uaevision.lookup.service.model.*;
import io.swagger.annotations.*;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by Nitesh.Gupta on 11/26/2015.
 */
@Api(value ="Lookup" , description = "All Details of Lookup services")
@RestController
@RequestMapping(value = "/lookup", method = RequestMethod.GET)
public class LookupController {

    // list page
    @Autowired
    @Qualifier(value = "lookupService")
    private LookupService lookupService;

    @Autowired
    private LookupQueryService queryService;

    @ApiOperation(value = "All Lookups", notes = "It will list all lookups available in the FIS application")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "All Lookup names", response = String.class,responseContainer = "List")})
    @RequestMapping (value="/lookups" , method = RequestMethod.GET)
    public List getAllLookups(){
        List<String> list = new LinkedList<>();
        LookupDefinition[] lookups = LookupDefinition.values();
        for (LookupDefinition lookup : lookups){
            list.add(lookup.name());
        }
        return list;
    }
    @ApiOperation(value = "Lookup Data", notes = "It will return Lookup Data for enquired lookup")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = LookupEntry.class,responseContainer = "List")})
    @RequestMapping (value="{id}", method = RequestMethod.GET)
    public List<LookupEntry> populateLookupData(@ApiParam(value = "Lookup Name for which Entries need to be displayed, Check output of /lookups service ",required = true) @PathVariable String id){
        if (Checks.isNotNull(id)){
            return lookupService.getLookupEntries(Enum.valueOf(LookupDefinition.class, id));
        }
        return new ArrayList<>();

    }
    @ApiOperation(value = "Lookup Data", notes = "It will return Lookup Data for enquired lookup")
    @RequestMapping(value = "/getData", method = RequestMethod.GET)
    public

    List getSelections(@RequestParam("term") String input, HttpServletRequest request) {

        return simulateSearchResult(input, request.getParameter("queryId"));
    }

    /**
     * Fetching Areas for Emirates
     */
    @ApiOperation(value = "Area Lookup Data", notes = "It will return Area for selected City")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = Entry.class,responseContainer = "List")})
    @RequestMapping(value = "/getAreas", method = RequestMethod.GET)
    public

    List getAreasForCity(@ApiParam(value = "City Id",required = true) @RequestParam(value = "cityName", required = true) String city) {

        if (Checks.isNotValidLookUpId(city)){
            return new ArrayList<>();
        }
        Lookup lookup =
                lookupService.getChildLookup(LookupDefinition.CITY, LookupDefinition.AREA, Long.parseLong(city), false,
                        LocaleContextHolder.getLocale());

        return lookup.getEntries();

    }

    /**
     * Fetching Areas for Emirates
     */
    @ApiOperation(value = "City Lookup Data", notes = "It will return City for selected Emirate")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = Entry.class,responseContainer = "List")})
    @RequestMapping(value = "/getCities", method = RequestMethod.GET)
    public

    List getCityForEmirate(@ApiParam(value = "Emirate Id",required = true)  @RequestParam(value = "emirateName", required = true) Long emirate) {

        if (Checks.isNotValidLookUpId(emirate)){
            return new ArrayList<>();
        }
        Lookup lookup =
                lookupService.getChildLookup(LookupDefinition.EMIRATE, LookupDefinition.CITY,
                        emirate, false, LocaleContextHolder.getLocale());
        return lookup.getEntries();

    }

    /**
     * Fetching destinations for countries.
     */
    @ApiOperation(value = "All Destination Data", notes = "It will return destinations for selected country")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = Entry.class,responseContainer = "List")})
    @RequestMapping(value = "/getDestinations", method = RequestMethod.GET)
    public List getDestinationsForCountry(@ApiParam(value = "Country Id",required = true)  @RequestParam(value = "countryId", required = true)
                                              Long countryId) {

        if(!Checks.isNotValidLookUpId(countryId)) {
            Lookup lookup =
                lookupService.getChildLookup(LookupDefinition.COUNTRY, LookupDefinition.DESTINATION,
                                             countryId, false, LocaleContextHolder.getLocale());
            return lookup.getEntries();
        }
        return new ArrayList<>();
    }

    /**
     * Fetching ports for port type.
     */
    @ApiOperation(value = "All Port Data", notes = "It will return port data for selected prot type id")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = Entry.class,responseContainer = "List")})
    @RequestMapping(value = "/getPorts", method = RequestMethod.GET)
    public List getPortsForPortType(@ApiParam(value = "Port Type Id",required = true)  @RequestParam(value = "portTypeId", required = true)
                                    Long portTypeId) {

        Lookup lookup =
            lookupService.getChildLookup(LookupDefinition.PORT_TYPE, LookupDefinition.PORT,
                                         portTypeId, false, LocaleContextHolder.getLocale());
        return lookup.getEntries();
    }

    /**
     * Fetching Areas for Emirates
     */
    @ApiOperation(value = "All Section Data", notes = "It will return sections data for selected Department type id")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = Entry.class,responseContainer = "List")})
    @RequestMapping(value = "/getAllSections", method = RequestMethod.GET)
    public

    List getAllSectionsForDepartment( @ApiParam(value = "Department ",required = true)
                                      @RequestParam(value = "departmentName", required = true) Long department,
                                      @RequestParam(value = "section", required = true) Long section) {

        Lookup lookup =
                lookupService.getChildLookup(LookupDefinition.DEPARTMENT,
                        LookupDefinition.SECTION, department, false,
                        LocaleContextHolder.getLocale());
        List<Entry> sections = lookup.getEntries();
        return sections.stream().filter(sec -> !Objects.equals(sec.getId(),section)).collect(Collectors.toList());


    }

    /**
     * Method to search for Party charges.
     *
     * @param request the http request.
     * @return list of party charges entries
     */
    @ApiOperation(value = "Party Charges Data", notes = "It will return Lookup Data for Charges")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = LookupEntry.class,responseContainer = "List")})
    @RequestMapping(value = "/searchPartyCharges", method = RequestMethod.GET)

    public List<Entry> findPartyCharges(HttpServletRequest request) {

        String search = request.getParameter("search");
        String filterColumn = request.getParameter("filterColumn");
        String filterValue = request.getParameter("filterValue");
        filterValue = null;
        LookupQuery lookupQuery;
        if (StringUtils.isNotBlank(filterColumn) && StringUtils.isNotBlank(filterValue)) {
            LookupQueryFilter filter = new LookupQueryFilter(filterColumn, filterValue);
            lookupQuery = new LookupQuery.Builder(search).withFilter(filter).build();
        } else {
            lookupQuery = new LookupQuery.Builder(search).build();
        }

        List partyChargesList = queryService.retrieveLookupList(ChargeLk.class, lookupQuery);

        List<Entry> entryList = new ArrayList<>();
        partyChargesList.forEach(
                chargeEntity -> {
                    ChargeLk charge = (ChargeLk) chargeEntity;
                    String value = null;
                    if (LocaleContextHolder.getLocale().getLanguage().equals(
                            Locale.ENGLISH.getLanguage())) {
                        value =   charge.getEnglishValue() + "-" + charge.getLegacyId();

                    } else {
                        value = charge.getArabicValue() + "-" + charge.getLegacyId();
                    }
                    entryList.add(new Entry(charge.getId(), value));
                });

        return entryList;
    }

    /**
     * Method to search for Arrest reason.
     *
     * @param request the http request.
     * @return list of arrest reason entries
     */
    @ApiOperation(value = "Arrest Reason Data", notes = "It will return All Arrest Reasons")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = LookupEntry.class,responseContainer = "List")})
    @RequestMapping(value = "/searchArrestReason", method = RequestMethod.GET)

    public List<Entry> findArrestReason(HttpServletRequest request,@RequestParam String currentSection) {

        String search = request.getParameter("search");

        LookupQuery lookupQuery;
        if (Objects.equals(Section.AIRPORT_CONTROL.id(),Long.parseLong(currentSection))
                || Objects.equals(Section.LANDPORT.id(),Long.parseLong(currentSection)) ||
            Objects.equals(Section.SEAPORT.id(),Long.parseLong(currentSection))){
            LookupQueryFilter filter = new LookupQueryFilter("sectionId", currentSection);
            lookupQuery = new LookupQuery.Builder(search).withFilter(filter).build();
        }
        else {
            lookupQuery = new LookupQuery.Builder(search).build();
        }
        List arrestReasonList = queryService.retrieveLookupList(ArrestReasonLk.class, lookupQuery);

        List<Entry> entryList = new ArrayList<>();
        arrestReasonList.forEach(
                arrestEntity -> {
                    ArrestReasonLk arrestReason = (ArrestReasonLk) arrestEntity;
                    String value = null;
                    if (LocaleContextHolder.getLocale().getLanguage().equals(
                            Locale.ENGLISH.getLanguage())) {
                        value = arrestReason.getEnglishValue();
                    } else {
                        value = arrestReason.getArabicValue();
                    }
                    entryList.add(new Entry(arrestReason.getId(), value));
                });

        return entryList;
    }

    /**
     * Fetching Areas for Emirates
     */
    @ApiOperation(value = "Country Data", notes = "It will return All Countries")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = LookupEntry.class,responseContainer = "List")})
    @RequestMapping(value = "/searchCountries", method = RequestMethod.GET)

    public List<Entry> findCountries(HttpServletRequest request) {

        String search = request.getParameter("search");
        LookupQuery lookupQuery = new LookupQuery.Builder(search).build();
        List countryList = queryService.retrieveLookupList(CountryLk.class, lookupQuery);

        List<Entry> entryList = new ArrayList<>();
        countryList.forEach(
                countryEntity -> {
                    CountryLk countryLk = (CountryLk) countryEntity;
                    String value = null;
                    if (LocaleContextHolder.getLocale().getLanguage().equals(
                            Locale.ENGLISH.getLanguage())) {
                        value = countryLk.getEnglishValue();
                    } else {
                        value = countryLk.getArabicValue();
                    }
                    entryList.add(new Entry(countryLk.getId(), value));
                });

        return entryList;
    }

    /**
     * Fetching Areas for Emirates
     */
    @ApiOperation(value = "City Data", notes = "It will return All cities")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = LookupEntry.class,responseContainer = "List")})
    @RequestMapping(value = "/searchCities", method = RequestMethod.GET)

    public List<Entry> findCities(HttpServletRequest request) {

        String search = request.getParameter("search");
        LookupQuery lookupQuery = new LookupQuery.Builder(search).build();
        List cityList = queryService.retrieveLookupList(CityLk.class, lookupQuery);

        List<Entry> entryList = new ArrayList<>();
        cityList.forEach(
                cityEntity -> {
                    CityLk city = (CityLk) cityEntity;
                    String value = null;
                    if (LocaleContextHolder.getLocale().getLanguage().equals(
                            Locale.ENGLISH.getLanguage())) {
                        value = city.getEnglishValue();
                    } else {
                        value = city.getArabicValue();
                    }
                    entryList.add(new Entry(city.getId(), value));
                });

        return entryList;
    }

    /**
     * Fetching Areas for Emirates
     */
    @ApiOperation(value = "All Flights Data", notes = "It will return All flight Data")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = LookupEntry.class,responseContainer = "List")})
    @RequestMapping(value = "/searchFlights", method = RequestMethod.GET)

    public List<Entry> findFlights(HttpServletRequest request) {

        String search = request.getParameter("search");
        LookupQuery lookupQuery = new LookupQuery.Builder(search).build();
        List flightList = queryService.retrieveLookupList(FlightLk.class, lookupQuery);

        List<Entry> entryList = new ArrayList<>();
        flightList.forEach(
                flightEntity -> {
                    FlightLk flight = (FlightLk) flightEntity;
                    String value = null;
                    if (LocaleContextHolder.getLocale().getLanguage().equals(
                            Locale.ENGLISH.getLanguage())) {
                        value = flight.getFlightId() + " " + flight.getEnglishValue();
                    } else {
                        value = flight.getFlightId() + " " + flight.getArabicValue();
                    }
                    entryList.add(new Entry(flight.getId(), value));
                });

        return entryList;
    }

    /**
     * Fetching Areas for Emirates
     */
    @ApiOperation(value = "Profession Data", notes = "It will return All Profiessions")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = LookupEntry.class,responseContainer = "List")})
    @RequestMapping(value = "/searchProfessions", method = RequestMethod.GET)

    public List<Entry> findProfessions(HttpServletRequest request) {

        String search = request.getParameter("search");
        LookupQuery lookupQuery = new LookupQuery.Builder(search).build();
        List professionList = queryService.retrieveLookupList(ProfessionLk.class, lookupQuery);

        List<Entry> entryList = new ArrayList<>();
        professionList.forEach(
                professionEntity -> {
                    ProfessionLk professionLk = (ProfessionLk) professionEntity;
                    String value = null;
                    if (LocaleContextHolder.getLocale().getLanguage().equals(
                            Locale.ENGLISH.getLanguage())) {
                        value = professionLk.getEnglishValue();
                    } else {
                        value = professionLk.getArabicValue();
                    }
                    entryList.add(new Entry(professionLk.getId(), value));
                });

        return entryList;
    }

    /**
     * Method to search for Transferred From drop down populate.
     *
     * @param request the http request.
     * @return list of transferred from entries
     */
    @ApiOperation(value = "Transferred From Data", notes = "It will return All Transferred From")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = LookupEntry.class,responseContainer = "List")})
    @RequestMapping(value = "/lstTransferredFrom", method = RequestMethod.GET)

    public List<Entry> listTransferedFrom(HttpServletRequest request) {

        String search = request.getParameter("search");
        LookupQuery lookupQuery = new LookupQuery.Builder(search).build();
        List transferFromLst = queryService.retrieveLookupList(TransferEntityLk.class, lookupQuery);

        List<Entry> entryList = new ArrayList<>();
        transferFromLst.forEach(
                transferObj -> {
                    TransferEntityLk transferEntityLkObj = (TransferEntityLk) transferObj;
                    String value = null;
                    if (LocaleContextHolder.getLocale().getLanguage().equals(
                            Locale.ENGLISH.getLanguage())) {
                        value = transferEntityLkObj.getEnglishValue();
                    } else {
                        value = transferEntityLkObj.getArabicValue();
                    }
                    entryList.add(new Entry(transferEntityLkObj.getId(), value));
                });

        return entryList;
    }
    /**
     * Fetching Areas for Emirates
     */
    @ApiOperation(value = "Detention Sub Process List", notes = "It will return Sub Process List")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = Entry.class,responseContainer = "List")})
    @RequestMapping(value = "/getSubProcess", method = RequestMethod.GET)
    public

    List getSubProcessList(@ApiParam(value = "Process Id",required = true) @RequestParam(value = "processId", required = true) String processId) {

        if (Checks.isNotValidLookUpId(processId)){
            return new ArrayList<>();
        }
        Lookup lookup =
                lookupService.getChildLookup(LookupDefinition.DETENTION_FOLLOW_UP_PROCESS, LookupDefinition.DETENTION_SUB_FOLLOW_UP_PROCESS, Long.parseLong(processId), false,
                        LocaleContextHolder.getLocale());

        return lookup.getEntries();

    }

    /**
     * Fetching Areas for Emirates
     */
    @ApiOperation(value = "Airport Data", notes = "It will return All Airports")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = LookupEntry.class,responseContainer = "List")})
    @RequestMapping(value = "/searchAirports", method = RequestMethod.GET)

    public List<Entry> findAirports(HttpServletRequest request) {

        String search = request.getParameter("search");
        LookupQuery lookupQuery = new LookupQuery.Builder(search).build();
        List airportList = queryService.retrieveLookupList(AirportLk.class, lookupQuery);

        List<Entry> entryList = new ArrayList<>();
        airportList.forEach(
               airportEntity -> {
                    AirportLk airportLk = (AirportLk) airportEntity;
                    String value = null;
                    if (LocaleContextHolder.getLocale().getLanguage().equals(
                            Locale.ENGLISH.getLanguage())) {
                        value = airportLk.getEnglishValue();
                    } else {
                        value = airportLk.getArabicValue();
                    }
                    entryList.add(new Entry(airportLk.getId(), value));
                });

        return entryList;
    }
    /**
     * Fetching Areas for Emirates
     */
    @ApiOperation(value = "All Case Status Data ", notes = "It will return All Case Statuses")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = Entry.class,responseContainer = "List")})
    @RequestMapping(value = "/case/statuses", method = RequestMethod.GET)
    public List getAllCaseStatus() {

        Lookup lookup =
                lookupService.getLookup(LookupDefinition.CASE_STATUS,
                        LocaleContextHolder.getLocale());
        return  lookup.getEntries();


    }
    /**
     * Fetching Areas for Emirates
     */
    @ApiOperation(value = "All Genders ", notes = "It will return All Case Statuses")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Lookup Data", response = Entry.class,responseContainer = "List")})
    @RequestMapping(value = "/genders", method = RequestMethod.GET)
    public List getAllGenders() {

        Lookup lookup =
                lookupService.getLookup(LookupDefinition.GENDER,
                        LocaleContextHolder.getLocale());
        return  lookup.getEntries();


    }
    private List<Entry> simulateSearchResult(String input, String queryId) {
        List<Entry> result = new ArrayList<>();

        for (LookupDefinition lookDef : LookupDefinition.values()) {
            if (lookDef.name().equals(queryId)) {
                Lookup lookup = lookupService.getLookup(lookDef, Long.parseLong(input), LookupFilter.NAME_STARTS_WITH);
                return lookup.getEntries();
            }
        }
        return result;
    }
}


