package ae.emaratech.uaevision.lookup.service.impl;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import ae.emaratech.uaevision.fis.common.util.PreCondition;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.*;

/**
 * Caches all the {@link LookupDefinition} in the singleton as a Map against the Locale. It uses the
 * {@link DefaultLookupServiceImpl} to load the lookup from the database during init.
 * <p/>
 * The structure of the Map is {@code Map<Locale, Map<LookupDefinition, Lookup>> }
 */
public class CachedLookupSeviceImpl implements LookupService {

    private static final Logger LOGGER = LogManager.getLogger();
    private static Locale ARABIC_LOCALE = Locale.forLanguageTag("ar");
    private static Locale ENGLISH_LOCALE = Locale.forLanguageTag("en");
    private static Locale DEFAULT_LOCALE = ARABIC_LOCALE;
    private Map<Locale, Map<LookupDefinition, Lookup>> lookups;
    private LookupService lookupService;

    /**
     * TODO : Javadoc
     */
    public CachedLookupSeviceImpl(DefaultLookupServiceImpl lookupService) {

        this.lookupService = lookupService;
    }

    /**
     * Loads all the lookups defined in {@link LookupDefinition}
     */
    public void init() {

        LOGGER.info("Loading all lookups during startup into the cache....");

        Map<LookupDefinition, Lookup> lookups_en = new HashMap<>();
        Map<LookupDefinition, Lookup> lookups_ar = new HashMap<>();

        for (LookupDefinition definition : LookupDefinition.values()) {

            lookups_en.put(definition, lookupService.getLookup(definition, ENGLISH_LOCALE));
            lookups_ar.put(definition, lookupService.getLookup(definition, ARABIC_LOCALE));
            LOGGER.printf(Level.INFO, "%s lookup loaded", definition.table());

        }
        Map<Locale, Map<LookupDefinition, Lookup>> lookupCache = new ConcurrentHashMap<>();
        lookupCache.put(ENGLISH_LOCALE, lookups_en);
        lookupCache.put(ARABIC_LOCALE, lookups_ar);

        lookups = lookupCache;

        LOGGER.info("All lookups have been loaded in the cache ...");
    }

    /**
     * Method which refreshes the lookups loaded in the memory by reading the updated lookup values
     * from database. The default scope is set to limit the visibility of refresh service to current
     * package.
     */
    void refresh() {
        init();
    }

    @Override
    public Lookup getLookup(LookupDefinition definition, Locale locale) {

        PreCondition.notNull(definition);
        PreCondition.notNull(locale);

        if (!lookups.containsKey(locale)) {


// TODO : Fix this issue as why locale is coming empty here (not null!!, but empty)
// throw new SystemException(SystemException.Code.DEFAULT,
//                                String.format("[%s] locale is not suuported by Lookups!", locale));

            //LOGGER.printf(Level.ERROR, "[%s] locale is not supported by Lookups!", locale);
            locale = DEFAULT_LOCALE;
        }

        return lookups.get(locale).get(definition);
    }

    @Override
    public Lookup getLookup(LookupDefinition lookupDefinition) {
        return getLookup(lookupDefinition, DEFAULT_LOCALE);
    }

    @Override
    public Lookup getLookup(LookupDefinition definition, Locale locale, Long name,
                            LookupFilter filter) {

        if (filter.equals(LookupFilter.PARENT_ID)) {
            return getChildLookup(definition.getParentLookup(), definition, name, false, locale);
        }

        return lookupService.getLookup(definition, locale, name, filter);

    }

    @Override
    public Lookup getLookup(LookupDefinition definition, Long name, LookupFilter filter) {
        return getLookup(definition, DEFAULT_LOCALE, name, filter);
    }

    @Override
    public Optional<Entry> getLookupEntry(LookupDefinition definition, Locale locale, Long id) {

        PreCondition.notNull(id);

        Lookup lookup = this.getLookup(definition, locale);
        List<Entry> entries = lookup.getEntries();

        for (Entry entry : entries) {

            if (id.equals(entry.getId())) {

                return Optional.of(entry);
            }
        }

        return Optional.empty();
    }

    @Override
    public Optional<Entry> getLookupEntry(LookupDefinition definition, Long id) {

        return this.getLookupEntry(definition, DEFAULT_LOCALE, id);
    }

    @Override
    public Lookup getChildLookup(LookupDefinition parentLookup, LookupDefinition childLookup, Long parentValue, Boolean includeOrphan, Locale locale) {

        List<Entry> childLookups = new ArrayList<>();

        if (childLookup.getParentLookup().equals(parentLookup)) {

            Entry parent = getLookupEntry(parentLookup, ARABIC_LOCALE, parentValue).get();
            Lookup lookup_en = getLookup(childLookup, ARABIC_LOCALE);

            if (locale.equals(ENGLISH_LOCALE)) {
                parent = getLookupEntry(parentLookup, ENGLISH_LOCALE, parentValue).get();
                lookup_en = getLookup(childLookup, ENGLISH_LOCALE);
            }

            for (Entry childLookupEntry : lookup_en.getEntries()) {
                if (childLookupEntry.getParentId() == null) {
                    if (includeOrphan) {
                        childLookups.add(childLookupEntry);
                    }
                } else {
                    if (childLookupEntry.getParentId().equals(parent.getId())) {
                        childLookups.add(childLookupEntry);
                    }
                }
            }
        }

        return new Lookup(childLookups, locale);
    }

    @Override
    public Optional<Entry> getParentLookup(LookupDefinition childLookup, LookupDefinition parentLookup, String childValue, Locale locale) {

        return lookupService.getParentLookup(childLookup, parentLookup, childValue, locale);

        //return Optional.of(getLookupEntry(childLookup, locale, childValue).get().getParentEntry());

    }

    @Override
    public Optional<Entry> getLookupByColumnAttributeFilter(Locale locale,
                                                            LookupDefinition lookupDefinition,
                                                            String filterColumnAttribute,
                                                            String attributeToFilter, boolean isFilterColumnAttributeNumber) {
        return lookupService.getLookupByColumnAttributeFilter(locale, lookupDefinition,
                filterColumnAttribute, attributeToFilter
                , isFilterColumnAttributeNumber);
    }

    @Override
    public Lookup getLookupAttributes(LookupDefinition lookupDefinition, Locale locale,
                                      List<Attribute> listOfAttributes) {
        return lookupService.getLookupAttributes(lookupDefinition, locale,
                listOfAttributes);
    }

    @Override
    public Optional<Entry> getLookupAttributes(LookupDefinition definition, Locale locale,
                                               Long id, List<Attribute> attributeList) {
        PreCondition.notNull(id);

        Lookup lookup = this.getLookupAttributes(definition, locale, attributeList);
        List<Entry> entries = lookup.getEntries();

        for (Entry entry : entries) {

            if (id.equals(entry.getId())) {

                return Optional.of(entry);
            }
        }

        return Optional.empty();
    }

    @Override
    public List<LookupEntry> getLookupEntries(LookupDefinition lookupDefinition) {
        return lookupService.getLookupEntries(lookupDefinition);
    }

}
