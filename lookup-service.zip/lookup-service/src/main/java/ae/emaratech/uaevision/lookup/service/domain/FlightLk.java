package ae.emaratech.uaevision.lookup.service.domain;

import org.hibernate.annotations.Formula;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by Nitesh.Gupta on 8/11/2016.
 */
@Entity
@Table(name = "FLIGHT_CODE_LK")
public class FlightLk {

    @Column(name = "ID", unique = true, nullable = false, precision = 22, scale = 0)
    @Id
    private Long id;

    @Column(name = "FLIGHT_ID", nullable = false)
    private String flightId;

    @Column(name = "NAME_EN", nullable = false)
    private String englishValue;

    @Column(name = "NAME_AR", nullable = false)
    private String arabicValue;

    @Column(name = "IS_DELETED", nullable = false)
    private Integer isDeleted;
    @Column(name = "FLIGHT_CODE_ID")
    private Long flightCodeId;

    @Formula("NAME_AR || '|' || lower(NAME_EN) || '|' || lower(FLIGHT_ID) || '|' || FLIGHT_CODE_ID")
    private String searchableInfo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFlightId() {
        return flightId;
    }

    public void setFlightId(String flightId) {
        this.flightId = flightId;
    }

    public String getEnglishValue() {
        return englishValue;
    }

    public void setEnglishValue(String englishValue) {
        this.englishValue = englishValue;
    }

    public String getArabicValue() {
        return arabicValue;
    }

    public void setArabicValue(String arabicValue) {
        this.arabicValue = arabicValue;
    }

    public Integer getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Long getFlightCodeId() {
        return flightCodeId;
    }

    public void setFlightCodeId(Long flightCodeId) {
        this.flightCodeId = flightCodeId;
    }

    public String getSearchableInfo() {
        return searchableInfo;
    }

    public void setSearchableInfo(String searchableInfo) {
        this.searchableInfo = searchableInfo;
    }
}
