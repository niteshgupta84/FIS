package ae.emaratech.uaevision.lookup.service.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * A simple JavaBean to represent label-value pairs. This is most commonly used when constructing
 * user interface elements which have a label to be displayed to the user, and a corresponding value
 * to be returned to the server. One example is the <code>&lt;html:options&gt;</code> tag.
 * <p/>
 * <p>Note: this class has a natural ordering that is inconsistent with equals.
 */
@ApiModel(value = "Entry")
public class Entry implements Comparable, Serializable {

    /**
     * Comparator that can be used for a case insensitive sort of <code>LabelValue</code> objects.
     */
    public static final Comparator CASE_INSENSITIVE_ORDER = (o1, o2) -> {
        String label1 = ((Entry) o1).getName();
        String label2 = ((Entry) o2).getName();
        return label1.compareToIgnoreCase(label2);
    };
    private static final long serialVersionUID = 3689355407466181430L;


    @ApiModelProperty(value = "The property which supplies the option label visible to the end user", required = false)
    private String name;


    @ApiModelProperty(value = "The property which supplies the value returned to the server",required = true)
    private Long id;


    @ApiModelProperty(value = "The property which contain the parent entry id",required = false)
    private Long parentId;

    @ApiModelProperty(value = "The List which will contain selected Values",required = false)
    private List<Attribute> selectedAttributes = new ArrayList<>();

    public Entry(){

    }
    public Entry(final Long id) {

        this.id = id;
    }

    /**
     * Constructor taking String and converting it into Long for defaault vlaues
     * @param id
     */
    public Entry(final String id) {
        this.id = Long.parseLong(id);
    }
    /**
     * Construct an instance with the supplied property values.
     *
     * @param name The label to be displayed to the user.
     * @param id   The value to be returned to the server.
     */
    public Entry(final Long id, final String name) {
        this(id, name, null);
    }

    public Entry(final String id, final String name) {
        this(id, name, null);
    }
    public Entry(final Long id, final String name, final Long parentId) {
        this.name = name;
        this.id = id;
        this.parentId = parentId;
    }

    public Entry(final String id, final String name, final String parentId) {
        this.name = name;
        this.id = Long.parseLong(id);
        this.parentId = Long.parseLong(parentId);
    }
    public Entry(final Long id, final String name, final Long parentId, List<Attribute> attributes) {
        this.name = name;
        this.id = id;
        this.parentId = parentId;
        this.selectedAttributes = attributes;
    }

    public Entry(final String name, final String id, final String parentId, List<Attribute> attributes) {
        this.name = name;
        this.id = Long.parseLong(id);
        this.parentId = Long.parseLong(parentId);
        this.selectedAttributes = attributes;
    }


    public String getName() {
        return this.name;
    }

    public Long getId() {
        return this.id;
    }

    public Long getParentId() {
        return parentId;
    }

    public List<Attribute> getSelectedAttributes() {
        return selectedAttributes;
    }

    // --------------------------------------------------------- Public Methods

    /**
     * Compare LabelValueBeans based on the label, because that's the human viewable part of the
     * object.
     *
     * @param o LabelValue object to compare to
     * @return 0 if labels match for compared objects
     * @see Comparable
     */
    public int compareTo(Object o) {
        // Implicitly tests for the correct type, throwing
        // ClassCastException as required by interface
        String otherLabel = ((Entry) o).getName();

        return this.getName().compareTo(otherLabel);
    }

    /**
     * Return a string representation of this object.
     *
     * @return object as a string
     */
    public String toString() {

        return ToStringBuilder.reflectionToString(this, ToStringStyle.SIMPLE_STYLE);

    }

    /**
     * LabelValueBeans are equal if their values are both null or equal.
     *
     * @param obj object to compare to
     * @return true/false based on whether values match or not
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }

        if (!(obj instanceof Entry)) {
            return false;
        }

        Entry bean = (Entry) obj;
        int nil = (this.getId() == null) ? 1 : 0;
        nil += (bean.getId() == null) ? 1 : 0;

        if (nil == 2) {
            return true;
        } else if (nil == 1) {
            return false;
        } else {
            return this.getId().equals(bean.getId());
        }

    }

    /**
     * The hash code is based on the object's value.
     *
     * @return hashCode
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
        return (this.getId() == null) ? 17 : this.getId().hashCode();
    }
}
