package ae.emaratech.uaevision.lookup.service.domain;

import org.hibernate.annotations.Formula;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by Nitesh.Gupta on 8/11/2016.
 */
@Entity
@Table(name = "CITY_LK")
public class CityLk extends LookupEntity {

    @Column(name = "COUNTRY_ID")
    private Long countryId;

    @Formula("NAME_AR || '|' || lower(NAME_EN) || '|' || ID")
    private String searchableInfo;

    private CityLk() {

    }


    public String getSearchableInfo() {
        return searchableInfo;
    }

    public void setSearchableInfo(String searchableInfo) {
        this.searchableInfo = searchableInfo;
    }

}
