package ae.emaratech.uaevision.lookup.service.domain;

import org.hibernate.annotations.Formula;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by Nitesh.Gupta on 8/11/2016.
 */
@Entity
@Table(name = "COUNTRY_LK")
public class CountryLk extends LookupEntity {

    @Column(name = "COUNTRY_CODE")
    private String countryCode;

    @Formula("NAME_AR || '|' || lower(NAME_EN) || '|' || ID || '|' || lower(COUNTRY_CODE)")
    private String searchableInfo;

    private CountryLk() {

    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getSearchableInfo() {
        return searchableInfo;
    }

    public void setSearchableInfo(String searchableInfo) {
        this.searchableInfo = searchableInfo;
    }
}
