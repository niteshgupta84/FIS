package ae.emaratech.uaevision.lookup.service.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.io.Serializable;
import java.util.Comparator;

/**
 * Created by Nitesh.Gupta on 11/13/2016.
 */
public class LookupEntry implements Comparable, Serializable {
    /**
     * Comparator that can be used for a case insensitive sort of <code>LabelValue</code> objects.
     */
    public static final Comparator CASE_INSENSITIVE_ORDER = (o1, o2) -> {
        String label1 = ((Entry) o1).getName();
        String label2 = ((Entry) o2).getName();
        return label1.compareToIgnoreCase(label2);
    };
    /**
     * The property which supplies the option label visible to the end user.
     */
    private String nameEn;
    /**
     * The property which supplies the option label visible to the end user.
     */
    private String nameAr;

    /**
     * The property which supplies the value returned to the server.
     */
    private Long id;

    public LookupEntry(final Long id) {

        this.id = id;
    }

    public LookupEntry(final Long id, final String nameEn, final String nameAr) {
        this.nameEn = nameEn;
        this.id = id;
        this.nameAr = nameAr;
    }
    @Override
    public int compareTo(Object o) {
        String otherLabel = ((Entry) o).getName();

        return this.getNameEn().compareTo(otherLabel);
    }

    public String getNameEn() {
        return nameEn;
    }

    public String getNameAr() {
        return nameAr;
    }

    public Long getId() {
        return id;
    }

    /**
     * Return a string representation of this object.
     *
     * @return object as a string
     */
    public String toString() {

        return ToStringBuilder.reflectionToString(this, ToStringStyle.SIMPLE_STYLE);

    }

    /**
     * LabelValueBeans are equal if their values are both null or equal.
     *
     * @param obj object to compare to
     * @return true/false based on whether values match or not
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }

        if (!(obj instanceof Entry)) {
            return false;
        }

        Entry bean = (Entry) obj;
        int nil = (this.getId() == null) ? 1 : 0;
        nil += (bean.getId() == null) ? 1 : 0;

        if (nil == 2) {
            return true;
        } else if (nil == 1) {
            return false;
        } else {
            return this.getId().equals(bean.getId());
        }

    }

    /**
     * The hash code is based on the object's value.
     *
     * @return hashCode
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
        return (this.getId() == null) ? 17 : this.getId().hashCode();
    }
}
