package ae.emaratech.uaevision.lookup.service.api;

import ae.emaratech.uaevision.lookup.service.model.Entry;

import java.util.List;

/**
 * Query service which provides methods to query lookup data.
 *
 * @author Haroon.Subair
 */
public interface LookupQueryService {

    List<Entry> retrieveLookupList(Class lookupEntity, LookupQuery lookupQuery);

}
