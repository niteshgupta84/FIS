package ae.emaratech.uaevision.lookup.service.api;

/**
 * Class wrapping the search query details for fetching look up data that match the criterion.
 *
 * @author Haroon.Subair
 */
public class LookupQuery {

    private String searchParameter;

    private LookupQueryFilter filter;

    private LookupQuery() {
    }

    public LookupQuery(Builder builder) {
        this.searchParameter = builder.searchParameter;
        this.filter = builder.filter;
    }

    public String getSearchParameter() {
        return searchParameter;
    }

    public LookupQueryFilter getFilter() {
        return filter;
    }

    public static class Builder {

        private String searchParameter;

        private LookupQueryFilter filter;

        public Builder(String searchParameter) {
            this.searchParameter = searchParameter;
        }

        public Builder withFilter(LookupQueryFilter filter) {
            this.filter = filter;
            return this;
        }

        public LookupQuery build() {
            return new LookupQuery(this);
        }

    }

}
