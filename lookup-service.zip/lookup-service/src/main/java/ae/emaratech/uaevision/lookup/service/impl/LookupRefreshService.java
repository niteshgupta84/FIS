package ae.emaratech.uaevision.lookup.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ae.emaratech.uaevision.lookup.service.api.LookupService;

/**
 * Service which refreshes the lookup definitions loaded in the memory with the latest content from
 * the database.
 *
 * @author Haroon.Subair
 */
@Service
public class LookupRefreshService {

  /**
   * Static containing logger for the debugging purpose.
   */
  private static final Logger LOGGER = LogManager.getLogger();

  /**
   * Reference to the lookupService bean which serves the lookups loaded from the cache.
   */
  @Autowired
  private LookupService lookupService;

  /**
   * Method which retrieves the latest lookup details from the database and updates the lookup
   * cache.
   */
  public synchronized void refresh() {

    LOGGER.debug("Preparing to refresh the lookup cache.");

    CachedLookupSeviceImpl cachedLookupSevice = (CachedLookupSeviceImpl) lookupService;
    cachedLookupSevice.refresh();

    LOGGER.debug("Lookup cache refreshed.");
  }

}
