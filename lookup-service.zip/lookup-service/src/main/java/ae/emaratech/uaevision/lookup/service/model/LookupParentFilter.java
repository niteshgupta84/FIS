package ae.emaratech.uaevision.lookup.service.model;

/**
 * List of filters on which the Lookup will be filtered by {@code Lookup#parent}
 */
public enum LookupParentFilter {

}
