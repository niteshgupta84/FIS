package ae.emaratech.uaevision.lookup.service.annotation;

import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


/**
 * This annotation should be used at JPA {@code Entity} for attributes that are lookup values.
 * <p/>
 * At the Service layer these will be resolved into {@code Lookup} values for use by the Application
 * layer.
 *
 * @see ae.emaratech.uaevision.lookup.service.model.Lookup
 * @see LookupDefinition
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface LookupField {

    /**
     * @return the lookup to be used to query and fill the reset of the {@code Lookup} object
     */
    LookupDefinition value();

}
