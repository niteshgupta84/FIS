package ae.emaratech.uaevision.lookup.service.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.util.*;

/**
 * The holder for the Lookup entries. <p> This might provided convenient utility methods in the
 * future.
 *
 * @see Entry
 */
// TODO : Need to add entry Maps so the getLookupById in this only
public class Lookup {


    private Map<Locale, List<Entry>> allEntries = new HashMap<>();
    private List<Entry> entries = new ArrayList<>();
    private Locale locale;

    public Lookup() {

    }

    public Lookup(List<Entry> entries, Locale locale) {

        this.entries = entries;
        this.locale = locale;
    }

    public List<Entry> getEntries() {
        return entries;
    }

    public void setEntries(List<Entry> entries) {
        this.entries = entries;
    }

    public void add(Entry entry) {

        entries.add(entry);
    }

    public Locale getLocale() {
        return locale;
    }

    public void setLocale(Locale locale) {
        this.locale = locale;
    }

    /**
     * Return a string representation of this object.
     *
     * @return object as a string
     */
    public String toString() {

        return ToStringBuilder.reflectionToString(this, ToStringStyle.SIMPLE_STYLE);

    }


}
