package ae.emaratech.uaevision.lookup.service.impl;

import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.domain.LookupEntity;
import ae.emaratech.uaevision.lookup.service.model.*;
import com.google.common.base.Preconditions;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * Default implementation class that gets the {@link Lookup} from the database.
 */
//@Service
public class DefaultLookupServiceImpl implements LookupService {

    /**
     *
     */
    private static final Logger LOGGER = LogManager.getLogger();
    /**
     *
     */
    private DataSource dataSource;

    /**
     * @param dataSource the database from which the lookup tables will be accessed
     */
    public DefaultLookupServiceImpl(final DataSource dataSource) {

        this.dataSource = dataSource;
    }

    @Override
    public final Lookup getLookup(final LookupDefinition definition, final Locale locale) {

        return this.getLookup(definition, locale, 0L, LookupFilter.NONE);

    }

    @Override
    public final Lookup getLookup(final LookupDefinition definition) {

        return this.getLookup(definition, DEFAULT_LOCALE);
    }

    @Override
    public Lookup getLookup(final LookupDefinition definition, final Locale locale,
                            final Long attribute, final LookupFilter nameFilter) {

        JdbcTemplate jdbc = new JdbcTemplate(dataSource);

        String SQL = definition.sql(locale.getLanguage(), attribute, nameFilter);

        LOGGER.printf(Level.DEBUG, "SQL = %s", SQL);

        List<Entry> entries = jdbc.query(SQL, (rs, i) -> {

            Entry entry = new Entry(rs.getLong(1), rs.getString(2), rs.getLong(3));

            return entry;
        });

        return new Lookup(entries, locale);
    }

    @Override
    public final Lookup getLookup(final LookupDefinition definition, final Long name,
                                  final LookupFilter nameFilter) {

        return getLookup(definition, DEFAULT_LOCALE, name, nameFilter);

    }

    @Override
    //@fixme Badly implemented and will have performance issues. Need to modify to select directly from db.
    public final Optional<Entry> getLookupEntry(final LookupDefinition definition,
                                                final Locale locale, final Long id) {

        Preconditions.checkNotNull(id);

        Lookup lookup = this.getLookup(definition, locale);
        List<Entry> entries = lookup.getEntries();

        for (Entry entry : entries) {

            if (id.equals(entry.getId())) {

                return Optional.of(entry);
            }
        }

        return Optional.empty();

    }

    @Override
    public final Optional<Entry> getLookupEntry(final LookupDefinition definition, final Long id) {
        return this.getLookupEntry(definition, DEFAULT_LOCALE, id);
    }

    @Override
    public Lookup getChildLookup(LookupDefinition parentLookup, LookupDefinition childLookup, Long parentValue,
                                 Boolean includeOrphan, Locale locale) {

        Preconditions.checkNotNull(parentValue);

        String SQL = LookupDefinition.childLookup(parentLookup, childLookup, parentValue, includeOrphan, locale);

        JdbcTemplate jdbc = new JdbcTemplate(dataSource);

        List<Entry> entries = jdbc.query(SQL, (rs, i) -> {

            Entry entry = new Entry(rs.getLong(1), rs.getString(2), rs.getLong(3));

            return entry;
        });

        return new Lookup(entries, locale);
    }

    @Override
    public Optional<Entry> getParentLookup(LookupDefinition childLookup, LookupDefinition parentLookup,
                                           String childValue, Locale locale) {

        Preconditions.checkNotNull(childValue);

        String SQL = LookupDefinition.parentLookup(childLookup, parentLookup, childValue, locale);

        JdbcTemplate jdbc = new JdbcTemplate(dataSource);

        List<Entry> entries = jdbc.query(SQL, (rs, i) -> {

            Entry entry = new Entry(rs.getLong(1), rs.getString(2), rs.getLong(3));

            return entry;
        });

        return Optional.of(entries.get(0));
    }

    @Override
    public Optional<Entry> getLookupByColumnAttributeFilter(Locale locale,
                                                            LookupDefinition lookupDefinition,
                                                            String filterColumnAttribute,
                                                            String attributeToFilter,
                                                            boolean isFilterColumnAttributeNumber) {

        Preconditions.checkNotNull(filterColumnAttribute);
        Preconditions.checkNotNull(attributeToFilter);

        String SQL = LookupDefinition.sqlFilterByColumnValue(locale, lookupDefinition,
                filterColumnAttribute,
                attributeToFilter,
                isFilterColumnAttributeNumber);

        JdbcTemplate jdbc = new JdbcTemplate(dataSource);

        List<Entry> entries = jdbc.query(SQL, (rs, i) -> {

            Entry entry = new Entry(rs.getLong(1), rs.getString(2), rs.getLong(3));

            return entry;
        });

        return Optional.of(entries.get(0));
    }

    @Override
    public Lookup getLookupAttributes(LookupDefinition lookupDefinition, Locale locale, List<Attribute> listOfAttributes) {


        String SQL = LookupDefinition.sqlSelectAllAttributes(locale, lookupDefinition, listOfAttributes);

        JdbcTemplate jdbc = new JdbcTemplate(dataSource);

        List<Entry> entries = jdbc.query(SQL, (rs, i) -> {

            List<Attribute> selectedColumns = new ArrayList();
            for (Attribute attribute : listOfAttributes) {
                selectedColumns.add(new Attribute(attribute.getName(), rs.getString(attribute.getName())));
            }
            Entry entry = new Entry(rs.getLong(1), rs.getString(2), rs.getLong(3), selectedColumns);
            return entry;
        });

        return new Lookup(entries, locale);
    }

    @Override
    public Optional<Entry> getLookupAttributes(LookupDefinition definition, Locale locale, Long id,
                                               List<Attribute> attributeList) {
        Preconditions.checkNotNull(id);

        Lookup lookup = this.getLookupAttributes(definition, locale, attributeList);
        List<Entry> entries = lookup.getEntries();

        for (Entry entry : entries) {

            if (id.equals(entry.getId())) {

                return Optional.of(entry);
            }
        }

        return Optional.empty();
    }

    @Override
    public List<LookupEntry> getLookupEntries(LookupDefinition lookupDefinition) {

        String SQL = LookupDefinition.getSQLWithoutLocale(lookupDefinition);

        JdbcTemplate jdbc = new JdbcTemplate(dataSource);

        List<LookupEntry> entries = jdbc.query(SQL, (rs, i) -> {
            LookupEntry lookupEntity = new LookupEntry(rs.getLong(1), rs.getString(2), rs.getString(3));

            return lookupEntity;
        });
        return entries;
    }
}
