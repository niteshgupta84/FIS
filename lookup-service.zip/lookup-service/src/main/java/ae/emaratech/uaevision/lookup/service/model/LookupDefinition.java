package ae.emaratech.uaevision.lookup.service.model;

import ae.emaratech.uaevision.fis.common.util.PreCondition;

import java.util.List;
import java.util.Locale;

/**
 * List of definitions of lookup tables in the database FIS_REF. <p> Lookup tables in the database
 * are considered to be of a specific format, i.e.
 * <p/>
 * * TableName = Enum.name()_LK * IdColumn = ID * NameColumn = NAME_EN * ArabicNameColumn = NAME_AR
 * <p/>
 * This stores the respective definitions for each lookup table and based on the above conventions
 * constructs an SQL dynamically based on the values configured for the table.
 */
public enum LookupDefinition {

    /**
     * The lookup definition which corresponds to a lookup table in the database.
     */
    DEPARTMENT("department_lk"),
    PARTY_TYPE("party_type_lk"),
    ARREST_STATUS("arrest_status_lk"),
    ATTACHMENT_TYPE("mime_type_lk"),
    IDENTIFICATION_DOC_TYPE("id_document_type_lk"),
    SECTION("section_lk", DEPARTMENT),
    CHARGE("charge_lk", SECTION),
    ASSOCIATION_TYPE("incident_link_type_lk"),
    //VFIS 1904
    ID_DOC_TYPE("id_doc_type_lk"),
    PASSPORT_TYPE("passport_type_lk", ID_DOC_TYPE),
    DOCUMENT_TYPE("document_type_lk"),
    PERSON_TYPE("person_type_lk"),
    EMIRATE("emirate_lk"),
    GENDER("gender_lk"),
    CITY("city_lk", EMIRATE),
    COUNTRY("country_lk"),


    //FILE_TYPE("file_type_lk"),
    LEGALITY_STATUS("legality_status_lk"),
    PROFESSION("profession_lk"),
    PROFESSION_MINI("PROFESSIONMINI_LK"),
    EDUCATION("education_lk"),

    AREA("area_lk", CITY),
    ARREST_REASON("arrest_reason_lk"),

    ARREST_ACTION("arrest_action_lk"),
    TRANSFERREDFROM("transfer_entity_lk"),
    PARTY_STATUS("party_status_type_lk"),
    INCIDENT_TYPE("incident_type_lk"),
    ORDER_STATUS("order_status_lk"),

    //Added for VFIS 553
    UAE_ID_TYPE("uae_id_type_lk", ID_DOC_TYPE),
    INTERROGATION_STATUS("interrogation_status_lk"),
    INTERROGATION_ACTION("interrogation_action_lk"),
    INTERROGATION_DECISION("interrogation_decision_lk"),

    DEPORTATION_STATUS("deportation_status_lk"),
    DEPORTATION_ACTION("deportation_action_lk"),
    DEPORTATION_DESTINATION("deportation_destination_lk"),
    DEPORTATION_EXIT("deportation_exit_lk"),
    DETENTION_STATUS("detention_status_lk"),
    DETENTION_ACTION("detention_action_lk"),
    PORT_TYPE("port_type_lk"),
    PORT("port_lk", PORT_TYPE),
    GUARANTEE_STATUS("GURANTEE_STATUS_LK"),
    GUARANTEE_ACTION("GURANTEE_ACTION_LK"),
    RELEASE_REASON("RELEASE_REASON_LK"),
    GUARANTEE_PERIOD_STATUS("GUARANTEE_PERIOD_STATUS_LK"),
    RELEASE_STATUS_LK("RELEASE_STATUS_LK"),
    GUARANTEE_REASON("GUARANTEE_REASON_LK"),
    ORDER_TYPE("ORDER_TYPE_LK"),
    SOCIAL_STATUS("SOCIAL_STATUS_LK"),
    RELIGION("RELIGION_LK"),
    DOC_INSPECTION_RESULT("DOC_INSPECTION_RESULT_LK"),
    SECTION_UNITS("PORT_TERMINAL_LK",SECTION),
    ARREST_LOCATION_LK("ARREST_LOCATION_LK", SECTION),
    SHIFT("SHIFT_LK"),
    //Added by Wasib
    FREQUENCY("FREQUENCY_LK"),
    DESTINATION("destination_lk", COUNTRY),
    DEPORTATION_TYPE("DEPORTATION_TYPE_LK"),
    IRIS_NAME_CHANGED("IRIS_NAME_CHANGED_LK"),
    IRIS_LOCATION("IRIS_LOCATION_LK", SECTION),
    CASE_ACTION("case_action_lk"),
    CASE_STATUS("case_status_lk"),
    FLIGHT_CODE("flight_code_lk"),
    BAN_PERIOD_TYPE("ban_period_lk"),
    BAN_CATEGORY_REASON("ban_cat_reason_lk"),
    DETENTION_FOLLOW_UP_PROCESS("FOLLOWUP_PROCESS_LK"),
    DETENTION_SUB_FOLLOW_UP_PROCESS("SUB_FOLLOWUP_PROCESS_LK",DETENTION_FOLLOW_UP_PROCESS),
    DETENTION_TYPE("DETENTION_TYPE_LK"),
    TRANSPORT("transport_lk"),
    ENTRY_EXIT("entry_exit_info_lk"),
    TRANSPORT_TYPE("transport_type_lk");
    private static final String ID_COLUMN_SUFFIX = "_id";
    //private static final String TABLE_NAME_SUFFIX = "_lk";
    private static final String NAME_COLUMN = "name";
    private static final String SPACE = " ";
    private static final String OR = "or";
    private static final String IS_NULL = "is null";
    String _table;
    String _idColumn;
    String _nameColumn;
    String _parentColumn;
    LookupDefinition parentLookup;

    //VFIS 1904
    String _parentTable;

    LookupDefinition(String table) {

        this._table = table;// + TABLE_NAME_SUFFIX;
        this._idColumn = name() + ID_COLUMN_SUFFIX;
        this._nameColumn = NAME_COLUMN;

    }

    LookupDefinition(String table, LookupDefinition parent) {

        this._table = table;// + TABLE_NAME_SUFFIX;
        this._idColumn = name() + ID_COLUMN_SUFFIX;
        this._nameColumn = NAME_COLUMN;
        this._parentColumn = replaceLKwithID(parent._table);
        //VFIS 1904
        this._parentTable = parent._table;
        this.parentLookup = parent;
    }

    private static String replaceLKwithID(String toReplace) {

        return toReplace.replaceAll("_lk", "_id").replaceAll("_LK", "_id");

    }

    public static String childLookup(LookupDefinition parentLookup, LookupDefinition childLookup, Long attributeToFilter,
                                     Boolean includeOrphan, Locale locale) {

        StringBuilder SQL = new StringBuilder("SELECT").append(SPACE);
        SQL.append("ID").append(",");
        final String NAME_COLUMN_VAL = NAME_COLUMN + "_" + locale;
        SQL.append(NAME_COLUMN_VAL).append(SPACE).append(",");
        SQL.append("-1").append(SPACE);
        SQL.append("FROM").append(SPACE).append(childLookup.table()).append(SPACE);
        SQL.append("WHERE").append(SPACE).append(replaceLKwithID(parentLookup.table())).append(SPACE)
                .append("=").append(SPACE).append(attributeToFilter);
        if (includeOrphan) {
            SQL.append(SPACE).append(OR).append(SPACE).append(replaceLKwithID(parentLookup.table())).append(SPACE).append(IS_NULL);
        }

        SQL.append(SPACE).append("ORDER BY 1");

        return SQL.toString();
    }

    public static String parentLookup(LookupDefinition childLookup, LookupDefinition parentLookup, String attributeToFilter, Locale locale) {

        StringBuilder SUB_SQL = new StringBuilder("SELECT").append(SPACE);
        SUB_SQL.append(replaceLKwithID(parentLookup.table())).append(SPACE);
        SUB_SQL.append("FROM").append(SPACE).append(childLookup.table()).append(SPACE);
        SUB_SQL.append("WHERE").append(SPACE).append("ID").append(SPACE)
                .append("=").append(SPACE).append(attributeToFilter);

        StringBuilder SQL = new StringBuilder("SELECT").append(SPACE);
        SQL.append("ID").append(",");
        final String NAME_COLUMN_VAL = NAME_COLUMN + "_" + locale;
        SQL.append(NAME_COLUMN_VAL).append(SPACE).append(",");
        SQL.append("-1").append(SPACE);
        SQL.append("FROM").append(SPACE).append(parentLookup.table()).append(SPACE);
        SQL.append("WHERE").append(SPACE).append("ID").append(SPACE)
                .append("=(").append(SPACE).append(SUB_SQL).append(")");

        SQL.append(SPACE).append("ORDER BY 1");

        return SQL.toString();
    }

    /**
     * Added to filter specific record of a table
     *
     * @param locale
     * @param lookupDefinition      Table definition for which filter going to apply
     * @param attributeToFilter     Column value for which filter should be applied
     * @param filterColumnAttribute Column name which need to apply in filter
     * @return
     */
    public static String sqlFilterByColumnValue(Locale locale, LookupDefinition lookupDefinition,
                                                String filterColumnAttribute, String attributeToFilter,
                                                boolean isFilterColumnAttributeNumber) {

        StringBuilder SQL = new StringBuilder("SELECT").append(SPACE);
        SQL.append("ID").append(",");
        final String NAME_COLUMN = lookupDefinition.nameColumn() + "_" + locale;
        SQL.append(NAME_COLUMN).append(SPACE).append(",").append("-1").append(SPACE);
        SQL.append("FROM").append(SPACE).append(lookupDefinition._table).append(SPACE);
        SQL.append("WHERE").append(SPACE).append(filterColumnAttribute).append(SPACE)
                .append("=");

        if (isFilterColumnAttributeNumber) {
            SQL.append(SPACE).append(attributeToFilter);
        } else {
            SQL.append(SPACE).append("'").append(attributeToFilter).append("'");
        }

        SQL.append(SPACE).append("ORDER BY 1");

        return SQL.toString();
    }

    /**
     * Added to filter specific record of a table
     *
     * @param locale
     * @param lookupDefinition Table definition for which filter going to apply
     * @return
     */
    public static String sqlSelectAllAttributes(Locale locale, LookupDefinition lookupDefinition, List<Attribute> selectedAttributes) {

        StringBuilder SQL = new StringBuilder("SELECT").append(SPACE);
        SQL.append("ID").append(",");
        final String NAME_COLUMN = lookupDefinition.nameColumn() + "_" + locale;
        SQL.append(NAME_COLUMN).append(SPACE).append(",").append("-1").append(SPACE);
        for (Attribute attribute : selectedAttributes) {
            SQL.append(",").append(attribute.getName());
        }
        SQL.append(SPACE);
        SQL.append("FROM").append(SPACE).append(lookupDefinition._table).append(SPACE);
        SQL.append("WHERE").append(SPACE).append("IS_DELETED").append(SPACE).append("!=1");

        SQL.append(SPACE).append("ORDER BY 1");

        return SQL.toString();
    }

    public static void main(String[] args) {

        System.out.println("party_LK".replaceAll("_lk", "_id").replaceAll("_LK", "_id"));

    }

    public String parentColumn() {
        return _parentColumn;
    }

    public String nameColumn() {
        return _nameColumn;
    }

    public String idColumn() {
        return _idColumn;
    }

    //VFIS 1904
    public String parentTable() {
        return _parentTable;
    }

    public String table() {

        return _table;
    }

    public LookupDefinition getParentLookup() {
        return parentLookup;
    }

    public String sql(String locale, Long attributeToFilter, LookupFilter nameFilter) {

        StringBuilder SQL = new StringBuilder("SELECT").append(SPACE);
        SQL.append("ID").append(",");
        final String NAME_COLUMN = nameColumn() + "_" + locale;
        final String NAME_COLUMN_EN = nameColumn() + "_en";
        final String NAME_COLUMN_AR = nameColumn() + "_ar";
        SQL.append(NAME_COLUMN).append(SPACE).append(",");
        if (null == parentColumn()) {
            SQL.append("-1").append(SPACE);
        } else {
            SQL.append(parentColumn()).append(SPACE);
        }
        SQL.append("FROM").append(SPACE).append(table()).append(SPACE);

        switch (nameFilter) {

            case PARENT_ID:

                PreCondition
                        .notNull(parentColumn(),
                                String.format("Parent for %s lookup is not defined!!", this.name()));
                SQL.append("WHERE").append(SPACE).append(parentColumn()).append(SPACE)
                        .append("=").append(SPACE).append(attributeToFilter);
                break;

            case NONE:
                break;

            case NAME_STARTS_WITH:
                SQL.append("WHERE").append(SPACE).append(NAME_COLUMN).append(SPACE)
                        .append("LIKE").append(SPACE).append("'").append(attributeToFilter).append("%'");
                break;

            case NAME_ANYWHERE:
                SQL.append("WHERE").append(SPACE).append(NAME_COLUMN_EN).append(SPACE)
                        .append("LIKE").append(SPACE).append("'%").append(attributeToFilter).append("%'").append(SPACE);
                SQL.append("OR").append(SPACE).append(NAME_COLUMN_AR).append(SPACE)
                        .append("LIKE").append(SPACE).append("'%").append(attributeToFilter).append("%'").append(SPACE);
                SQL.append("OR").append(SPACE).append("ID").append(SPACE)
                        .append("LIKE").append(SPACE).append("'%").append(attributeToFilter).append("%'");
                break;

            case NAME_ENDS_WITH:
                throw new UnsupportedOperationException();

                //VFIS 1904
            case ID:
                SQL = new StringBuilder("SELECT").append(SPACE);
                SQL.append(parentColumn()).append(",");
                final String NAME_COLUMN_VAL = nameColumn() + "_" + locale;
                SQL.append(NAME_COLUMN_VAL).append(SPACE).append(",");
                SQL.append("-1").append(SPACE);
                SQL.append("FROM").append(SPACE).append(table()).append(SPACE);
                SQL.append("WHERE").append(SPACE).append("ID").append(SPACE)
                        .append("=").append(SPACE).append(attributeToFilter);
                break;

            default:

        }

        SQL.append(SPACE).append("ORDER BY "+NAME_COLUMN+",ID");

        return SQL.toString();
    }

    public static String getSQLWithoutLocale (LookupDefinition lookupDefinition){
        StringBuilder SQL = new StringBuilder("SELECT").append(SPACE);
        SQL.append("ID").append(",");

        SQL.append("NAME_EN").append(",").append("NAME_AR").append(SPACE).append(SPACE);

        SQL.append(SPACE);
        SQL.append("FROM").append(SPACE).append(lookupDefinition._table).append(SPACE);

        SQL.append(SPACE).append("ORDER BY 1");

        return SQL.toString();
    }


}
