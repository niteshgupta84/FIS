package ae.emaratech.uaevision.lookup.service.model;

/**
 * List of filters on which the Lookup will be filtered by {@code Lookup#name}
 */

public enum LookupFilter {

    NONE,
    NAME_STARTS_WITH,
    NAME_ENDS_WITH,
    NAME_ANYWHERE,
    PARENT_ID,
    ID

}
