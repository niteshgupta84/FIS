package ae.emaratech.uaevision.lookup.service.api;

/**
 * Method which wraps the lookup filter details.
 *
 * @author Haroon.Subair.
 */
public class LookupQueryFilter {

    private String filterColumn;

    private String filterValue;

    public LookupQueryFilter(String filterColumn, String filterValue) {
        this.filterColumn = filterColumn;
        this.filterValue = filterValue;
    }

    public String getFilterValue() {
        return filterValue;
    }

    public String getFilterColumn() {
        return filterColumn;
    }
}
