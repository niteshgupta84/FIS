package ae.emaratech.uaevision.lookup.service.impl;

/**
 * No-Op Marker class which helps to mark the current package for component scanning. Will be
 * referenced in {@Link FISApplicationConfig} .
 */
public class FISLookupServiceMarker {

}
