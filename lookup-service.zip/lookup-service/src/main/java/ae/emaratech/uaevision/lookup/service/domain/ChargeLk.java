package ae.emaratech.uaevision.lookup.service.domain;

import org.hibernate.annotations.Formula;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Entity representing Charge lookup table.
 *
 * @author Haroon.Subair
 */
@Entity
@Table(name = "CHARGE_LK")
public class ChargeLk extends LookupEntity {

    private static final long serialVersionUID = 1L;

    @Column(name = "SECTION_ID")
    private Long sectionId;

    @Column(name = "LEGACY_ID")
    private Long legacyId;

    @Formula("NAME_AR || '|' || lower(NAME_EN) || '|' || LEGACY_ID")
    private String searchableInfo;

    private ChargeLk() {

    }

    public Long getSectionId() {
        return sectionId;
    }

    private void setSectionId(Long sectionId) {
        this.sectionId = sectionId;
    }

    public String getSearchableInfo() {
        return searchableInfo;
    }

    public Long getLegacyId() {
        return legacyId;
    }

    private void setLegacyId(Long legacyId) {
        this.legacyId = legacyId;
    }
}
