package ae.emaratech.uaevision.lookup.service.domain;

import org.hibernate.annotations.Formula;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by Nitesh.Gupta on 6/11/2017.
 */
@Entity
@Table(name = "DESTINATION_LK")
public class AirportLk extends LookupEntity  {

    @Formula("NAME_AR || '|' || lower(NAME_EN) || '|' || ID")
    private String searchableInfo;

    public String getSearchableInfo() {
        return searchableInfo;
    }

    public void setSearchableInfo(String searchableInfo) {
        this.searchableInfo = searchableInfo;
    }
}
