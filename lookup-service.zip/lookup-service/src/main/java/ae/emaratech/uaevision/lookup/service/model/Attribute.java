package ae.emaratech.uaevision.lookup.service.model;

/**
 * Attribute class which will hold Column name and values
 * Created by Nitesh.Gupta on 7/26/2016.
 */
public class Attribute {

    private String name;
    private String value;

    public Attribute(){}

    public Attribute(String name) {
        this.name = name;
    }

    public Attribute(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }
}
