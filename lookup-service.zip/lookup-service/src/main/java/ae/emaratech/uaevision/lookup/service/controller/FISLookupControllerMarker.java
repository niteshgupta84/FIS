package ae.emaratech.uaevision.lookup.service.controller;

/**
 * No-Op Marker class which helps to mark the current package for component scanning. Will be
 * referenced in {@Link FISApplicationConfig} .
 */
public class FISLookupControllerMarker {

}
