package ae.emaratech.uaevision.lookup.service.config;

import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.controller.FISLookupControllerMarker;
import ae.emaratech.uaevision.lookup.service.impl.CachedLookupSeviceImpl;
import ae.emaratech.uaevision.lookup.service.impl.DefaultLookupServiceImpl;
import ae.emaratech.uaevision.lookup.service.impl.FISLookupServiceMarker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

import javax.sql.DataSource;
import java.util.Properties;

/**
 * Created with IntelliJ IDEA. User: asimqureshi Date: 11/25/15 Time: 7:12 PM To change this
 * template use File | Settings | File Templates.
 */

@Configuration
@ComponentScan(basePackageClasses = {FISLookupServiceMarker.class, FISLookupControllerMarker.class})
@EnableJpaRepositories(
        basePackages = "ae.emaratech.uaevision.lookup.service.domain",
        entityManagerFactoryRef = "lookupEntityManager"
)
public class LookupContext {


    private static final String FIS_LOOKUP_DATASOURCE = "lookup.ds.name";

    private static final String PROPERTY_NAME_HIBERNATE_DIALECT = "hibernate.dialect";
    private static final String PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO = "hibernate.hbm2ddl.auto";

    @Autowired
    private Environment environment;

    @Bean
    public LocalContainerEntityManagerFactoryBean lookupEntityManager() {

        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(lookupDataSource(environment));
        em.setPackagesToScan(new String[]{"ae.emaratech.uaevision.lookup.service.domain"});
        em.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
        Properties jpaProperties = new Properties();

        //Configures the used database dialect. This allows Hibernate to create SQL
        //that is optimized for the used database.
        jpaProperties.put(PROPERTY_NAME_HIBERNATE_DIALECT,
                environment.getRequiredProperty(PROPERTY_NAME_HIBERNATE_DIALECT));

        //Specifies the action that is invoked to the database when the Hibernate
        //SessionFactory is created or closed.
        jpaProperties.put(PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO,
                environment.getRequiredProperty(PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO));
        em.setJpaProperties(jpaProperties);

        return em;
    }

    /**
     * Creates and configures the HikariCP datasource bean.
     *
     * @param env The runtime environment of  our application.
     */
    @Bean(destroyMethod = "")
    DataSource lookupDataSource(Environment env) {

        final JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
        dsLookup.setResourceRef(true);
        DataSource dataSource = dsLookup.getDataSource(env.getRequiredProperty(FIS_LOOKUP_DATASOURCE));
        return dataSource;
    }


    @Bean
    LookupService lookupService(Environment env) {

        CachedLookupSeviceImpl cachedLookupSevice =
                new CachedLookupSeviceImpl(new DefaultLookupServiceImpl(lookupDataSource(env)));

        cachedLookupSevice.init();

        return cachedLookupSevice;

    }

    @Configuration
    @PropertySource(value = "classpath:lookup.properties")
    static class PersistenceProperties {

    }


}
