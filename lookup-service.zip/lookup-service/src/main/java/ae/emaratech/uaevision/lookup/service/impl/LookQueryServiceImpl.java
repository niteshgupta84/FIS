package ae.emaratech.uaevision.lookup.service.impl;

import ae.emaratech.uaevision.lookup.service.api.LookupQuery;
import ae.emaratech.uaevision.lookup.service.api.LookupQueryFilter;
import ae.emaratech.uaevision.lookup.service.api.LookupQueryService;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

/**
 * Query service implementation for Reference data.
 *
 * @author Haroon.Subair
 */
@Service
public class LookQueryServiceImpl implements LookupQueryService {

    /**
     * Static containing Logger for the class.
     */
    private static final Logger LOGGER = LogManager.getLogger();

    @Autowired
    @Qualifier("lookupEntityManager")
    private EntityManager entityManager;

    @Override
    public List retrieveLookupList(Class entity, LookupQuery lookupQuery) {

        LOGGER.info("LookupQueryService: " + entity.getSimpleName());

        StringBuilder query = new StringBuilder("FROM ").append(entity.getSimpleName()).append(" p");
        if (lookupQuery == null) {
            return entityManager.createQuery(query.toString()).getResultList();
        }

        String searchQuery = lookupQuery.getSearchParameter();
        LookupQueryFilter filter = lookupQuery.getFilter();
        if (filter != null) {
            query.append(" where (p.").append(filter.getFilterColumn()).append("=");
            query.append(filter.getFilterValue());
            query.append(" )");
        }
        if (searchQuery == null || searchQuery.length() < 1) {
            return entityManager.createQuery(query.toString()).setMaxResults(50).getResultList();
        }

        if (filter != null) {
            query.append(" and");
        } else {
            query.append(" where");
        }
        query.append(" p.searchableInfo like '%");
        query.append(searchQuery.toLowerCase()).append("%' ");
        if (StringUtils.isNumeric(searchQuery)) {

            List<Method> methodList = Arrays.asList(entity.getMethods());
            long columnCount = methodList.stream()
                    .filter(method -> method.getName().toLowerCase().contains("legacyid"))
                    .count();
            if (columnCount > 0) {
                query.append("order by p.legacyId");
            } else {
                query.append("order by p.id");
            }
        } else if (LocaleContextHolder.getLocale().getLanguage().equals("en")) {
            query.append("order by p.englishValue");
        } else {
            query.append("order by p.arabicValue");
        }
        LOGGER.info("LookupQueryService: query: " + query.toString());
        return entityManager.createQuery(query.toString()).getResultList();
    }
}
