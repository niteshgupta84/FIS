package ae.emaratech.uaevision.lookup.service.api;

import ae.emaratech.uaevision.lookup.service.domain.LookupEntity;
import ae.emaratech.uaevision.lookup.service.model.*;
import org.springframework.context.i18n.LocaleContextHolder;

import java.io.Serializable;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * Service facade for reading the lookup values.
 */

public interface LookupService extends Serializable {

    /**
     * The default locale to be used in case none is provided
     */
    Locale DEFAULT_LOCALE = LocaleContextHolder.getLocale();

    /**
     * Gets the {@link Lookup} along with the list of {@link Entry} for the provided locale
     *
     * @param definition the lookup to access
     * @param locale     the locale for which the lookup description is required
     */
    Lookup getLookup(LookupDefinition definition, Locale locale);

    /**
     * @Overloaded {@code locale} defaults to {@link LookupService#DEFAULT_LOCALE}
     * @see LookupService#getLookup(LookupDefinition, Locale)
     */
    Lookup getLookup(LookupDefinition lookupDefinition);


    /**
     * Gets the {@link Lookup} along with the list of {@link Entry} for the provided locale
     *
     * @param definition the lookup to access
     * @param locale     the locale for which the lookup description is required
     * @param name       the name on which the filter is to be applied
     * @param filter     type of filter to be applied on the name, e.g. start_with, ends with etc.
     */
    Lookup getLookup(LookupDefinition definition, Locale locale,
                     Long name, LookupFilter filter);

    /**
     * @Overloaded {@code locale} defaults to {@link LookupService#DEFAULT_LOCALE}
     * @see LookupService#getLookup(LookupDefinition, Locale, Long, ae.emaratech.uaevision.lookup.service.model.LookupFilter)
     */
    Lookup getLookup(LookupDefinition definition, Long name, LookupFilter filter);

    /**
     * Gets the {@link Entry} for the provided {@code lookup} against the {@link Entry#id}
     *
     * @param definition the lookup to access
     * @param locale     the locale for which the lookup description is required
     * @param id         the id or PK against which the the {@code Entry} needs to be fetched
     */
    Optional<Entry> getLookupEntry(LookupDefinition definition, Locale locale, Long id);

    /**
     * @Overloaded {@code locale} defaults to {@link LookupService#DEFAULT_LOCALE}
     * @see LookupService#getLookupEntry(LookupDefinition, Long)
     */
    Optional<Entry> getLookupEntry(LookupDefinition definition, Long id);


    /**
     * @Overloaded {@code locale} defaults to {@link LookupService#DEFAULT_LOCALE} The purpose of this
     * method is to fetch the child lookups of any lookup. Eg fetch all charges belonging to a
     * particular section, fetch all cities in an emirate etc. The purpose of this method is that
     * lookup tables can have more than one foreign key and we might need to fetch child values
     * specific to a particular parent only. Eg charge can depend on section, charge can also have a
     * charge_type, so based on the parent lookup definition specified i.e. section or charge_type,
     * the charge values can be fetched. The includeOrphans flag indicates whether to include the
     * child entries that parent_id as null.
     */
    Lookup getChildLookup(LookupDefinition parentLookup, LookupDefinition childLookup,
                          Long parentValue,
                          Boolean includeOrphans, Locale locale);

    /**
     * @Overloaded {@code locale} defaults to {@link LookupService#DEFAULT_LOCALE} The purpose of this
     * method is to fetch the parent lookup of any lookup. Eg fetch the section id to which a
     * particular charge belong, or fetch the emirate to which the city belong. User will provide the
     * child value and the corresponding parent value will be fetched. This will be a single value.
     */
    Optional<Entry> getParentLookup(LookupDefinition childLookup, LookupDefinition parentLookup,
                                    String childValue, Locale locale);

    /**
     * @Overloaded {@code locale} defaults to {@link LookupService#DEFAULT_LOCALE} The purpose of this
     * method is to fetch the look up value based on column filter value
     */
    Optional<Entry> getLookupByColumnAttributeFilter(Locale locale, LookupDefinition lookupDefinition,
                                                     String filterColumnAttribute,
                                                     String attributeToFilter,
                                                     boolean isFilterColumnAttributeNumber);

    /**
     * Method to retrieve Lookup With All selected Attributes
     */
    Lookup getLookupAttributes(LookupDefinition lookupDefinition, Locale locale,
                               List<Attribute> listOfAttributes);

    Optional<Entry> getLookupAttributes(LookupDefinition definition, Locale locale, Long id, List<Attribute> attributeList);

    List<LookupEntry> getLookupEntries(LookupDefinition lookupDefinition);
}
