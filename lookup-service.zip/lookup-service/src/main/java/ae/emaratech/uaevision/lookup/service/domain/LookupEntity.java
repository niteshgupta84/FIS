package ae.emaratech.uaevision.lookup.service.domain;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

/**
 * Created by Haroon.Subair on 8/8/2016.
 */
@MappedSuperclass
public class LookupEntity {

    @Column(name = "ID", unique = true, nullable = false, precision = 22, scale = 0)
    @Id
    private Long id;

    @Column(name = "NAME_EN", nullable = false)
    private String englishValue;

    @Column(name = "NAME_AR", nullable = false)
    private String arabicValue;

    @Column(name = "IS_DELETED", nullable = false)
    private Integer isDeleted;

    public Long getId() {
        return id;
    }

    protected void setId(Long id) {
        this.id = id;
    }

    public String getEnglishValue() {
        return englishValue;
    }

    protected void setEnglishValue(String englishValue) {
        this.englishValue = englishValue;
    }

    public String getArabicValue() {
        return arabicValue;
    }

    protected void setArabicValue(String arabicValue) {
        this.arabicValue = arabicValue;
    }

    public Integer getIsDeleted() {
        return isDeleted;
    }

    protected void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }
}
