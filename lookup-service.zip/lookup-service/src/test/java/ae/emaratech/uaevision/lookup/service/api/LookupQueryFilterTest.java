package ae.emaratech.uaevision.lookup.service.api;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;

/**
 * Test class providing unit test cases for {@link ae.emaratech.uaevision.lookup.service.api.LookupQueryFilter}
 *
 * @author Haroon.Subair
 */
@RunWith(MockitoJUnitRunner.class)
public class LookupQueryFilterTest {

  @InjectMocks
  private LookupQueryFilter _test = new LookupQueryFilter("COL1", "VAL1");

  @Test
  public void shouldReturnSearchParameter() {
    assertNotNull(_test.getFilterColumn());
    assertNotNull(_test.getFilterValue());
  }
}
