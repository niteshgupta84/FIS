package ae.emaratech.uaevision.lookup.service.api;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

/**
 * Test class providing unit test cases for {@link ae.emaratech.uaevision.lookup.service.api.LookupQuery}
 *
 * @author Haroon.Subair
 */
@RunWith(MockitoJUnitRunner.class)
public class LookupQueryTest {

  @InjectMocks
  private LookupQuery _test = new LookupQuery.Builder("TEST").withFilter(mock(LookupQueryFilter.class)).build();

  @Test
  public void shouldReturnSearchParameter() {
    assertNotNull(_test.getSearchParameter());
    assertNotNull(_test.getFilter());
  }
}
