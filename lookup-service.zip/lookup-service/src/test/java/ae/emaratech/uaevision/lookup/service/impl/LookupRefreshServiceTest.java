package ae.emaratech.uaevision.lookup.service.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Test class providing unit test cases for {@link ae.emaratech.uaevision.lookup.service.impl.LookupRefreshService}
 *
 * @author Haroon.Subair
 */
@RunWith(MockitoJUnitRunner.class)
public class LookupRefreshServiceTest {

  @InjectMocks
  private LookupRefreshService _test;

  @Mock
  private CachedLookupSeviceImpl lookupService;

  @Test
  public void shouldRefreshLookups() {

    _test.refresh();
    verify(lookupService, times(1)).refresh();
  }


}
