package ae.emaratech.uaevision.lookup.service.impl;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Locale;

import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import ae.emaratech.uaevision.lookup.service.model.LookupFilter;

import static org.junit.Assert.assertNull;

/**
 * Test class providing unit test cases for {@link ae.emaratech.uaevision.lookup.service.impl.CachedLookupSeviceImpl}
 *
 * @author Haroon.Subair
 */
@RunWith(MockitoJUnitRunner.class)
public class CachedLookupServiceImplTest {

  @Mock
  private DefaultLookupServiceImpl mockLookupService;

  @InjectMocks
  private CachedLookupSeviceImpl _test = new CachedLookupSeviceImpl(mockLookupService);

  @Before
  public void init() {

  }

  @Test
  public void shouldInitializeSuccessfully() {

    _test.init();
    assertNull(
        _test.getLookup(LookupDefinition.IDENTIFICATION_DOC_TYPE, Locale.forLanguageTag("en")));
    assertNull(
        _test.getLookup(LookupDefinition.IDENTIFICATION_DOC_TYPE, Locale.forLanguageTag("en"), 25L,
                        LookupFilter.ID));
    assertNull(
        _test.getLookup(LookupDefinition.PASSPORT_TYPE, 25L, LookupFilter.ID));
    assertNull(
        _test.getLookup(LookupDefinition.IDENTIFICATION_DOC_TYPE));
  }

}
