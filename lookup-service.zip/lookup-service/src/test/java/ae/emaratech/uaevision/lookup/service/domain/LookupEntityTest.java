package ae.emaratech.uaevision.lookup.service.domain;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;

/**
 * Test class providing unit test cases for {@link ae.emaratech.uaevision.lookup.service.domain.LookupEntity}
 *
 * @author Haroon.Subair
 */
@RunWith(MockitoJUnitRunner.class)
public class LookupEntityTest {

  @InjectMocks
  private LookupEntity _test;;

  @Test
  public void shouldReturnSearchParameter() {
    _test.setArabicValue("AR");
    _test.setEnglishValue("EN");
    _test.setId(1L);
    _test.setIsDeleted(0);
    assertNotNull(_test.getArabicValue());
    assertNotNull(_test.getEnglishValue());
    assertNotNull(_test.getId());
    assertNotNull(_test.getIsDeleted());
  }
}
