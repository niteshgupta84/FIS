package ae.emaratech.uaevision.lookup.service.impl;


import ae.emaratech.uaevision.lookup.service.model.Entry;

/**
 * Test constants for {@link DefaultLookupServiceIntegrationTest}
 */
public class LookupTestConstants {

    /**
     * Prevents instantiation
     */
    private LookupTestConstants() {
    }

    public static void main(String[] args) {

        System.out.println("متهم".getBytes());
        System.out.println("متهم".getBytes());


    }

    public static class PartyLookupEntries {

        public static class Accused {

            public static final String ID = "3";
            public static final String NAME_EN = "Accused";
            //public static final String NAME_AR = "متهم";
            public static final String NAME_AR = "متهم";
            public static final String DESCRIPTION = "Person as Accused";
           // public static final Entry LOOKUP_ENTRY = new Entry(ID, NAME_EN);
          //  public static final Entry LOOKUP_ENTRY_AR = new Entry(ID, NAME_AR);

        }

        public static class Complainant {

            public static final String ID = "2";
            public static final String NAME_EN = "Complainant";
            public static final String NAME_AR = "مشتكي";
            public static final String DESCRIPTION = "Person as Complainant";
           //public static final Entry LOOKUP_ENTRY = new Entry(ID, NAME_EN);
            ///public static final Entry LOOKUP_ENTRY_AR = new Entry(ID, NAME_AR);

        }
    }

    public static class CityLookupEntries {

        public static class Ghayathi {

            public static final String ID = "116";
            public static final String NAME_EN = "GHAYATHI";
            public static final String NAME_AR = "غياثى";
            public static final String DESCRIPTION = "Person as Accused";
          //  public static final Entry LOOKUP_ENTRY = new Entry(ID, NAME_EN);
           // public static final Entry LOOKUP_ENTRY_AR = new Entry(ID, NAME_AR);

        }
    }

    public static class AreaLookupEntries {

        public static class Ghayasy {

            public static final String ID = "539";
            public static final String NAME_EN = "Ghayasy";
            public static final String NAME_AR = "مدينة غياثي";
            public static final String DESCRIPTION = "Person as Accused";
          //  public static final Entry LOOKUP_ENTRY = new Entry(ID, NAME_EN);
          //  public static final Entry LOOKUP_ENTRY_AR = new Entry(ID, NAME_AR);

        }

        public static class Unknown {

            public static final String ID = "99116";
            public static final String NAME_EN = "UNKNOWN";
            public static final String NAME_AR = "غير محدد";
            public static final String DESCRIPTION = "Person as Accused";
           // public static final Entry LOOKUP_ENTRY = new Entry(ID, NAME_EN);
          //  public static final Entry LOOKUP_ENTRY_AR = new Entry(ID, NAME_AR);

        }
    }

}
