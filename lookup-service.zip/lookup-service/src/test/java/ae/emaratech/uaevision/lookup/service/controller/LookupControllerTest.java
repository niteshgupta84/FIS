package ae.emaratech.uaevision.lookup.service.controller;

import ae.emaratech.uaevision.lookup.service.api.LookupQuery;
import ae.emaratech.uaevision.lookup.service.api.LookupQueryService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.domain.*;
import ae.emaratech.uaevision.lookup.service.model.Lookup;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import ae.emaratech.uaevision.lookup.service.model.LookupEntry;
import ae.emaratech.uaevision.lookup.service.model.LookupFilter;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletRequest;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

/**
 * Test class providing unit test cases for {@link ae.emaratech.uaevision.lookup.service.controller.LookupController}
 *
 * @author Haroon.Subair
 */
@RunWith(MockitoJUnitRunner.class)
public class LookupControllerTest {

  @InjectMocks
  private LookupController _test;

  @Mock
  private LookupService lookupService;
  @Mock
  private LookupQueryService queryService;

  @Mock
  private MockHttpServletRequest mockRequest;

  @Before
  public void init() {
    doReturn(mock(Lookup.class)).when(lookupService)
        .getChildLookup(any(LookupDefinition.class), any(LookupDefinition.class), anyLong(),
                        anyBoolean(), any(
                Locale.class));

    doReturn(Arrays.asList(new LookupEntry(24L, "SS_EN", "SAS_AR"))).when(lookupService)
        .getLookupEntries(any(LookupDefinition.class));
  }

  @Test
  public void shouldReturnAllLookups() {
    List lookups = _test.getAllLookups();
    assertNotNull(lookups);
  }

  @Test
  public void shouldPopulateLookupData() {
    List lookups = _test.populateLookupData("DEPARTMENT");
    assertNotNull(lookups);
  }

  @Test
  public void shouldNotPopulateLookupDataForInvalidId() {
    List lookups = _test.populateLookupData(null);
    assertNotNull(lookups);
  }

  @Test
  public void shouldGetAreasForCity() {
    List lookups = _test.getAreasForCity("1");
    assertNotNull(lookups);
  }

  @Test
  public void shouldGetCityForEmirate() {
    List lookups = _test.getCityForEmirate(1L);
    assertNotNull(lookups);
  }

  @Test
  public void shouldGetDestinationsForCountry() {
    List lookups = _test.getDestinationsForCountry(1L);
    assertNotNull(lookups);
  }

  @Test
  public void shouldGetPortsForPortType() {
    List lookups = _test.getPortsForPortType(1L);
    assertNotNull(lookups);
  }

  @Test
  public void shouldGetAllSectionsForDepartment() {
    List lookups = _test.getAllSectionsForDepartment(1L,1L);
    assertNotNull(lookups);
  }


  @Test
  public void shouldListTransferedFrom() {
    mockRequest.addParameter("search", "transferredFrom");
    doReturn(Arrays.asList(mock(TransferEntityLk.class))).when(queryService)
        .retrieveLookupList(any(), any(LookupQuery.class));
    List lookups = _test.listTransferedFrom(mockRequest);
    assertNotNull(lookups);
  }

  @Test
  public void shouldFindArrestReason() {
    mockRequest.addParameter("search", "arrestReason");
    doReturn(Arrays.asList(mock(ArrestReasonLk.class))).when(queryService)
        .retrieveLookupList(any(), any(LookupQuery.class));
    List lookups = _test.findArrestReason(mockRequest,"172");
    assertNotNull(lookups);
  }

  @Test
  public void shouldFindCountries() {
    mockRequest.addParameter("search", "Countries");
    doReturn(Arrays.asList(mock(CountryLk.class))).when(queryService)
        .retrieveLookupList(any(), any(LookupQuery.class));
    List lookups = _test.findCountries(mockRequest);
    assertNotNull(lookups);
  }

  @Test
  public void shouldFindCities() {
    mockRequest.addParameter("search", "Cities");
    doReturn(Arrays.asList(mock(CityLk.class))).when(queryService)
        .retrieveLookupList(any(), any(LookupQuery.class));
    List lookups = _test.findCities(mockRequest);
    assertNotNull(lookups);
  }

  @Test
  public void shouldFindFlights() {
    mockRequest.addParameter("search", "Flights");
    doReturn(Arrays.asList(mock(FlightLk.class))).when(queryService)
        .retrieveLookupList(any(), any(LookupQuery.class));
    List lookups = _test.findFlights(mockRequest);
    assertNotNull(lookups);
  }

  @Test
  public void shouldFindProfessions() {
    mockRequest.addParameter("search", "Professions");
    doReturn(Arrays.asList(mock(ProfessionLk.class))).when(queryService)
        .retrieveLookupList(any(), any(LookupQuery.class));
    List lookups = _test.findProfessions(mockRequest);
    assertNotNull(lookups);
  }

  @Test
  public void shouldFindPartyCharges() {
    doReturn("Charges").when(mockRequest).getParameter("search");
    doReturn(Arrays.asList(mock(ChargeLk.class))).when(queryService)
        .retrieveLookupList(any(), any(LookupQuery.class));
    List lookups = _test.findPartyCharges(mockRequest);
    assertNotNull(lookups);
  }

  @Test
  public void shouldFindPartyChargesWithFilter() {
    doReturn("Charges").when(mockRequest).getParameter("search");
    doReturn("filterC").when(mockRequest).getParameter("filterColumn");
    doReturn("filterV").when(mockRequest).getParameter("filterValue");
    doReturn(Arrays.asList(mock(ChargeLk.class))).when(queryService)
        .retrieveLookupList(any(), any(LookupQuery.class));
    List lookups = _test.findPartyCharges(mockRequest);
    assertNotNull(lookups);
  }

  @Test
  public void shouldReturnSelections() {
    doReturn("DEPARTMENT").when(mockRequest).getParameter("queryId");
    doReturn(mock(Lookup.class)).when(lookupService).getLookup(any(), anyLong(),
                                                                                any(LookupFilter.class));
    List lookups = _test.getSelections("1", mockRequest);
    assertNotNull(lookups);
  }

  @Test
  public void shouldNotReturnSelectionsForInvalidInput() {
    doReturn("INVALID").when(mockRequest).getParameter("queryId");
    doReturn(mock(Lookup.class)).when(lookupService).getLookup(any(), anyLong(),
                                                               any(LookupFilter.class));
    List lookups = _test.getSelections("1", mockRequest);
    assertNotNull(lookups);
  }
}
