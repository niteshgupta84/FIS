package ae.emaratech.uaevision.lookup.service.impl;

//import static org.junit.Assert.assertTrue;

/**
 * Test for the {@link DefaultLookupServiceImpl}
 */

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(classes = {LookupTestContext.class, LookupContext.class})
//@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
//                         DirtiesContextTestExecutionListener.class,
//                         TransactionalTestExecutionListener.class
//        DbMigrationTestExecutionListener.class,
//                         DbUnitTestExecutionListener.class}
//})
//@Transactional
//@DatabaseSetup(value = {"classpath:party-type-entries.xml"}, type = DatabaseOperation.REFRESH)
//@DatabaseTearDown(value = {"classpath:party-type-entries.xml"}, type = DatabaseOperation.DELETE)
//@TransactionConfiguration(transactionManager="transactionManager", defaultRollback= false)

public class  DefaultLookupServiceIntegrationTest {

//  private static final Logger LOGGER = LogManager.getLogger();
//  private static final LookupDefinition LOOKUP_UT = LookupDefinition.PARTY_TYPE;
//  private static Locale ENGLISH_LOCALE = Locale.forLanguageTag("en");
//
//  @Autowired
//  LookupService lookupService;

//  @Test
//  public void shouldLoadValuesInLookup() {
//
//    Lookup lookup = lookupService.getLookup(LOOKUP_UT);
//
//    assertNotNull(lookup);
//    assertNotNull(lookup.getEntries());
//   // assertEquals(6, lookup.getEntries().size());
//
//  }
//
//  @Test
//  public void shouldMatchValuesInLookupForDefaultLocale() {
//
//    Lookup lookup = lookupService.getLookup(LOOKUP_UT);
//
//    assertEquals(Accused.LOOKUP_ENTRY, lookup.getEntries().get(2));
//    //assertEquals(Complainant.LOOKUP_ENTRY, lookup.getEntries().get(1));
//
//  }
//
//  /*@Test
//  public void shouldMatchValuesInLookupForArabicLocale() {
//
//    Lookup
//        lookup =
//        lookupService.getLookup(LookupDefinition.PARTY_TYPE, Locale.forLanguageTag("AR"));
//
//        assertEquals(Accused.LOOKUP_ENTRY_AR, lookup.getEntries().get(0));
//        assertEquals(Complainant.LOOKUP_ENTRY_AR, lookup.getEntries().get(1));
//
//  }*/
//
//  @Test
//  public void shouldGetLookupEntryById() {
//
//    Optional<Entry>
//        lookupEntryExpected =
//        lookupService.getLookupEntry(LookupDefinition.PARTY_TYPE, Accused.ID);
//
//    assertNotNull(lookupEntryExpected);
//    assertEquals(Accused.LOOKUP_ENTRY, lookupEntryExpected.get());
//
//  }
//
//  @Test
//  public void shouldFilterByNameEqual() {
//
//    Lookup
//        lookup =
//        lookupService.getLookup(LookupDefinition.PARTY_TYPE, LookupService.DEFAULT_LOCALE,
//                                LookupTestConstants.PartyLookupEntries.Accused.NAME_EN,
//                                LookupFilter.NAME_STARTS_WITH);
//
//    assertEquals(Accused.LOOKUP_ENTRY, lookup.getEntries().get(0));
//
//  }
//
//  @Test
//  public void shouldFilterByNameStartsWith() {
//
//    Lookup
//        lookup =
//        lookupService.getLookup(LookupDefinition.PARTY_TYPE,ENGLISH_LOCALE,
//                                LookupTestConstants.PartyLookupEntries.Accused.NAME_EN
//                                    .substring(0, 1),
//                                LookupFilter.NAME_STARTS_WITH);
//
//    assertEquals(Accused.LOOKUP_ENTRY, lookup.getEntries().get(0));
//  }
//
//  @Test
//  public void shouldFilterByParentId() {
//
//    Lookup
//        lookup =
//        lookupService.getLookup(LookupDefinition.AREA,
//                                Ghayathi.ID,
//                                LookupFilter.PARENT_ID);
//
//    assertEquals(2, lookup.getEntries().size());
//    assertEquals(Ghayasy.LOOKUP_ENTRY, lookup.getEntries().get(0));
//    assertEquals(Unknown.LOOKUP_ENTRY, lookup.getEntries().get(1));
//  }
//
//  @Test
//  public void shouldFilterAreaById() {
//
//    StopWatch stopWatch = new StopWatch();
//    stopWatch.start();
//
//    Entry
//        entry =
//        lookupService.getLookupEntry(LookupDefinition.AREA, Locale.ENGLISH,
//                                     Ghayasy.ID).get();
//
//    assertEquals(Ghayasy.LOOKUP_ENTRY, entry);
//
//    stopWatch.stop();
//    LOGGER.printf(Level.INFO, "Time taken by shouldFilterAreaById is %s seconds",
//                  stopWatch.getTotalTimeSeconds());
//  }
//
//  /*@Test
//  public void shouldThrowExceptionForUnsupportedLocale() {
//
//    boolean exceptionThrown = false;
//
//    try {
//
//      Lookup lookup = lookupService.getLookup(LOOKUP_UT, Locale.forLanguageTag("fr"));
//
//    } catch (Exception e) {
//
//      LOGGER.error(e);
//      exceptionThrown = true;
//
//    }
//
//    assertTrue(exceptionThrown);
//
//
//  }*/
//
//  @Test
//  public void shouldReturnPartyStatusEntryForEnglishLocale() {
//    Lookup
//        partyStatusLookup =
//        lookupService.getLookup(LookupDefinition.PARTY_STATUS, Locale.ENGLISH);
//    assertNotNull(partyStatusLookup);
//  }
//
//  @Test
//  public void shouldReturnPartyStatusEntryForArabicLocale() {
//    Lookup
//        partyStatusLookup =
//        lookupService.getLookup(LookupDefinition.PARTY_STATUS, Locale.forLanguageTag("ar"));
//    assertNotNull(partyStatusLookup);
//  }
//
//  @Test
//  public void shouldReturnPartyStatusEntryForDefaultLocale() {
//    Lookup
//        partyStatusLookup =
//        lookupService.getLookup(LookupDefinition.PARTY_STATUS);
//    assertNotNull(partyStatusLookup);
//  }
}
