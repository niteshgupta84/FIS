package ae.emaratech.uaevision.lookup.service.impl;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import ae.emaratech.uaevision.lookup.service.api.LookupQuery;
import ae.emaratech.uaevision.lookup.service.api.LookupQueryFilter;
import ae.emaratech.uaevision.lookup.service.domain.ChargeLk;
import ae.emaratech.uaevision.lookup.service.domain.FlightLk;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

/**
 * Test class providing unit test cases for {@link ae.emaratech.uaevision.lookup.service.impl.LookQueryServiceImpl}
 *
 * @author Haroon.Subair
 */
@RunWith(MockitoJUnitRunner.class)
public class LookupQueryServiceImplTest {

  @InjectMocks
  private LookQueryServiceImpl _test;

  @Mock
  private EntityManager mockEntityManager;

  @Before
  public void init() {
    List resultList = Arrays.asList();
    Query query = mock(Query.class);
    doReturn(resultList).when(query).getResultList();
    doReturn(query).when(query).setMaxResults(anyInt());
    doReturn(query).when(mockEntityManager).createQuery(anyString());
  }

  @Test
  public void shouldRetrieveLookupList() {

    LookupQuery lookupQuery = mock(LookupQuery.class);
    List result = _test.retrieveLookupList(FlightLk.class, lookupQuery);
    assertNotNull(result);
  }


  @Test
  public void shouldRetrieveLookupListWithFilter() {

    LookupQuery lookupQuery = mock(LookupQuery.class);
    LookupQueryFilter lookupFilter = mock(LookupQueryFilter.class);
    doReturn("COL1").when(lookupFilter).getFilterColumn();
    doReturn("VAL1").when(lookupFilter).getFilterValue();
    doReturn("AIR").when(lookupQuery).getSearchParameter();
    doReturn(lookupFilter).when(lookupQuery).getFilter();
    List result = _test.retrieveLookupList(FlightLk.class, lookupQuery);
    assertNotNull(result);
  }

  @Test
  public void shouldRetrieveLookupListWithLegacyIdFilter() {

    LookupQuery lookupQuery = mock(LookupQuery.class);
    LookupQueryFilter lookupFilter = mock(LookupQueryFilter.class);
    doReturn("COL1").when(lookupFilter).getFilterColumn();
    doReturn("VAL1").when(lookupFilter).getFilterValue();
    doReturn("122").when(lookupQuery).getSearchParameter();
    doReturn(lookupFilter).when(lookupQuery).getFilter();
    List result = _test.retrieveLookupList(ChargeLk.class, lookupQuery);
    assertNotNull(result);
  }

  @Test
  public void shouldRetrieveLookupListWithIdFilter() {

    LookupQuery lookupQuery = mock(LookupQuery.class);
    LookupQueryFilter lookupFilter = mock(LookupQueryFilter.class);
    doReturn("COL1").when(lookupFilter).getFilterColumn();
    doReturn("VAL1").when(lookupFilter).getFilterValue();
    doReturn("122").when(lookupQuery).getSearchParameter();
    doReturn(lookupFilter).when(lookupQuery).getFilter();
    List result = _test.retrieveLookupList(FlightLk.class, lookupQuery);
    assertNotNull(result);
  }

  @Test
  public void shouldRetrieveAllLookupListWhenQueryIsNull() {
    List result = _test.retrieveLookupList(FlightLk.class, null);
    assertNotNull(result);
  }

}
