package ae.emaratech.uaevision.lookup.service.config;

import com.github.springtestdbunit.bean.DatabaseConfigBean;
import com.github.springtestdbunit.bean.DatabaseDataSourceConnectionFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.env.Environment;

/**
 * Configuration for "Test" context
 */

@Configuration
@Import(LookupContext.class)
public class LookupTestContext extends LookupContext {

    @Bean
    DatabaseDataSourceConnectionFactoryBean dbUnitDatabaseConnection(Environment env) {

        DatabaseDataSourceConnectionFactoryBean
                bean =
                new DatabaseDataSourceConnectionFactoryBean(lookupDataSource(env));

        DatabaseConfigBean config = new DatabaseConfigBean();
//        config.setQualifiedTableNames(Boolean.TRUE);
//        config.setSkipOracleRecyclebinTables(Boolean.TRUE);

        bean.setDatabaseConfig(config);
        bean.setSchema("FIS_REF");

        return bean;

    }
}
