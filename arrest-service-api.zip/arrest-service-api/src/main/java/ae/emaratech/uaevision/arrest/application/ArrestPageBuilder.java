package ae.emaratech.uaevision.arrest.application;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Created by Nitesh.Gupta on 6/13/2016.
 */
public class ArrestPageBuilder<T> implements Serializable{
    private long totalElements;
    private Map<Long, T> dtoList;
    private int start;
    private int length;
    private List<String> sortColumns;


    public ArrestPageBuilder(long totalElements, Map<Long, T> dtoList) {
        this.totalElements = totalElements;
        this.dtoList = dtoList;
    }

    public ArrestPageBuilder(int start, int length) {
        this.start = start;
        this.length = length;
    }

    public ArrestPageBuilder(int start, int length, List<String> sortColumns) {
        this.start = start;
        this.length = length;

        this.sortColumns = sortColumns;
    }

    public long getTotalElements() {
        return totalElements;
    }

    public Map<Long, T> getDtoList() {
        return dtoList;
    }

    public int getStart() {
        return start;
    }

    public int getLength() {
        return length;
    }

    public List<String> getSortColumns() {
        return sortColumns;
    }
}
