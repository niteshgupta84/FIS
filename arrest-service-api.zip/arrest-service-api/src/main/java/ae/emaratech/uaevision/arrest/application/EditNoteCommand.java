package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.application.dto.ArrestNoteDto;
import ae.emaratech.uaevision.fis.common.key.NoteKey;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
public class EditNoteCommand {

    private NoteKey noteKey;

    private String noteText;

    private List<ArrestNoteDto> arrestNoteDtoList = new ArrayList<>();

    public EditNoteCommand(NoteKey noteKey, String noteText) {
        this.noteKey = noteKey;
        this.noteText = noteText;
    }

    public EditNoteCommand withNoteList(List<ArrestNoteDto> arrestNoteDtoList) {
        this.arrestNoteDtoList = arrestNoteDtoList;
        return this;
    }

    public NoteKey getNoteKey() {
        return noteKey;
    }

    public String getNoteText() {
        return noteText;
    }

    public List<ArrestNoteDto> getArrestNoteDtoList() {
        return arrestNoteDtoList;
    }
}
