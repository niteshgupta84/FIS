package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
public class AddArrestTeamCommand {

    private String employeeId;

    private String officerNameEn;

    private String officerNameAr;

    private List<ArrestTeamDto> arrestTeamDtoList = new ArrayList<>();

    public AddArrestTeamCommand(String employeeId) {
        this.employeeId = employeeId;
    }

    public AddArrestTeamCommand withArrestTeam(List<ArrestTeamDto> arrestTeamDtoList) {
        this.arrestTeamDtoList = arrestTeamDtoList;
        return this;
    }

    public AddArrestTeamCommand withAOfficerNameEn(String officerNameEn) {
        this.officerNameEn = officerNameEn;
        return this;
    }

    public AddArrestTeamCommand withAOfficerNameAr(String officerNameAr) {
        this.officerNameAr = officerNameAr;
        return this;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public List<ArrestTeamDto> getArrestTeamDtoList() {
        return arrestTeamDtoList;
    }

    public String getOfficerNameEn() {
        return officerNameEn;
    }

    public String getOfficerNameAr() {
        return officerNameAr;
    }
}
