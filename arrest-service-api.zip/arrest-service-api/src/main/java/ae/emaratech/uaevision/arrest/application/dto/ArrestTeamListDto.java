package ae.emaratech.uaevision.arrest.application.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Muzzamil.Idrees on 5/30/2017.
 */
public class ArrestTeamListDto implements Serializable {
    public List<ArrestTeamDto> getArrestTeamDtoList() {
        return arrestTeamDtoList;
    }

    public void setArrestTeamDtoList(List<ArrestTeamDto> arrestTeamDtoList) {
        this.arrestTeamDtoList = arrestTeamDtoList;
    }

    List<ArrestTeamDto> arrestTeamDtoList;

    public ArrestTeamListDto() {
        arrestTeamDtoList = new ArrayList<>();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ArrestTeamListDto that = (ArrestTeamListDto) o;

        if (arrestTeamDtoList != null ? !arrestTeamDtoList.equals(that.arrestTeamDtoList) : that.arrestTeamDtoList != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        return arrestTeamDtoList != null ? arrestTeamDtoList.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "ArrestTeamListDto{" +
                "arrestTeamDtoList=" + arrestTeamDtoList +
                '}';
    }
}
