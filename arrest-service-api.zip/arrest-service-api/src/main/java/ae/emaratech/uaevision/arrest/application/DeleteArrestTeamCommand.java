package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;
import ae.emaratech.uaevision.fis.common.key.ArrestTeamKey;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
public class DeleteArrestTeamCommand {

    private ArrestTeamKey arrestTeamKey;

    private List<ArrestTeamDto> arrestTeamDtoList = new ArrayList<>();

    public DeleteArrestTeamCommand(ArrestTeamKey arrestTeamKey) {
        this.arrestTeamKey = arrestTeamKey;

    }

    public DeleteArrestTeamCommand withArrestTeam(List<ArrestTeamDto> arrestTeamDtoList) {
        this.arrestTeamDtoList = arrestTeamDtoList;
        return this;
    }

    public ArrestTeamKey getArrestTeamKey() {
        return arrestTeamKey;
    }

    public List<ArrestTeamDto> getArrestTeamDtoList() {
        return arrestTeamDtoList;
    }
}
