package ae.emaratech.uaevision.arrest.domain;

import java.util.List;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Event triggered by the arrest report module on create operation.
 *
 * @author Haroon.Subair
 */
public class ArrestReportUpdatedEvent extends DomainEvent {

    private ArrestReportKey arrestReportKey;
    private String arrestLocation;
    private String reportDescription;
    private Long arrestReason;
    private Long status;
    private Long transferredFrom;
    private String arrestParties;
    private List<Long> attachments;
    private List<Long> notes;
    private List<Long> seizures;
    private List<Long> arrestAssociations;
    private List<String> arrestTeams;
    private Long entryExitId;

    public ArrestReportUpdatedEvent(Builder builder) {
        super(builder);
        this.arrestReportKey = builder.arrestReportKey;
        this.arrestLocation = builder.arrestLocation;
        this.reportDescription = builder.reportDescription;
        this.arrestReason = builder.arrestReasonId;
        this.status = builder.statusId;
        this.transferredFrom = builder.transferredFromDeptId;
        this.notes = builder.notes;
        this.seizures = builder.seizures;
        this.attachments = builder.attachments;
        this.arrestAssociations = builder.arrestAssociations;
        this.arrestTeams = builder.arrestTeams;
        this.entryExitId = builder.entryExitId;

    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public String getParties() {
        return arrestParties;
    }

    public List<Long> getAttachments() {
        return attachments;
    }

    public String getArrestLocation() {
        return arrestLocation;
    }

    public String getReportDescription() {
        return reportDescription;
    }

    public Long getStatus() {
        return status;
    }

    public Long getEntryExitId() {
        return entryExitId;
    }

    public void withArrestPartiesJson(String arrestPartyListJson) {
        this.arrestParties = arrestPartyListJson;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private Long arrestReasonId;
        private Long transferredFromDeptId;
        private String reportDescription;
        private Long statusId;
        private String arrestLocation;
        private List<Long> attachments;
        private List<Long> notes;
        private List<Long> seizures;
        private List<Long> arrestAssociations;
        private List<String> arrestTeams;
        private Long entryExitId;

        public Builder(EventContext eventContext,
                       ArrestReportKey arrestReportKey, ArrestReason arrestReason,
                       String reportDescription) {
            super(eventContext);
            this.arrestReasonId = arrestReason.id();
            this.arrestReportKey = arrestReportKey;
            this.reportDescription = reportDescription;
        }

        public ArrestReportUpdatedEvent build() {
            return new ArrestReportUpdatedEvent(this);
        }

        public Builder withNotes(List<Long> notesList) {
            this.notes = notesList;
            return this;
        }

        public Builder withSeizures(List<Long> seizureList) {
            this.seizures = seizureList;
            return this;
        }

        public Builder withAttachments(List<Long> arrestedReportAttachments) {

            this.attachments = arrestedReportAttachments;
            return this;
        }

        public Builder withArrestAssociations(List<Long> arrestAssociations) {
            this.arrestAssociations = arrestAssociations;
            return this;
        }

        public Builder withArrestTeams(List<String> arrestTeams) {
            this.arrestTeams = arrestTeams;
            return this;
        }

        public Builder withArrestLocation(String arrestLocation) {
            this.arrestLocation = arrestLocation;
            return this;
        }

        public Builder withStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withTransferredFrom(Long transferredFromDeptId) {
            this.transferredFromDeptId = transferredFromDeptId;
            return this;
        }

        public Builder withEntryExitId(Long entryExitId) {
            this.entryExitId = entryExitId;
            return this;
        }
    }
}
