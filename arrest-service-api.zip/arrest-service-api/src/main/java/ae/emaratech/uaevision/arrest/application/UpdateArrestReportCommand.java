package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.application.dto.ArrestNoteDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestPartyDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;
import ae.emaratech.uaevision.arrest.application.dto.SeizureDto;
import ae.emaratech.uaevision.arrest.domain.ArrestDescription;
import ae.emaratech.uaevision.arrest.domain.ArrestReason;
import ae.emaratech.uaevision.arrest.domain.LocationType;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.AssociatedArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.AttachmentReferenceKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.lookup.service.model.Entry;

import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * Command class which provides the information to update the arrest report.
 *
 * @author Haroon.Subair
 */
public class UpdateArrestReportCommand {

    private ArrestReportKey arrestReportKey;
    private List<PartyKey> partyList;
    private List<AttachmentReferenceKey> attachmentList;
    private List<SeizureDto> seizureList;
    private List<ArrestNoteDto> arrestNoteList;
    private List<ArrestTeamDto> arrestTeamList;
    private Entry emirateId;
    private Entry cityId;
    private Entry areaId;
    private LocationType locationType;
    private String arrestLocation;
    private Entry unit;
    private ArrestReason arrestReason;
    private ArrestDescription arrestDescription;
    private Set<AssociatedArrestReportKey> associatedArrestList;
    private String locationDescription;
    private String arrestBuilding;
    private String arrestStreet;

    private Date arrestDate;
    private Date arrestDateTime;
    private String arrestTime;
    private Entry transferredFromId;
    private Entry shift;
    private boolean isUrgent;
    private boolean isCreatedByAhwal;
    private Department department;
    private Entry terminalLocation;
    private List<ArrestPartyDto> arrestPartyDtoList;
    private Long version;
    private Entry entryExitInfo;

    public UpdateArrestReportCommand(Builder builder) {

        this.arrestReportKey = builder.arrestReportKey;
        this.partyList = builder.partyList;
        this.arrestReason = builder.arrestReason;
        this.emirateId = builder.emirateId;
        this.cityId = builder.cityId;
        this.areaId = builder.areaId;
        this.locationType = builder.locationType;
        this.arrestLocation = builder.arrestLocation;
        this.attachmentList = builder.attachmentList;
        this.unit = builder.unit;
        this.arrestDescription = builder.arrestDescription;
        this.seizureList = builder.seizureList;
        this.arrestNoteList = builder.arrestNoteList;
        this.associatedArrestList = builder.associatedArrestList;
        this.arrestTeamList = builder.arrestTeamList;


        this.transferredFromId = builder.transferredFromId;
        this.shift = builder.shift;
        this.isUrgent = builder.isUrgent;
        this.isCreatedByAhwal = builder.isCreatedByAhwal;
        this.arrestDate = builder.arrestDate;
        this.arrestTime = builder.arrestTime;
        this.arrestDateTime = builder.arrestDateTime;
        this.locationDescription = builder.locationDescription;
        this.arrestBuilding = builder.arrestBuilding;
        this.arrestStreet = builder.arrestStreet;
        this.department = builder.department;
        this.terminalLocation = builder.terminalLocation;

        this.arrestPartyDtoList = builder.arrestPartyDtoList;
        this.version = builder.version;
        this.entryExitInfo = builder.entryExitInfo;

    }

    public Entry getTerminalLocation() {
        return terminalLocation;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public List<PartyKey> getPartyList() {
        return partyList;
    }

    public List<AttachmentReferenceKey> getAttachmentList() {
        return attachmentList;
    }

    public Entry getEmirateId() {
        return emirateId;
    }

    public Entry getCityId() {
        return cityId;
    }

    public Entry getAreaId() {
        return areaId;
    }

    public LocationType getLocationType() {
        return locationType;
    }

    public String getArrestLocation() {
        return arrestLocation;
    }

    public Entry getUnit() {
        return unit;
    }

    public ArrestReason getArrestReason() {
        return arrestReason;
    }

    public ArrestDescription getArrestDescription() {
        return arrestDescription;
    }

    public List<SeizureDto> getSeizureList() {
        return seizureList;
    }

    public List<ArrestNoteDto> getArrestNoteList() {
        return arrestNoteList;
    }

    public Entry getTransferredFromId() {
        return transferredFromId;
    }

    public Entry getShift() {
        return shift;
    }

    public boolean isUrgent() {
        return isUrgent;
    }

    public boolean isCreatedByAhwal() {
        return isCreatedByAhwal;
    }

    public Date getArrestDate() {
        return arrestDate;
    }

    public String getArrestTime() {
        return arrestTime;
    }

    public Set<AssociatedArrestReportKey> getAssociatedArrestList() {
        return associatedArrestList;
    }

    public Date getArrestDateTime() {
        return arrestDateTime;
    }

    public String getArrestBuilding() {
        return arrestBuilding;
    }

    public String getArrestStreet() {
        return arrestStreet;
    }

    public String getLocationDescription() {
        return locationDescription;
    }

    public List<ArrestTeamDto> getArrestTeamList() {
        return arrestTeamList;
    }

    public Department getDepartment() {
        return department;
    }

    public List<ArrestPartyDto> getArrestPartyDtoList() {
        return arrestPartyDtoList;
    }

    public Long getVersion() {
        return version;
    }

    public Entry getEntryExitInfo() {
        return entryExitInfo;
    }

    public static class Builder {

        private Date arrestDateTime;
        private ArrestReportKey arrestReportKey;
        private List<PartyKey> partyList;
        private List<AttachmentReferenceKey> attachmentList;
        private Entry emirateId;
        private Entry cityId;
        private Entry areaId;
        private LocationType locationType;
        private String arrestLocation;
        private Entry unit;
        private ArrestReason arrestReason;
        private ArrestDescription arrestDescription;
        private List<SeizureDto> seizureList;
        private List<ArrestNoteDto> arrestNoteList;
        private Set<AssociatedArrestReportKey> associatedArrestList;
        private List<ArrestTeamDto> arrestTeamList;

        private Entry transferredFromId;
        private Entry shift;
        private boolean isUrgent;
        private boolean isCreatedByAhwal;
        private Date arrestDate;
        private String arrestTime;
        private String locationDescription;
        private String arrestBuilding;
        private String arrestStreet;
        private Department department;
        private Entry terminalLocation;
        private List<ArrestPartyDto> arrestPartyDtoList;
        private Long version;
        private Entry entryExitInfo;

        public Builder(ArrestReportKey arrestReportKey, List<PartyKey> partyList,
                       ArrestReason arrestReason, ArrestDescription arrestDescription) {

            this.arrestReportKey = arrestReportKey;
            this.partyList = partyList;
            this.arrestReason = arrestReason;
            this.arrestDescription = arrestDescription;
        }

        public Builder withTerminalLocation(Entry terminalLocation) {
            this.terminalLocation = terminalLocation;
            return this;
        }

        public Builder withEmirate(Entry emiratesId) {
            this.emirateId = emiratesId;
            return this;
        }

        public Builder withCity(Entry cityId) {
            this.cityId = cityId;
            return this;
        }

        public Builder withArea(Entry areaId) {
            this.areaId = areaId;
            return this;
        }

        public Builder withArrestLocation(String location) {
            this.arrestLocation = location;
            return this;
        }

        public Builder withUnit(Entry unit) {
            this.unit = unit;
            return this;
        }

        public Builder withAttachmentList(List<AttachmentReferenceKey> attachments) {
            this.attachmentList = attachments;
            return this;
        }

        public Builder withSeizureList(List<SeizureDto> seizures) {
            this.seizureList = seizures;
            return this;
        }

        public Builder withArrestNoteList(List<ArrestNoteDto> arrestNotes) {
            this.arrestNoteList = arrestNotes;
            return this;
        }

        public Builder withAssociatedArrestList(Set<AssociatedArrestReportKey> associatedArrestList) {
            this.associatedArrestList = associatedArrestList;
            return this;
        }

        public Builder withArrestTeamList(List<ArrestTeamDto> arrestTeamList) {
            this.arrestTeamList = arrestTeamList;
            return this;
        }

        public Builder withShift(Entry shift) {
            this.shift = shift;
            return this;
        }

        public Builder withIsUrgent(boolean isUrgent) {
            this.isUrgent = isUrgent;
            return this;
        }

        public Builder withIsCreatedByAhwal(boolean isCreatedByAhwal) {
            this.isCreatedByAhwal = isCreatedByAhwal;
            return this;
        }

        public Builder withTransferredFrom(Entry transferredFromId) {
            this.transferredFromId = transferredFromId;
            return this;
        }


        public Builder withLocationType(LocationType locationType) {
            this.locationType = locationType;
            return this;
        }

        public Builder withArrestDate(Date arrestDate) {
            this.arrestDate = arrestDate;
            return this;
        }

        public Builder withArrestTime(String arrestTime) {
            this.arrestTime = arrestTime;
            return this;
        }

        public Builder withArrestDateTime(Date arrestDateTime) {
            this.arrestDateTime = arrestDateTime;
            return this;
        }

        public Builder withLocationDescription(String locationDescription) {
            this.locationDescription = locationDescription;
            return this;
        }

        public Builder withArrestBuilding(String arrestBuilding) {
            this.arrestBuilding = arrestBuilding;
            return this;
        }

        public Builder withArrestStreet(String arrestStreet) {
            this.arrestStreet = arrestStreet;
            return this;
        }

        public Builder withDepartment(Department department) {
            this.department = department;
            return this;
        }

        public Builder withArrestPartyList(List<ArrestPartyDto> partyKeyList) {
            this.arrestPartyDtoList = partyKeyList;
            return this;
        }
        public Builder withVersion(Long version) {
            this.version = version;
            return this;
        }
        public Builder withEntryExitInfo(Entry entryExitInfo) {
            this.entryExitInfo = entryExitInfo;
            return this;
        }
        public UpdateArrestReportCommand build() {
            return new UpdateArrestReportCommand(this);
        }
    }
}
