package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public class RejectArrestReportCommand {
    private ArrestReportKey arrestReportKey;
    private String rejectComments;

    public RejectArrestReportCommand(ArrestReportKey arrestReportKey, String rejectComments) {
        this.arrestReportKey = arrestReportKey;
        this.rejectComments = rejectComments;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public String getRejectComments() {
        return rejectComments;
    }
}
