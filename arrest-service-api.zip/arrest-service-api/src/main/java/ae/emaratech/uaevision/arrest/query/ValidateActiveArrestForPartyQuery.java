package ae.emaratech.uaevision.arrest.query;

import java.io.Serializable;
import java.util.List;

/**
 * Query object which wraps the list of party id nos to be validated whether they are associated
 * with any existing active arrest incident record.
 *
 * @author Haroon.Subair
 */
public class ValidateActiveArrestForPartyQuery implements Serializable {

    private List<Long> partyIdList;

    public ValidateActiveArrestForPartyQuery(List<Long> partyIdList) {
        this.partyIdList = partyIdList;
    }

    public List<Long> getPartyIdList() {
        return partyIdList;
    }
}
