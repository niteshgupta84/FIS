package ae.emaratech.uaevision.arrest.application.dto;

import ae.emaratech.uaevision.fis.common.dto.AbstractDtoBase;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by Nitesh.Gupta on 11/26/2015.
 */
@ApiModel(value = "Seizure Dto ")
public class SeizureDto extends AbstractDtoBase implements Serializable {

    /**
     * Sequence No
     */
    @ApiModelProperty(value = "Sequence Number ", required = true , dataType = "long")
    private long sequenceNo;
    /**
     * Primary Key
     */
    @ApiModelProperty(value = "Unique Seizure Id", required = true , dataType = "long")
    private long id;
    /**
     * Seizure Id
     */
    @ApiModelProperty(value = "Unique Seizure Id", required = true , dataType = "long")
    private long seizureId;
    @ApiModelProperty(value = "Count of Seizure", required = true , dataType = "string")
    private String count;
    @ApiModelProperty(value = "Seized Item", required = true , dataType = "string")
    private String seizedItem;
    @ApiModelProperty(value = "Created Date", required = true , dataType = "date")
    private Date createdDate;
    @ApiModelProperty(value = "Created By", required = true , dataType = "string")
    private String createdBy;
    @ApiModelProperty(value = "Is Deleted", required = true , dataType = "long")
    private Long isDeleted;
    @ApiModelProperty(value = "Version", required = true , dataType = "long")
    private Long version;

    public long getSeizureId() {
        return seizureId;
    }

    public void setSeizureId(long seizureId) {
        this.seizureId = seizureId;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getSeizedItem() {
        return seizedItem;
    }

    public void setSeizedItem(String seizedItem) {
        this.seizedItem = seizedItem;
    }


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getSequenceNo() {
        return sequenceNo;
    }

    public void setSequenceNo(long sequenceNo) {
        this.sequenceNo = sequenceNo;
    }


    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public Long getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Long isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        SeizureDto that = (SeizureDto) o;

        if (id != that.id) return false;
        if (seizureId != that.seizureId) return false;
        if (sequenceNo != that.sequenceNo) return false;
        if (count != null ? !count.equals(that.count) : that.count != null) return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDate != null ? !createdDate.equals(that.createdDate) : that.createdDate != null) return false;
        if (isDeleted != null ? !isDeleted.equals(that.isDeleted) : that.isDeleted != null) return false;
        if (seizedItem != null ? !seizedItem.equals(that.seizedItem) : that.seizedItem != null) return false;
        if (version != null ? !version.equals(that.version) : that.version != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (int) (sequenceNo ^ (sequenceNo >>> 32));
        result = 31 * result + (int) (id ^ (id >>> 32));
        result = 31 * result + (int) (seizureId ^ (seizureId >>> 32));
        result = 31 * result + (count != null ? count.hashCode() : 0);
        result = 31 * result + (seizedItem != null ? seizedItem.hashCode() : 0);
        result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (isDeleted != null ? isDeleted.hashCode() : 0);
        result = 31 * result + (version != null ? version.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SeizureDto{" +
                "sequenceNo=" + sequenceNo +
                ", id=" + id +
                ", seizureId=" + seizureId +
                ", count='" + count + '\'' +
                ", seizedItem='" + seizedItem + '\'' +
                ", createdDate=" + createdDate +
                ", createdBy='" + createdBy + '\'' +
                ", isDeleted=" + isDeleted +
                ", version=" + version +
                '}';
    }
}
