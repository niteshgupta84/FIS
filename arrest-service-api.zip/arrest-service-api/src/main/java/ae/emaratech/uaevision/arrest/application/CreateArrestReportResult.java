package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Result class which provides the acknowledgement information after the creation of arrest report.
 *
 * @author Haroon.Subair
 */
public class CreateArrestReportResult {

    private ArrestReportKey arrestReportKey;

    public CreateArrestReportResult(ArrestReportKey arrestReportKey) {
        this.arrestReportKey = arrestReportKey;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }
}
