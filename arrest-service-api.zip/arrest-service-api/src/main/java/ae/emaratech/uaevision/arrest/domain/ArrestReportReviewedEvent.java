package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Event triggered by Arrest module when an arrest report is sent to supervisor for review.
 *
 * @author Nitesh.Gupta
 */
public class ArrestReportReviewedEvent extends DomainEvent {

    private ArrestReportKey arrestReportKey;
    private Long status;
    private String reviewComments;

    private ArrestReportReviewedEvent(Builder builder) {
        super(builder);
        this.arrestReportKey = builder.arrestReportKey;
        this.status = builder.statusId;
        this.reviewComments = builder.reviewComments;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public Long getStatus() {
        return status;
    }

    public String getReviewComments() {
        return reviewComments;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private Long statusId;
        private String reviewComments;

        public Builder(EventContext eventContext, ArrestReportKey arrestReportKey) {
            super(eventContext);
            this.arrestReportKey = arrestReportKey;
        }

        public Builder withArrestStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withReviewComments(String reviewComments) {
            this.reviewComments = reviewComments;
            return this;
        }

        public ArrestReportReviewedEvent build() {
            return new ArrestReportReviewedEvent(this);
        }
    }
}
