package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Created by Nitesh.Gupta on 6/14/2016.
 */
public class AssignArrestCommand {
    private ArrestReportKey arrestReportKey;

    private String userId;

    public AssignArrestCommand(ArrestReportKey arrestReportKey, String userId) {
        this.arrestReportKey = arrestReportKey;
        this.userId = userId;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public String getUserId() {
        return userId;
    }
}
