package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Event triggered by the Detective supervisor to instruct the detective officer to update the
 * arrest report further.
 *
 * @author Haroon.Subair
 */
public class ArrestReportRejectedEvent extends DomainEvent {

    private ArrestReportKey arrestReportKey;
    private Long status;
    private String rejectComments;

    private ArrestReportRejectedEvent(Builder builder) {
        super(builder);
        this.arrestReportKey = builder.arrestReportKey;
        this.status = builder.statusId;
        this.rejectComments = builder.rejectComments;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public Long getStatus() {
        return status;
    }

    public String getRejectComments() {
        return rejectComments;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private Long statusId;
        private String rejectComments;

        public Builder(EventContext eventContext, ArrestReportKey arrestReportKey) {
            super(eventContext);
            this.arrestReportKey = arrestReportKey;
        }

        public Builder withArrestStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withRejectedComments(String rejectComments) {
            this.rejectComments = rejectComments;
            return this;
        }

        public ArrestReportRejectedEvent build() {
            return new ArrestReportRejectedEvent(this);
        }
    }
}
