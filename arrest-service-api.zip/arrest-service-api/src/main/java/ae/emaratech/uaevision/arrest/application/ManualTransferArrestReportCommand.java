package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public class ManualTransferArrestReportCommand {

    private ArrestReportKey arrestReportKey;
    private String transferComments;

    private Long manualTransferTo;

    public ManualTransferArrestReportCommand(ArrestReportKey arrestReportKey, String transferComments, Long manualTransferTo) {
        this.arrestReportKey = arrestReportKey;
        this.transferComments = transferComments;
        this.manualTransferTo = manualTransferTo;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public String getTransferComments() {
        return transferComments;
    }

    public Long getManualTransferTo() {
        return manualTransferTo;
    }
}
