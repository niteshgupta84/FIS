package ae.emaratech.uaevision.arrest.application.dto;

import ae.emaratech.uaevision.fis.common.dto.AbstractDtoBase;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@ApiModel(value="Arrest Report Track ")
public class ArrestReportTrackDto extends AbstractDtoBase implements Serializable {

    /**
     * The identifier for interrogation track event.
     */
    @ApiModelProperty(value = "The identifier for Arrest Report track event", required = true)
    private Long id;

    /**
     * The identifier for the action performed during arrest activity.
     */
    @ApiModelProperty(value = "Arrest Report Action", required = true)
    private Entry action;

    /**
     * Reference to the interrogation activity.
     */
    @ApiModelProperty(value = "Arrest Id ", required = true)
    private Long arrestId;

    /**
     * The user comments captured while triggering the action.
     */
    @ApiModelProperty(value = "User Comments for action taken", required = false)
    private String comments;

    private long sequenceNo;

    private String createdBy;
    private Date createdDate;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Entry getAction() {
        return action;
    }

    public void setAction(Entry action) {
        this.action = action;
    }

    public Long getArrestId() {
        return arrestId;
    }

    public void setArrestId(Long arrestId) {
        this.arrestId = arrestId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }


    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }


    public long getSequenceNo() {
        return sequenceNo;
    }

    public void setSequenceNo(long sequenceNo) {
        this.sequenceNo = sequenceNo;
    }

    @Override
    public String toString() {
        return "ArrestReportTrackDto{" +
                "id=" + id +
                ", action=" + action +
                ", arrestId=" + arrestId +
                ", comments='" + comments + '\'' +
                ", sequenceNo=" + sequenceNo +
                ", createdBy='" + createdBy + '\'' +
                ", createdDate=" + createdDate +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        ArrestReportTrackDto that = (ArrestReportTrackDto) o;

        if (sequenceNo != that.sequenceNo) return false;
        if (action != null ? !action.equals(that.action) : that.action != null) return false;
        if (arrestId != null ? !arrestId.equals(that.arrestId) : that.arrestId != null) return false;
        if (comments != null ? !comments.equals(that.comments) : that.comments != null) return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDate != null ? !createdDate.equals(that.createdDate) : that.createdDate != null) return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (id != null ? id.hashCode() : 0);
        result = 31 * result + (action != null ? action.hashCode() : 0);
        result = 31 * result + (arrestId != null ? arrestId.hashCode() : 0);
        result = 31 * result + (comments != null ? comments.hashCode() : 0);
        result = 31 * result + (int) (sequenceNo ^ (sequenceNo >>> 32));
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
        return result;
    }
}
