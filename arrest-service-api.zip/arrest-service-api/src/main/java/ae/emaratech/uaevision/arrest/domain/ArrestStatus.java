package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.dto.Identifiable;

/**
 * Created by Nitesh.Gupta on 6/5/2016.
 */
public enum ArrestStatus implements Identifiable {
    NEW(1L),
    OPENED(2L),
    CLOSED(3L, true),
    PENDING_DECISION(4L, true),
    FORWARDED(5L, true),
    ENDED(6L, true),
    APPROVED(10L, true);

    private final Long id;
    private Boolean makeReadOnly;


    private ArrestStatus(Long id) {
        this(id, Boolean.FALSE);
    }

    private ArrestStatus(Long id, Boolean makeReadOnly) {
        this.id = id;
        this.makeReadOnly = makeReadOnly;
    }


    public Long id() {

        return this.id;
    }

    public boolean makeReadOnly() {

        return makeReadOnly;
    }
}
