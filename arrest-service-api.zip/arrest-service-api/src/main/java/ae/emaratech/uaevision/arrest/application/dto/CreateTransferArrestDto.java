package ae.emaratech.uaevision.arrest.application.dto;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.TrackerKey;

import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public class CreateTransferArrestDto {



    private ArrestReportKey arrestReportKey;
    private TrackerKey trackerKey;
    private List<ArrestPartyDto> transferredArrestPartyDtoList;

    public CreateTransferArrestDto(ArrestReportKey arrestReportKey, TrackerKey trackerKey,
                                   List<ArrestPartyDto> transferredArrestPartyDtoList){

        this.arrestReportKey = arrestReportKey;
        this.trackerKey = trackerKey;
        this.transferredArrestPartyDtoList = transferredArrestPartyDtoList;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public TrackerKey getTrackerKey() {
        return trackerKey;
    }

    public List<ArrestPartyDto> getTransferredArrestPartyDtoList() {
        return transferredArrestPartyDtoList;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CreateTransferArrestDto that = (CreateTransferArrestDto) o;

        if (arrestReportKey != null ? !arrestReportKey.equals(that.arrestReportKey) : that.arrestReportKey != null)
            return false;
        if (trackerKey != null ? !trackerKey.equals(that.trackerKey) : that.trackerKey != null) return false;
        if (transferredArrestPartyDtoList != null ? !transferredArrestPartyDtoList.equals(that.transferredArrestPartyDtoList) : that.transferredArrestPartyDtoList != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = arrestReportKey != null ? arrestReportKey.hashCode() : 0;
        result = 31 * result + (trackerKey != null ? trackerKey.hashCode() : 0);
        result = 31 * result + (transferredArrestPartyDtoList != null ? transferredArrestPartyDtoList.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "CreateTransferArrestDto{" +
                "arrestReportKey=" + arrestReportKey +
                ", trackerKey=" + trackerKey +
                ", transferredArrestPartyDtoList=" + transferredArrestPartyDtoList +
                '}';
    }
}
