package ae.emaratech.uaevision.arrest.query;

import ae.emaratech.uaevision.arrest.application.ArrestPageBuilder;

import java.io.Serializable;

/**
 * Created by Nitesh.Gupta on 6/14/2016.
 */
public class RetrieveArrestsWithOwnerDetailQuery implements Serializable{
    private Long sectionId;

    private Long sectionUnitId;

    private String userId;

    private ArrestPageBuilder arrestPageBuilder;

    public RetrieveArrestsWithOwnerDetailQuery(Long sectionId) {
        this.sectionId = sectionId;
    }

    public RetrieveArrestsWithOwnerDetailQuery withSectionUnitId(Long sectionUnitId) {
        this.sectionUnitId = sectionUnitId;
        return this;
    }

    /**
     * User
     *
     * @param userId
     * @return
     */
    public RetrieveArrestsWithOwnerDetailQuery withUser(String userId) {
        this.userId = userId;
        return this;
    }

    public RetrieveArrestsWithOwnerDetailQuery withArrestPageBuilder(ArrestPageBuilder arrestPageBuilder) {
        this.arrestPageBuilder = arrestPageBuilder;
        return this;
    }

    public Long getSectionId() {
        return sectionId;
    }

    public Long getSectionUnitId() {
        return sectionUnitId;
    }

    public String getUserId() {
        return userId;
    }

    public ArrestPageBuilder getArrestPageBuilder() {
        return arrestPageBuilder;
    }
}
