package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.dto.Identifiable;

/**
 * Enum holding values for various location type.
 *
 * @author Haroon.Subair
 */
public enum LocationType implements Identifiable {

    LOC(1L, "incident.arrestReport.label.locvalue1"),
    COORDINATES(2L, "incident.arrestReport.label.locvalue2");

    private String key;
    private Long id;

    LocationType(Long id, String key) {
        this.id = id;
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    public Long id() {
        return this.id;
    }

}
