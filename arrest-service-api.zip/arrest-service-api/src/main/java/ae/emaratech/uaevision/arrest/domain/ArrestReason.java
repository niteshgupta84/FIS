package ae.emaratech.uaevision.arrest.domain;

/**
 * Value object encapsulating the value of arrest reason identifier.
 *
 * @author Haroon.Subair
 */
public class ArrestReason {

    private Long id;

    public ArrestReason(Long arrestReasonId) {
        this.id = arrestReasonId;
    }

    public Long id() {
        return id;
    }
}
