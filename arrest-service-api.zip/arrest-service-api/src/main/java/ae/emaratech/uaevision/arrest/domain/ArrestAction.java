package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.dto.Identifiable;
import ae.emaratech.uaevision.fis.user.service.dto.PrivilegeConstant;

/**
 * Created by Nitesh.Gupta on 6/5/2016.
 */
public enum ArrestAction implements Identifiable {
    //Name   (id  lock    commentable   track    priv   state
    NEW(1L, false, false, false, PrivilegeConstant.FIS_ARREST_INCIDENT_CREATE, null),
    OPEN(2L, false, false, true, PrivilegeConstant.FIS_ARREST_INCIDENT_CREATE, ArrestStatus.OPENED),
    ACQUIRE(3L, false, false, false, PrivilegeConstant.FIS_ARREST_INCIDENT_ACQUIRE, null),
    UPDATE(4L, true, false, false, PrivilegeConstant.FIS_ARREST_INCIDENT_UPDATE, null),
    FORWARD_TO_CASE(5L, true, true, true, PrivilegeConstant.FIS_ARREST_FORWARD_TO_CASE,
            ArrestStatus.FORWARDED), //TODO : rename to Transfer
    REOPEN(6L, false, false, true, PrivilegeConstant.FIS_ARREST_INCIDENT_REOPEN, ArrestStatus.OPENED),
    CLOSE(7L, true, true, true, PrivilegeConstant.FIS_ARREST_INCIDENT_CLOSE, ArrestStatus.CLOSED),
    REJECT(8L, true, true, true, PrivilegeConstant.FIS_ARREST_INCIDENT_SUPERVISOR_REJECT, ArrestStatus.OPENED),
    FORWARD_TO_SUPERVISOR(9L, true, true, true, PrivilegeConstant.FIS_ARREST_ESCALATE_TO_SUPERVISOR,
            ArrestStatus.PENDING_DECISION), //TODO : rename to Forward
    END(10L, true, true, true, 1148L, ArrestStatus.ENDED),
    VIEW(11L, false, false, false, PrivilegeConstant.FIS_ARREST_INCIDENT_VIEW, null),
    SEARCH(12L, false, false, false, PrivilegeConstant.FIS_ARREST_INCIDENT_VIEW, null),
    ACQUIRE_LONGER(16L, true, false, true, 3016L, null),

    APPROVE(19L, true, true, true, PrivilegeConstant.FIS_ARREST_INCIDENT_SUPERVISOR_APPROVE, ArrestStatus.APPROVED),
    DELETE_PARTY(23L, true, true, true, PrivilegeConstant.FIS_ARREST_PARTY_REMOVE, null),
    ADD_PARTY(24L, true, true, true, PrivilegeConstant.FIS_ARREST_PARTY_ADD, null),
    ADD_IRIS(29L, false, true, true, PrivilegeConstant.FIS_ARREST_PARTY_ADD, null),
    TRANSFERRED(30L, false, true, true, PrivilegeConstant.FIS_ARREST_FORWARD_TO_CASE, null);


    private Long id;
    private Boolean requiresLock;
    private Boolean commentable;
    private Boolean trackable;
    private Long visionPrivilegeId;
    private ArrestStatus resultState;

    ArrestAction(Long id, Boolean requiresLock, Boolean commentable, Boolean trackable,
                 Long visionPrivilegeId, ArrestStatus resultState) {
        this.id = id;
        this.requiresLock = requiresLock;
        this.commentable = commentable;
        this.trackable = trackable;
        this.visionPrivilegeId = visionPrivilegeId;
        this.resultState = resultState;

    }

    public String authority() {

        return this.name();
    }

    public Long getId() {
        return id;
    }

    public boolean requiresLock() {
        return requiresLock;
    }

    public boolean commentable() {
        return commentable;
    }

    public boolean trackable() {
        return trackable;
    }

    public Long visionPrivilegeId() {
        return visionPrivilegeId;
    }

    public ArrestStatus resultState() {
        return resultState;
    }


    @Override
    public String toString() {
        return "IncidentActions{" +
                "name=" + name() +
                ", id=" + id +
                ", requiresLock=" + requiresLock +
                ", commentable=" + commentable +
                ", trackable=" + trackable +
                ", visionPrivilegeId=" + visionPrivilegeId +
                ", resultState=" + resultState +
                '}';
    }

    @Override
    public Long id() {
        return id;
    }
}
