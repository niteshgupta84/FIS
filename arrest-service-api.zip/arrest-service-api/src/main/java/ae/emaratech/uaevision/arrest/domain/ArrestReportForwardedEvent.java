package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Event triggered when the arrest report is forwarded to case.
 *
 * @author Nitesh.Gupta
 */
public class ArrestReportForwardedEvent extends DomainEvent {

    private ArrestReportKey arrestReportKey;
    private Long status;
    private String forwardComments;
    private Long transferredFromId;

    private ArrestReportForwardedEvent(Builder builder) {
        super(builder);
        this.arrestReportKey = builder.arrestReportKey;
        this.status = builder.statusId;
        this.forwardComments = builder.forwardComments;
        this.transferredFromId = builder.transferredFromId;
    }

    public Long getTransferredFromId() {
        return transferredFromId;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public Long getStatus() {
        return status;
    }

    public String getForwardComments() {
        return forwardComments;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private Long statusId;
        private String forwardComments;
        private Long transferredFromId;
        private Long arrestReason;

        public Builder(EventContext eventContext, ArrestReportKey arrestReportKey) {
            super(eventContext);
            this.arrestReportKey = arrestReportKey;
        }

        public Builder withArrestStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withForwardComments(String rejectComments) {
            this.forwardComments = rejectComments;
            return this;
        }

        public Builder withTransferredFrom(Long transferredFromId) {
            this.transferredFromId = transferredFromId;
            return this;
        }

        public Builder withArrestReason(Long arrestReasonId) {
            this.arrestReason = arrestReasonId;
            return this;
        }

        public ArrestReportForwardedEvent build() {
            return new ArrestReportForwardedEvent(this);
        }
    }
}
