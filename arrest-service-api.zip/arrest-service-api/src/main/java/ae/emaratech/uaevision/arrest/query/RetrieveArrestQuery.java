package ae.emaratech.uaevision.arrest.query;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Created by Nitesh.Gupta on 6/12/2016.
 */
public class RetrieveArrestQuery {

    /**
     * Reference to the arrest identifier.
     */
    private ArrestReportKey arrestReportKey;

    public RetrieveArrestQuery(ArrestReportKey arrestReportKey) {
        this.arrestReportKey = arrestReportKey;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }
}
