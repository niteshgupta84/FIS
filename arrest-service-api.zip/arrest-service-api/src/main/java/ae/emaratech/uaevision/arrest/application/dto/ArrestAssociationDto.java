package ae.emaratech.uaevision.arrest.application.dto;

import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@ApiModel(value = "Arrest Association Dto ", description = "Dto holds arrest association details ")
public class ArrestAssociationDto implements Serializable {
    @ApiModelProperty(value = "Unique Arrest Association Id", required = true ,dataType = "long")
    private long id;
    @ApiModelProperty(value = "Arrest Association Id", required = true,dataType = "long")
    private long associationId;
    @ApiModelProperty(value = "Unique Arrest Report Id", required = true,dataType = "long")
    private long arrestReportId;
    @ApiModelProperty(value = "Linked Arrest Report Id", required = true,dataType = "long")
    private long linkedArrestReportId;
    @ApiModelProperty(value = "Association Type", required = true, dataType = "object")
    private Entry associationType;
    @ApiModelProperty(value = "Created Date ", required = true,dataType = "date")
    private Date createdDate;
    @ApiModelProperty(value = "Created By ", required = true,dataType = "string")
    private String createdBy;
    private Long version;
    @ApiModelProperty(value = "Arrest Report Dto ", required = true,dataType = "object")
    private ArrestReportDto arrestReportDto;
    @ApiModelProperty(value = "Party Dto ", required = true,dataType = "object")
    private PartyDto partyDto;

    public long getAssociationId() {
        return associationId;
    }

    public void setAssociationId(long associationId) {
        this.associationId = associationId;
    }

    public long getArrestReportId() {
        return arrestReportId;
    }

    public void setArrestReportId(long arrestReportId) {
        this.arrestReportId = arrestReportId;
    }

    public long getLinkedArrestReportId() {
        return linkedArrestReportId;
    }

    public void setLinkedArrestReportId(long linkedArrestReportId) {
        this.linkedArrestReportId = linkedArrestReportId;
    }

    public Entry getAssociationType() {
        return associationType;
    }

    public void setAssociationType(Entry associationType) {
        this.associationType = associationType;
    }


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public ArrestReportDto getArrestReportDto() {
        return arrestReportDto;
    }

    public void setArrestReportDto(ArrestReportDto arrestReportDto) {
        this.arrestReportDto = arrestReportDto;
    }

    public PartyDto getPartyDto() {
        return partyDto;
    }

    public void setPartyDto(PartyDto partyDto) {
        this.partyDto = partyDto;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ArrestAssociationDto that = (ArrestAssociationDto) o;

        if (arrestReportId != that.arrestReportId) return false;
        if (associationId != that.associationId) return false;
        if (id != that.id) return false;
        if (linkedArrestReportId != that.linkedArrestReportId) return false;
        if (arrestReportDto != null ? !arrestReportDto.equals(that.arrestReportDto) : that.arrestReportDto != null)
            return false;
        if (associationType != null ? !associationType.equals(that.associationType) : that.associationType != null)
            return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDate != null ? !createdDate.equals(that.createdDate) : that.createdDate != null) return false;
        if (partyDto != null ? !partyDto.equals(that.partyDto) : that.partyDto != null) return false;
        if (version != null ? !version.equals(that.version) : that.version != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (id ^ (id >>> 32));
        result = 31 * result + (int) (associationId ^ (associationId >>> 32));
        result = 31 * result + (int) (arrestReportId ^ (arrestReportId >>> 32));
        result = 31 * result + (int) (linkedArrestReportId ^ (linkedArrestReportId >>> 32));
        result = 31 * result + (associationType != null ? associationType.hashCode() : 0);
        result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (version != null ? version.hashCode() : 0);
        result = 31 * result + (arrestReportDto != null ? arrestReportDto.hashCode() : 0);
        result = 31 * result + (partyDto != null ? partyDto.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ArrestAssociationDto{" +
                "id=" + id +
                ", associationId=" + associationId +
                ", arrestReportId=" + arrestReportId +
                ", linkedArrestReportId=" + linkedArrestReportId +
                ", associationType=" + associationType +
                ", createdDate=" + createdDate +
                ", createdBy='" + createdBy + '\'' +
                ", version=" + version +
                ", arrestReportDto=" + arrestReportDto +
                ", partyDto=" + partyDto +
                '}';
    }
}
