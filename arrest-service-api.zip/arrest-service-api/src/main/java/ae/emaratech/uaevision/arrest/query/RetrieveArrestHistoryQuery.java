package ae.emaratech.uaevision.arrest.query;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

import java.io.Serializable;

/**
 * Query class which provides the information to retrieve the arrest history details.
 * Created by Nitesh.Gupta on 6/8/2016.
 */
public class RetrieveArrestHistoryQuery implements Serializable{

    /**
     * Reference to the interrogation identifier.
     */
    private ArrestReportKey arrestReportKey;

    public RetrieveArrestHistoryQuery(ArrestReportKey arrestReportKey) {

        this.arrestReportKey = arrestReportKey;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }
}
