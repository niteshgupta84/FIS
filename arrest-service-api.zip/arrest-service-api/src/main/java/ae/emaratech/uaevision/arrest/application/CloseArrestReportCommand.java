package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public class CloseArrestReportCommand {
    private ArrestReportKey arrestReportKey;
    private String closeComments;

    public CloseArrestReportCommand(ArrestReportKey arrestReportKey, String closeComments) {
        this.arrestReportKey = arrestReportKey;
        this.closeComments = closeComments;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public String getCloseComments() {
        return closeComments;
    }
}
