package ae.emaratech.uaevision.arrest.query;

import ae.emaratech.uaevision.fis.common.type.Department;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
public class RetrieveArrestTeamByEmployeeIdQuery implements Serializable{

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    private String employeeId;
    private Department department;

    public RetrieveArrestTeamByEmployeeIdQuery(){}
    public RetrieveArrestTeamByEmployeeIdQuery(Department department) {
        this.department = department;
    }
    public RetrieveArrestTeamByEmployeeIdQuery(Department department,String  employeeId) {
        this.employeeId = employeeId;
        this.department = department;
    }
    public RetrieveArrestTeamByEmployeeIdQuery withEmployeeId(String employeeId) {
        this.employeeId = employeeId;
        return this;
    }

    public String getEmployeeId() {
        return employeeId;
    }
    public Department getDepartment() {
        return department;
    }
}
