package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Event triggered when arrest report sent for review by supervisor has been approved.
 *
 * @author Nitesh.Gupta
 */
public class ArrestReportApprovedEvent extends DomainEvent {

    private ArrestReportKey arrestReportKey;
    private Long status;
    private String approveComments;

    private ArrestReportApprovedEvent(Builder builder) {
        super(builder);
        this.arrestReportKey = builder.arrestReportKey;
        this.status = builder.statusId;
        this.approveComments = builder.approveComments;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public Long getStatus() {
        return status;
    }

    public String getApproveComments() {
        return approveComments;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private Long statusId;
        private String approveComments;

        public Builder(EventContext eventContext, ArrestReportKey arrestReportKey) {
            super(eventContext);
            this.arrestReportKey = arrestReportKey;
        }

        public Builder withArrestStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withApproveComments(String approveComments) {
            this.approveComments = approveComments;
            return this;
        }

        public ArrestReportApprovedEvent build() {
            return new ArrestReportApprovedEvent(this);
        }
    }
}
