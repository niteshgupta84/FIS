package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Event triggered when Arrest is marked as Ended.
 *
 * @author Nitesh.Gupta
 */
public class ArrestReportEndedEvent extends DomainEvent {

    private ArrestReportKey arrestReportKey;
    private Long status;
    private String endComments;

    private ArrestReportEndedEvent(Builder builder) {
        super(builder);
        this.arrestReportKey = builder.arrestReportKey;
        this.status = builder.statusId;
        this.endComments = builder.endComments;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public Long getStatus() {
        return status;
    }

    public String getEndComments() {
        return endComments;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private Long statusId;
        private String endComments;

        public Builder(EventContext eventContext, ArrestReportKey arrestReportKey) {
            super(eventContext);
            this.arrestReportKey = arrestReportKey;
        }

        public Builder withArrestStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withEndComments(String endComments) {
            this.endComments = endComments;
            return this;
        }

        public ArrestReportEndedEvent build() {
            return new ArrestReportEndedEvent(this);
        }
    }
}
