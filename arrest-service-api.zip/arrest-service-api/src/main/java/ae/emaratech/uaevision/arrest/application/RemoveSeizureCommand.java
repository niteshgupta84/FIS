package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.application.dto.SeizureDto;
import ae.emaratech.uaevision.fis.common.key.SeizureKey;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
public class RemoveSeizureCommand {

    private SeizureKey seizureKey;
    private List<SeizureDto> seizureDtoList = new ArrayList();

    public RemoveSeizureCommand(SeizureKey seizureKey) {
        this.seizureKey = seizureKey;
    }

    public RemoveSeizureCommand withSeizureList(List<SeizureDto> seizureDtoList) {
        this.seizureDtoList = seizureDtoList;
        return this;
    }

    public List<SeizureDto> getSeizureDtoList() {
        return seizureDtoList;
    }

    public SeizureKey getSeizureKey() {
        return seizureKey;
    }
}
