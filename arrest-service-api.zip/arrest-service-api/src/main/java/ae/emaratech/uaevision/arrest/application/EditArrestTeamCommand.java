package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;
import ae.emaratech.uaevision.fis.common.key.ArrestTeamKey;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
public class EditArrestTeamCommand {
    private ArrestTeamKey arrestTeamKey;
    private String employeeId;
    private String officerNameEn;

    private String officerNameAr;
    private List<ArrestTeamDto> arrestTeamDtoList = new ArrayList<>();

    public EditArrestTeamCommand(ArrestTeamKey arrestTeamKey, String employeeId) {
        this.arrestTeamKey = arrestTeamKey;
        this.employeeId = employeeId;

    }

    public EditArrestTeamCommand withArrestTeam(List<ArrestTeamDto> arrestTeamDtoList) {
        this.arrestTeamDtoList = arrestTeamDtoList;
        return this;
    }

    public EditArrestTeamCommand withAOfficerNameEn(String officerNameEn) {
        this.officerNameEn = officerNameEn;
        return this;
    }

    public EditArrestTeamCommand withAOfficerNameAr(String officerNameAr) {
        this.officerNameAr = officerNameAr;
        return this;
    }

    public ArrestTeamKey getArrestTeamKey() {
        return arrestTeamKey;
    }

    public List<ArrestTeamDto> getArrestTeamDtoList() {
        return arrestTeamDtoList;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public String getOfficerNameEn() {
        return officerNameEn;
    }

    public String getOfficerNameAr() {
        return officerNameAr;
    }
}
