package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.application.dto.SeizureDto;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
public class AddSeizureCommand {

    private List<SeizureDto> seizureDtoList = new ArrayList();
    private String seizedItem;
    private String itemCount;

    public AddSeizureCommand(String seizedItem, String itemCount) {
        this.seizedItem = seizedItem;
        this.itemCount = itemCount;
    }

    public AddSeizureCommand withSeizureList(List<SeizureDto> seizureDtoList) {
        this.seizureDtoList = seizureDtoList;
        return this;
    }

    public List<SeizureDto> getSeizureDtoList() {
        return seizureDtoList;
    }

    public String getSeizedItem() {
        return seizedItem;
    }

    public String getItemCount() {
        return itemCount;
    }
}
