package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.application.dto.ArrestNoteDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestPartyDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;
import ae.emaratech.uaevision.arrest.application.dto.SeizureDto;
import ae.emaratech.uaevision.arrest.domain.ArrestDescription;
import ae.emaratech.uaevision.arrest.domain.ArrestReason;
import ae.emaratech.uaevision.arrest.domain.LocationType;
import ae.emaratech.uaevision.fis.common.key.AssociatedArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.AttachmentReferenceKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.key.TrackerKey;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;
import ae.emaratech.uaevision.lookup.service.model.Entry;

import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * Command class which provides the information to create the arrest report.
 *
 * @author Haroon.Subair
 */
public class CreateArrestReportCommand {

    private List<PartyKey> partyList;
    private List<AttachmentReferenceKey> attachmentList;
    private List<SeizureDto> seizureList;
    private List<ArrestNoteDto> arrestNoteList;
    private List<ArrestTeamDto> arrestTeamList;
    private Entry emirateId;
    private Entry cityId;
    private Entry areaId;
    private LocationType locationType;
    private String arrestLocation;
    private Section section;
    private Department department;
    private Entry unit;
    private ArrestReason arrestReason;
    private ArrestDescription arrestDescription;
    private Set<AssociatedArrestReportKey> associatedArrestList;
    private String locationDescription;
    private String arrestBuilding;
    private String arrestStreet;

    private Date arrestDate;
    private Date arrestDateTime;
    private String arrestTime;


    private Entry transferredFromId;
    private Entry shift;
    private boolean isUrgent;
    private boolean isCreatedByAhwal;
    private Entry terminalLocation;
    private List<ArrestPartyDto> arrestPartyDtoList;
    private String createdBy;
    private TrackerKey trackerKey;
    private String arrestNumber;
    private Entry entryExitInfo;

    public CreateArrestReportCommand(Builder builder) {

        this.partyList = builder.partyList;
        this.arrestReason = builder.arrestReason;
        this.emirateId = builder.emirateId;
        this.cityId = builder.cityId;
        this.areaId = builder.areaId;
        this.locationType = builder.locationType;
        this.arrestLocation = builder.arrestLocation;
        this.attachmentList = builder.attachmentList;
        this.section = builder.section;
        this.department = builder.department;
        this.unit = builder.unit;
        this.arrestDescription = builder.arrestDescription;
        this.seizureList = builder.seizureList;
        this.arrestNoteList = builder.arrestNoteList;
        this.associatedArrestList = builder.associatedArrestList;
        this.arrestTeamList = builder.arrestTeamList;


        this.transferredFromId = builder.transferredFromId;
        this.shift = builder.shift;
        this.isUrgent = builder.isUrgent;
        this.isCreatedByAhwal = builder.isCreatedByAhwal;
        this.arrestDate = builder.arrestDate;
        this.arrestTime = builder.arrestTime;
        this.arrestDateTime = builder.arrestDateTime;
        this.locationDescription = builder.locationDescription;
        this.arrestBuilding = builder.arrestBuilding;
        this.arrestStreet = builder.arrestStreet;
        this.terminalLocation = builder.terminalLocation;
        this.arrestPartyDtoList = builder.arrestPartyDtoList;
        this.createdBy = builder.createdBy;
        this.trackerKey = builder.trackerKey;
        this.arrestNumber = builder.arrestNumber;
        this.entryExitInfo = builder.entryExitInfo;


    }

    public TrackerKey getTrackerKey() {
        return trackerKey;
    }

    public List<PartyKey> getPartyList() {
        return partyList;
    }

    public List<AttachmentReferenceKey> getAttachmentList() {
        return attachmentList;
    }

    public Entry getEmirateId() {
        return emirateId;
    }

    public Entry getCityId() {
        return cityId;
    }

    public Entry getAreaId() {
        return areaId;
    }

    public LocationType getLocationType() {
        return locationType;
    }

    public String getArrestLocation() {
        return arrestLocation;
    }

    public Section getSection() {
        return section;
    }

    public Department getDepartment() {
        return department;
    }

    public Entry getUnit() {
        return unit;
    }

    public ArrestReason getArrestReason() {
        return arrestReason;
    }

    public ArrestDescription getArrestDescription() {
        return arrestDescription;
    }

    public List<SeizureDto> getSeizureList() {
        return seizureList;
    }

    public List<ArrestNoteDto> getArrestNoteList() {
        return arrestNoteList;
    }

    public Entry getTransferredFromId() {
        return transferredFromId;
    }

    public Entry getShift() {
        return shift;
    }

    public boolean isUrgent() {
        return isUrgent;
    }

    public boolean isCreatedByAhwal() {
        return isCreatedByAhwal;
    }

    public Date getArrestDate() {
        return arrestDate;
    }

    public String getArrestTime() {
        return arrestTime;
    }

    public Set<AssociatedArrestReportKey> getAssociatedArrestList() {
        return associatedArrestList;
    }

    public Date getArrestDateTime() {
        return arrestDateTime;
    }

    public String getArrestBuilding() {
        return arrestBuilding;
    }

    public String getArrestStreet() {
        return arrestStreet;
    }

    public String getLocationDescription() {
        return locationDescription;
    }

    public List<ArrestTeamDto> getArrestTeamList() {
        return arrestTeamList;
    }

    public Entry getTerminalLocation() {
        return terminalLocation;
    }

    public List<ArrestPartyDto> getArrestPartyDtoList() {
        return arrestPartyDtoList;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public String getArrestNumber() {
        return arrestNumber;
    }


    public Entry getEntryExitInfo() {
        return entryExitInfo;
    }

    public static class Builder {

        private Date arrestDateTime;
        private List<PartyKey> partyList;
        private List<AttachmentReferenceKey> attachmentList;
        private Entry emirateId;
        private Entry cityId;
        private Entry areaId;
        private LocationType locationType;
        private String arrestLocation;
        private Section section;
        private Department department;
        private Entry unit;
        private ArrestReason arrestReason;
        private ArrestDescription arrestDescription;
        private List<SeizureDto> seizureList;
        private List<ArrestNoteDto> arrestNoteList;
        private Set<AssociatedArrestReportKey> associatedArrestList;
        private List<ArrestTeamDto> arrestTeamList;

        private Entry transferredFromId;
        private Entry shift;
        private boolean isUrgent;
        private boolean isCreatedByAhwal;
        private Date arrestDate;
        private String arrestTime;
        private String locationDescription;
        private String arrestBuilding;
        private String arrestStreet;
        private Entry terminalLocation;
        private List<ArrestPartyDto> arrestPartyDtoList;
        private String createdBy;
        private TrackerKey trackerKey;
        private String arrestNumber;

        private Entry entryExitInfo;

        public Builder(List<PartyKey> partyList, ArrestReason arrestReason,
                       ArrestDescription arrestDescription, Section section, Department department) {
            this.partyList = partyList;
            this.arrestReason = arrestReason;
            this.section = section;
            this.department = department;
            this.arrestDescription = arrestDescription;
        }

        public Builder withEmirate(Entry emiratesId) {
            this.emirateId = emiratesId;
            return this;
        }

        public Builder withTerminalLocation(Entry terminalLocation) {
            this.terminalLocation = terminalLocation;
            return this;
        }

        public Builder withCity(Entry cityId) {
            this.cityId = cityId;
            return this;
        }

        public Builder withArea(Entry areaId) {
            this.areaId = areaId;
            return this;
        }

        public Builder withArrestLocation(String location) {
            this.arrestLocation = location;
            return this;
        }

        public Builder withUnit(Entry unit) {
            this.unit = unit;
            return this;
        }

        public Builder withAttachmentList(List<AttachmentReferenceKey> attachments) {
            this.attachmentList = attachments;
            return this;
        }

        public Builder withSeizureList(List<SeizureDto> seizures) {
            this.seizureList = seizures;
            return this;
        }

        public Builder withArrestNoteList(List<ArrestNoteDto> arrestNotes) {
            this.arrestNoteList = arrestNotes;
            return this;
        }

        public Builder withAssociatedArrestList(Set<AssociatedArrestReportKey> associatedArrestList) {
            this.associatedArrestList = associatedArrestList;
            return this;
        }

        public Builder withArrestTeamList(List<ArrestTeamDto> arrestTeamList) {
            this.arrestTeamList = arrestTeamList;
            return this;
        }

        public Builder withShift(Entry shift) {
            this.shift = shift;
            return this;
        }

        public Builder withIsUrgent(boolean isUrgent) {
            this.isUrgent = isUrgent;
            return this;
        }

        public Builder withIsCreatedByAhwal(boolean isCreatedByAhwal) {
            this.isCreatedByAhwal = isCreatedByAhwal;
            return this;
        }

        public Builder withTransferredFrom(Entry transferredFromId) {
            this.transferredFromId = transferredFromId;
            return this;
        }

        public Builder withLocationType(LocationType locationType) {
            this.locationType = locationType;
            return this;
        }

        public Builder withArrestDate(Date arrestDate) {
            this.arrestDate = arrestDate;
            return this;
        }

        public Builder withArrestTime(String arrestTime) {
            this.arrestTime = arrestTime;
            return this;
        }

        public Builder withArrestDateTime(Date arrestDateTime) {
            this.arrestDateTime = arrestDateTime;
            return this;
        }

        public Builder withLocationDescription(String locationDescription) {
            this.locationDescription = locationDescription;
            return this;
        }

        public Builder withArrestBuilding(String arrestBuilding) {
            this.arrestBuilding = arrestBuilding;
            return this;
        }

        public Builder withArrestStreet(String arrestStreet) {
            this.arrestStreet = arrestStreet;
            return this;
        }

        public Builder withArrestPartyList(List<ArrestPartyDto> partyKeyList) {
            this.arrestPartyDtoList = partyKeyList;
            return this;
        }

        public Builder withCreatedBy(String createdBy) {
            this.createdBy = createdBy;
            return this;
        }

        public Builder withTrackerKey(TrackerKey trackerKey) {
            this.trackerKey = trackerKey;
            return this;
        }

        public Builder withArrestNumber(String arrestNumber) {
            this.arrestNumber = arrestNumber;
            return this;
        }
        public Builder withEntryExitInfo(Entry entryExitInfo) {
            this.entryExitInfo = entryExitInfo;
            return this;
        }


        public CreateArrestReportCommand build() {
            return new CreateArrestReportCommand(this);
        }
    }
}
