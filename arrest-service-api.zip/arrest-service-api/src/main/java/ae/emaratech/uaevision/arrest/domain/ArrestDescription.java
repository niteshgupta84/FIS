package ae.emaratech.uaevision.arrest.domain;

/**
 * Value object encapsulating the value of arrest report data
 *
 * @author Haroon.Subair
 */
public class ArrestDescription {

    private String value;

    public ArrestDescription(String arrestReportDescription) {
        this.value = arrestReportDescription;
    }

    public String getValue() {
        return value;
    }
}
