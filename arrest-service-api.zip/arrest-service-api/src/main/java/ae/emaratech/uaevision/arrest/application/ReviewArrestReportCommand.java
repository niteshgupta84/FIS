package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public class ReviewArrestReportCommand {

    private ArrestReportKey arrestReportKey;
    private String reviewComments;

    public ReviewArrestReportCommand(ArrestReportKey arrestReportKey, String reviewComments) {
        this.arrestReportKey = arrestReportKey;
        this.reviewComments = reviewComments;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public String getReviewComments() {
        return reviewComments;
    }
}
