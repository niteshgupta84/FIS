package ae.emaratech.uaevision.arrest.query;

import ae.emaratech.uaevision.arrest.application.ArrestPageBuilder;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.springframework.format.annotation.DateTimeFormat;

import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by Nitesh.Gupta on 6/13/2016.
 */
public class RetrieveArrestBySearchQuery implements Serializable{
    ArrestPageBuilder arrestPageBuilder;
    @DateTimeFormat(pattern = "MM/dd/yyyy")
    private Date arrestDate;
    @DateTimeFormat(pattern = "MM/dd/yyyy")
    private Date arrestDateTo;
    private String arrestTime;
    private String arrestTimeTo;
    @Nullable
    private Entry emirateLk;
    @Nullable
    private Entry areaLk;
    @Nullable
    private Entry cityLk;
    @Nullable
    private Entry terminalLocation;
    @Nullable
    private Entry department;
    @Nullable
    private Entry section;
    @Nullable
    private Entry sectionUnit;
    @Nullable
    private Entry arrestReason;
    @Nullable
    private Entry transferredFrom;
    @Nullable
    private Entry shift;
    private boolean urgent;
    private Entry status;
    private String createdBy;
    @DateTimeFormat(pattern = "MM/dd/yyyy")
    private Date createdDate;
    private String firNo;
    private Integer start;

    private Integer length;

    private Integer currentPage;
    private long totalRecord;

    private Boolean fetchDependencies = true;

    @Nullable
    private Entry partyStatus;

    private String arrestNumber;

    private String assignedUser;

    private String searchFrom;

    public Date getArrestDate() {
        return arrestDate;
    }

    public void setArrestDate(Date arrestDate) {
        this.arrestDate = arrestDate;
    }

    public String getArrestTime() {
        return arrestTime;
    }

    public void setArrestTime(String arrestTime) {
        this.arrestTime = arrestTime;
    }

    @Nullable
    public Entry getEmirateLk() {
        return emirateLk;
    }

    public void setEmirateLk(@Nullable Entry emirateLk) {
        this.emirateLk = emirateLk;
    }

    @Nullable
    public Entry getAreaLk() {
        return areaLk;
    }

    public void setAreaLk(@Nullable Entry areaLk) {
        this.areaLk = areaLk;
    }

    @Nullable
    public Entry getCityLk() {
        return cityLk;
    }

    public void setCityLk(@Nullable Entry cityLk) {
        this.cityLk = cityLk;
    }

    @Nullable
    public Entry getTerminalLocation() {
        return terminalLocation;
    }

    public void setTerminalLocation(@Nullable Entry terminalLocation) {
        this.terminalLocation = terminalLocation;
    }

    @Nullable
    public Entry getDepartment() {
        return department;
    }

    public void setDepartment(@Nullable Entry department) {
        this.department = department;
    }

    @Nullable
    public Entry getSection() {
        return section;
    }

    public void setSection(@Nullable Entry section) {
        this.section = section;
    }

    @Nullable
    public Entry getSectionUnit() {
        return sectionUnit;
    }

    public void setSectionUnit(@Nullable Entry sectionUnit) {
        this.sectionUnit = sectionUnit;
    }

    @Nullable
    public Entry getArrestReason() {
        return arrestReason;
    }

    public void setArrestReason(@Nullable Entry arrestReason) {
        this.arrestReason = arrestReason;
    }

    @Nullable
    public Entry getTransferredFrom() {
        return transferredFrom;
    }

    public void setTransferredFrom(@Nullable Entry transferredFrom) {
        this.transferredFrom = transferredFrom;
    }

    @Nullable
    public Entry getShift() {
        return shift;
    }

    public void setShift(@Nullable Entry shift) {
        this.shift = shift;
    }

    public boolean isUrgent() {
        return urgent;
    }

    public void setUrgent(boolean urgent) {
        this.urgent = urgent;
    }

    public Entry getStatus() {
        return status;
    }

    public void setStatus(Entry status) {
        this.status = status;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getFirNo() {
        return firNo;
    }

    public void setFirNo(String firNo) {
        this.firNo = firNo;
    }

    public String getArrestNumber() {
        return arrestNumber;
    }

    public void setArrestNumber(String arrestNumber) {
        this.arrestNumber = arrestNumber;
    }

    public Date getArrestDateTo() {
        return arrestDateTo;
    }

    public void setArrestDateTo(Date arrestDateTo) {
        this.arrestDateTo = arrestDateTo;
    }

    public String getArrestTimeTo() {
        return arrestTimeTo;
    }

    public void setArrestTimeTo(String arrestTimeTo) {
        this.arrestTimeTo = arrestTimeTo;
    }

    @Nullable
    public Entry getPartyStatus() {
        return partyStatus;
    }

    public void setPartyStatus(@Nullable Entry partyStatus) {
        this.partyStatus = partyStatus;
    }

    public String getAssignedUser() {
        return assignedUser;
    }

    public void setAssignedUser(String assignedUser) {
        this.assignedUser = assignedUser;
    }

    public ArrestPageBuilder getArrestPageBuilder() {
        return arrestPageBuilder;
    }

    public void setArrestPageBuilder(ArrestPageBuilder arrestPageBuilder) {
        this.arrestPageBuilder = arrestPageBuilder;
    }

    public Integer getLength() {
        return length;
    }

    public void setLength(Integer length) {
        this.length = length;
    }

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

    public Integer getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage;
    }

    public long getTotalRecord() {
        return totalRecord;
    }

    public void setTotalRecord(long totalRecord) {
        this.totalRecord = totalRecord;
    }

    public String getSearchFrom() {
        return searchFrom;
    }

    public void setSearchFrom(String searchFrom) {
        this.searchFrom = searchFrom;
    }

    public boolean fetchDependencies(){
        return this.fetchDependencies;
    }

    public RetrieveArrestBySearchQuery withFetchDependenciesFalse(){
        this.fetchDependencies = false;
        return this;
    }
}
