package ae.emaratech.uaevision.arrest.application.dto;

import ae.emaratech.uaevision.fis.common.dto.AbstractDtoBase;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@ApiModel(value = "Arrest Report Note Dto ")
public class ArrestNoteDto extends AbstractDtoBase implements Serializable {
    @ApiModelProperty(value = "Unique Case Note Id", required = true , dataType = "long")
    private long id;
    @ApiModelProperty(value = "Arrest Report Note Created By ", required = true, dataType = "string")
    private String createdBy;
    @ApiModelProperty(value = "Arrest Report Note Created on Date ", required = true, dataType = "date" )
    private Date createdDate;
    @ApiModelProperty(value = "Arrest Report View Id ", required = true, dataType = "long" )
    private long viewId;
    @ApiModelProperty(value = " Note Details", required = true, dataType = "string" )
    private String textNote;
    @ApiModelProperty(value = " Display Text for Notes", required = true, dataType = "string" )
    private String displayTextNote;
    @ApiModelProperty(value = "Sequence Number for display Purpose", required = true, dataType = "long" )
    private Long sequenceNo;
    @ApiModelProperty(value = "Current version of record to avoid concurrency", required = true, dataType = "long" )
    private Long version;
    @ApiModelProperty(value = " Arrest Report note Deleted or Note", required = true, dataType = "long", allowableValues = "1 or 0")
    private Long isDeleted;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public long getViewId() {
        return viewId;
    }

    public void setViewId(long viewId) {
        this.viewId = viewId;
    }

    public String getTextNote() {
        return textNote;
    }

    public void setTextNote(String textNote) {
        this.textNote = textNote;
    }

    public String getDisplayTextNote() {
        return displayTextNote;
    }

    public void setDisplayTextNote(String displayTextNote) {
        this.displayTextNote = displayTextNote;
    }

    public Long getSequenceNo() {
        return sequenceNo;
    }

    public void setSequenceNo(Long sequenceNo) {
        this.sequenceNo = sequenceNo;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public Long getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Long isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        ArrestNoteDto that = (ArrestNoteDto) o;

        if (id != that.id) return false;
        if (viewId != that.viewId) return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDate != null ? !createdDate.equals(that.createdDate) : that.createdDate != null) return false;
        if (displayTextNote != null ? !displayTextNote.equals(that.displayTextNote) : that.displayTextNote != null)
            return false;
        if (isDeleted != null ? !isDeleted.equals(that.isDeleted) : that.isDeleted != null) return false;
        if (sequenceNo != null ? !sequenceNo.equals(that.sequenceNo) : that.sequenceNo != null) return false;
        if (textNote != null ? !textNote.equals(that.textNote) : that.textNote != null) return false;
        if (version != null ? !version.equals(that.version) : that.version != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (int) (id ^ (id >>> 32));
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
        result = 31 * result + (int) (viewId ^ (viewId >>> 32));
        result = 31 * result + (textNote != null ? textNote.hashCode() : 0);
        result = 31 * result + (displayTextNote != null ? displayTextNote.hashCode() : 0);
        result = 31 * result + (sequenceNo != null ? sequenceNo.hashCode() : 0);
        result = 31 * result + (version != null ? version.hashCode() : 0);
        result = 31 * result + (isDeleted != null ? isDeleted.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ArrestNoteDto{" +
                "id=" + id +
                ", createdBy='" + createdBy + '\'' +
                ", createdDate=" + createdDate +
                ", viewId=" + viewId +
                ", textNote='" + textNote + '\'' +
                ", displayTextNote='" + displayTextNote + '\'' +
                ", sequenceNo=" + sequenceNo +
                ", version=" + version +
                ", isDeleted=" + isDeleted +
                '}';
    }
}
