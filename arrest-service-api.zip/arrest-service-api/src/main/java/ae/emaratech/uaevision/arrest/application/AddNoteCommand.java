package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.application.dto.ArrestNoteDto;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
public class AddNoteCommand {

    private String noteText;

    private List<ArrestNoteDto> arrestNoteDtoList = new ArrayList<>();

    public AddNoteCommand(String noteText) {
        this.noteText = noteText;
    }

    public AddNoteCommand withNoteList(List<ArrestNoteDto> arrestNoteDtoList) {
        this.arrestNoteDtoList = arrestNoteDtoList;
        return this;
    }

    public List<ArrestNoteDto> getArrestNoteDtoList() {
        return arrestNoteDtoList;
    }

    public String getNoteText() {
        return noteText;
    }
}
