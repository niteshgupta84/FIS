package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public class EndArrestReportCommand {
    private ArrestReportKey arrestReportKey;
    private String endComments;

    public EndArrestReportCommand(ArrestReportKey arrestReportKey, String endComments) {
        this.arrestReportKey = arrestReportKey;
        this.endComments = endComments;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public String getEndComments() {
        return endComments;
    }
}
