package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public class ApproveArrestReportCommand {
    private ArrestReportKey arrestReportKey;
    private String approvalComments;

    public ApproveArrestReportCommand(ArrestReportKey arrestReportKey, String approvalComments) {
        this.arrestReportKey = arrestReportKey;
        this.approvalComments = approvalComments;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public String getApprovalComments() {
        return approvalComments;
    }
}
