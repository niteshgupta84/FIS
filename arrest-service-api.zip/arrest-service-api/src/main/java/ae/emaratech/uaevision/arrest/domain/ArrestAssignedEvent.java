package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Event triggered when the arrest report is assigned to an officer for processing.
 *
 * @author Nitesh.Gupta
 */
public class ArrestAssignedEvent extends DomainEvent {

    private ArrestReportKey arrestReportKey;
    private String assignedUser;

    private ArrestAssignedEvent(Builder builder) {
        super(builder);
        this.arrestReportKey = builder.arrestReportKey;
        this.assignedUser = builder.assignedUser;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public String getAssignedUser() {
        return assignedUser;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private String assignedUser;

        public Builder(EventContext eventContext, ArrestReportKey arrestReportKey) {
            super(eventContext);
            this.arrestReportKey = arrestReportKey;
        }

        public Builder withAssignedUser(String assignedUser) {
            this.assignedUser = assignedUser;
            return this;
        }

        public ArrestAssignedEvent build() {
            return new ArrestAssignedEvent(this);
        }
    }
}
