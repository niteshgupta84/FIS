package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.application.dto.SeizureDto;
import ae.emaratech.uaevision.fis.common.key.SeizureKey;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
public class EditSeizureCommand {

    private SeizureKey seizureKey;
    private String seizedItem;
    private String itemCount;
    private List<SeizureDto> seizureDtoList = new ArrayList();

    public EditSeizureCommand(SeizureKey seizureKey, String seizedItem, String itemCount) {
        this.seizureKey = seizureKey;
        this.seizedItem = seizedItem;
        this.itemCount = itemCount;
    }

    public SeizureKey getSeizureKey() {
        return seizureKey;
    }

    public EditSeizureCommand withSeizureList(List<SeizureDto> seizureDtoList) {
        this.seizureDtoList = seizureDtoList;
        return this;
    }

    public List<SeizureDto> getSeizureDtoList() {
        return seizureDtoList;
    }

    public String getSeizedItem() {
        return seizedItem;
    }

    public String getItemCount() {
        return itemCount;
    }
}
