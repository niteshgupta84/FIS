package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public class ForwardArrestReportCommand {
    private ArrestReportKey arrestReportKey;
    private String forwardComments;

    public ForwardArrestReportCommand(ArrestReportKey arrestReportKey, String forwardComments) {
        this.arrestReportKey = arrestReportKey;
        this.forwardComments = forwardComments;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public String getForwardComments() {
        return forwardComments;
    }
}
