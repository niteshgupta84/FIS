package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.application.dto.ArrestNoteDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;
import ae.emaratech.uaevision.arrest.application.dto.CreateTransferArrestDto;
import ae.emaratech.uaevision.arrest.application.dto.SeizureDto;

import java.util.List;

/**
 * Application Service layer which defines the command operations performed by the Arrest Report
 * domain.
 *
 * @author Nitesh.Gupta, Haroon.Subair
 */
public interface ArrestReportApplicationService {

    /**
     * Method which creates the arrest report.
     *
     * @param command command object with information regarding the arrest.
     * @return result object with arrest key data
     */
    CreateArrestReportResult create(CreateArrestReportCommand command);

    /**
     * Method which updates the arrest report.
     *
     * @param command command object with information regarding the arrest.
     * @return result object with arrest key data
     */
    void update(UpdateArrestReportCommand command);

    /**
     * Method which marks the arrest activity as ready for review. The arrest will be submitted for
     * review by the supervisor.
     *
     * @param command the wrapper providing information to for submitting arrest for review by the
     *                supervisor.
     */
    void review(ReviewArrestReportCommand command);

    /**
     * Method which marks the arrest activity as ready for reject. The arrest will be submitted for
     * review by the supervisor.
     *
     * @param command the wrapper providing information to for submitting arrest for reject by the
     *                supervisor.
     */
    void reject(RejectArrestReportCommand command);

    /**
     * Method which marks the arrest activity as ready for approve. The arrest will be submitted for
     * review by the supervisor.
     *
     * @param command the wrapper providing information to for submitting arrest for approved by the
     *                supervisor.
     */
    void approve(ApproveArrestReportCommand command);

    /**
     * Method which marks the arrest activity as ready for end. The arrest will be submitted for
     * review by the supervisor.
     *
     * @param command the wrapper providing information to for submitting arrest for approved by the
     *                supervisor.
     */
    void end(EndArrestReportCommand command);

    /**
     * Method which marks the arrest activity as ready for end. The arrest will be submitted for
     * review by the supervisor.
     *
     * @param command the wrapper providing information to for submitting arrest for approved by the
     *                supervisor.
     */
    void forwardToCase(ForwardArrestReportCommand command);

    /**
     * Method which marks the arrest activity as ready for close. The arrest will be submitted for
     * review by the supervisor.
     *
     * @param command the wrapper providing information to for submitting arrest for close
     */
    void close(CloseArrestReportCommand command);

    /**
     * Method which marks the arrest activity as ready for close. The arrest will be submitted for
     * review by the supervisor.
     *
     * @param command the wrapper providing information to for submitting arrest for reopen
     */
    void reOpen(ReOpenArrestReportCommand command);

    /**
     * Method is to return List of Seizure after adding new Seizure DTO
     */
    List<SeizureDto> addSeizure(AddSeizureCommand command);

    List<SeizureDto> modifySeizure(EditSeizureCommand command);

    List<SeizureDto> removeSeizure(RemoveSeizureCommand command);

    List<ArrestTeamDto> addArrestTeam(AddArrestTeamCommand command);

    List<ArrestTeamDto> removeArrestTeam(DeleteArrestTeamCommand command);

    List<ArrestTeamDto> modifyArrestTeam(EditArrestTeamCommand command);

    List<ArrestNoteDto> addNote(AddNoteCommand command);

    List<ArrestNoteDto> modifyNote(EditNoteCommand command);

    List<ArrestNoteDto> removeNote(DeleteNoteCommand command);
    /**
     * Method which will assign arrest to given user
     * review by the supervisor.
     *
     * @param assignArrestCommand the wrapper providing information to for submitting arrest for assignement
     */
    void arrestAssignment(AssignArrestCommand assignArrestCommand);

    /**
     * Method which will create new Arrest by provided arrest id
     * review by the supervisor.
     *
     * @param command the wrapper providing information to for submitting arrest for transfer create
     */
    CreateArrestReportResult createTransferredArrest(CreateTransferArrestDto command);
}
