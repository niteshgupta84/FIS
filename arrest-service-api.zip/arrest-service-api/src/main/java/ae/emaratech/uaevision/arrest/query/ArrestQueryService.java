package ae.emaratech.uaevision.arrest.query;

import ae.emaratech.uaevision.arrest.application.ArrestPageBuilder;
import ae.emaratech.uaevision.arrest.application.dto.*;
import ae.emaratech.uaevision.document.application.AttachedDocumentDto;
import ae.emaratech.uaevision.fis.common.notification.Notification;
import ae.emaratech.uaevision.fis.workassignment.service.dto.EmployeeInfoDto;

import java.util.List;


/**
 * Query Service layer which defines the query operations performed by the Query domain.
 *
 * @author Nitesh.Gupta
 */
public interface ArrestQueryService {

    /**
     * Method which retrieves the history records for the interrogation.
     *
     * @param retrieveArrestHistoryQuery the query object for retrieving arrest history details.
     * @return list of ArrestReportTrackDto information detailing the history of Arrest.
     */
    List<ArrestReportTrackDto> retrieveArrestHistory(
            RetrieveArrestHistoryQuery retrieveArrestHistoryQuery);

    /**
     * Method which retrieves the employee details for the arrest team
     *
     * @param retrieveArrestTeamByEmployee the query object with the employee id
     */
    List<ArrestTeamDto> retrieveArrestTeam(
            RetrieveArrestTeamByEmployeeIdQuery retrieveArrestTeamByEmployee);

    /**
     * Method which will retrieve  arrest based on Key  Given
     *
     * @return
     */
    ArrestReportDto retrieveArrestReport(RetrieveArrestQuery retrieveArrestQuery);

    /**
     * Method which will retrieve all arrest based on Criteria Given
     *
     * @param criterias
     * @param query
     * @return
     */
    ArrestPageBuilder findIncidentsByCriteria(ArrestPageBuilder criterias,
                                              RetrieveArrestBySearchQuery query);

    /**
     * Method is to retrieve Arrest By Given Search Criteria
     *
     * @param retrieveArrestBySearchQuery
     * @return
     */
    ArrestPageBuilder retrieveArrestBySearchCriteria(
            RetrieveArrestBySearchQuery retrieveArrestBySearchQuery);

    /**
     * Returning Arrest Page builder with Arrest Created by Current User
     *
     * @param retrieveArrestsWithOwnerDetailQuery
     * @return
     */
    ArrestPageBuilder retrieveArrestsCreatedByUser(
            RetrieveArrestsWithOwnerDetailQuery retrieveArrestsWithOwnerDetailQuery);

    /**
     * retrieving arrest Assigned to perticular user
     *
     * @param retrieveArrestsWithOwnerDetailQuery
     * @return
     */
    ArrestPageBuilder retrieveArrestsAssignedToUser(
            RetrieveArrestsWithOwnerDetailQuery retrieveArrestsWithOwnerDetailQuery);

    /**
     * Retrieving Arrest Report for Given Party
     *
     * @param arrestQuery
     * @return
     */
    ArrestReportDto retrieveArrestReportForParty(RetrieveArrestForPartyQuery arrestQuery);

    /**
     * Listing all employees info
     *
     * @return
     */
    public List<EmployeeInfoDto> getAllEmployees();



    Notification validateActiveArrestForParty(
            ValidateActiveArrestForPartyQuery validateActiveArrestForPartyQuery);

    /**
     * Method to retrieve Notes for Arrest
     *
     * @param retrieveArrestQuery
     * @return
     */
    List<ArrestNoteDto> retrieveNotesForArrest(RetrieveArrestQuery retrieveArrestQuery);

    /**
     * Method to retrieve Attachments for Arrest
     *
     * @param retrieveArrestQuery
     * @return
     */
    List<AttachedDocumentDto> retrieveAttachmentsForArrest(RetrieveArrestQuery retrieveArrestQuery);

    /**
     * Method to retrieve Association for Arrest
     *
     * @param retrieveArrestQuery
     * @return
     */
    List<ArrestAssociationDto> retrieveAssociationsForArrest(RetrieveArrestQuery retrieveArrestQuery);

    /**
     * Method to retreive Seizures for Arrest
     *
     * @param retrieveArrestQuery
     * @return
     */
    List<SeizureDto> retrieveSeizuresForArrest(RetrieveArrestQuery retrieveArrestQuery);

    /**
     * Method to retreive arrest Teams  for Arrest
     *
     * @param retrieveArrestQuery
     * @return
     */
    List<ArrestTeamDto> retrieveArrestTeamsForArrest(RetrieveArrestQuery retrieveArrestQuery);

    ArrestPageBuilder retrieveForwardedArrestBySearchCriteria(RetrieveArrestBySearchQuery query);


}
