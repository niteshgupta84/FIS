package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Event triggered when the arrest report is marked as closed.
 *
 * @author Haroon.Subair
 */
public class ArrestReportClosedEvent extends DomainEvent {

    private ArrestReportKey arrestReportKey;
    private Long status;
    private String closeComments;

    private ArrestReportClosedEvent(Builder builder) {
        super(builder);
        this.arrestReportKey = builder.arrestReportKey;
        this.status = builder.statusId;
        this.closeComments = builder.closeComments;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public Long getStatus() {
        return status;
    }

    public String getCloseComments() {
        return closeComments;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private Long statusId;
        private String closeComments;

        public Builder(EventContext eventContext, ArrestReportKey arrestReportKey) {
            super(eventContext);
            this.arrestReportKey = arrestReportKey;
        }

        public Builder withArrestStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withCloseComments(String closeComments) {
            this.closeComments = closeComments;
            return this;
        }

        public ArrestReportClosedEvent build() {
            return new ArrestReportClosedEvent(this);
        }
    }
}
