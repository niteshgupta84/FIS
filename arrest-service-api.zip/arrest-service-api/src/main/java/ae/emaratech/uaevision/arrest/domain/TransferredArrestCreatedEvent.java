package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;


/**
 * Case Cloned Event
 * Created by Nitesh.Gupta on 3/20/2017.
 */
public class TransferredArrestCreatedEvent extends DomainEvent{

    private ArrestReportKey oldArrestReportKey;
    private ArrestReportKey arrestReportKey;
    private Long departmentId;
    private Long sectionId;
    private String arrestNumber;
    private String arrestParties;
    private TransferredArrestCreatedEvent(Builder builder) {
        super(builder);
        this.arrestReportKey = builder.arrestReportKey;
        this.departmentId = builder.departmentId;
        this.sectionId = builder.sectionId;
        this.arrestNumber = builder.arrestNumber;
        this.oldArrestReportKey = builder.oldArrestReportKey;

    }

    public ArrestReportKey getOldArrestReportKey() {
        return oldArrestReportKey;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public Long getSectionId() {
        return sectionId;
    }

    public String getArrestNumber() {
        return arrestNumber;
    }
    public void withArrestPartiesJson(String arrestPartyListJson) {
        this.arrestParties = arrestPartyListJson;
    }

    public String getArrestParties() {
        return arrestParties;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private Long departmentId;
        private Long sectionId;
        private ArrestReportKey oldArrestReportKey;
        private String arrestNumber;

        public Builder(EventContext eventContext, ArrestReportKey arrestReportKey, String arrestNumber) {
            super(eventContext);
            this.arrestReportKey = arrestReportKey;
            this.arrestNumber = arrestNumber;
        }
        public Builder withDepartment(Long department) {
            this.departmentId = department;
            return this;
        }
        public Builder withSection(Long sectionId) {
            this.sectionId = sectionId;
            return this;
        }
        public Builder withOldArrestKey(ArrestReportKey oldArrestReportKey) {
            this.oldArrestReportKey = oldArrestReportKey;
            return this;
        }
        public TransferredArrestCreatedEvent build() {
            return new TransferredArrestCreatedEvent(this);
        }
    }
}
