package ae.emaratech.uaevision.arrest.query;

import ae.emaratech.uaevision.fis.common.key.PartyKey;

import java.io.Serializable;

/**
 * Created by Nitesh.Gupta on 6/14/2016.
 */
public class RetrieveArrestForPartyQuery implements Serializable {

    private PartyKey partyKey;

    public RetrieveArrestForPartyQuery(PartyKey partyKey) {
        this.partyKey = partyKey;
    }

    public PartyKey getPartyKey() {
        return partyKey;
    }
}
