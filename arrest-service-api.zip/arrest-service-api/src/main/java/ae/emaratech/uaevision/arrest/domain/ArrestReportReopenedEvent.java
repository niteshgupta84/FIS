package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.OrderKey;

/**
 * Event triggered when the arrest report is re-opened for further processing.
 *
 * @author Haroon.Subair
 */
public class ArrestReportReopenedEvent extends DomainEvent {

    private ArrestReportKey arrestReportKey;
    private Long status;
    private OrderKey orderKey;

    private ArrestReportReopenedEvent(Builder builder) {
        super(builder);
        this.arrestReportKey = builder.arrestReportKey;
        this.status = builder.statusId;
        this.orderKey = builder.orderKey;

    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public Long getStatus() {
        return status;
    }

    public OrderKey getOrderKey() {
        return orderKey;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private Long statusId;
        private OrderKey orderKey;

        public Builder(EventContext eventContext,
                       ArrestReportKey arrestReportKey, OrderKey orderKey) {
            super(eventContext);
            this.arrestReportKey = arrestReportKey;
            this.orderKey = orderKey;
        }

        public Builder withArrestStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public ArrestReportReopenedEvent build() {
            return new ArrestReportReopenedEvent(this);
        }
    }
}
