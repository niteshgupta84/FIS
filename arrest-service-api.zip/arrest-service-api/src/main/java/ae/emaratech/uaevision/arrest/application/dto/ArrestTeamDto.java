package ae.emaratech.uaevision.arrest.application.dto;

import ae.emaratech.uaevision.fis.common.dto.AbstractDtoBase;
import ae.emaratech.uaevision.fis.user.service.dto.UserShiftDetail;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 11/26/2015.
 */
@ApiModel(value="Arrest Team Dto ")
public class ArrestTeamDto extends AbstractDtoBase implements Serializable {
    @ApiModelProperty(value = "Unique Arreat Team Id ", required = true , dataType = "long")
    private long arrestTeamId;
    @ApiModelProperty(value = "Unique Id ", required = true , dataType = "long")
    private long id;
    @ApiModelProperty(value = "Sequence No", required = true , dataType = "long")
    private long sequenceNo;
    @ApiModelProperty(value = "Employee ID ", required = true , dataType = "string")
    private String employeeId;
    @ApiModelProperty(value = "Officer Name in English", required = true , dataType = "string")
    private String officerName;
    @ApiModelProperty(value = "Officer Name in Arabic ", required = true , dataType = "string")
    private String officerNameAr;
    @ApiModelProperty(value = "User Login ", required = true , dataType = "string")
    private String userLogin;
    @ApiModelProperty(value = "Version ", required = true , dataType = "long")
    private Long version;
    @ApiModelProperty(value = "Created By", required = true , dataType = "string")
    private String createdBy;
    @ApiModelProperty(value = "Created Date  ", required = true , dataType = "Date (MM/DD/YYYY)")
    private Date createdDate;
    @ApiModelProperty(value = "Rank in English", required = true , dataType = "string")
    private String rankEn;
    @ApiModelProperty(value = "Rank in Arabic", required = true , dataType = "string")
    private String rankAr;
    @ApiModelProperty(value = "User Shift Detail", required = true , dataType = "object")
    private UserShiftDetail userShiftDetail;
    @ApiModelProperty(value = "Is Deleted ", required = true , dataType = "long")
    private Long isDeleted;
    @ApiModelProperty(value = "Display String", required = true , dataType = "string")
    private String displayString;

    @ApiModelProperty(value = "List of Employee Ids", required = true , dataType = "object")
    private List<String> employeeIds;

    public long getArrestTeamId() {
        return arrestTeamId;
    }

    public void setArrestTeamId(long arrestTeamId) {
        this.arrestTeamId = arrestTeamId;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getOfficerName() {
        return officerName;
    }

    public void setOfficerName(String officerName) {
        this.officerName = officerName;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getSequenceNo() {
        return sequenceNo;
    }

    public void setSequenceNo(long sequenceNo) {
        this.sequenceNo = sequenceNo;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getOfficerNameAr() {
        return officerNameAr;
    }

    public void setOfficerNameAr(String officerNameAr) {
        this.officerNameAr = officerNameAr;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }

    public String getRankEn() {
        return rankEn;
    }

    public void setRankEn(String rankEn) {
        this.rankEn = rankEn;
    }

    public String getRankAr() {
        return rankAr;
    }

    public void setRankAr(String rankAr) {
        this.rankAr = rankAr;
    }

    public Long getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Long isDeleted) {
        this.isDeleted = isDeleted;
    }

    public UserShiftDetail getUserShiftDetail() {
        return userShiftDetail;
    }

    public void setUserShiftDetail(UserShiftDetail userShiftDetail) {
        this.userShiftDetail = userShiftDetail;
    }

    public void generateDisplayString(){
        this.displayString = this.userLogin + "-" + this.officerNameAr + "-" + this.officerName;
    }

    public String getDisplayString() {
        return displayString;
    }

    public void setDisplayString(String displayString) {
        this.displayString = displayString;
    }

    public List<String> getEmployeeIds() {
        return employeeIds;
    }

    public void setEmployeeIds(List<String> employeeIds) {
        this.employeeIds = employeeIds;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        ArrestTeamDto that = (ArrestTeamDto) o;

        if (arrestTeamId != that.arrestTeamId) return false;
        if (id != that.id) return false;
        if (sequenceNo != that.sequenceNo) return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDate != null ? !createdDate.equals(that.createdDate) : that.createdDate != null) return false;
        if (displayString != null ? !displayString.equals(that.displayString) : that.displayString != null)
            return false;
        if (employeeId != null ? !employeeId.equals(that.employeeId) : that.employeeId != null) return false;
        if (employeeIds != null ? !employeeIds.equals(that.employeeIds) : that.employeeIds != null) return false;
        if (isDeleted != null ? !isDeleted.equals(that.isDeleted) : that.isDeleted != null) return false;
        if (officerName != null ? !officerName.equals(that.officerName) : that.officerName != null) return false;
        if (officerNameAr != null ? !officerNameAr.equals(that.officerNameAr) : that.officerNameAr != null)
            return false;
        if (rankAr != null ? !rankAr.equals(that.rankAr) : that.rankAr != null) return false;
        if (rankEn != null ? !rankEn.equals(that.rankEn) : that.rankEn != null) return false;
        if (userLogin != null ? !userLogin.equals(that.userLogin) : that.userLogin != null) return false;
        if (userShiftDetail != null ? !userShiftDetail.equals(that.userShiftDetail) : that.userShiftDetail != null)
            return false;
        if (version != null ? !version.equals(that.version) : that.version != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (int) (arrestTeamId ^ (arrestTeamId >>> 32));
        result = 31 * result + (int) (id ^ (id >>> 32));
        result = 31 * result + (int) (sequenceNo ^ (sequenceNo >>> 32));
        result = 31 * result + (employeeId != null ? employeeId.hashCode() : 0);
        result = 31 * result + (officerName != null ? officerName.hashCode() : 0);
        result = 31 * result + (officerNameAr != null ? officerNameAr.hashCode() : 0);
        result = 31 * result + (userLogin != null ? userLogin.hashCode() : 0);
        result = 31 * result + (version != null ? version.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
        result = 31 * result + (rankEn != null ? rankEn.hashCode() : 0);
        result = 31 * result + (rankAr != null ? rankAr.hashCode() : 0);
        result = 31 * result + (userShiftDetail != null ? userShiftDetail.hashCode() : 0);
        result = 31 * result + (isDeleted != null ? isDeleted.hashCode() : 0);
        result = 31 * result + (displayString != null ? displayString.hashCode() : 0);
        result = 31 * result + (employeeIds != null ? employeeIds.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ArrestTeamDto{" +
                "arrestTeamId=" + arrestTeamId +
                ", id=" + id +
                ", sequenceNo=" + sequenceNo +
                ", employeeId='" + employeeId + '\'' +
                ", officerName='" + officerName + '\'' +
                ", officerNameAr='" + officerNameAr + '\'' +
                ", userLogin='" + userLogin + '\'' +
                ", version=" + version +
                ", createdBy='" + createdBy + '\'' +
                ", createdDate=" + createdDate +
                ", rankEn='" + rankEn + '\'' +
                ", rankAr='" + rankAr + '\'' +
                ", userShiftDetail=" + userShiftDetail +
                ", isDeleted=" + isDeleted +
                ", displayString='" + displayString + '\'' +
                ", employeeIds=" + employeeIds +
                '}';
    }
}
