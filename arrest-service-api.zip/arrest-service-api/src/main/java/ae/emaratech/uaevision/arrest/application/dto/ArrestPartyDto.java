package ae.emaratech.uaevision.arrest.application.dto;

import ae.emaratech.uaevision.lookup.service.model.Entry;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@ApiModel(value = "Arrest Party Dto")
public class ArrestPartyDto implements Serializable {
    @ApiModelProperty(value = "Unique Case Party Id", required = true , dataType = "long")
    private Long id;
    @ApiModelProperty(value = "Arrest Report Id", required = true , dataType = "long")
    private Long arrestReportId;
    @ApiModelProperty(value = "Party Id", required = true , dataType = "long")
    private Long partyId;
    @ApiModelProperty(value = " Arrest Report note Deleted or Note", required = true, dataType = "long", allowableValues = "1 or 0")
    private Long isDeleted;
    @ApiModelProperty(value = "Arrest Party Created By ", required = true, dataType = "string")
    private String createdBy;
    @ApiModelProperty(value = "Arrest Party Created on Date ", required = true, dataType = "Date" )
    private Date createdDate;
    @ApiModelProperty(value = "Arrest Party Type ", required = true, dataType = "object" )
    private Entry partyType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getArrestReportId() {
        return arrestReportId;
    }

    public void setArrestReportId(Long arrestReportId) {
        this.arrestReportId = arrestReportId;
    }

    public Long getPartyId() {
        return partyId;
    }

    public void setPartyId(Long partyId) {
        this.partyId = partyId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Long getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Long isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Entry getPartyType() {
        return partyType;
    }

    public void setPartyType(Entry partyType) {
        this.partyType = partyType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ArrestPartyDto that = (ArrestPartyDto) o;

        if (arrestReportId != null ? !arrestReportId.equals(that.arrestReportId) : that.arrestReportId != null)
            return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDate != null ? !createdDate.equals(that.createdDate) : that.createdDate != null) return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (isDeleted != null ? !isDeleted.equals(that.isDeleted) : that.isDeleted != null) return false;
        if (partyId != null ? !partyId.equals(that.partyId) : that.partyId != null) return false;
        if (partyType != null ? !partyType.equals(that.partyType) : that.partyType != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (arrestReportId != null ? arrestReportId.hashCode() : 0);
        result = 31 * result + (partyId != null ? partyId.hashCode() : 0);
        result = 31 * result + (isDeleted != null ? isDeleted.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
        result = 31 * result + (partyType != null ? partyType.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ArrestPartyDto{" +
                "id=" + id +
                ", arrestReportId=" + arrestReportId +
                ", partyId=" + partyId +
                ", isDeleted=" + isDeleted +
                ", createdBy='" + createdBy + '\'' +
                ", createdDate=" + createdDate +
                ", partyType=" + partyType +
                '}';
    }
}
