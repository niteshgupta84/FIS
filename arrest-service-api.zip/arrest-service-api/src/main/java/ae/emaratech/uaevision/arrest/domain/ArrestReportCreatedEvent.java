package ae.emaratech.uaevision.arrest.domain;

import java.util.Date;
import java.util.List;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

/**
 * Event triggered by the arrest report module on create operation.
 *
 * @author Haroon.Subair
 */
public class ArrestReportCreatedEvent extends DomainEvent {

    private ArrestReportKey arrestReportKey;
    private Long arrestReason;
    private Long transferredFrom;
    private Date arrestDateTime;
    private String reportDescription;
    private Long isCreatedByAhwal;
    private Long status;
    private String arrestLocation;
    private String arrestParties;
    private List<Long> attachments;
    private List<Long> notes;
    private List<Long> seizures;
    private List<Long> arrestAssociations;
    private List<String> arrestTeams;
    private String arrestNumber;
    private Long entryExitId;

    public ArrestReportCreatedEvent(Builder builder) {
        super(builder);
        this.arrestReportKey = builder.arrestReportKey;
        this.attachments = builder.attachments;
        this.arrestLocation = builder.arrestLocation;
        this.reportDescription = builder.reportDescription;
        this.status = builder.statusId;
        this.transferredFrom = builder.transferredFromDeptId;
        this.notes = builder.notes;
        this.seizures = builder.seizures;
        this.arrestAssociations = builder.arrestAssociations;
        this.arrestTeams = builder.arrestTeams;
        this.arrestReason = builder.arrestReasonId;
        this.arrestDateTime = builder.arrestDateTime;
        this.isCreatedByAhwal = builder.isCreatedByAhwal;
        this.transferredFrom = builder.transferredFromDeptId;
        this.arrestNumber = builder.arrestNumber;
        this.entryExitId = builder.entryExitId;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public List<Long> getAttachments() {
        return attachments;
    }

    public String getArrestLocation() {
        return arrestLocation;
    }

    public String getReportDescription() {
        return reportDescription;
    }

    public Long getStatus() {
        return status;
    }

    public Long getArrestReason() {
        return arrestReason;
    }

    public Long getTransferredFrom() {
        return transferredFrom;
    }

    public Date getArrestDatetime() {
        return arrestDateTime;
    }

    public Long getIsCreatedByAhwal() {
        return isCreatedByAhwal;
    }

    public List<Long> getNotes() {
        return notes;
    }

    public List<Long> getSeizures() {
        return seizures;
    }

    public List<Long> getArrestAssociations() {
        return arrestAssociations;
    }

    public List<String> getArrestTeams() {
        return arrestTeams;
    }

    public void withArrestPartiesJson(String arrestPartyListJson) {
        this.arrestParties = arrestPartyListJson;
    }

    public String getArrestParties() {
        return arrestParties;
    }

    public String getArrestNumber() {
        return arrestNumber;
    }

    public Long getEntryExitId() {
        return entryExitId;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private Long arrestReasonId;
        private Long transferredFromDeptId;
        private Date arrestDateTime;
        private String reportDescription;
        private Long isCreatedByAhwal;
        private Long statusId;
        private String arrestLocation;
        private List<Long> attachments;
        private List<Long> notes;
        private List<Long> seizures;
        private List<Long> arrestAssociations;
        private List<String> arrestTeams;
        private String arrestNumber;
        private Long entryExitId;

        public Builder(EventContext eventContext,
                       ArrestReportKey arrestReportKey, ArrestReason arrestReason,
                       String reportDescription) {
            super(eventContext);
            this.arrestReasonId = arrestReason.id();
            this.arrestReportKey = arrestReportKey;
            this.reportDescription = reportDescription;
        }

        public Builder withArrestLocation(String arrestLocation) {
            this.arrestLocation = arrestLocation;
            return this;
        }

        public Builder withNotes(List<Long> notesList) {
            this.notes = notesList;
            return this;
        }

        public Builder withSeizures(List<Long> seizureList) {
            this.seizures = seizureList;
            return this;
        }

        public Builder withAttachments(List<Long> arrestedReportAttachments) {

            this.attachments = arrestedReportAttachments;
            return this;
        }

        public Builder withArrestAssociations(List<Long> arrestAssociations) {
            this.arrestAssociations = arrestAssociations;
            return this;
        }

        public Builder withArrestTeams(List<String> arrestTeams) {
            this.arrestTeams = arrestTeams;
            return this;
        }

        public Builder withStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withIsCreatedByAhwal(Long isCreatedByAhwal) {
            this.isCreatedByAhwal = isCreatedByAhwal;
            return this;
        }

        public Builder withArrestDateTime(Date arrestDateTime) {
            this.arrestDateTime = arrestDateTime;
            return this;
        }

        public Builder withTransferredFrom(Long transferredFromDeptId) {
            this.transferredFromDeptId = transferredFromDeptId;
            return this;
        }

        public Builder withArrestNumber(String arrestNumber) {
            this.arrestNumber = arrestNumber;
            return this;
        }

        public Builder withEntryExitId(Long entryExitId) {
            this.entryExitId = entryExitId;
            return this;
        }

        public ArrestReportCreatedEvent build() {
            return new ArrestReportCreatedEvent(this);
        }
    }
}
