package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.application.dto.ArrestNoteDto;
import ae.emaratech.uaevision.fis.common.key.NoteKey;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
public class DeleteNoteCommand {

    private NoteKey noteKey;
    private List<ArrestNoteDto> arrestNoteDtoList = new ArrayList<>();


    public DeleteNoteCommand(NoteKey noteKey) {
        this.noteKey = noteKey;
    }

    public DeleteNoteCommand withNoteList(List<ArrestNoteDto> arrestNoteDtoList) {
        this.arrestNoteDtoList = arrestNoteDtoList;
        return this;
    }

    public NoteKey getNoteKey() {
        return noteKey;
    }

    public List<ArrestNoteDto> getArrestNoteDtoList() {
        return arrestNoteDtoList;
    }
}
