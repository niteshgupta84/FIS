package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.OrderKey;

/**
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public class ReOpenArrestReportCommand {
    private ArrestReportKey arrestReportKey;

    private OrderKey orderKey;

    public ReOpenArrestReportCommand(ArrestReportKey arrestReportKey) {
        this.arrestReportKey = arrestReportKey;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public OrderKey getOrderKey() {
        return orderKey;
    }

    public ReOpenArrestReportCommand forOrder(OrderKey orderKey) {
        this.orderKey = orderKey;
        return this;
    }
}
