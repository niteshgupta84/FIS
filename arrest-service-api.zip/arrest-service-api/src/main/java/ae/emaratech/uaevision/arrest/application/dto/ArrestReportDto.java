package ae.emaratech.uaevision.arrest.application.dto;

import ae.emaratech.uaevision.document.application.AttachedDocumentDto;
import ae.emaratech.uaevision.fis.common.dto.AbstractDtoBase;
import ae.emaratech.uaevision.fis.common.lock.Lockable;
import ae.emaratech.uaevision.fis.common.lock.LockableEntityName;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.format.annotation.DateTimeFormat;

import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * Arrest Report Dto which will hold all information related to Arrest
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@ApiModel(value = "Arrest Report Dto ")
public class ArrestReportDto extends AbstractDtoBase implements Serializable, Lockable {
    @ApiModelProperty(value = "Unique Arrest Report Id", required = true)
    private Long id;
    @ApiModelProperty(value = "Arrest Date ", required = true, dataType = "date")
    @NotNull(message = "incident.arrestReport.warn.arrestDate.notNull")
    @DateTimeFormat(pattern = "MM/dd/yyyy")
    private Date arrestDate;
    @ApiModelProperty(value = "Arrest Location", required = true)
    private String arrestLocation;
    @Nullable
    @ApiModelProperty(value = "Location Type ", required = true , dataType = "object")
    private Entry locType;
    @ApiModelProperty(value = "Arrest Report Description ", required = true , dataType = "string")
    private String arrestReportDescription;
    @ApiModelProperty(value = "Arrest Time ", required = true , dataType = "string")
    private String arrestTime;
    @ApiModelProperty(value = "Building ", required = true , dataType = "string")
    private String building;
    @ApiModelProperty(value = "Emirate Selected", required = true , dataType = "object")
    @Nullable
    private Entry emirateLk;
    @ApiModelProperty(value = "Area Selected ", required = true , dataType = "object")
    @Nullable
    private Entry areaLk;
    @ApiModelProperty(value = "City Type ", required = true , dataType = "object")
    @Nullable
    private Entry cityLk;
    @ApiModelProperty(value = "Street", required = true , dataType = "object")
    private String street;
    @ApiModelProperty(value = "Location Description ", required = true , dataType = "string")
    private String locationDescription;
    @ApiModelProperty(value = "Version of Case for handling concurrency", required = true )
    private Long version;
    @ApiModelProperty(value = "Terminal Location", required = true , dataType = "object")
    @Nullable
    private Entry terminalLocation;
    @ApiModelProperty(value = "Department of Arrest Creation", required = true , dataType = "object")
    @Nullable
    private Entry department;
    @ApiModelProperty(value = "Section of Arrest Creation", required = true , dataType = "object")
    @Nullable
    private Entry section;
    @ApiModelProperty(value = "Section unit Arrest Creation ", required = true , dataType = "object")
    @Nullable
    private Entry sectionUnit;
    @ApiModelProperty(value = "Arrest Reason of Arrest", required = true , dataType = "object")
    @Nullable
    private Entry arrestReason;
    @ApiModelProperty(value = "Transferred From", required = true , dataType = "object")
    @Nullable
    private Entry transferredFrom;
    @ApiModelProperty(value = "Shift Selected", required = true , dataType = "object")
    @Nullable
    private Entry shift;
    @ApiModelProperty(value = "Arrest is urgent or not  ", required = true , dataType = "object", allowableValues = "1 or 0")
    private boolean urgent;
    @ApiModelProperty(value = "Arrest Status", required = true , dataType = "boolean")
    private Entry status;
    @ApiModelProperty(value = "Last Action Taken ", required = true , dataType = "object")
    @Nullable
    private Entry lastAction;
    @ApiModelProperty(value = "Arrest Report Number", required = true , dataType = "string")
    private String arrestReportNumber;
    @ApiModelProperty(value = "Created By", required = true , dataType = "string")
    private String createdBy;
    @ApiModelProperty(value = "Created Date", required = true , dataType = "date")
    private Date createdDate;
    @ApiModelProperty(value = "Fir Number", required = true , dataType = "string")
    private String firNo;
    @ApiModelProperty(value = "Created By Ahwal officer ", required = true , dataType = "boolean", allowableValues = "true or false")
    private boolean isCreatedByAhwal;
    @ApiModelProperty(value = "Arrest Urgency", required = true , dataType = "string")
    private String urgentString;
    @ApiModelProperty(value = "Assigned User", required = true , dataType = "string")
    private String assignedUser;
    @ApiModelProperty(value = "Arrest Team List", required = false , dataType = "object")
    private List<ArrestTeamDto> arrestTeamList = null;
    @ApiModelProperty(value = "Seizure List", required = false , dataType = "object")
    private List<SeizureDto> seizureDtoList = null;
    @ApiModelProperty(value = "Arrest Association List", required = false , dataType = "object")
    private List<ArrestAssociationDto> arrestAssociationDtoList = new ArrayList<>();
    @ApiModelProperty(value = "Arrest Note List", required = false , dataType = "object")
    private List<ArrestNoteDto> arrestNoteDtoList = null;
    @ApiModelProperty(value = "Arrest Track List", required = false , dataType = "object")
    private List<ArrestReportTrackDto> arrestReportTrackDtoList = new ArrayList<>();
    @ApiModelProperty(value = "Arrest Party List", required = true , dataType = "object")
    private List<ArrestPartyDto> arrestPartyDtoList = new LinkedList<>();
    @ApiModelProperty(value = "Attached Document List", required = false , dataType = "object")
    private List<AttachedDocumentDto> arrestAttachmentDtoList = null;
    @ApiModelProperty(value = "Arrest Number", required = true , dataType = "string")
    private String arrestNumber;
    @ApiModelProperty(value = "Entry Exit Selected", required = true , dataType = "object")
    @Nullable
    private Entry entryExit;


    public Date getArrestDate() {
        return arrestDate;
    }

    public void setArrestDate(Date arrestDate) {
        this.arrestDate = arrestDate;
    }

    public String getArrestLocation() {
        return arrestLocation;
    }

    public void setArrestLocation(String arrestLocation) {
        this.arrestLocation = arrestLocation;
    }

    public String getArrestReportDescription() {
        return arrestReportDescription;
    }

    public void setArrestReportDescription(String arrestReportDescription) {
        this.arrestReportDescription = arrestReportDescription;
    }


    public String getArrestTime() {
        return arrestTime;
    }

    public void setArrestTime(String arrestTime) {
        this.arrestTime = arrestTime;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public List<ArrestTeamDto> getArrestTeamList() {
        return arrestTeamList;
    }

    public void setArrestTeamList(List<ArrestTeamDto> arrestTeamList) {
        this.arrestTeamList = arrestTeamList;
    }

    public List<SeizureDto> getSeizureDtoList() {
        return seizureDtoList;
    }

    public void setSeizureDtoList(List<SeizureDto> seizureDtoList) {
        this.seizureDtoList = seizureDtoList;
    }

    public Entry getEmirateLk() {
        return emirateLk;
    }

    public void setEmirateLk(Entry emirateLk) {
        this.emirateLk = emirateLk;
    }

    public Entry getAreaLk() {
        return areaLk;
    }

    public void setAreaLk(Entry areaLk) {
        this.areaLk = areaLk;
    }

    public String getLocationDescription() {
        return locationDescription;
    }

    public void setLocationDescription(String locationDescription) {
        this.locationDescription = locationDescription;
    }

    public Entry getCityLk() {
        return cityLk;
    }

    public void setCityLk(Entry cityLk) {
        this.cityLk = cityLk;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    @Nullable
    public Entry getLocType() {
        return locType;
    }

    public void setLocType(@Nullable Entry locType) {
        this.locType = locType;
    }

    @Nullable
    public Entry getTerminalLocation() {
        return terminalLocation;
    }

    public void setTerminalLocation(Entry terminalLocation) {
        this.terminalLocation = terminalLocation;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<ArrestAssociationDto> getArrestAssociationDtoList() {
        return arrestAssociationDtoList;
    }

    public void setArrestAssociationDtoList(List<ArrestAssociationDto> arrestAssociationDtoList) {
        this.arrestAssociationDtoList = arrestAssociationDtoList;
    }

    public List<ArrestNoteDto> getArrestNoteDtoList() {
        return arrestNoteDtoList;
    }

    public void setArrestNoteDtoList(List<ArrestNoteDto> arrestNoteDtoList) {
        this.arrestNoteDtoList = arrestNoteDtoList;
    }

    public List<ArrestReportTrackDto> getArrestReportTrackDtoList() {
        return arrestReportTrackDtoList;
    }

    public void setArrestReportTrackDtoList(List<ArrestReportTrackDto> arrestReportTrackDtoList) {
        this.arrestReportTrackDtoList = arrestReportTrackDtoList;
    }

    public List<ArrestPartyDto> getArrestPartyDtoList() {
        return arrestPartyDtoList;
    }

    public void setArrestPartyDtoList(List<ArrestPartyDto> arrestPartyDtoList) {
        this.arrestPartyDtoList = arrestPartyDtoList;
    }

    @Nullable
    public Entry getDepartment() {
        return department;
    }

    public void setDepartment(@Nullable Entry department) {
        this.department = department;
    }

    @Nullable
    public Entry getSection() {
        return section;
    }

    public void setSection(@Nullable Entry section) {
        this.section = section;
    }

    @Nullable
    public Entry getSectionUnit() {
        return sectionUnit;
    }

    public void setSectionUnit(@Nullable Entry sectionUnit) {
        this.sectionUnit = sectionUnit;
    }

    @Nullable
    public Entry getArrestReason() {
        return arrestReason;
    }

    public void setArrestReason(@Nullable Entry arrestReason) {
        this.arrestReason = arrestReason;
    }

    @Nullable
    public Entry getTransferredFrom() {
        return transferredFrom;
    }

    public void setTransferredFrom(@Nullable Entry transferredFrom) {
        this.transferredFrom = transferredFrom;
    }

    @Nullable
    public Entry getShift() {
        return shift;
    }

    public void setShift(@Nullable Entry shift) {
        this.shift = shift;
    }

    public boolean isUrgent() {
        return urgent;
    }

    public void setUrgent(boolean urgent) {
        this.urgent = urgent;
    }

    public Entry getStatus() {
        return status;
    }

    public void setStatus(Entry status) {
        this.status = status;
    }

    @Nullable
    public Entry getLastAction() {
        return lastAction;
    }

    public void setLastAction(@Nullable Entry lastAction) {
        this.lastAction = lastAction;
    }

    public String getArrestReportNumber() {
        return arrestReportNumber;
    }

    public void setArrestReportNumber(String arrestReportNumber) {
        this.arrestReportNumber = arrestReportNumber;
    }

    public String getFirNo() {
        return firNo;
    }

    public void setFirNo(String firNo) {
        this.firNo = firNo;
    }

    public boolean isCreatedByAhwal() {
        return isCreatedByAhwal;
    }

    public void setCreatedByAhwal(boolean isCreatedByAhwal) {
        this.isCreatedByAhwal = isCreatedByAhwal;
    }

    @Override
    public String getLockId() {
        return String.valueOf(id);
    }

    @Override
    public LockableEntityName getLockableEntityName() {
        return LockableEntityName.ARREST_REPORT;
    }

    public String getUrgentString() {
        return urgentString;
    }

    public void setUrgentString(String urgentString) {
        this.urgentString = urgentString;
    }

    public String getAssignedUser() {
        return assignedUser;
    }

    public void setAssignedUser(String assignedUser) {
        this.assignedUser = assignedUser;
    }

    public List<AttachedDocumentDto> getArrestAttachmentDtoList() {
        return arrestAttachmentDtoList;
    }

    public void setArrestAttachmentDtoList(List<AttachedDocumentDto> arrestAttachmentDtoList) {
        this.arrestAttachmentDtoList = arrestAttachmentDtoList;
    }

    public String getArrestNumber() {
        return arrestNumber;
    }

    public void setArrestNumber(String arrestNumber) {
        this.arrestNumber = arrestNumber;
    }

    @Nullable
    public Entry getEntryExit() {
        return entryExit;
    }

    public void setEntryExit(@Nullable Entry entryExit) {
        this.entryExit = entryExit;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        ArrestReportDto that = (ArrestReportDto) o;

        if (isCreatedByAhwal != that.isCreatedByAhwal) return false;
        if (urgent != that.urgent) return false;
        if (areaLk != null ? !areaLk.equals(that.areaLk) : that.areaLk != null) return false;
        if (arrestAssociationDtoList != null ? !arrestAssociationDtoList.equals(that.arrestAssociationDtoList) : that.arrestAssociationDtoList != null)
            return false;
        if (arrestAttachmentDtoList != null ? !arrestAttachmentDtoList.equals(that.arrestAttachmentDtoList) : that.arrestAttachmentDtoList != null)
            return false;
        if (arrestDate != null ? !arrestDate.equals(that.arrestDate) : that.arrestDate != null) return false;
        if (arrestLocation != null ? !arrestLocation.equals(that.arrestLocation) : that.arrestLocation != null)
            return false;
        if (arrestNoteDtoList != null ? !arrestNoteDtoList.equals(that.arrestNoteDtoList) : that.arrestNoteDtoList != null)
            return false;
        if (arrestNumber != null ? !arrestNumber.equals(that.arrestNumber) : that.arrestNumber != null) return false;
        if (arrestPartyDtoList != null ? !arrestPartyDtoList.equals(that.arrestPartyDtoList) : that.arrestPartyDtoList != null)
            return false;
        if (arrestReason != null ? !arrestReason.equals(that.arrestReason) : that.arrestReason != null) return false;
        if (arrestReportDescription != null ? !arrestReportDescription.equals(that.arrestReportDescription) : that.arrestReportDescription != null)
            return false;
        if (arrestReportNumber != null ? !arrestReportNumber.equals(that.arrestReportNumber) : that.arrestReportNumber != null)
            return false;
        if (arrestReportTrackDtoList != null ? !arrestReportTrackDtoList.equals(that.arrestReportTrackDtoList) : that.arrestReportTrackDtoList != null)
            return false;
        if (arrestTeamList != null ? !arrestTeamList.equals(that.arrestTeamList) : that.arrestTeamList != null)
            return false;
        if (arrestTime != null ? !arrestTime.equals(that.arrestTime) : that.arrestTime != null) return false;
        if (assignedUser != null ? !assignedUser.equals(that.assignedUser) : that.assignedUser != null) return false;
        if (building != null ? !building.equals(that.building) : that.building != null) return false;
        if (cityLk != null ? !cityLk.equals(that.cityLk) : that.cityLk != null) return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDate != null ? !createdDate.equals(that.createdDate) : that.createdDate != null) return false;
        if (department != null ? !department.equals(that.department) : that.department != null) return false;
        if (emirateLk != null ? !emirateLk.equals(that.emirateLk) : that.emirateLk != null) return false;
        if (entryExit != null ? !entryExit.equals(that.entryExit) : that.entryExit != null) return false;
        if (firNo != null ? !firNo.equals(that.firNo) : that.firNo != null) return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (lastAction != null ? !lastAction.equals(that.lastAction) : that.lastAction != null) return false;
        if (locType != null ? !locType.equals(that.locType) : that.locType != null) return false;
        if (locationDescription != null ? !locationDescription.equals(that.locationDescription) : that.locationDescription != null)
            return false;
        if (section != null ? !section.equals(that.section) : that.section != null) return false;
        if (sectionUnit != null ? !sectionUnit.equals(that.sectionUnit) : that.sectionUnit != null) return false;
        if (seizureDtoList != null ? !seizureDtoList.equals(that.seizureDtoList) : that.seizureDtoList != null)
            return false;
        if (shift != null ? !shift.equals(that.shift) : that.shift != null) return false;
        if (status != null ? !status.equals(that.status) : that.status != null) return false;
        if (street != null ? !street.equals(that.street) : that.street != null) return false;
        if (terminalLocation != null ? !terminalLocation.equals(that.terminalLocation) : that.terminalLocation != null)
            return false;
        if (transferredFrom != null ? !transferredFrom.equals(that.transferredFrom) : that.transferredFrom != null)
            return false;
        if (urgentString != null ? !urgentString.equals(that.urgentString) : that.urgentString != null) return false;
        if (version != null ? !version.equals(that.version) : that.version != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (id != null ? id.hashCode() : 0);
        result = 31 * result + (arrestDate != null ? arrestDate.hashCode() : 0);
        result = 31 * result + (arrestLocation != null ? arrestLocation.hashCode() : 0);
        result = 31 * result + (locType != null ? locType.hashCode() : 0);
        result = 31 * result + (arrestReportDescription != null ? arrestReportDescription.hashCode() : 0);
        result = 31 * result + (arrestTime != null ? arrestTime.hashCode() : 0);
        result = 31 * result + (building != null ? building.hashCode() : 0);
        result = 31 * result + (emirateLk != null ? emirateLk.hashCode() : 0);
        result = 31 * result + (areaLk != null ? areaLk.hashCode() : 0);
        result = 31 * result + (cityLk != null ? cityLk.hashCode() : 0);
        result = 31 * result + (street != null ? street.hashCode() : 0);
        result = 31 * result + (locationDescription != null ? locationDescription.hashCode() : 0);
        result = 31 * result + (version != null ? version.hashCode() : 0);
        result = 31 * result + (terminalLocation != null ? terminalLocation.hashCode() : 0);
        result = 31 * result + (department != null ? department.hashCode() : 0);
        result = 31 * result + (section != null ? section.hashCode() : 0);
        result = 31 * result + (sectionUnit != null ? sectionUnit.hashCode() : 0);
        result = 31 * result + (arrestReason != null ? arrestReason.hashCode() : 0);
        result = 31 * result + (transferredFrom != null ? transferredFrom.hashCode() : 0);
        result = 31 * result + (shift != null ? shift.hashCode() : 0);
        result = 31 * result + (urgent ? 1 : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (lastAction != null ? lastAction.hashCode() : 0);
        result = 31 * result + (arrestReportNumber != null ? arrestReportNumber.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
        result = 31 * result + (firNo != null ? firNo.hashCode() : 0);
        result = 31 * result + (isCreatedByAhwal ? 1 : 0);
        result = 31 * result + (urgentString != null ? urgentString.hashCode() : 0);
        result = 31 * result + (assignedUser != null ? assignedUser.hashCode() : 0);
        result = 31 * result + (arrestTeamList != null ? arrestTeamList.hashCode() : 0);
        result = 31 * result + (seizureDtoList != null ? seizureDtoList.hashCode() : 0);
        result = 31 * result + (arrestAssociationDtoList != null ? arrestAssociationDtoList.hashCode() : 0);
        result = 31 * result + (arrestNoteDtoList != null ? arrestNoteDtoList.hashCode() : 0);
        result = 31 * result + (arrestReportTrackDtoList != null ? arrestReportTrackDtoList.hashCode() : 0);
        result = 31 * result + (arrestPartyDtoList != null ? arrestPartyDtoList.hashCode() : 0);
        result = 31 * result + (arrestAttachmentDtoList != null ? arrestAttachmentDtoList.hashCode() : 0);
        result = 31 * result + (arrestNumber != null ? arrestNumber.hashCode() : 0);
        result = 31 * result + (entryExit != null ? entryExit.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ArrestReportDto{" +
                "id=" + id +
                ", arrestDate=" + arrestDate +
                ", arrestLocation='" + arrestLocation + '\'' +
                ", locType=" + locType +
                ", arrestReportDescription='" + arrestReportDescription + '\'' +
                ", arrestTime='" + arrestTime + '\'' +
                ", building='" + building + '\'' +
                ", emirateLk=" + emirateLk +
                ", areaLk=" + areaLk +
                ", cityLk=" + cityLk +
                ", street='" + street + '\'' +
                ", locationDescription='" + locationDescription + '\'' +
                ", version=" + version +
                ", terminalLocation=" + terminalLocation +
                ", department=" + department +
                ", section=" + section +
                ", sectionUnit=" + sectionUnit +
                ", arrestReason=" + arrestReason +
                ", transferredFrom=" + transferredFrom +
                ", shift=" + shift +
                ", urgent=" + urgent +
                ", status=" + status +
                ", lastAction=" + lastAction +
                ", arrestReportNumber='" + arrestReportNumber + '\'' +
                ", createdBy='" + createdBy + '\'' +
                ", createdDate=" + createdDate +
                ", firNo='" + firNo + '\'' +
                ", isCreatedByAhwal=" + isCreatedByAhwal +
                ", urgentString='" + urgentString + '\'' +
                ", assignedUser='" + assignedUser + '\'' +
                ", arrestTeamList=" + arrestTeamList +
                ", seizureDtoList=" + seizureDtoList +
                ", arrestAssociationDtoList=" + arrestAssociationDtoList +
                ", arrestNoteDtoList=" + arrestNoteDtoList +
                ", arrestReportTrackDtoList=" + arrestReportTrackDtoList +
                ", arrestPartyDtoList=" + arrestPartyDtoList +
                ", arrestAttachmentDtoList=" + arrestAttachmentDtoList +
                ", arrestNumber='" + arrestNumber + '\'' +
                ", entryExit=" + entryExit +
                '}';
    }
}
