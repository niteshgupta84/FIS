package ae.emaratech.uaevision.arrest.domain;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Created by Nitesh.Gupta on 6/29/2016.
 */
public class ArrestActionTest {
    @Test
    public void shouldReturnOpenAction() {
        ArrestAction arrestAction = ArrestAction.valueOf("OPEN");
        assertTrue(arrestAction.id() == 2);
        assertTrue(!arrestAction.commentable());
        assertTrue(!arrestAction.requiresLock());
        assertTrue(arrestAction.trackable());
        assertTrue(arrestAction.resultState() == ArrestStatus.OPENED);
    }

    @Test
    public void shouldReturnAcquireAction() {
        ArrestAction arrestAction = ArrestAction.valueOf("ACQUIRE");
        assertTrue(arrestAction.id() == 3);
        assertTrue(!arrestAction.commentable());
        assertTrue(!arrestAction.requiresLock());
        assertTrue(!arrestAction.trackable());

    }

    @Test
    public void shouldReturnUpdateAction() {
        ArrestAction arrestAction = ArrestAction.valueOf("UPDATE");
        assertTrue(arrestAction.id() == 4);
        assertTrue(!arrestAction.commentable());
        assertTrue(arrestAction.requiresLock());
        assertTrue(!arrestAction.trackable());

    }

    @Test
    public void shouldReturnForwardToCaseAction() {
        ArrestAction arrestAction = ArrestAction.valueOf("FORWARD_TO_CASE");
        assertTrue(arrestAction.id() == 5);
        assertTrue(arrestAction.commentable());
        assertTrue(arrestAction.requiresLock());
        assertTrue(arrestAction.trackable());
        assertTrue(arrestAction.resultState() == ArrestStatus.FORWARDED);
    }

    @Test
    public void shouldReturnApproveAction() {
        ArrestAction arrestAction = ArrestAction.valueOf("APPROVE");
        assertTrue(arrestAction.id() == 19);
        assertTrue(arrestAction.commentable());
        assertTrue(arrestAction.requiresLock());
        assertTrue(arrestAction.trackable());
        assertTrue(arrestAction.resultState() == ArrestStatus.APPROVED);
    }

    @Test
    public void shouldReturnRejectAction() {
        ArrestAction arrestAction = ArrestAction.valueOf("REJECT");
        assertTrue(arrestAction.id() == 8);
        assertTrue(arrestAction.commentable());
        assertTrue(arrestAction.requiresLock());
        assertTrue(arrestAction.trackable());
        assertTrue(arrestAction.resultState() == ArrestStatus.OPENED);
    }

    @Test
    public void shouldReturnCloseAction() {
        ArrestAction arrestAction = ArrestAction.valueOf("CLOSE");
        assertTrue(arrestAction.id() == 7);
        assertTrue(arrestAction.commentable());
        assertTrue(arrestAction.requiresLock());
        assertTrue(arrestAction.trackable());
        assertTrue(arrestAction.resultState() == ArrestStatus.CLOSED);
    }

    @Test
    public void shouldReturnReOpenAction() {
        ArrestAction arrestAction = ArrestAction.valueOf("REOPEN");
        assertTrue(arrestAction.id() == 6);
        assertTrue(!arrestAction.commentable());
        assertTrue(!arrestAction.requiresLock());
        assertTrue(arrestAction.trackable());
        assertTrue(arrestAction.resultState() == ArrestStatus.OPENED);
    }

    @Test
    public void shouldReturnViewAction() {
        ArrestAction arrestAction = ArrestAction.valueOf("VIEW");
        assertTrue(arrestAction.id() == 11);
        assertTrue(!arrestAction.commentable());
        assertTrue(!arrestAction.requiresLock());
        assertTrue(!arrestAction.trackable());

    }

    @Test
    public void shouldReturnForwardToSupervisorAction() {
        ArrestAction arrestAction = ArrestAction.valueOf("FORWARD_TO_SUPERVISOR");
        assertTrue(arrestAction.id() == 9);
        assertTrue(arrestAction.getId() == 9);
        assertTrue(arrestAction.commentable());
        assertTrue(arrestAction.requiresLock());
        assertTrue(arrestAction.trackable());
        assertTrue(arrestAction.resultState() == ArrestStatus.PENDING_DECISION);
        //assertTrue(arrestAction.visionPrivilegeId() == 3014L);
        assertTrue(arrestAction.toString() != null);
    }

    @Test
    public void shouldReturnEndAction() {
        ArrestAction arrestAction = ArrestAction.valueOf("END");
        assertTrue(arrestAction.id() == 10);
        assertTrue(arrestAction.getId() == 10);
        assertTrue(arrestAction.commentable());
        assertTrue(arrestAction.requiresLock());
        assertTrue(arrestAction.trackable());
        assertTrue(arrestAction.resultState() == ArrestStatus.ENDED);
        //assertTrue(arrestAction.visionPrivilegeId() == 3014L);
        assertTrue(arrestAction.toString() != null);
    }

    @Test
    public void shouldReturnSearchAction() {
        ArrestAction arrestAction = ArrestAction.valueOf("SEARCH");
        assertTrue(arrestAction.id() == 12);
        assertTrue(arrestAction.getId() == 12);
        assertTrue(!arrestAction.commentable());
        assertTrue(!arrestAction.requiresLock());
        assertTrue(!arrestAction.trackable());

        //assertTrue(arrestAction.visionPrivilegeId() == 3014L);
        assertTrue(arrestAction.toString() != null);
    }

    @Test
    public void shouldAcquireLongerSearchAction() {
        ArrestAction arrestAction = ArrestAction.valueOf("ACQUIRE_LONGER");
        assertTrue(arrestAction.id() == 16);
        assertTrue(arrestAction.getId() == 16);
        assertTrue(!arrestAction.commentable());
        assertTrue(arrestAction.requiresLock());
        assertTrue(arrestAction.trackable());

        //assertTrue(arrestAction.visionPrivilegeId() == 3014L);
        assertTrue(arrestAction.toString() != null);
    }

    @Test
    public void shouldReturnNEWAction() {
        ArrestAction arrestAction = ArrestAction.valueOf("NEW");
        assertTrue(arrestAction.id() == 1);
        assertTrue(!arrestAction.commentable());
        assertTrue(!arrestAction.requiresLock());
        assertTrue(!arrestAction.trackable());
        assertTrue(arrestAction.resultState() == null);
    }


}
