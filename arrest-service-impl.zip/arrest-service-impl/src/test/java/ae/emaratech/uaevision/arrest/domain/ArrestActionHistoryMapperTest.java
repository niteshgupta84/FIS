package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportTrackDto;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.fis.user.service.dto.User;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static org.assertj.core.api.StrictAssertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;

/**
 * Created by Nitesh.Gupta on 4/2/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestActionHistoryMapperTest {

    @Mock
    LookupService lookupService;
    @InjectMocks
    ArrestActionHistoryMapper arrestActionHistoryMapper;

    @Mock
    protected UserService userDetailsService;

    /**
     * Testing if Dto is mapped by providing Entity
     */
    @Test
    public void shouldReturnDtoFromEntity() {

        Entry entry = new Entry(1L, "lk_key");
        Optional option = Optional.of(entry);
        doReturn(option).when(lookupService).getLookupEntry(any(), any(), any());

        ArrestActionHistory arrestActionHistory = new ArrestActionHistory.Builder(1L)
                .withActionId(1L).withComments("Nitesh").build();

        ArrestReportTrackDto
                arrestReportTrackDto =
                arrestActionHistoryMapper.mapArrestTrackDto(arrestActionHistory);
        assertThat(arrestReportTrackDto).isNotNull();

    }
}
