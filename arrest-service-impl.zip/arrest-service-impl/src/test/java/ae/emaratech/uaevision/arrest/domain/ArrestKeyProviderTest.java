package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceDefinition;
import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceService;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.assertj.core.api.StrictAssertions.assertThat;
import static org.mockito.Mockito.doReturn;

/**
 * Created by Nitesh.Gupta on 4/2/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestKeyProviderTest {

    @Mock
    private SequenceService sequenceService;

    @InjectMocks
    private ArrestKeyProvider arrestKeyProvider;

    @Test
    public void shouldReturnInterrogationKey() {
        doReturn(1L).when(sequenceService).nextValue(SequenceDefinition.INTERROGATION);
        ArrestReportKey arrestReportKey = arrestKeyProvider.next();
        assertThat(arrestReportKey).isInstanceOf(ArrestReportKey.class);
        assertThat(arrestReportKey).isNotNull();
    }
}
