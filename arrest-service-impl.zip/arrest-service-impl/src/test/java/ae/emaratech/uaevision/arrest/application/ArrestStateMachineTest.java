package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.domain.ArrestAction;
import ae.emaratech.uaevision.arrest.domain.ArrestStatus;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.List;

import static org.junit.Assert.assertNotNull;

/**
 * Test class providing unit test cases for {@link ae.emaratech.uaevision.interrogation.application.InterrogationStateMachine}
 *
 * @author Haroon.Subair
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestStateMachineTest {

    @InjectMocks
    private ArrestStateMachine _test;

    @Test
    public void shouldReturnNextActionList() {

        List<ArrestAction> nextActionList = ArrestStateMachine.nextPossibleActions(
                ArrestStatus.OPENED, false);
        assertNotNull("nextActionList returned is null", nextActionList);

        nextActionList = ArrestStateMachine.nextPossibleActions(
                ArrestStatus.APPROVED, true);
        assertNotNull("nextActionList returned is null", nextActionList);

        nextActionList = ArrestStateMachine.nextPossibleActions(
                ArrestStatus.CLOSED, false);
        assertNotNull("nextActionList returned is null", nextActionList);

        nextActionList = ArrestStateMachine.nextPossibleActions(
                ArrestStatus.ENDED, true);
        assertNotNull("nextActionList returned is null", nextActionList);

        nextActionList = ArrestStateMachine.nextPossibleActions(
                ArrestStatus.PENDING_DECISION, false);
        assertNotNull("nextActionList returned is null", nextActionList);

        nextActionList = ArrestStateMachine.nextPossibleActions(
                ArrestStatus.FORWARDED, false);
        assertNotNull("nextActionList returned is null", nextActionList);
    }

}
