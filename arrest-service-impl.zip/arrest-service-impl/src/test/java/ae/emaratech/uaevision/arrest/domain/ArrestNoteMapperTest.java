package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.application.dto.ArrestNoteDto;
import ae.emaratech.uaevision.fis.common.key.NoteKey;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashSet;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Nitesh.Gupta on 7/10/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestNoteMapperTest {

    @InjectMocks
    private ArrestNoteMapper _test;
    @Mock
    protected UserService userDetailsService;

    @Test
    public void shouldMapToNoteDto() {

        ArrestNote arrestNote = new ArrestNote(new NoteKey(1L), "test", 0L);
        arrestNote.setArrestReport(ArrestReportDataConstants.getArrestData());
        arrestNote.setIsDeleted(1L);
        arrestNote.setNote("Note");
        ArrestNoteDto dto = _test.mapToArrestNoteDto(arrestNote);
        assertThat(dto).isNotNull();
        assertThat(arrestNote.getArrestReport()).isNotNull();
        assertThat(arrestNote.getNote()).isNotNull();
        assertThat(arrestNote.getIsDeleted()).isNotNull();
    }

    @Test
    public void shouldMapNoteDtoList() {
        ArrestNote arrestNote = new ArrestNote(new NoteKey(1L), "test", 0L);
        arrestNote.setArrestReport(ArrestReportDataConstants.getArrestData());
        arrestNote.setIsDeleted(1L);
        arrestNote.setNote("Note");
        Set<ArrestNote> entities = new HashSet<>();
        entities.add(arrestNote);
        assertThat(_test.mapToArrestNoteDtList(entities)).isNotNull().hasSize(1);
    }

    @Test
    public void shouldMapNoteDtoList_blank() {

        Set<ArrestNote> entities = new HashSet<>();

        assertThat(_test.mapToArrestNoteDtList(entities)).isNotNull().hasSize(0);
    }
}
