package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceDefinition;
import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceService;
import ae.emaratech.uaevision.fis.common.key.ArrestTeamKey;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.assertj.core.api.StrictAssertions.assertThat;
import static org.mockito.Mockito.doReturn;

/**
 * Created by Nitesh.Gupta on 4/2/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestTeamKeyProviderTest {

    @Mock
    private SequenceService sequenceService;

    @InjectMocks
    private ArrestTeamKeyProvider arrestTeamKeyProvider;

    @Test
    public void shouldReturnInterrogationKey() {
        doReturn(1L).when(sequenceService).nextValue(SequenceDefinition.ARREST_TEAM);
        ArrestTeamKey arrestTeamKey = arrestTeamKeyProvider.next();
        assertThat(arrestTeamKey).isInstanceOf(ArrestTeamKey.class);
        assertThat(arrestTeamKey).isNotNull();
    }
}
