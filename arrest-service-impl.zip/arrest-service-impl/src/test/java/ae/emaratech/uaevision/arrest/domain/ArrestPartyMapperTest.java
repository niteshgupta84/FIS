package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.application.dto.ArrestPartyDto;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Nitesh.Gupta on 7/11/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestPartyMapperTest {

    @InjectMocks
    private ArrestPartyMapper _test;
    @Mock
    protected UserService userDetailsService;

    @Test
    public void shouldMapArrestPartyDto() {
        ArrestParty arrestParty = new ArrestParty(new PartyKey(1L));
        arrestParty.setCreatedDate(new Date());
        arrestParty.setCreatedBy("Nitesh");
        arrestParty.setArrestReport(ArrestReportDataConstants.getArrestData());

        assertThat(_test.mapToArrestPartyDto(arrestParty)).isNotNull();
        assertThat(arrestParty.getCreatedDate()).isNotNull();
        assertThat(arrestParty.getCreatedBy()).isNotNull();
        assertThat(arrestParty.getPartyId()).isNotNull();
        assertThat(arrestParty.getArrestReport()).isNotNull();
        assertThat(arrestParty.id()).isNull();
    }

    @Test
    public void shouldMapArrestPartyDtoList() {
        ArrestParty arrestParty = new ArrestParty(new PartyKey(1L));
        arrestParty.setCreatedDate(new Date());
        arrestParty.setCreatedBy("Nitesh");
        arrestParty.setArrestReport(ArrestReportDataConstants.getArrestData());
        Set<ArrestParty> arrestParties = new HashSet<>();
        arrestParties.add(arrestParty);
        assertThat(_test.mapToDtoList(arrestParties)).isNotNull().hasSize(1);
    }

    @Test
    public void shouldMapArrestPartyEntitySet() {
        ArrestPartyDto arrestPartyDto = new ArrestPartyDto();
        arrestPartyDto.setId(0L);
        arrestPartyDto.setPartyId(1L);
        arrestPartyDto.setArrestReportId(1L);
        //arrestPartyDto.setDeleted(true);
        List<ArrestPartyDto> arrestPartyDtoList = new ArrayList<>();
        arrestPartyDtoList.add(arrestPartyDto);
        Set<ArrestParty> arrestPartySet = _test.mapToEntitySet(arrestPartyDtoList, ArrestReportDataConstants.getArrestData());
        assertThat(arrestPartySet).isNotNull().hasSize(2);
    }

    @Test
    public void shouldMapArrestPartyDtoListWithEmptySet() {

        assertThat(_test.mapToDtoList(null)).isNotNull().hasSize(0);
    }

    @Test
    public void shouldMapArrestPartyEntitySetWithEmptyList() {

        Set<ArrestParty> arrestPartySet = _test.mapToEntitySet(null, ArrestReportDataConstants.getArrestData());
        assertThat(arrestPartySet).isNotNull().hasSize(1);
    }

}
