package ae.emaratech.uaevision.arrest.resource;

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestReportTrackDto;
import ae.emaratech.uaevision.arrest.query.ArrestQueryService;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestHistoryQuery;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestQuery;
import ae.emaratech.uaevision.arrest.report.ArrestReportGenerator;
import ae.emaratech.uaevision.fis.report.core.FISReport;
import ae.emaratech.uaevision.fis.report.core.FISReportFormat;
import ae.emaratech.uaevision.fis.report.core.FISReportGenerator;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import com.github.dandelion.datatables.core.ajax.ColumnDef;
import com.github.dandelion.datatables.core.ajax.DatatablesCriterias;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Test class providing unit test cases for {}
 *
 * @author Nitesh.Gupta
 */
public class ArrestResourceTest {

    @InjectMocks
    private ArrestResource _test;

    @Autowired
    private MockHttpSession mockSession;

    @Mock
    private MockHttpServletRequest mockRequest;

    private MockMvc mockMvc;

    @Mock
    private ArrestQueryService mockArrestQueryService;

    @Mock
    private FISReportGenerator mockArrestReportGenerator;

    @Mock
    private ArrestReportGenerator arrestReportGenerator;


    @Before
    public void setUp() {

        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(_test).build();
        given(mockRequest.getSession()).willReturn(mockSession);
    }

    @Test
    public void shouldReturnTrack() throws Exception {

        ArrestReportTrackDto arrestTrackDto = new ArrestReportTrackDto();
        arrestTrackDto.setId(1L);
        arrestTrackDto.setComments("Test");
        List<ColumnDef> columnDefs = getColumnDefs();
        List<ColumnDef> sortedColumnDefs = getSortedColumnDefs();
        List<ArrestReportTrackDto> arrestTrackList = new ArrayList<>();
        arrestTrackList.add(arrestTrackDto);
        doReturn(arrestTrackList).when(mockArrestQueryService)
                .retrieveArrestHistory(any(RetrieveArrestHistoryQuery.class));

        DatatablesCriterias mockCriteria = mock(DatatablesCriterias.class);
        when(mockCriteria.getColumnDefs()).thenReturn(getColumnDefs());
        when(mockCriteria.getSortedColumnDefs()).thenReturn(getSortedColumnDefs());
        when(mockCriteria.getLength()).thenReturn(10);

        assertNotNull(_test.fetchTracks(1L, mockCriteria));
    }



    @Test
    public void shouldGenerateArrestReport() throws Exception {

        FISReport report = new FISReport();
        byte[] bytes = new byte[1];
        report.setContent(bytes);
        doReturn(report).when(arrestReportGenerator)
                .generateReport(any(ReportParameters.class), any(FISReportFormat.class));
        mockMvc.perform(get("/rest/arrest/viewArrestReport/1").contentType(MediaType.ALL_VALUE))
                .andExpect(status().isOk());


    }
    @Test
    public void shouldAcessArrestReport(){
        ArrestReportDto arrest = mock(ArrestReportDto.class);
        doReturn(arrest).when(mockArrestQueryService).retrieveArrestReport(any(RetrieveArrestQuery.class));
        _test.getArrestReport(1L);

    }

    private List<ColumnDef> getColumnDefs() {

        List<ColumnDef> list = new ArrayList<>();
        // 0. identifier
        ColumnDef def0 = new ColumnDef();
        def0.setFiltered(false);
        def0.setName("identifier");
        list.add(def0);

        // 1. name
        ColumnDef def1 = new ColumnDef();
        def1.setFiltered(false);
        def1.setName("name");
        list.add(def1);

        // 2. organism
        ColumnDef def2 = new ColumnDef();
        def2.setFiltered(false);
        def2.setName("organism");
        list.add(def2);

        return list;
    }

    private List<ColumnDef> getSortedColumnDefs() {

        List<ColumnDef> list = new ArrayList<>();

        ColumnDef def = new ColumnDef();
        def.setSortDirection(ColumnDef.SortDirection.ASC);
        def.setName("name");
        list.add(def);

        return list;
    }

}
