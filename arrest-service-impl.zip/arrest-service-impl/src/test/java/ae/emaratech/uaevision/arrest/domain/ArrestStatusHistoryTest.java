package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Nitesh.Gupta on 7/10/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestStatusHistoryTest {

    @Test
    public void shouldInitializeArrestStatusHistory() {
        ArrestStatusHistory statusHistory = new ArrestStatusHistory(new ArrestReportKey(1l), 1L);
        statusHistory.setCreatedBy("Nitesh");
        statusHistory.setCreatedDate(new Date());
        assertThat(statusHistory.getCreatedDate()).isNotNull();
        assertThat(statusHistory.getCreatedBy()).isNotNull();
        assertThat(statusHistory.getArrestId()).isNotNull();
        assertThat(statusHistory.getId()).isNull();

        ArrestStatusHistory history = new ArrestStatusHistory.Builder(1L).withStatusId(1L).build();
        assertThat(history).isNotNull();

    }

}
