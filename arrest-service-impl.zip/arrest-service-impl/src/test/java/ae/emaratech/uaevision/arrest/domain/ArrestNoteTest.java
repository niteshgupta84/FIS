package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.key.NoteKey;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Nitesh.Gupta on 7/8/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestNoteTest {

    @Test
    public void shouldInitializeArrestNote() {

        ArrestNote arrestNote = new ArrestNote(new NoteKey(1L), "Test", 1L);
        arrestNote.getNote();
        arrestNote.getCreatedBy();
        arrestNote.getCreatedDate();
        arrestNote.getArrestReport();

        assertThat(arrestNote.getIsDeleted()).isEqualTo(1L);
    }
}
