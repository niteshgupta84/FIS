package ae.emaratech.uaevision.arrest.domain;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Nitesh.Gupta on 7/10/2016.
 */

public class ArrestLocationTest {
    @Test
    public void shouldInitializeArrestLocation() {

        ArrestLocation arrestLocation = new ArrestLocation(1L, 1L, 1L, LocationType.LOC, "Test", "test", "test",
                "Test", 1L);
        assertThat(arrestLocation.getAreaId()).isNotNull();
        assertThat(arrestLocation.getBuilding()).isNotNull();
        assertThat(arrestLocation.getCityId()).isNotNull();
        assertThat(arrestLocation.getEmirateId()).isNotNull();
        assertThat(arrestLocation.getLocation()).isNotNull();
        assertThat(arrestLocation.getLocationDescription()).isNotNull();
        assertThat(arrestLocation.getTerminalLocation()).isNotNull();
        assertThat(arrestLocation.getLocType()).isNotNull();
        assertThat(arrestLocation.getStreet()).isNotNull();

        ArrestLocation arrestLocation1 = new ArrestLocation(1L);
        assertThat(arrestLocation1).isNotNull();
    }

}
