package ae.emaratech.uaevision.arrest.domain;

/**
 * Created by Nitesh.Gupta on 7/10/2016.
 */

import ae.emaratech.uaevision.fis.common.key.PartyKey;
import org.junit.Test;

import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;

public class ArrestPartyTest {

    @Test
    public void shouldInitializeArrestParty() {
        ArrestParty arrestParty = new ArrestParty(new PartyKey(1L));
        arrestParty.setArrestReport(ArrestReportDataConstants.getArrestData());
        arrestParty.setCreatedBy("test");
        arrestParty.setCreatedDate(new Date());
        assertThat(arrestParty.getArrestReport()).isNotNull();
        assertThat(arrestParty.getPartyId()).isNotNull();
        assertThat(arrestParty.getCreatedDate()).isNotNull();
        assertThat(arrestParty.getCreatedBy()).isNotNull();
        assertThat(arrestParty.id()).isNull();
    }
}
