package ae.emaratech.uaevision.arrest.domain;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.ArrestTeamKey;
import ae.emaratech.uaevision.fis.common.key.AssociatedArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.AttachmentReferenceKey;
import ae.emaratech.uaevision.fis.common.key.NoteKey;
import ae.emaratech.uaevision.fis.common.key.OrderKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.key.SeizureKey;
import ae.emaratech.uaevision.fis.common.key.TrackerKey;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;
import ae.emaratech.uaevision.lookup.service.model.Entry;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Nitesh.Gupta on 7/8/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestTest {


    @Test
    public void shouldCloseArrest() {
        Arrest _test = createArrestObject();
        ArrestReportClosedEvent event = _test.close("Close");
        assertThat(event).isNotNull();
    }

    @Test
    public void shouldReOpenArrest() {
        Arrest _test = createArrestObject();
        ArrestReportReopenedEvent event = _test.reopen(new OrderKey(1L));
        assertThat(event).isNotNull();
    }

    @Test
    public void shouldForwardToCaseArrest() {
        Arrest _test = createArrestObject();
        ArrestReportForwardedEvent event = _test.forwardToCase("Test");
        assertThat(event).isNotNull();
    }

    @Test
    public void shouldForwardToSuperVisorArrest() {
        Arrest _test = createArrestObject();
        ArrestReportReviewedEvent event = _test.review("Test");
        assertThat(event).isNotNull();
    }

    @Test
    public void shouldFRejectArrest() {
        Arrest _test = createArrestObject();
        ArrestReportRejectedEvent event = _test.reject("Test");
        assertThat(event).isNotNull();
    }

    @Test
    public void shouldApproveArrest() {
        Arrest _test = createArrestObject();

        ArrestReportApprovedEvent event = _test.approve("Test");
        assertThat(event).isNotNull();
    }

    @Test
    public void shouldEndArrest() {
        Arrest _test = createArrestObject();

        ArrestReportEndedEvent event = _test.end("Test");
        assertThat(event).isNotNull();
    }

    @Test
    public void shouldAssignArrest() {
        Arrest _test = createArrestObject();
        ArrestAssignedEvent event = _test.assignUser("Test");
        assertThat(event).isNotNull();

    }

    @Test
    public void shouldCreateArrest() {
        Arrest _test = createArrestObject();
        // Arrest Attachment Set
        ArrestAttachment arrestAttachment = new ArrestAttachment(new AttachmentReferenceKey(1L));
        Set<ArrestAttachment> attachmentSet = new HashSet<>();
        attachmentSet.add(arrestAttachment);

        //Arrest Seizure
        Seizure seizure = new Seizure(new SeizureKey(1L), "Test", 1L, 0L);
        Set<Seizure> seizures = new HashSet<>();
        seizures.add(seizure);
        //Arrest Note
        ArrestNote arrestNote = new ArrestNote(new NoteKey(1L), "String", 1L);
        Set<ArrestNote> arrestNoteSet = new HashSet<>();
        arrestNoteSet.add(arrestNote);

        //Arrest Association
        ArrestAssociation arrestAssociation = new ArrestAssociation(new AssociatedArrestReportKey(1L), 0L);
        Set<ArrestAssociation> arrestAssociations = new HashSet<>();
        arrestAssociations.add(arrestAssociation);

        //Arrest Team
        ArrestTeam arrestTeam = new ArrestTeam(new ArrestTeamKey(1L), "Test", 0L);
        Set<ArrestTeam> arrestTeams = new HashSet<>();
        arrestTeams.add(arrestTeam);
        ArrestReportCreatedEvent event = _test.create(attachmentSet, seizures, arrestNoteSet, arrestAssociations, arrestTeams,
                new Entry(1L), new Entry(1L), true, true, new Date(),"",new Entry(1L));


        assertThat(event).isNotNull();

    }

    @Test
    public void shouldUpdateArrest() {
        Arrest _test = createArrestObject();

        Set<ArrestParty> arrestPartyDtos = new HashSet<>();
        ArrestParty arrestPartyDto = new ArrestParty(new PartyKey(1L), 1L, 0L);

        arrestPartyDtos.add(arrestPartyDto);
        List<PartyKey> partyKeyList = new ArrayList<>();
        partyKeyList.add(new PartyKey(1L));
        //ArrestDescription
        ArrestDescription arrestDescription = new ArrestDescription("tes");

        ArrestLocation arrestLocation = new ArrestLocation(1L, 1L, 1L, LocationType.LOC, "Test", "Test", "Test", "Description", 1L);
        // Arrest Attachment Set
        ArrestAttachment arrestAttachment = new ArrestAttachment(new AttachmentReferenceKey(1L));
        Set<ArrestAttachment> attachmentSet = new HashSet<>();
        attachmentSet.add(arrestAttachment);

        //Arrest Seizure
        Seizure seizure = new Seizure(new SeizureKey(1L), "Test", 1L, 0L);
        Set<Seizure> seizures = new HashSet<>();
        seizures.add(seizure);
        //Arrest Note
        ArrestNote arrestNote = new ArrestNote(new NoteKey(1L), "String", 1L);
        Set<ArrestNote> arrestNoteSet = new HashSet<>();
        arrestNoteSet.add(arrestNote);

        //Arrest Association

        Set<AssociatedArrestReportKey> arrestAssociations = new HashSet<>();
        arrestAssociations.add(new AssociatedArrestReportKey(1L));

        //Arrest Team
        ArrestTeam arrestTeam = new ArrestTeam(new ArrestTeamKey(1L), "Test", 0L);
        Set<ArrestTeam> arrestTeams = new HashSet<>();
        arrestTeams.add(arrestTeam);
        //Attachment List
        List<AttachmentReferenceKey> attachmentReferenceKeys = new ArrayList<>();
        attachmentReferenceKeys.add(new AttachmentReferenceKey(1L));
        ArrestReportUpdatedEvent event = _test.update(partyKeyList, arrestPartyDtos, new ArrestReason(24L), arrestDescription, arrestLocation,
                attachmentReferenceKeys, arrestAssociations, seizures,
                arrestNoteSet,
                arrestTeams, new Entry(1L), new Entry(1L), true,
                true, new Date(),0L, new Entry(1L));
        assertThat(event).isNotNull();

    }

    private Arrest createArrestObject() {
        ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
        Set<ArrestParty> arrestParties = new HashSet<>();
        ArrestParty arrestParty = new ArrestParty(new PartyKey(1L));
        arrestParties.add(arrestParty);
        ArrestReason arrestReason = new ArrestReason(9999L);
        ArrestDescription arrestDescription = new ArrestDescription("Test");
        ArrestLocation arrestLocation = new ArrestLocation(1L, 1L, 1L, LocationType.LOC, "Test", "Test", "Test", "Description", 1L);
        Owner owner = new Owner(Department.DETECTIVE, Section.CRM, null);
        Arrest arrestReport = new Arrest(arrestReportKey, arrestReason, arrestDescription, arrestLocation, arrestParties, owner, new TrackerKey(233L),"");
        return arrestReport;
    }

}
