package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.application.dto.*;
import ae.emaratech.uaevision.document.application.AttachedDocumentDto;
import ae.emaratech.uaevision.fis.common.resolver.MessageResolver;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

/**
 * Created by Nitesh.Gupta on 7/11/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestMapperTest {
    @InjectMocks
    private ArrestMapper _test;

    @Mock
    private LookupService lookupService;
    @Mock
    private MessageResolver messageResolver;

    @Mock
    private ArrestNoteMapper arrestNoteMapper;
    @Mock
    private ArrestPartyMapper arrestPartyMapper;
    @Mock
    private ArrestAssociationMapper arrestAssociationMapper;
    @Mock
    private SeizureMapper seizureMapper;
    @Mock
    private ArrestTeamMapper arrestTeamMapper;
    @Mock
    private ArrestAttachmentMapper arrestAttachmentMapper;

    @Mock
    protected UserService userDetailsService;

    @Test
    public void shouldMapToArrestDto() {

        Entry entry = new Entry(1L, "lk_key");
        Optional option = Optional.of(entry);
        doReturn(option).when(lookupService).getLookupEntry(any(), any(), any());
        doReturn("test").when(messageResolver).resolveMessageCode(any());
        doReturn(new ArrayList<ArrestNoteDto>()).when(arrestNoteMapper).mapToArrestNoteDtList(any());
        doReturn(new ArrayList<ArrestPartyDto>()).when(arrestPartyMapper).mapToDtoList(any());
        doReturn(new ArrayList<ArrestAssociationDto>()).when(arrestAssociationMapper).mapArrestAssociationDtoList(any());
        doReturn(new ArrayList<SeizureDto>()).when(seizureMapper).mapToDtoList(any());
        doReturn(mock(AttachedDocumentDto.class)).when(arrestAttachmentMapper).mapArrestAttachmentDto(
                any());
        doReturn(new ArrayList<ArrestTeamDto>()).when(arrestTeamMapper).mapToDtoList(any());
        Arrest arrest = ArrestReportDataConstants.getArrestData();
        ArrestReportCreatedEvent event = arrest.create(null, null, null, null, null,
                new Entry(1L), new Entry(1L), true, true, new Date(),"",new Entry(1L));
        assertThat(_test.mapToArrestReportDto(arrest)).isNotNull();
    }

    @Test
    public void shouldMapToArrestDtoList() {

        Entry entry = new Entry(1L, "lk_key");
        Optional option = Optional.of(entry);
        doReturn(option).when(lookupService).getLookupEntry(any(), any(), any());
        doReturn("test").when(messageResolver).resolveMessageCode(any());
        doReturn(new ArrayList<ArrestNoteDto>()).when(arrestNoteMapper).mapToArrestNoteDtList(any());
        doReturn(new ArrayList<ArrestPartyDto>()).when(arrestPartyMapper).mapToDtoList(any());
        doReturn(new ArrayList<ArrestAssociationDto>()).when(arrestAssociationMapper).mapArrestAssociationDtoList(any());
        doReturn(new ArrayList<SeizureDto>()).when(seizureMapper).mapToDtoList(any());
        doReturn(mock(AttachedDocumentDto.class)).when(arrestAttachmentMapper).mapArrestAttachmentDto(
                any());
        doReturn(new ArrayList<ArrestTeamDto>()).when(arrestTeamMapper).mapToDtoList(any());
        Arrest arrest = ArrestReportDataConstants.getArrestData();
        List<Arrest> list = new ArrayList<>();
        list.add(arrest);
        assertThat(_test.mapEntityToDTOList(list)).isNotNull();
    }
}
