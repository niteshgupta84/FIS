package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.application.dto.ArrestAssociationDto;
import ae.emaratech.uaevision.fis.common.key.AssociatedArrestReportKey;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.fis.user.service.dto.User;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Nitesh.Gupta on 7/12/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestAssociationMapperTest {
    @InjectMocks
    ArrestAssociationMapper _test;

    @Mock
    protected UserService userDetailsService;

    @Test
    public void shouldReturnAssociationDto() {
        Arrest arrest = ArrestReportDataConstants.getArrestData();
        ArrestAssociation arrestAssociation = new ArrestAssociation(new AssociatedArrestReportKey(1L), 0L);
        arrestAssociation.setArrestReport(arrest);
        arrestAssociation.setCreatedDate(new Date());
        arrestAssociation.setCreatedBy("Nitesh");
        assertThat(_test.mapArrestAssociationDto(arrestAssociation)).isNotNull();
        assertThat(arrestAssociation.getArrestReport()).isNotNull();
        assertThat(arrestAssociation.getCreatedDate()).isNotNull();
        assertThat(arrestAssociation.getCreatedBy()).isNotNull();
        assertThat(arrestAssociation.getAssociatedArrestReportId()).isNotNull();
    }

    @Test
    public void shouldReturnAssociationDtoList() {
        Arrest arrest = ArrestReportDataConstants.getArrestData();
        ArrestAssociation arrestAssociation = new ArrestAssociation(new AssociatedArrestReportKey(1L), 0L);
        arrestAssociation.setArrestReport(arrest);
        arrestAssociation.setCreatedDate(new Date());
        arrestAssociation.setCreatedBy("Nitesh");
        Set<ArrestAssociation> arrestAssociations = new HashSet<>();
        arrestAssociations.add(arrestAssociation);
        assertThat(_test.mapArrestAssociationDtoList(arrestAssociations)).isNotNull();
    }

    @Test
    public void shouldReturnAssociationEntitySet() {
        List<ArrestAssociationDto> list = new ArrayList<>();
        ArrestAssociationDto arrestAssociationDto = new ArrestAssociationDto();
        arrestAssociationDto.setAssociationType(new Entry(1L));
        arrestAssociationDto.setId(1L);
        arrestAssociationDto.setLinkedArrestReportId(2L);
        arrestAssociationDto.setArrestReportId(1L);
        list.add(arrestAssociationDto);
        assertThat(_test.mapToEntitySet(list, ArrestReportDataConstants.getArrestData())).isNotNull();
    }
}
