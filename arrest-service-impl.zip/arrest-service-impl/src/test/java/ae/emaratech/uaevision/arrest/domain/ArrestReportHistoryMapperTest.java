package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportTrackDto;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;
import java.util.Optional;

import static org.assertj.core.api.StrictAssertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;

/**
 * Created by Nitesh.Gupta on 7/11/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestReportHistoryMapperTest {
    @Mock
    LookupService lookupService;
    @InjectMocks
    private ArrestReportHistoryMapper _test;
    @Mock
    protected UserService userDetailsService;
    @Test
    public void shouldMapArrestReportTrackDto() {
        Entry entry = new Entry(1L, "lk_key");
        Optional option = Optional.of(entry);
        doReturn(option).when(lookupService).getLookupEntry(any(), any(), any());

        ArrestActionHistory.Builder builder =
                new ArrestActionHistory.Builder(1L)
                        .withActionId(ArrestAction.ACQUIRE.id())
                        .withComments("CancelComments");

        ArrestActionHistory arrestActionHistory = new ArrestActionHistory(builder);
        arrestActionHistory.setCreatedBy("Nitesh");
        arrestActionHistory.setCreatedDate(new Date());
        ArrestReportTrackDto
                arrestReportTrackDto =
                _test.mapArrestReportTrackDto(arrestActionHistory);
        assertThat(arrestReportTrackDto).isNotNull();
    }
}
