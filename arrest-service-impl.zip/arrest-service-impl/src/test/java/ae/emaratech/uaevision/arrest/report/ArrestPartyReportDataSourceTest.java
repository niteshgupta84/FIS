package ae.emaratech.uaevision.arrest.report;

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportDto;
import ae.emaratech.uaevision.arrest.query.ArrestQueryService;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestQuery;
import ae.emaratech.uaevision.document.service.api.DocumentService;
import ae.emaratech.uaevision.document.service.dto.DocumentReferenceDto;
import ae.emaratech.uaevision.fis.party.application.dto.ChargeDto;
import ae.emaratech.uaevision.fis.party.application.dto.IRISDto;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import ae.emaratech.uaevision.fis.party.query.RetrievePartyQuery;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import net.sf.jasperreports.engine.JRDataSource;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;

/**
 * Test class providing unit test cases for {PartyReportDataSource}
 *
 * @author Wasib Ali Khan
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestPartyReportDataSourceTest {

    @InjectMocks
    private ArrestPartyReportDataSource _test;

    @Mock
    private PartyQueryService partyQueryService;

    @Mock
    private DocumentService documentService;

    @Mock
    private MessageSource messageSource;

    @Mock
    private ArrestQueryService arrestQueryService;


    @Test
    public void shouldGetPARTYDataSource() throws Exception {

        //Preparing input data
        ReportParameters reportParameters = new ReportParameters();
        reportParameters.addParameter("ARREST_ID", 12);
        reportParameters.addParameter("PARTY_ID", 2);

        ArrestReportDto arrestReportDto = new ArrestReportDto();
        arrestReportDto.setId(1L);
        arrestReportDto.setArrestReportNumber("incident number");
        arrestReportDto.setCreatedBy("incident number");
        arrestReportDto.setCreatedDate(new Date());
        arrestReportDto.setDepartment(new Entry(1L, "Investigation"));
        arrestReportDto.setSection(new Entry(1L, "Section"));
        arrestReportDto.setStatus(new Entry(1L, "Status"));

        // incidentDto.set

        PartyDto partyDto = new PartyDto();
        List<ChargeDto> listOfCharges = new ArrayList<>();
        ChargeDto chargeDto = new ChargeDto();
        chargeDto.setCharge(new Entry(1L, "Test charge"));
        listOfCharges.add(chargeDto);

        IRISDto irisDto = new IRISDto();
        irisDto.setIrisNumber("Iris number");
        irisDto.setNameChangedId(new Entry(2L, "Changed"));
        irisDto.setLocationId(new Entry(3L, "Loc"));

        partyDto.setIrisDto(irisDto);
        partyDto.setNameEn("En Name");
        partyDto.setNameAr("AR Name");
        partyDto.setNationality(new Entry(2L, "Naitonality"));
        partyDto.setOriginalNationality(new Entry(2L, "Naitonality"));
        partyDto.setDateofbirth(new Date());
        partyDto.setGender(new Entry(3L, "Male"));
        partyDto.setPersonType(new Entry(7L, "Visa"));
        partyDto.setIsBanned(true);
        partyDto.setIsOverstayed(true);
        partyDto.setIsBlackListed(true);
        partyDto.setAttachmentId(1L);
        byte[] photo = new byte[1];
        DocumentReferenceDto documentReferenceDto = new DocumentReferenceDto();
        documentReferenceDto.setAttachment(photo);
        doReturn(documentReferenceDto).when(documentService).downloadDocument(any());
        doReturn(documentReferenceDto).when(documentService).downloadPartyPhoto(any());

        doReturn(partyDto).when(partyQueryService).retrieveParty(any(RetrievePartyQuery.class));
        doReturn(arrestReportDto).when(arrestQueryService).retrieveArrestReport(
                any(RetrieveArrestQuery.class));

        // Invoking the getDataSource on _test
        JRDataSource dataSource = _test.getDataSource(reportParameters);
        assertThat(dataSource).isInstanceOf(JRDataSource.class);
        assertThat(dataSource).isNotNull();
    }
}
