package ae.emaratech.uaevision.arrest.application.validators;

import ae.emaratech.uaevision.arrest.application.AddSeizureCommand;
import ae.emaratech.uaevision.arrest.application.EditSeizureCommand;
import ae.emaratech.uaevision.fis.common.key.SeizureKey;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.notification.NotificationBusinessException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

/**
 * Created by Nitesh.Gupta on 7/11/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class SeizureValidatorsTest {

    @InjectMocks
    private SeizureValidator _test;


    @Mock
    private NotificationBus notificationBus;

    @Before
    public void init() {
        // Setting the behaviour of mocked dependencies.
        doThrow(NotificationBusinessException.class).when(notificationBus)
                .send(any(NotificationBuilder.class));
        NotificationBuilder notificationBuilder = new NotificationBuilder();
        doReturn(notificationBuilder).when(notificationBus).getBuilder();
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldValidateSeizureDto() {

        AddSeizureCommand command = new AddSeizureCommand("test", "test");
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfBothValuesAreNull() {

        AddSeizureCommand command = new AddSeizureCommand(null, null);
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfItemCountLengthMoreThanFive() {

        AddSeizureCommand command = new AddSeizureCommand("test", "111111");
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfItemMessageLengthMoreThan200() {

        AddSeizureCommand command = new AddSeizureCommand("fdsfdsfdsafdsafsafdsafasfdasdfsadfsafdasdfsafdsa"
                + "fdsafasdfdsafdsafsadfdsafsadfsafsafdsafsa"
                + "fdsafsadfsafddsafdsa"
                + "fdsafsadfasdasasdfasdfdsafasdfdsafdsafasdfasdfasfasdfadsfadsfsadfsafddsafsafdsafads"
                + "fsdafsadfsadfsadfaasdfasdfasdfsadfsadfasdfasdfadsfdsafsadfdsafsadfsadfds"
                + "fsadfasddddddddddddddddddddddddddddddddddddd", "1111");
        _test.validate(command);
    }


    @Test(expected = NotificationBusinessException.class)
    public void shouldValidateSeizureDtoForEdit() {
        SeizureKey seizureKey = new SeizureKey(1L);
        EditSeizureCommand command = new EditSeizureCommand(seizureKey, "test", "test");
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfBothValuesAreNullForEdit() {
        SeizureKey seizureKey = new SeizureKey(1L);
        EditSeizureCommand command = new EditSeizureCommand(seizureKey, null, null);
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfItemCountLengthMoreThanFiveForEdit() {
        SeizureKey seizureKey = new SeizureKey(1L);
        EditSeizureCommand command = new EditSeizureCommand(seizureKey, "test", "111111");
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfItemMessageLengthMoreThan200ForEdit() {
        SeizureKey seizureKey = new SeizureKey(1L);
        EditSeizureCommand command = new EditSeizureCommand(seizureKey, "fdsfdsfdsafdsafsafdsafasfdasdfsadfsafdasdfsafdsa"
                + "fdsafasdfdsafdsafsadfdsafsadfsafsafdsafsa"
                + "fdsafsadfsafddsafdsa"
                + "fdsafsadfasdasasdfasdfdsafasdfdsafdsafasdfasdfasfasdfadsfadsfsadfsafddsafsafdsafads"
                + "fsdafsadfsadfsadfaasdfasdfasdfsadfsadfasdfasdfadsfdsafsadfdsafsadfsadfds"
                + "fsadfasddddddddddddddddddddddddddddddddddddd", "1111");
        _test.validate(command);
    }
}
