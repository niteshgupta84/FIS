package ae.emaratech.uaevision.arrest.application.validators;

import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.notification.NotificationBusinessException;
import ae.emaratech.uaevision.fis.party.application.CreatePartyCommand;
import ae.emaratech.uaevision.fis.party.application.UpdatePartyCommand;
import ae.emaratech.uaevision.fis.party.application.dto.ChargeDto;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.application.dto.PassportDto;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Attribute;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

/**
 * Created by Nitesh.Gupta on 7/13/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestPartyValidatorTest {
    @InjectMocks
    private ArrestPartyValidator _test;


    @Mock
    private NotificationBus notificationBus;

    @Mock
    private LookupService lookupService;

    @Before
    public void init() {
        // Setting the behaviour of mocked dependencies.
        doThrow(NotificationBusinessException.class).when(notificationBus)
                .send(any(NotificationBuilder.class));
        NotificationBuilder notificationBuilder = new NotificationBuilder();
        doReturn(notificationBuilder).when(notificationBus).getBuilder();
        Entry entry = new Entry(1L, "lk_key");
        Optional option = Optional.of(entry);
        doReturn(option).when(lookupService).getLookupEntry(any(),any(),any());
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfNoPartyFound() {
        List<PartyDto> lisOfParties = new ArrayList<>();
        CreatePartyCommand command = new CreatePartyCommand(lisOfParties);
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfNoAccusedPartyFound() {
        List<PartyDto> lisOfParties = new ArrayList<>();
        PartyDto partyDto = new PartyDto();
        List<Attribute> listOfAttributes = new ArrayList<>();
        listOfAttributes.add(new Attribute("IS_CHARABLE", "0"));
        partyDto.setPartytype(new Entry(1L, "Name", -1L, listOfAttributes));
        partyDto.setIsDeleted(0L);
        lisOfParties.add(partyDto);
        CreatePartyCommand command = new CreatePartyCommand(lisOfParties);
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfNoValidPartyFound() {
        List<PartyDto> lisOfParties = new ArrayList<>();
        PartyDto partyDto = new PartyDto();
        partyDto.setPartytype(new Entry(1L));
        partyDto.setIsDeleted(1L);
        lisOfParties.add(partyDto);
        CreatePartyCommand command = new CreatePartyCommand(lisOfParties);
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfNoChargesFoundForAccused() {
        List<PartyDto> lisOfParties = new ArrayList<>();
        PartyDto partyDto = new PartyDto();
        List<Attribute> listOfAttributes = new ArrayList<>();
        listOfAttributes.add(new Attribute("IS_CHARABLE", "0"));
        partyDto.setPartytype(new Entry(1L, "Name", -1L, listOfAttributes));
        partyDto.setIsDeleted(0L);
        lisOfParties.add(partyDto);
        CreatePartyCommand command = new CreatePartyCommand(lisOfParties);
        _test.validate(command);
    }


    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfNoPartyFoundForEdit() {
        List<PartyDto> lisOfParties = new ArrayList<>();
        UpdatePartyCommand command = new UpdatePartyCommand(lisOfParties);
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfNoAccusedPartyFoundForEdit() {
        List<PartyDto> lisOfParties = new ArrayList<>();
        PartyDto partyDto = new PartyDto();
        List<Attribute> listOfAttributes = new ArrayList<>();
        listOfAttributes.add(new Attribute("IS_CHARABLE", "0"));
        partyDto.setPartytype(new Entry(1L, "Name", -1L, listOfAttributes));
        partyDto.setIsDeleted(0L);
        lisOfParties.add(partyDto);
        UpdatePartyCommand command = new UpdatePartyCommand(lisOfParties);
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfNoValidPartyFoundForEdit() {
        List<PartyDto> lisOfParties = new ArrayList<>();
        PartyDto partyDto = new PartyDto();
        partyDto.setPartytype(new Entry(1L));
        partyDto.setIsDeleted(1L);
        lisOfParties.add(partyDto);
        UpdatePartyCommand command = new UpdatePartyCommand(lisOfParties);
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfNoChargesFoundForAccusedForEdit() {
        List<PartyDto> lisOfParties = new ArrayList<>();
        PartyDto partyDto = new PartyDto();
        partyDto.setPartytype(new Entry(3L));
        partyDto.setIsDeleted(0L);
        List<Attribute> listOfAttributes = new ArrayList<>();
        listOfAttributes.add(new Attribute("IS_CHARABLE", "0"));
        partyDto.setPartytype(new Entry(1L, "Name", -1L, listOfAttributes));
        lisOfParties.add(partyDto);
        UpdatePartyCommand command = new UpdatePartyCommand(lisOfParties);
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfNoAccusedPartyFoundWhenAccusedPartyMandatoryTrueDuringEdit() {
        List<PartyDto> lisOfParties = new ArrayList<>();
        PartyDto partyDto = new PartyDto();
        partyDto.setPartytype(new Entry(1L));
        partyDto.setIsDeleted(0L);

        List<ChargeDto> listOfCharges = new ArrayList();
        ChargeDto chargeDto = new ChargeDto();
        chargeDto.setChargeId(1L);

        partyDto.setListofCharges(listOfCharges);

        List<Attribute> listOfAttributes = new ArrayList<>();
        listOfAttributes.add(new Attribute("IS_CHARABLE", "0"));
        partyDto.setPartytype(new Entry(1L, "Name", -1L, listOfAttributes));
        lisOfParties.add(partyDto);
        UpdatePartyCommand command = new UpdatePartyCommand(lisOfParties);
        _test.validate(command);
    }

    @Test
    public void shouldValidateIfNoAccusedPartyFoundWhenAccusedMandatoryFalseDuringEdit() {
        List<PartyDto> lisOfParties = new ArrayList<>();
        PartyDto partyDto = new PartyDto();
        partyDto.setPartytype(new Entry(1L));
        partyDto.setIsDeleted(0L);

        List<ChargeDto> listOfCharges = new ArrayList();
        ChargeDto chargeDto = new ChargeDto();
        chargeDto.setChargeId(1L);
        partyDto.setEmailAddress("nitesh841@gmail.com");
        partyDto.setPhoneNumber("nitesh");
        partyDto.setListofCharges(listOfCharges);
        List<PassportDto> list = new ArrayList<>();
        list.add(new PassportDto());
        partyDto.setPassports(list);
        List<Attribute> listOfAttributes = new ArrayList<>();
        listOfAttributes.add(new Attribute("IS_CHARABLE", "0"));
        partyDto.setPartytype(new Entry(1L, "Name", -1L, listOfAttributes));
        lisOfParties.add(partyDto);
        UpdatePartyCommand command = new UpdatePartyCommand(lisOfParties);
        command.setAccusedMandatory(false);
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnExceptionIfNoAccusedPartyFoundWhenAccusedPartyMandatoryTrueDuringCreate() {
        List<PartyDto> lisOfParties = new ArrayList<>();
        PartyDto partyDto = new PartyDto();
        partyDto.setPartytype(new Entry(1L));
        partyDto.setIsDeleted(0L);

        List<ChargeDto> listOfCharges = new ArrayList();
        ChargeDto chargeDto = new ChargeDto();
        chargeDto.setChargeId(1L);
        partyDto.setEmailAddress("nitesh841@gmail.com");
        partyDto.setPhoneNumber("nitesh");
        partyDto.setListofCharges(listOfCharges);

        List<Attribute> listOfAttributes = new ArrayList<>();
        listOfAttributes.add(new Attribute("IS_CHARABLE", "0"));
        partyDto.setPartytype(new Entry(1L, "Name", -1L, listOfAttributes));
        lisOfParties.add(partyDto);
        CreatePartyCommand command = new CreatePartyCommand(lisOfParties);
        _test.validate(command);
    }

    @Test
    public void shouldValidateIfNoAccusedPartyFoundWhenAccusedPartyMandatoryFalseDuringCreate() {
        List<PartyDto> lisOfParties = new ArrayList<>();
        PartyDto partyDto = new PartyDto();
        partyDto.setPartytype(new Entry(1L));
        partyDto.setIsDeleted(0L);

        List<ChargeDto> listOfCharges = new ArrayList();
        ChargeDto chargeDto = new ChargeDto();
        chargeDto.setChargeId(1L);

        partyDto.setListofCharges(listOfCharges);
        partyDto.setEmailAddress("nitesh841@gmail.com");
        partyDto.setPhoneNumber("nitesh");
        List<PassportDto> list = new ArrayList<>();
        list.add(new PassportDto());
        partyDto.setPassports(list);
        List<Attribute> listOfAttributes = new ArrayList<>();
        listOfAttributes.add(new Attribute("IS_CHARABLE", "0"));
        partyDto.setPartytype(new Entry(1L, "Name", -1L, listOfAttributes));
        lisOfParties.add(partyDto);
        CreatePartyCommand command = new CreatePartyCommand(lisOfParties);
        command.setAccusedMandatory(false);
        _test.validate(command);
    }

}
