package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.document.application.AttachedDocumentDto;
import ae.emaratech.uaevision.document.service.api.DocumentService;
import ae.emaratech.uaevision.document.service.dto.DocumentReferenceDto;
import ae.emaratech.uaevision.fis.common.key.AttachmentReferenceKey;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.fis.user.service.dto.User;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;

/**
 * Created by Nitesh.Gupta on 4/21/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestAttachmentMapperTest {

    @InjectMocks
    ArrestAttachmentMapper arrestAttachmentMapper;
    @Mock
    private LookupService lookupService;
    @Mock
    private DocumentService documentService;

    @Mock
    protected UserService userDetailsService;

    @Test
    public void shouldReturnGuaranteeAttachmentObjectFromGivenDto() {

        AttachmentReferenceKey key = new AttachmentReferenceKey(1L);
        ArrestAttachment guaranteeAttachment = new ArrestAttachment(key);
        guaranteeAttachment.setArrestReport(ArrestReportDataConstants.getArrestData());

        guaranteeAttachment.setCreatedBy("nitesh");
        guaranteeAttachment.setCreatedDate(new Date());
        Optional<Entry> entry = Optional.of(new Entry(1L, "Test"));
        DocumentReferenceDto documentReferenceDto = new DocumentReferenceDto();
        documentReferenceDto.setFileName("Test");
        documentReferenceDto.setDocumentType(new Entry(1L, "Test"));
        documentReferenceDto.setAttachmentType(1L);
        documentReferenceDto.setMimeTypeId(1L);
        doReturn(entry).when(lookupService).getLookupEntry(any(), any(), any());
        doReturn(documentReferenceDto).when(documentService).downloadDocument(any());
        AttachedDocumentDto
                attachedDocumentDto =
                arrestAttachmentMapper.mapArrestAttachmentDto(guaranteeAttachment);
        assertThat(attachedDocumentDto).isNotNull();
        Mockito.doReturn(new User()).when(userDetailsService).getUser(Matchers.any(), Matchers.any(),Matchers.anyBoolean());
        assertThat(guaranteeAttachment.getArrestReport()).isNotNull();
    }


}
