package ae.emaratech.uaevision.arrest.domain;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashSet;
import java.util.Set;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.key.SeizureKey;
import ae.emaratech.uaevision.fis.common.key.TrackerKey;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Nitesh.Gupta on 7/6/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class SeizureMapperTest {

    @InjectMocks
    SeizureMapper _test;

    @Test
    public void shouldMapSeizureDto() {
        SeizureKey seizureKey = new SeizureKey(1L);
        ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
        Set<ArrestParty> arrestParties = new HashSet<>();
        ArrestParty arrestParty = new ArrestParty(new PartyKey(1L));
        arrestParties.add(arrestParty);
        ArrestReason arrestReason = new ArrestReason(9999L);
        ArrestDescription arrestDescription = new ArrestDescription("Test");
        ArrestLocation arrestLocation = new ArrestLocation(1L, 1L, 1L, LocationType.LOC, "Test", "Test", "Test", "Description", 1L);
        Owner owner = new Owner(Department.DETECTIVE, Section.CRM, null);
        Arrest arrestReport = new Arrest(arrestReportKey, arrestReason, arrestDescription, arrestLocation, arrestParties, owner, new TrackerKey(123L),"");
        Seizure seizure = new Seizure(seizureKey, "Chaku", 1L, 0L);
        seizure.setArrestReport(arrestReport);
        seizure.withItemName("TEst");
        seizure.withItemCount(5L);
        assertThat(_test.mapToSeizureDto(seizure)).isNotNull();
        assertThat(seizure.getArrestReport()).isNotNull();
        assertThat(seizure.getItemCount()).isNotNull();
        assertThat(seizure.getItemName()).isNotNull();
        assertThat(seizure.getCreatedBy()).isNull();
        assertThat(seizure.getCreatedDate()).isNull();
        seizure.equals(seizure);
    }

    @Test
    public void shouldMapDtoList() {
        SeizureKey seizureKey = new SeizureKey(1L);
        ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
        Set<ArrestParty> arrestParties = new HashSet<>();
        ArrestParty arrestParty = new ArrestParty(new PartyKey(1L));
        arrestParties.add(arrestParty);
        ArrestReason arrestReason = new ArrestReason(9999L);
        ArrestDescription arrestDescription = new ArrestDescription("Test");
        ArrestLocation arrestLocation = new ArrestLocation(1L, 1L, 1L, LocationType.LOC, "Test", "Test", "Test", "Description", 1L);
        Owner owner = new Owner(Department.DETECTIVE, Section.CRM, null);
        Arrest arrestReport = new Arrest(arrestReportKey, arrestReason, arrestDescription, arrestLocation, arrestParties, owner, new TrackerKey(123L),"");
        Seizure seizure = new Seizure(seizureKey, "Chaku", 1L, 0L);
        seizure.setArrestReport(arrestReport);

        Set<Seizure> entities = new HashSet<>();
        entities.add(seizure);
        assertThat(_test.mapToDtoList(entities)).isNotNull().hasSize(1);
    }

}
