package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.application.dto.ArrestNoteDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestPartyDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;
import ae.emaratech.uaevision.arrest.application.dto.SeizureDto;
import ae.emaratech.uaevision.arrest.application.validators.ArrestReportValidator;
import ae.emaratech.uaevision.arrest.application.validators.ArrestTeamValidator;
import ae.emaratech.uaevision.arrest.application.validators.SeizureValidator;
import ae.emaratech.uaevision.arrest.domain.*;
import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.IncidentNumberProvider;
import ae.emaratech.uaevision.fis.common.domain.TrackerKeyProvider;
import ae.emaratech.uaevision.fis.common.infrastructure.EventBus;
import ae.emaratech.uaevision.fis.common.key.*;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;

import static org.assertj.core.api.StrictAssertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anySet;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.*;

/**
 * Created by Nitesh.Gupta on 7/12/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestApplicationServiceImplTest {

    @Mock
    private ArrestKeyProvider arrestReportKeyProvider;

    @Mock
    private SeizureKeyProvider seizureKeyProvider;

    @Mock
    private ArrestTeamKeyProvider arrestTeamKeyProvider;

    @Mock
    private ArrestNoteKeyProvider arrestNoteKeyProvider;

    @Mock
    private TrackerKeyProvider trackerKeyProvider;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private ArrestRepository arrestRepository;

    @Mock
    private NotificationBus mockNotificationBus;

    @Mock
    private EventBus<DomainEvent> eventBus;

    @Mock
    private ArrestActionHistoryRepository arrestActionHistoryRepository;

    @Mock
    private ArrestStatusHistoryRepository arrestStatusHistoryRepository;

    @Mock
    private SeizureValidator seizureValidator;

    @Mock
    private ArrestTeamValidator arrestTeamValidator;

    @Mock
    private ArrestReportValidator arrestReportValidator;

    @Mock
    private IncidentNumberProvider incidentNumberProvider;

    @InjectMocks
    private ArrestReportApplicationServiceImpl _test;

    @Before
    public void init() {
        doReturn(mock(NotificationBuilder.class)).when(mockNotificationBus).getBuilder();
        doReturn(new TrackerKey(1L)).when(trackerKeyProvider).next();
        doReturn("test").when(incidentNumberProvider).next(anyLong(),anyLong(),anyString());
    }

    @Test
    public void shouldCloseArrest() {

        // Preparing test data.
        ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
        CloseArrestReportCommand closeArrestReportCommand =
                new CloseArrestReportCommand(arrestReportKey, "completionComments");
        Arrest arrest = mock(Arrest.class);
        ArrestReportClosedEvent arrestReportClosedEvent =
                mock(ArrestReportClosedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(arrest).when(arrestRepository).findOne(arrestReportKey.id());
        doReturn(arrestReportClosedEvent).when(arrest)
                .close(anyString());

        // Invoking the complete operation on the _test
        _test.close(closeArrestReportCommand);

        // Verifies whether interrogation domain was saved.
        verify(arrestRepository, times(1)).save(arrest);
        // Verifies whether interrogation action history was saved.
        verify(arrestActionHistoryRepository, times(1)).save(isA(ArrestActionHistory.class));
        // Verifies whether interrogation status history was saved.
        verify(arrestStatusHistoryRepository, times(1)).save(isA(ArrestStatusHistory.class));
        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(ArrestReportClosedEvent.class));
    }

    @Test
    public void shouldNotCloseArrestIfArrestCommentNotProvided() {

        // Preparing test data.
        ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
        CloseArrestReportCommand closeArrestReportCommand =
                new CloseArrestReportCommand(arrestReportKey, "");
        Arrest arrest = mock(Arrest.class);
        ArrestReportClosedEvent arrestReportClosedEvent =
                mock(ArrestReportClosedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(arrest).when(arrestRepository).findOne(arrestReportKey.id());
        doReturn(arrestReportClosedEvent).when(arrest)
                .close(anyString());

        // Invoking the complete operation on the _test
        _test.close(closeArrestReportCommand);


        // Verifies whether interrogation action history was saved.
        verify(arrestActionHistoryRepository, times(1)).save(isA(ArrestActionHistory.class));
        // Verifies whether interrogation status history was saved.
        verify(arrestStatusHistoryRepository, times(1)).save(isA(ArrestStatusHistory.class));
        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(ArrestReportClosedEvent.class));
    }


  /*@Test
  public void shouldReturnErrorIfCommentsNotGiven() {

    // Preparing test data.
    ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
    ReviewArrestReportCommand reviewArrestReportCommand =
        new ReviewArrestReportCommand(arrestReportKey, null);
    Arrest arrest = mock(Arrest.class);
    ArrestReportReviewedEvent arrestReportReviewedEvent =
        mock(ArrestReportReviewedEvent.class);

    // Setting the behaviour of mocked dependencies.
    doReturn(arrest).when(arrestRepository).findOne(arrestReportKey.id());
    doReturn(arrestReportReviewedEvent).when(arrest)
        .review("aaa");

    // Invoking the complete operation on the _test
    _test.review(reviewArrestReportCommand);

    // Verifies whether interrogation domain was saved.
    verify(arrestRepository, times(1)).save(arrest);
    // Verifies whether interrogation action history was saved.
    verify(arrestActionHistoryRepository, times(1)).save(isA(ArrestActionHistory.class));
    // Verifies whether interrogation status history was saved.
    verify(arrestStatusHistoryRepository, times(1)).save(isA(ArrestStatusHistory.class));
    // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
    // being published to the EventBus.
    verify(eventBus, times(1)).publish(isA(ArrestReportReviewedEvent.class));
  }*/

    @Test
    public void shouldReviewArrest() {

        // Preparing test data.
        ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
        ReviewArrestReportCommand reviewArrestReportCommand =
                new ReviewArrestReportCommand(arrestReportKey, "completionComments");
        Arrest arrest = mock(Arrest.class);
        ArrestReportReviewedEvent arrestReportReviewedEvent =
                mock(ArrestReportReviewedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(arrest).when(arrestRepository).findOne(arrestReportKey.id());
        doReturn(arrestReportReviewedEvent).when(arrest)
                .review(anyString());

        // Invoking the complete operation on the _test
        _test.review(reviewArrestReportCommand);

        // Verifies whether interrogation domain was saved.
        verify(arrestRepository, times(1)).save(arrest);
        // Verifies whether interrogation action history was saved.
        verify(arrestActionHistoryRepository, times(1)).save(isA(ArrestActionHistory.class));
        // Verifies whether interrogation status history was saved.
        verify(arrestStatusHistoryRepository, times(1)).save(isA(ArrestStatusHistory.class));
        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(ArrestReportReviewedEvent.class));
    }

    @Test
    public void shouldRejectArrest() {

        // Preparing test data.
        ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
        RejectArrestReportCommand rejectArrestReportCommand =
                new RejectArrestReportCommand(arrestReportKey, "completionComments");
        Arrest arrest = mock(Arrest.class);
        ArrestReportRejectedEvent arrestReportReviewedEvent =
                mock(ArrestReportRejectedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(arrest).when(arrestRepository).findOne(arrestReportKey.id());
        doReturn(arrestReportReviewedEvent).when(arrest)
                .reject(anyString());

        // Invoking the complete operation on the _test
        _test.reject(rejectArrestReportCommand);

        // Verifies whether interrogation domain was saved.
        verify(arrestRepository, times(1)).save(arrest);
        // Verifies whether interrogation action history was saved.
        verify(arrestActionHistoryRepository, times(1)).save(isA(ArrestActionHistory.class));
        // Verifies whether interrogation status history was saved.
        verify(arrestStatusHistoryRepository, times(1)).save(isA(ArrestStatusHistory.class));
        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(ArrestReportRejectedEvent.class));
    }

    @Test
    public void shouldForwardToCaseArrest() {

        // Preparing test data.
        ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
        ForwardArrestReportCommand forwardArrestReportCommand =
                new ForwardArrestReportCommand(arrestReportKey, "completionComments");
        Arrest arrest = mock(Arrest.class);
        ArrestReportForwardedEvent arrestReportForwardedEvent =
                mock(ArrestReportForwardedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(arrest).when(arrestRepository).findOne(arrestReportKey.id());
        doReturn(arrestReportForwardedEvent).when(arrest)
                .forwardToCase(anyString());

        // Invoking the complete operation on the _test
        _test.forwardToCase(forwardArrestReportCommand);

        // Verifies whether interrogation domain was saved.
        verify(arrestRepository, times(1)).save(arrest);
        // Verifies whether interrogation action history was saved.
        verify(arrestActionHistoryRepository, times(1)).save(isA(ArrestActionHistory.class));
        // Verifies whether interrogation status history was saved.
        verify(arrestStatusHistoryRepository, times(1)).save(isA(ArrestStatusHistory.class));
        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(ArrestReportForwardedEvent.class));
    }

    @Test
    public void shouldReopenCaseArrest() {

        // Preparing test data.
        ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
        ReOpenArrestReportCommand reOpenArrestReportCommand =
                new ReOpenArrestReportCommand(arrestReportKey);
        OrderKey orderKey = new OrderKey(1L);
        reOpenArrestReportCommand.forOrder(orderKey);
        Arrest arrest = mock(Arrest.class);
        ArrestReportReopenedEvent arrestReportReopenedEvent =
                mock(ArrestReportReopenedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(arrest).when(arrestRepository).findOne(arrestReportKey.id());
        doReturn(arrestReportReopenedEvent).when(arrest).reopen(orderKey);

        // Invoking the complete operation on the _test
        _test.reOpen(reOpenArrestReportCommand);

        // Verifies whether interrogation domain was saved.
        verify(arrestRepository, times(1)).save(arrest);
        // Verifies whether interrogation action history was saved.
        verify(arrestActionHistoryRepository, times(1)).save(isA(ArrestActionHistory.class));
        // Verifies whether interrogation status history was saved.
        verify(arrestStatusHistoryRepository, times(1)).save(isA(ArrestStatusHistory.class));
        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(ArrestReportReopenedEvent.class));
    }

    @Test
    public void shouldEndCaseArrest() {

        // Preparing test data.
        ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
        EndArrestReportCommand endArrestReportCommand =
                new EndArrestReportCommand(arrestReportKey, "Test");
        Arrest arrest = mock(Arrest.class);
        ArrestReportEndedEvent arrestReportEndedEvent =
                mock(ArrestReportEndedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(arrest).when(arrestRepository).findOne(arrestReportKey.id());
        doReturn(arrestReportEndedEvent).when(arrest)
                .end(anyString());

        // Invoking the complete operation on the _test
        _test.end(endArrestReportCommand);

        // Verifies whether interrogation domain was saved.
        verify(arrestRepository, times(1)).save(arrest);
        // Verifies whether interrogation action history was saved.
        verify(arrestActionHistoryRepository, times(1)).save(isA(ArrestActionHistory.class));
        // Verifies whether interrogation status history was saved.
        verify(arrestStatusHistoryRepository, times(1)).save(isA(ArrestStatusHistory.class));
        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(ArrestReportEndedEvent.class));
    }

    @Test
    public void shouldApproveCaseArrest() {

        // Preparing test data.
        ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
        ApproveArrestReportCommand approveArrestReportCommand =
                new ApproveArrestReportCommand(arrestReportKey, "Test");
        Arrest arrest = mock(Arrest.class);
        ArrestReportApprovedEvent arrestReportApprovedEvent =
                mock(ArrestReportApprovedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doReturn(arrest).when(arrestRepository).findOne(arrestReportKey.id());
        doReturn(arrestReportApprovedEvent).when(arrest)
                .approve(anyString());

        // Invoking the complete operation on the _test
        _test.approve(approveArrestReportCommand);

        // Verifies whether interrogation domain was saved.
        verify(arrestRepository, times(1)).save(arrest);
        // Verifies whether interrogation action history was saved.
        verify(arrestActionHistoryRepository, times(1)).save(isA(ArrestActionHistory.class));
        // Verifies whether interrogation status history was saved.
        verify(arrestStatusHistoryRepository, times(1)).save(isA(ArrestStatusHistory.class));
        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(ArrestReportApprovedEvent.class));
    }

    @Test
    public void shouldCreateArrestReport() {

        List<ArrestPartyDto> partyDtoList = new ArrayList<>();
        ArrestPartyDto arrestPartyDto = new ArrestPartyDto();
        arrestPartyDto.setPartyId(1L);
        arrestPartyDto.setPartyType(new Entry(1L));
        arrestPartyDto.setArrestReportId(1L);
        partyDtoList.add(arrestPartyDto);
        List<PartyKey> partyKeyList = new ArrayList<>();
        ArrestNoteDto arrestNoteDto = new ArrestNoteDto();
        arrestNoteDto.setId(0);
        arrestNoteDto.setIsDeleted(1L);
        List<ArrestNoteDto> noteList = new ArrayList<>();
        noteList.add(arrestNoteDto);

        List<SeizureDto> seizureDtoList = new ArrayList<>();
        SeizureDto seizureDto = new SeizureDto();
        seizureDto.setId(0L);
        seizureDto.setSeizureId(0L);
        seizureDto.setCount("1");
        seizureDtoList.add(seizureDto);

        List<ArrestTeamDto> arrestTeamDtoList = new ArrayList<>();
        ArrestTeamDto arrestTeamDto = new ArrestTeamDto();
        arrestTeamDto.setId(0L);
        arrestTeamDto.setArrestTeamId(0L);
        arrestTeamDtoList.add(arrestTeamDto);

        List<AssociatedArrestReportKey> arrestAssociationDtoList = new ArrayList<>();
        AssociatedArrestReportKey arrestAssociationDto = new AssociatedArrestReportKey(1L);
        arrestAssociationDtoList.add(arrestAssociationDto);

        List<AttachmentReferenceKey> attachmentReferenceKeys = new ArrayList<>();
        AttachmentReferenceKey attachmentReferenceKey = new AttachmentReferenceKey(1L);
        attachmentReferenceKeys.add(attachmentReferenceKey);
        CreateArrestReportCommand command = new CreateArrestReportCommand.Builder(
                partyKeyList, new ArrestReason(1L), new ArrestDescription("TEst"), Section.CRM,
                Department.DETECTIVE
        ).withTerminalLocation(new Entry(1L))
                .withArea(new Entry(1L))
                .withArrestBuilding("TEst")
                .withArrestDate(new Date())
                .withArrestDateTime(new Date())
                .withArrestLocation("Test")
                .withArrestStreet("Street")
                .withArrestTime("10:00")
                .withCity(new Entry(1L))
                .withEmirate(new Entry(1L))
                .withIsCreatedByAhwal(false)

                .withIsUrgent(false)
                .withLocationDescription("Test")
                .withLocationType(LocationType.COORDINATES)
                .withUnit(new Entry(1L))
                .withTransferredFrom(new Entry(1L))
                .withSeizureList(seizureDtoList)
                .withArrestTeamList(arrestTeamDtoList)
                .withArrestPartyList(partyDtoList)
                .withAttachmentList(attachmentReferenceKeys)
                .build();

        Arrest arrest = mock(Arrest.class);
        ArrestReportCreatedEvent arrestReportCreatedEvent =
                mock(ArrestReportCreatedEvent.class);

        // Setting the behaviour of mocked dependencies.
        doNothing().when(arrestReportValidator).validate(command);
        doReturn(new ArrestReportKey(1L)).when(arrestReportKeyProvider).next();
        doReturn(new SeizureKey(1L)).when(seizureKeyProvider).next();
        doReturn(new ArrestTeamKey(1L)).when(arrestTeamKeyProvider).next();
        doReturn(new NoteKey(1L)).when(arrestNoteKeyProvider).next();


        // Invoking the complete operation on the _test
        _test.create(command);

        // Verifies whether interrogation domain was saved.
        verify(arrestRepository, times(0)).save(arrest);
        // Verifies whether interrogation action history was saved.
        verify(arrestActionHistoryRepository, times(1)).save(isA(ArrestActionHistory.class));
        // Verifies whether interrogation status history was saved.
        verify(arrestStatusHistoryRepository, times(1)).save(isA(ArrestStatusHistory.class));
        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(ArrestReportCreatedEvent.class));
    }

    @Test
    public void shouldUpdateArrestReport() {
        List<PartyKey> partyKeyList = new ArrayList<>();
        ArrestNoteDto arrestNoteDto = new ArrestNoteDto();
        arrestNoteDto.setId(1L);
        arrestNoteDto.setIsDeleted(1L);
        List<ArrestNoteDto> noteList = new ArrayList<>();
        noteList.add(arrestNoteDto);

        List<SeizureDto> seizureDtoList = new ArrayList<>();
        SeizureDto seizureDto = new SeizureDto();
        seizureDto.setId(1);
        seizureDto.setSeizureId(1L);
        seizureDto.setCount("1");
        seizureDtoList.add(seizureDto);

        List<ArrestTeamDto> arrestTeamDtoList = new ArrayList<>();
        ArrestTeamDto arrestTeamDto = new ArrestTeamDto();
        arrestTeamDto.setId(1L);
        arrestTeamDto.setArrestTeamId(1L);
        arrestTeamDtoList.add(arrestTeamDto);

        Set<AssociatedArrestReportKey> arrestAssociationDtoList = new HashSet<>();
        AssociatedArrestReportKey arrestAssociationDto = new AssociatedArrestReportKey(1L);
        arrestAssociationDtoList.add(arrestAssociationDto);

        List<AttachmentReferenceKey> attachmentReferenceKeys = new ArrayList<>();
        AttachmentReferenceKey attachmentReferenceKey = new AttachmentReferenceKey(1L);
        attachmentReferenceKeys.add(attachmentReferenceKey);
        UpdateArrestReportCommand
                command =
                new UpdateArrestReportCommand.Builder(new ArrestReportKey(1L),
                        partyKeyList, new ArrestReason(1L),
                        new ArrestDescription("TEst")
                ).withTerminalLocation(new Entry(1L))
                        .withArea(new Entry(1L))
                        .withArrestBuilding("TEst")
                        .withArrestDate(new Date())
                        .withArrestDateTime(new Date())
                        .withArrestLocation("Test")
                        .withArrestStreet("Street")
                        .withArrestTime("10:00")
                        .withCity(new Entry(1L))
                        .withEmirate(new Entry(1L))
                        .withIsCreatedByAhwal(false)

                        .withIsUrgent(false)
                        .withLocationDescription("Test")
                        .withLocationType(LocationType.COORDINATES)
                        .withUnit(new Entry(1L))
                        .withTransferredFrom(new Entry(1L))
                        .withSeizureList(seizureDtoList)
                        .withArrestTeamList(arrestTeamDtoList)
                        .withArrestNoteList(noteList)
                        .withDepartment(Department.DETECTIVE)
                        .withAssociatedArrestList(arrestAssociationDtoList)
                        .withAttachmentList(attachmentReferenceKeys)
                        .withArrestPartyList(new ArrayList<>())
                        .build();

        Arrest arrest = mock(Arrest.class);
        ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
        ArrestReportUpdatedEvent arrestReportUpdatedEvent =
                mock(ArrestReportUpdatedEvent.class);
        doReturn(arrest).when(arrestRepository).findOne(arrestReportKey.id());
        // Setting the behaviour of mocked dependencies.
        doNothing().when(arrestReportValidator).validate(command);
        doReturn(new ArrestReportKey(1L)).when(arrestReportKeyProvider).next();
        doReturn(new SeizureKey(1L)).when(seizureKeyProvider).next();
        doReturn(new ArrestTeamKey(1L)).when(arrestTeamKeyProvider).next();
        doReturn(new NoteKey(1L)).when(arrestNoteKeyProvider).next();
        doReturn(arrestReportUpdatedEvent).when(arrest).update(anyList(), anySet(), any(ArrestReason.class), any(ArrestDescription.class),
                any(ArrestLocation.class),
                anyList(), anySet(), anySet(),
                anySet(), anySet(),

                any(Entry.class),
                any(Entry.class),
                anyBoolean(),
                anyBoolean(),
                any(Date.class)
        ,anyLong(), any(Entry.class));

        // Invoking the complete operation on the _test
        _test.update(command);

        // Verifies whether interrogation domain was saved.
        verify(arrestRepository, times(1)).save(arrest);
        // Verifies whether interrogation action history was saved.
        //verify(arrestActionHistoryRepository, times(1)).save(isA(ArrestActionHistory.class));
        // Verifies whether interrogation status history was saved.
        verify(arrestStatusHistoryRepository, times(1)).save(isA(ArrestStatusHistory.class));
        // Verify whether the complete interrogation operation resulted in InterrogationCompletedEvent
        // being published to the EventBus.
        verify(eventBus, times(1)).publish(isA(ArrestReportUpdatedEvent.class));
    }

    @Test
    public void shouldAddSeizureInArrest() {
        AddSeizureCommand command = new AddSeizureCommand("Test", "1");
        SeizureDto seizureDto = new SeizureDto();
        seizureDto.setSeizureId(1L);
        seizureDto.setId(1L);
        List<SeizureDto> list = new ArrayList<>();
        list.add(seizureDto);
        command.withSeizureList(list);
        assertThat(_test.addSeizure(command)).isNotNull();
    }

    @Test
    public void shouldEditSeizureInArrest() {
        EditSeizureCommand command = new EditSeizureCommand(new SeizureKey(1L), "Test", "1");
        SeizureDto seizureDto = new SeizureDto();
        seizureDto.setSeizureId(1L);
        seizureDto.setId(1L);
        List<SeizureDto> list = new ArrayList<>();
        list.add(seizureDto);
        command.withSeizureList(list);
        assertThat(_test.modifySeizure(command)).isNotNull();
    }

    @Test
    public void shouldRemoveSeizureInArrest() {
        RemoveSeizureCommand command = new RemoveSeizureCommand(new SeizureKey(1L));
        SeizureDto seizureDto = new SeizureDto();
        seizureDto.setSeizureId(1L);
        seizureDto.setId(1L);
        List<SeizureDto> list = new ArrayList<>();
        list.add(seizureDto);
        command.withSeizureList(list);
        assertThat(_test.removeSeizure(command)).isNotNull();
    }

    @Test
    public void shouldAddArrestTeamInArrest() {
        AddArrestTeamCommand command = new AddArrestTeamCommand("10000");
        List<ArrestTeamDto> list = new ArrayList<>();
        command.withArrestTeam(list);
        command.withAOfficerNameAr("Test");
        command.withAOfficerNameEn("Test");
        ArrestTeamDto arrestTeamDto = new ArrestTeamDto();
        arrestTeamDto.setId(1L);
        arrestTeamDto.setArrestTeamId(1L);
        arrestTeamDto.setEmployeeId("10000");
        arrestTeamDto.setIsDeleted(1L);
        list.add(arrestTeamDto);
        assertThat(_test.addArrestTeam(command)).isNotNull();
    }

    @Test
    public void shouldEditArrestTeamInArrest() {
        EditArrestTeamCommand command = new EditArrestTeamCommand(new ArrestTeamKey(1L), "10000");
        List<ArrestTeamDto> list = new ArrayList<>();
        command.withArrestTeam(list);
        command.withAOfficerNameAr("Test");
        command.withAOfficerNameEn("Test");
        ArrestTeamDto arrestTeamDto = new ArrestTeamDto();
        arrestTeamDto.setId(1L);
        arrestTeamDto.setArrestTeamId(1L);
        list.add(arrestTeamDto);
        assertThat(_test.modifyArrestTeam(command)).isNotNull();
    }

    @Test
    public void shouldRemoveArrestTeamInArrest() {
        DeleteArrestTeamCommand command = new DeleteArrestTeamCommand(new ArrestTeamKey(1L));
        List<ArrestTeamDto> list = new ArrayList<>();
        command.withArrestTeam(list);
        ArrestTeamDto arrestTeamDto = new ArrestTeamDto();
        arrestTeamDto.setId(1L);
        arrestTeamDto.setArrestTeamId(1L);
        list.add(arrestTeamDto);
        assertThat(_test.removeArrestTeam(command)).isNotNull();
    }

    @Test
    public void shouldAddNoteInArrest() {
        AddNoteCommand command = new AddNoteCommand("Nitesh");
        List<ArrestNoteDto> noteDtoList = new ArrayList<>();
        ArrestNoteDto arrestNoteDto = new ArrestNoteDto();
        arrestNoteDto.setId(1L);
        arrestNoteDto.setViewId(1L);
        arrestNoteDto.setDisplayTextNote("test");
        arrestNoteDto.setIsDeleted(0L);
        noteDtoList.add(arrestNoteDto);
        command.withNoteList(noteDtoList);
        assertThat(_test.addNote(command)).isNotNull();
    }

    @Test
    public void shouldEditNoteInArrest() {
        EditNoteCommand command = new EditNoteCommand(new NoteKey(1L), "Nitesh");
        List<ArrestNoteDto> noteDtoList = new ArrayList<>();
        ArrestNoteDto arrestNoteDto = new ArrestNoteDto();
        arrestNoteDto.setId(1L);
        arrestNoteDto.setDisplayTextNote("test");
        arrestNoteDto.setIsDeleted(0L);
        arrestNoteDto.setViewId(1L);
        noteDtoList.add(arrestNoteDto);
        command.withNoteList(noteDtoList);
        assertThat(_test.modifyNote(command)).isNotNull();
    }

    @Test
    public void shouldRemoveNoteInArrest() {
        DeleteNoteCommand command = new DeleteNoteCommand(new NoteKey(1L));
        List<ArrestNoteDto> noteDtoList = new ArrayList<>();
        ArrestNoteDto arrestNoteDto = new ArrestNoteDto();
        arrestNoteDto.setId(1L);
        arrestNoteDto.setViewId(1L);
        arrestNoteDto.setDisplayTextNote("test");
        arrestNoteDto.setIsDeleted(0L);
        noteDtoList.add(arrestNoteDto);
        command.withNoteList(noteDtoList);
        assertThat(_test.removeNote(command)).isNotNull();
    }

    @Test
    public void shouldAssignArrestToUser() {
        ArrestReportKey arrestReportKey = new ArrestReportKey(1L);

        AssignArrestCommand command = new AssignArrestCommand(arrestReportKey, "K_khajah");
        Arrest arrest = mock(Arrest.class);
        doReturn(arrest).when(arrestRepository).findOne(arrestReportKey.id());
        doReturn(mock(ArrestAssignedEvent.class)).when(arrest).assignUser(anyString());
        _test.arrestAssignment(command);
        verify(arrestRepository, times(1)).save(arrest);
    }
}
