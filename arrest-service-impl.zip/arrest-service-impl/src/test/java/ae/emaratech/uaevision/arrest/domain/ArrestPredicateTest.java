package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.query.RetrieveArrestBySearchQuery;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestsWithOwnerDetailQuery;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;

import static org.assertj.core.api.StrictAssertions.assertThat;

/**
 * Created by Nitesh.Gupta on 7/11/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestPredicateTest {
    /**
     * Predicate Test which will return Null
     */
    @Test
    public void shouldReturnNoPredicateOrNull() {
        BooleanExpression booleanExpression = ArrestPredicates.hasNoPredicate();
        assertThat(booleanExpression).isEqualTo(null);
    }

    /**
     * Predicate Test which will return Order Specifier desc by CreatedDate
     */
    @Test
    public void shouldReturnOrderSpecifier() {
        OrderSpecifier orderSpecifier = ArrestPredicates.getOrderSpecifier();
        assertThat(orderSpecifier).isInstanceOf(OrderSpecifier.class);
    }

    /**
     * Checks if Predicate returned is having where criteria to find out history
     */
    @Test
    public void shouldReturnArrestHistoryIfIdProvided() {
        ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
        Predicate predicate = ArrestPredicates.getHistoryByArrestId(arrestReportKey);
        assertThat(predicate).isNotNull();
    }

    /**
     * Predicate which having a criteria to build Order Specifier
     */
    @Test
    public void shouldReturnArrestHistoryOrderSpecifier() {
        OrderSpecifier orderSpecifier = ArrestPredicates.getActionHistoryOrderSpecifier();
        assertThat(orderSpecifier).isInstanceOf(OrderSpecifier.class);
        assertThat(orderSpecifier).isNotNull();
    }

    @Test
    public void shouldReturnArrestByOwnerDetailsIfSectionOnlyProvided() {
        RetrieveArrestsWithOwnerDetailQuery query = new RetrieveArrestsWithOwnerDetailQuery(1L);
        Predicate predicate = ArrestPredicates.getArrestByOwnerDetails(query);
        assertThat(predicate).isNotNull();
    }

    @Test
    public void shouldReturnArrestByOwnerDetailsIfUserProvided() {
        RetrieveArrestsWithOwnerDetailQuery query = new RetrieveArrestsWithOwnerDetailQuery(1L);
        query.withUser("Test");
        Predicate predicate = ArrestPredicates.getArrestByOwnerDetails(query);
        assertThat(predicate).isNotNull();
    }

    @Test
    public void shouldReturnArrestIfSearchCriteriaProvided() {
        RetrieveArrestBySearchQuery retrieveArrestBySearchQuery = new RetrieveArrestBySearchQuery();
        retrieveArrestBySearchQuery.setSection(new Entry(1L));
        retrieveArrestBySearchQuery.setSectionUnit(new Entry(1L));
        retrieveArrestBySearchQuery.setFirNo("Test");
        retrieveArrestBySearchQuery.setArrestNumber("30/00000001/2014");
        retrieveArrestBySearchQuery.setCreatedBy("Test");
        retrieveArrestBySearchQuery.setAreaLk(new Entry(1L));
        retrieveArrestBySearchQuery.setArrestReason(new Entry(1L));
        retrieveArrestBySearchQuery.setTransferredFrom(new Entry(1L));
        retrieveArrestBySearchQuery.setCityLk(new Entry(1L));
        retrieveArrestBySearchQuery.setEmirateLk(new Entry(1L));
        retrieveArrestBySearchQuery.setTerminalLocation(new Entry(1L));
        retrieveArrestBySearchQuery.setUrgent(true);
        retrieveArrestBySearchQuery.setCreatedDate(new Date());
        retrieveArrestBySearchQuery.setCreatedBy("Nitesh");
        retrieveArrestBySearchQuery.setArrestDate(new Date());
        retrieveArrestBySearchQuery.setArrestTime("10:00");
        retrieveArrestBySearchQuery.setArrestTimeTo("12:00");
        retrieveArrestBySearchQuery.setArrestDateTo(new Date());
        retrieveArrestBySearchQuery.setDepartment(new Entry(1L));
        retrieveArrestBySearchQuery.setStatus(new Entry(1L));
        Predicate predicate = ArrestPredicates.getArrestBySearchCriteria(retrieveArrestBySearchQuery);
        assertThat(predicate).isNotNull();
    }

    @Test
    public void shouldReturnArrestIfNoSearchCriteriaProvided() {
        RetrieveArrestBySearchQuery retrieveArrestBySearchQuery = new RetrieveArrestBySearchQuery();
        retrieveArrestBySearchQuery.setSection(new Entry(1L));
        Predicate predicate = ArrestPredicates.getArrestBySearchCriteria(retrieveArrestBySearchQuery);
        assertThat(predicate).isNotNull();
    }
}
