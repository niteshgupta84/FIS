package ae.emaratech.uaevision.arrest.domain;

import java.util.HashSet;
import java.util.Set;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.key.TrackerKey;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;

/**
 * Created by Nitesh.Gupta on 7/10/2016.
 */
public class ArrestReportDataConstants {

    public static Arrest getArrestData() {
        ArrestReportKey arrestReportKey = new ArrestReportKey(1L);
        Set<ArrestParty> arrestParties = new HashSet<>();
        ArrestParty arrestParty = new ArrestParty(new PartyKey(1L));

        arrestParties.add(arrestParty);
        ArrestReason arrestReason = new ArrestReason(9999L);
        ArrestDescription arrestDescription = new ArrestDescription("Test");
        ArrestLocation arrestLocation = new ArrestLocation(1L, 1L, 1L, LocationType.LOC, "Test", "Test", "Test", "Description", 1L);
        Owner owner = new Owner(Department.DETECTIVE, Section.CRM, null);
        Arrest arrestReport = new Arrest(arrestReportKey, arrestReason, arrestDescription, arrestLocation, arrestParties, owner, new TrackerKey(1233L),"");
        return arrestReport;
    }
}
