package ae.emaratech.uaevision.arrest.query;

import ae.emaratech.uaevision.arrest.application.ArrestPageBuilder;
import ae.emaratech.uaevision.arrest.application.dto.*;
import ae.emaratech.uaevision.arrest.domain.*;
import ae.emaratech.uaevision.document.application.AttachedDocumentDto;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.key.TrackerKey;
import ae.emaratech.uaevision.fis.common.notification.Notification;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.gateway.incident.UserManagementServiceClient;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import com.google.common.collect.Sets;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

/**
 * Created by Nitesh.Gupta on 7/13/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestQueryServiceImplTest {

    @InjectMocks
    private ArrestQueryServiceImpl _test;
    @Mock
    private ArrestActionHistoryRepository arrestActionHistoryRepository;

    @Mock
    private ArrestActionHistoryMapper arrestActionHistoryMapper;

    @Mock
    private UserManagementServiceClient userManagementServiceClient;

    @Mock
    private ArrestRepository arrestRepository;

    @Mock
    private ArrestMapper arrestMapper;

    @Mock
    private NotificationBus mockNotificationBus;
    @Mock
    private ArrestTeamMapper arrestTeamMapper;

    @Mock
    private SeizureMapper seizureMapper;

    @Mock
    private ArrestAssociationMapper arrestAssociationMapper;

    @Mock
    private ArrestAttachmentMapper arrestAttachmentMapper;

    @Mock
    private ArrestNoteMapper arrestNoteMapper;

    @Before
    public void init() {
        NotificationBuilder mockNotificationBuilder = mock(NotificationBuilder.class);
        doReturn(mock(Notification.class)).when(mockNotificationBuilder).createNotification();
        doReturn(mockNotificationBuilder).when(mockNotificationBus).getBuilder();
    }

    @Test
    public void shouldReturnArrestActionHistoryIfArrestIdGiven() {
        RetrieveArrestHistoryQuery retrieveHistoryQuery =
                new RetrieveArrestHistoryQuery(new ArrestReportKey(1L));
// Create Predicate to retrieve InterrogationHistory instances for interrogation identifier.
        Predicate predicate =
                ArrestPredicates.getHistoryByArrestId(
                        retrieveHistoryQuery.getArrestReportKey());
        // Create order specifier for ordering the InterrogationHistory instances based on created date.
        OrderSpecifier orderSpecifier = ArrestPredicates.getActionHistoryOrderSpecifier();
        List<ArrestActionHistory> arrestActionHistories = new ArrayList<>();
        ArrestActionHistory arrestActionHistory =
                new ArrestActionHistory.Builder(1L)
                        .withActionId(ArrestAction.OPEN.id())
                        .withComments("CancelComments")
                        .build();

        arrestActionHistories.add(arrestActionHistory);
        doReturn(arrestActionHistories).when(arrestActionHistoryRepository)
                .findAll(any(Predicate.class), any(OrderSpecifier.class));

        List<ArrestReportTrackDto> arrestReportTrackDtos = new ArrayList<>();
        ArrestReportTrackDto arrestReportTrackDto = new ArrestReportTrackDto();
        arrestReportTrackDtos.add(arrestReportTrackDto);
        doReturn(arrestReportTrackDto).when(arrestActionHistoryMapper).mapArrestTrackDto(
                any());

        assertThat(_test.retrieveArrestHistory(retrieveHistoryQuery))
                .isNotNull();
    }

    @Test
    public void shouldValidateActiveArrestForParty() {

        // Mock Dependencies
        ValidateActiveArrestForPartyQuery mockQuery =
                new ValidateActiveArrestForPartyQuery(Arrays.asList(2L));

        Iterable<Arrest> activeArrestForUDBList = new Iterable<Arrest>() {
            @Override
            public Iterator<Arrest> iterator() {
                Set<ArrestParty> arrestParties = Sets.newHashSet(new ArrestParty(new PartyKey(2L)));
                return Arrays.asList(
                        new Arrest(new ArrestReportKey(2L), new ArrestReason(2L),
                                new ArrestDescription("ARRESTED"), null, arrestParties, null, new TrackerKey(233L),""))
                        .iterator();
            }
        };
        doReturn(new ArrestReportDto()).when(arrestMapper).mapToArrestReportDto(any(Arrest.class));
        doReturn(activeArrestForUDBList).when(arrestRepository).findAll(any(Predicate.class),any(OrderSpecifier.class));

        // Invoke the operation on _test
        Notification notification = _test.validateActiveArrestForParty(mockQuery);
        assertThat(notification).isNotNull();
    }

    @Test
    public void shouldNotValidateWhenNoActiveArrestExistsForParty() {

        // Mock Dependencies
        ValidateActiveArrestForPartyQuery mockQuery =
                new ValidateActiveArrestForPartyQuery(Arrays.asList(2L));

        Iterable<Arrest> activeArrestForUDBList = new Iterable<Arrest>() {
            @Override
            public Iterator<Arrest> iterator() {
                return new HashSet<Arrest>().iterator();
            }
        };
        doReturn(new ArrestReportDto()).when(arrestMapper).mapToArrestReportDto(any(Arrest.class));
        doReturn(activeArrestForUDBList).when(arrestRepository).findAll(any(Predicate.class),any(OrderSpecifier.class));

        // Invoke the operation on _test
        Notification notification = _test.validateActiveArrestForParty(mockQuery);
        assertThat(notification).isNull();
    }

    @Test
    public void shouldReturnArrestTeamsForArrest() {
        RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(new ArrestReportKey(1L));
        Arrest arrest = ArrestReportDataConstants.getArrestData();
        doReturn(arrest).when(arrestRepository).findOne(anyLong());
        List<ArrestTeamDto> list = new ArrayList<>();
        doReturn(list).when(arrestTeamMapper).mapToDtoList(arrest.getArrestTeams());
        _test.retrieveArrestTeamsForArrest(retrieveArrestQuery);
    }

    @Test
    public void shouldReturnSeizuresForArrest() {
        RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(new ArrestReportKey(1L));
        Arrest arrest = ArrestReportDataConstants.getArrestData();
        doReturn(arrest).when(arrestRepository).findOne(anyLong());
        List<SeizureDto> list = new ArrayList<>();
        doReturn(list).when(seizureMapper).mapToDtoList(arrest.getSeizures());
        _test.retrieveSeizuresForArrest(retrieveArrestQuery);
    }

    @Test
    public void shouldReturnAssociationsForArrest() {
        RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(new ArrestReportKey(1L));
        Arrest arrest = ArrestReportDataConstants.getArrestData();
        doReturn(arrest).when(arrestRepository).findOne(anyLong());
        List<ArrestAssociationDto> list = new ArrayList<>();
        doReturn(list).when(arrestAssociationMapper).mapArrestAssociationDtoList(arrest.getArrestAssociations());
        _test.retrieveAssociationsForArrest(retrieveArrestQuery);
    }

    @Test
    public void shouldReturnAttachmentsForArrest() {
        RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(new ArrestReportKey(1L));
        Arrest arrest = ArrestReportDataConstants.getArrestData();
        doReturn(arrest).when(arrestRepository).findOne(anyLong());


        doReturn(mock(AttachedDocumentDto.class)).when(arrestAttachmentMapper).mapArrestAttachmentDto(any(ArrestAttachment.class));
        _test.retrieveAttachmentsForArrest(retrieveArrestQuery);
    }

    @Test
    public void shouldReturnNotesForArrest() {
        RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(new ArrestReportKey(1L));
        Arrest arrest = ArrestReportDataConstants.getArrestData();
        doReturn(arrest).when(arrestRepository).findOne(anyLong());
        List<ArrestNoteDto> list = new ArrayList<>();
        doReturn(list).when(arrestNoteMapper).mapToArrestNoteDtList(arrest
                .getNotes());
        _test.retrieveNotesForArrest(retrieveArrestQuery);
    }

    @Test
    public void shouldReturnEmptyArrestTeamsForArrest() {
        RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(new ArrestReportKey(1L));

        doReturn(null).when(arrestRepository).findOne(anyLong());
        List<ArrestTeamDto> list = new ArrayList<>();

        _test.retrieveArrestTeamsForArrest(retrieveArrestQuery);
    }

    @Test
    public void shouldReturnEmptySeizuresForArrest() {
        RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(new ArrestReportKey(1L));

        doReturn(null).when(arrestRepository).findOne(anyLong());
        List<SeizureDto> list = new ArrayList<>();

        _test.retrieveSeizuresForArrest(retrieveArrestQuery);
    }

    @Test
    public void shouldReturnEmptyAssociationsForArrest() {
        RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(new ArrestReportKey(1L));

        doReturn(null).when(arrestRepository).findOne(anyLong());
        List<ArrestAssociationDto> list = new ArrayList<>();

        _test.retrieveAssociationsForArrest(retrieveArrestQuery);
    }

    @Test
    public void shouldReturnEmptyAttachmentsForArrest() {
        RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(new ArrestReportKey(1L));

        doReturn(null).when(arrestRepository).findOne(anyLong());
        _test.retrieveAttachmentsForArrest(retrieveArrestQuery);
    }

    @Test
    public void shouldReturnEmptyNotesForArrestIfArrestNull() {
        RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(new ArrestReportKey(1L));

        doReturn(null).when(arrestRepository).findOne(anyLong());
        List<ArrestAssociationDto> list = new ArrayList<>();

        _test.retrieveNotesForArrest(retrieveArrestQuery);
    }

    @Test
    public void shouldReturnArrestForParty() {
        RetrieveArrestForPartyQuery query = new RetrieveArrestForPartyQuery(new PartyKey(1L));
        RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(new ArrestReportKey(1L));
        Arrest arrest = ArrestReportDataConstants.getArrestData();
        doReturn(arrest).when(arrestRepository).findOne(anyLong());

        doReturn(mock(ArrestReportDto.class)).when(arrestMapper).mapToArrestReportDto(arrest);
        _test.retrieveArrestReportForParty(query);
    }

    @Test
    public void shouldReturnArrestReport() {

        RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(new ArrestReportKey(1L));
        Arrest arrest = ArrestReportDataConstants.getArrestData();
        doReturn(arrest).when(arrestRepository).findOne(anyLong());

        doReturn(mock(ArrestReportDto.class)).when(arrestMapper).mapToArrestReportDto(arrest);
        _test.retrieveArrestReport(retrieveArrestQuery);
    }

    @Test
    public void shouldRetrieveArrestBySearchCriteria() {

        RetrieveArrestBySearchQuery retrieveArrestQuery = new RetrieveArrestBySearchQuery();
        retrieveArrestQuery.setSection(new Entry(1L));
        retrieveArrestQuery.setStatus(new Entry(1L));
        retrieveArrestQuery.setCityLk(new Entry(1L));
        retrieveArrestQuery.setAreaLk(new Entry(1L));
        retrieveArrestQuery.setArrestDate(new Date());
        retrieveArrestQuery.setArrestReason(new Entry(1L));
        retrieveArrestQuery.setTransferredFrom(new Entry(1L));
        retrieveArrestQuery.setArrestNumber("1");
        retrieveArrestQuery.setPartyStatus(new Entry(1L));
        List<String> sortColumns = new ArrayList();
        sortColumns.add("id");
        sortColumns.add("createdDate");
        ArrestPageBuilder arrestPageBuilder = new ArrestPageBuilder(1, 10, sortColumns);
        Arrest arrest = ArrestReportDataConstants.getArrestData();
        List<Arrest> list = new ArrayList<>();
        list.add(arrest);
        retrieveArrestQuery.setArrestPageBuilder(arrestPageBuilder);
        doReturn(mock(Page.class)).when(arrestRepository).findAll(any(Predicate.class),
                any(Pageable.class));
        doReturn(mock(Map.class)).when(arrestMapper).mapEntityToDTOList(list);
        _test.retrieveArrestBySearchCriteria(retrieveArrestQuery);
    }

    @Test
    public void shouldFindIncidentsByCriteria() {
        RetrieveArrestBySearchQuery retrieveArrestQuery = new RetrieveArrestBySearchQuery();
        retrieveArrestQuery.setSection(new Entry(1L));
        List<String> sortColumns = new ArrayList();
        sortColumns.add("id");
        sortColumns.add("createdDate");
        ArrestPageBuilder
                arrestPageBuilder =
                new ArrestPageBuilder(0, 10, sortColumns);

        Arrest arrest = ArrestReportDataConstants.getArrestData();
        List<Arrest> list = new ArrayList<>();
        list.add(arrest);
//    Page<Arrest> page =  new PageImpl(anyList(), any(Pageable.class), anyLong());
        doReturn(mock(Page.class)).when(arrestRepository).findAll(any(Predicate.class),
                any(Pageable.class));
        _test.findIncidentsByCriteria(arrestPageBuilder, retrieveArrestQuery);
    }

    @Test
    public void shouldRetrieveArrestsCreatedByUser() {
        RetrieveArrestsWithOwnerDetailQuery retrieveArrestQuery = new RetrieveArrestsWithOwnerDetailQuery(1L);
        retrieveArrestQuery.withUser("Nitesh");

        List<String> sortColumns = new ArrayList();
        sortColumns.add("id");
        sortColumns.add("createdDate");
        ArrestPageBuilder
                arrestPageBuilder =
                new ArrestPageBuilder(0, 10, sortColumns);
        retrieveArrestQuery.withArrestPageBuilder(arrestPageBuilder);
        Arrest arrest = ArrestReportDataConstants.getArrestData();
        List<Arrest> list = new ArrayList<>();
        list.add(arrest);
//    Page<Arrest> page =  new PageImpl(anyList(), any(Pageable.class), anyLong());
        doReturn(mock(Page.class)).when(arrestRepository).findAll(any(Predicate.class), any(Pageable.class));
        _test.retrieveArrestsCreatedByUser(retrieveArrestQuery);
    }

    @Test
    public void shouldRetrieveArrestsToAssignedUser() {
        RetrieveArrestsWithOwnerDetailQuery retrieveArrestQuery = new RetrieveArrestsWithOwnerDetailQuery(1L);
        retrieveArrestQuery.withUser("Nitesh");

        List<String> sortColumns = new ArrayList();
        sortColumns.add("id");
        sortColumns.add("createdDate");
        ArrestPageBuilder
                arrestPageBuilder =
                new ArrestPageBuilder(0, 10, sortColumns);
        retrieveArrestQuery.withArrestPageBuilder(arrestPageBuilder);
        Arrest arrest = ArrestReportDataConstants.getArrestData();
        List<Arrest> list = new ArrayList<>();
        list.add(arrest);
//    Page<Arrest> page =  new PageImpl(anyList(), any(Pageable.class), anyLong());
        doReturn(mock(Page.class)).when(arrestRepository).findAll(any(Predicate.class), any(Pageable.class));
        doReturn(mock(Map.class)).when(arrestMapper).mapEntityToDTOList(list);
        _test.retrieveArrestsAssignedToUser(retrieveArrestQuery);
    }
}
