package ae.emaratech.uaevision.arrest.domain;

import org.junit.Test;

import static org.assertj.core.api.StrictAssertions.assertThat;

/**
 * Created by Nitesh.Gupta on 6/29/2016.
 */

public class ArrestActionHistoryTest {
    @Test
    public void shouldReturnArrestHistoryBuilder() {
        ArrestActionHistory arrestActionHistory =
                new ArrestActionHistory.Builder(1L)
                        .withActionId(ArrestAction.CLOSE.id())
                        .withComments("closeComment")
                        .build();
        arrestActionHistory.getId();
        arrestActionHistory.getCreatedBy();
        arrestActionHistory.getCreatedDate();
        arrestActionHistory.getArrestActionId();
        arrestActionHistory.getArrestId();
        arrestActionHistory.getComments();
        assertThat(arrestActionHistory).isNotNull();

    }
}
