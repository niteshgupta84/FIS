package ae.emaratech.uaevision.arrest.application.validators;

import ae.emaratech.uaevision.arrest.application.CreateArrestReportCommand;
import ae.emaratech.uaevision.arrest.application.UpdateArrestReportCommand;
import ae.emaratech.uaevision.arrest.application.dto.ArrestAssociationDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestNoteDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;
import ae.emaratech.uaevision.arrest.application.dto.SeizureDto;
import ae.emaratech.uaevision.arrest.domain.ArrestDescription;
import ae.emaratech.uaevision.arrest.domain.ArrestReason;
import ae.emaratech.uaevision.arrest.domain.LocationType;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.AssociatedArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.AttachmentReferenceKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.notification.NotificationBusinessException;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

/**
 * Created by Nitesh.Gupta on 7/13/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestReportValidatorTest {
    @InjectMocks
    private ArrestReportValidator _test;


    @Mock
    private NotificationBus notificationBus;

    @Before
    public void init() {
        // Setting the behaviour of mocked dependencies.
        doThrow(NotificationBusinessException.class).when(notificationBus)
                .send(any(NotificationBuilder.class));
        NotificationBuilder notificationBuilder = new NotificationBuilder();
        doReturn(notificationBuilder).when(notificationBus).getBuilder();
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnErrorIfArrestLocationNotFound() {
        List<PartyKey> partyKeyList = new ArrayList<>();
        CreateArrestReportCommand command = new CreateArrestReportCommand.Builder(
                partyKeyList, new ArrestReason(1L), new ArrestDescription("TEst"), Section.AIRPORT_CONTROL,
                Department.BORDER_CONTROL
        ).withTerminalLocation(new Entry(-1L)).build();
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnErrorIfArrestLocationCRMNotFound() {
        List<PartyKey> partyKeyList = new ArrayList<>();
        CreateArrestReportCommand command = new CreateArrestReportCommand.Builder(
                partyKeyList, new ArrestReason(1L), new ArrestDescription("TEst"), Section.DETECTIVE,
                Department.DETECTIVE
        ).withTerminalLocation(new Entry(-1L))
                .withEmirate(new Entry(-1L))
                .withCity(new Entry(-1L))
                .withArea(new Entry(-1L)).build();
        _test.validate(command);
    }


    public void shouldNotReturnErrorIfArrestLocationCRMNotFound() {
        List<PartyKey> partyKeyList = new ArrayList<>();

        ArrestNoteDto arrestNoteDto = new ArrestNoteDto();
        arrestNoteDto.setId(0);
        arrestNoteDto.setIsDeleted(1L);
        List<ArrestNoteDto> noteList = new ArrayList<>();
        noteList.add(arrestNoteDto);

        List<SeizureDto> seizureDtoList = new ArrayList<>();
        SeizureDto seizureDto = new SeizureDto();
        seizureDto.setId(0L);
        seizureDto.setSeizureId(0L);
        seizureDto.setCount("1");
        seizureDtoList.add(seizureDto);

        List<ArrestTeamDto> arrestTeamDtoList = new ArrayList<>();
        ArrestTeamDto arrestTeamDto = new ArrestTeamDto();
        arrestTeamDto.setId(0L);
        arrestTeamDto.setArrestTeamId(0L);
        arrestTeamDtoList.add(arrestTeamDto);

        List<AssociatedArrestReportKey> arrestAssociationDtoList = new ArrayList<>();
        AssociatedArrestReportKey arrestAssociationDto = new AssociatedArrestReportKey(1L);
        arrestAssociationDtoList.add(arrestAssociationDto);

        List<AttachmentReferenceKey> attachmentReferenceKeys = new ArrayList<>();
        AttachmentReferenceKey attachmentReferenceKey = new AttachmentReferenceKey(1L);
        attachmentReferenceKeys.add(attachmentReferenceKey);
        CreateArrestReportCommand command = new CreateArrestReportCommand.Builder(
                partyKeyList, new ArrestReason(1L), new ArrestDescription("TEst"), Section.CRM,
                Department.DETECTIVE
        ).withTerminalLocation(new Entry(1L))
                .withArea(new Entry(1L))
                .withArrestBuilding("TEst")
                .withArrestDate(new Date())
                .withArrestDateTime(new Date())
                .withArrestLocation("Test")
                .withArrestStreet("Street")
                .withArrestTime("10:00")
                .withCity(new Entry(1L))
                .withEmirate(new Entry(1L))
                .withIsCreatedByAhwal(false)

                .withIsUrgent(false)
                .withLocationDescription("Test")
                .withLocationType(LocationType.COORDINATES)
                .withUnit(new Entry(1L))
                .withTransferredFrom(new Entry(1L))
                .withSeizureList(seizureDtoList)
                .withArrestTeamList(arrestTeamDtoList)

                .withAttachmentList(attachmentReferenceKeys)
                .build();
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnErrorIfArrestLocationCRMNotFoundForEdit() {
        List<PartyKey> partyKeyList = new ArrayList<>();
        UpdateArrestReportCommand
                command =
                new UpdateArrestReportCommand.Builder(new ArrestReportKey(1L),
                        partyKeyList, new ArrestReason(1L),
                        new ArrestDescription("TEst")
                ).withDepartment(Department.DETECTIVE)

                        .withTerminalLocation(new Entry(-1L))
                        .withEmirate(new Entry(-1L))
                        .withCity(new Entry(-1L))
                        .withArea(new Entry(-1L)).build();
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnErrorIfArrestLocationNotFoundForCRM() {
        List<PartyKey> partyKeyList = new ArrayList<>();
        UpdateArrestReportCommand
                command =
                new UpdateArrestReportCommand.Builder(new ArrestReportKey(1L),
                        partyKeyList, new ArrestReason(1L),
                        new ArrestDescription("TEst")
                ).withDepartment(Department.BORDER_CONTROL)
                        .withTerminalLocation(new Entry(-1L)).withUnit(new Entry(-1L))
                        .build();
        _test.validate(command);
    }

    public void shouldNotReturnErrorIfAllDetailsProvided() {
        List<PartyKey> partyKeyList = new ArrayList<>();
        ArrestNoteDto arrestNoteDto = new ArrestNoteDto();
        arrestNoteDto.setId(1L);
        arrestNoteDto.setIsDeleted(1L);
        List<ArrestNoteDto> noteList = new ArrayList<>();
        noteList.add(arrestNoteDto);

        List<SeizureDto> seizureDtoList = new ArrayList<>();
        SeizureDto seizureDto = new SeizureDto();
        seizureDto.setId(1);
        seizureDto.setSeizureId(1L);
        seizureDto.setCount("1");
        seizureDtoList.add(seizureDto);

        List<ArrestTeamDto> arrestTeamDtoList = new ArrayList<>();
        ArrestTeamDto arrestTeamDto = new ArrestTeamDto();
        arrestTeamDto.setId(1L);
        arrestTeamDto.setArrestTeamId(1L);
        arrestTeamDtoList.add(arrestTeamDto);

        Set<AssociatedArrestReportKey> arrestAssociationDtoList = new HashSet<>();
        AssociatedArrestReportKey arrestAssociationDto = new AssociatedArrestReportKey(1L);
        arrestAssociationDtoList.add(arrestAssociationDto);

        List<AttachmentReferenceKey> attachmentReferenceKeys = new ArrayList<>();
        AttachmentReferenceKey attachmentReferenceKey = new AttachmentReferenceKey(1L);
        attachmentReferenceKeys.add(attachmentReferenceKey);
        UpdateArrestReportCommand
                command =
                new UpdateArrestReportCommand.Builder(new ArrestReportKey(1L),
                        partyKeyList, new ArrestReason(1L),
                        new ArrestDescription("TEst")
                ).withTerminalLocation(new Entry(1L))
                        .withArea(new Entry(1L))
                        .withArrestBuilding("TEst")
                        .withArrestDate(new Date())
                        .withArrestDateTime(new Date())
                        .withArrestLocation("Test")
                        .withArrestStreet("Street")
                        .withArrestTime("10:00")
                        .withCity(new Entry(1L))
                        .withEmirate(new Entry(1L))
                        .withIsCreatedByAhwal(false)

                        .withIsUrgent(false)
                        .withLocationDescription("Test")
                        .withLocationType(LocationType.COORDINATES)
                        .withUnit(new Entry(1L))
                        .withTransferredFrom(new Entry(1L))
                        .withSeizureList(seizureDtoList)
                        .withArrestTeamList(arrestTeamDtoList)
                        .withArrestNoteList(noteList)
                        .withDepartment(Department.DETECTIVE)
                        .withAssociatedArrestList(arrestAssociationDtoList)
                        .withAttachmentList(attachmentReferenceKeys)
                        .build();
        _test.validate(command);
    }

    @Test
    public void shouldReturnTrueIfAssociationFound() {
        ArrestAssociationDto arrestAssociationDto = new ArrestAssociationDto();
        arrestAssociationDto.setLinkedArrestReportId(1L);
        List<ArrestAssociationDto> list = new ArrayList<>();

        assertThat(_test.checkDuplicateAssociation(list, 1L)).isFalse();
        list.add(arrestAssociationDto);
        assertThat(_test.checkDuplicateAssociation(list, 1L)).isTrue();
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnErrorIfTerminalNotFound() {
        List<PartyKey> partyKeyList = new ArrayList<>();
        CreateArrestReportCommand command = new CreateArrestReportCommand.Builder(
                partyKeyList, new ArrestReason(1L), new ArrestDescription("TEst"), Section.AIRPORT_CONTROL,
                Department.BORDER_CONTROL
        ).withTerminalLocation(new Entry(-1L)).withUnit(new Entry(-1L))
                .build();
        _test.validate(command);
    }
    @Test(expected = NotificationBusinessException.class)
    public void shouldReturnErrorIfTransferedFromNotFound() {
        List<PartyKey> partyKeyList = new ArrayList<>();
        CreateArrestReportCommand command = new CreateArrestReportCommand.Builder(
                partyKeyList, new ArrestReason(1L), new ArrestDescription("TEst"), Section.AIRPORT_CONTROL,
                Department.BORDER_CONTROL
        ).withTerminalLocation(new Entry(-1L)).withUnit(null).withTransferredFrom(null)
                .build();
        _test.validate(command);
    }
}
