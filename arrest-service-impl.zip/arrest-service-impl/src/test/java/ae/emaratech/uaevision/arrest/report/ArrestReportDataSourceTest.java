package ae.emaratech.uaevision.arrest.report;

import ae.emaratech.uaevision.arrest.application.dto.ArrestPartyDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestReportDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;
import ae.emaratech.uaevision.arrest.query.ArrestQueryService;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestQuery;
import ae.emaratech.uaevision.fis.gateway.incident.UserManagementServiceClient;
import ae.emaratech.uaevision.fis.gateway.usermanagementservice.EmployeeDetail;
import ae.emaratech.uaevision.fis.gateway.usermanagementservice.EmployeeDetails;
import ae.emaratech.uaevision.fis.party.application.dto.ChargeDto;
import ae.emaratech.uaevision.fis.party.application.dto.IRISDto;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import ae.emaratech.uaevision.fis.party.query.RetrievePartyQuery;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import net.sf.jasperreports.engine.JRDataSource;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.StrictAssertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

/**
 * Created by Nitesh.Gupta on 7/13/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestReportDataSourceTest {
    @InjectMocks
    private ArrestReportDataSource _test;

    @Mock
    private ArrestQueryService arrestQueryService;

    @Mock
    private UserManagementServiceClient userManagementServiceClient;

    @Mock
    private PartyQueryService partyQueryService;

    @Test
    public void shouldGenerateReport() {
        //Preparing input data
        ReportParameters reportParameters = new ReportParameters();
        reportParameters.addParameter("ARREST_ID", 12);
        reportParameters.addParameter("PARTY_ID", 2);

        ArrestReportDto arrestReportDto = new ArrestReportDto();
        arrestReportDto.setId(1L);
        arrestReportDto.setArrestReportNumber("incident number");
        arrestReportDto.setCreatedBy("incident number");
        arrestReportDto.setCreatedDate(new Date());
        arrestReportDto.setDepartment(new Entry(1L, "Investigation"));
        arrestReportDto.setSection(new Entry(1L, "Section"));
        arrestReportDto.setStatus(new Entry(1L, "Status"));
        arrestReportDto.setArrestDate(new Date());
        arrestReportDto.setArrestLocation("TEst");
        arrestReportDto.setEmirateLk(new Entry(1L));
        arrestReportDto.setCityLk(new Entry(1L));
        arrestReportDto.setAreaLk(new Entry(1L));
        List<ArrestPartyDto> arrestPartyDtos = new ArrayList<>();
        ArrestPartyDto arrestPartyDto = new ArrestPartyDto();
        arrestPartyDto.setId(1L);
        arrestPartyDto.setPartyId(1L);
        arrestPartyDto.setPartyType(new Entry(1L));
        arrestPartyDtos.add(arrestPartyDto);
        // incidentDto.set
        arrestReportDto.setArrestPartyDtoList(arrestPartyDtos);

        ArrestTeamDto arrestTeamDto  = new ArrestTeamDto();
        arrestTeamDto.setEmployeeId("1");
        arrestTeamDto.setArrestTeamId(1L);
        List<ArrestTeamDto> arrestTeamDtos = new ArrayList<>();
        arrestTeamDtos.add(arrestTeamDto);
        arrestReportDto.setArrestTeamList(arrestTeamDtos);
        PartyDto partyDto = new PartyDto();
        List<ChargeDto> listOfCharges = new ArrayList<>();
        ChargeDto chargeDto = new ChargeDto();
        chargeDto.setCharge(new Entry(1L, "Test charge"));
        listOfCharges.add(chargeDto);

        IRISDto irisDto = new IRISDto();
        irisDto.setIrisNumber("Iris number");
        irisDto.setNameChangedId(new Entry(2L, "Changed"));
        irisDto.setLocationId(new Entry(3L, "Loc"));

        partyDto.setIrisDto(irisDto);
        partyDto.setNameEn("En Name");
        partyDto.setNameAr("AR Name");
        partyDto.setNationality(new Entry(2L, "Naitonality"));
        partyDto.setOriginalNationality(new Entry(2L, "Naitonality"));
        partyDto.setDateofbirth(new Date());
        partyDto.setGender(new Entry(3L, "Male"));
        partyDto.setPersonType(new Entry(7L, "Visa"));
        partyDto.setIsBanned(true);
        partyDto.setIsOverstayed(true);
        partyDto.setIsBlackListed(true);
        partyDto.setAttachmentId(null);
        partyDto.setIsDeleted(0L);

        doReturn(partyDto).when(partyQueryService).retrieveParty(any(RetrievePartyQuery.class));
        doReturn(arrestReportDto).when(arrestQueryService).retrieveArrestReport(
                any(RetrieveArrestQuery.class));

        EmployeeDetails employeeDetails = mock(EmployeeDetails.class);

        doReturn(employeeDetails).when(userManagementServiceClient).getAllEmployeeDetails();
        List<EmployeeDetail> list = new ArrayList<>();
        EmployeeDetail employeeDetail = mock(EmployeeDetail.class);
        doReturn(1L).when(employeeDetail).getEmployeeId();
        list.add(employeeDetail);
        doReturn(list).when(employeeDetails).getEmployeeDetail();

        // Invoking the getDataSource on _test
        JRDataSource dataSource = _test.getDataSource(reportParameters);
        assertThat(dataSource).isInstanceOf(JRDataSource.class);
        assertThat(dataSource).isNotNull();
    }
}
