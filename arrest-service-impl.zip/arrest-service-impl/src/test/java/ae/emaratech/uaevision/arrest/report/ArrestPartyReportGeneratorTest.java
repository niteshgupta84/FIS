package ae.emaratech.uaevision.arrest.report;

/**
 * Created by Wasib Ali Khan
 */

import ae.emaratech.uaevision.fis.report.core.FISReportFormat;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperReportGenerator;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.doReturn;


@RunWith(MockitoJUnitRunner.class)
public class ArrestPartyReportGeneratorTest {

    @InjectMocks
    ArrestPartyReportGenerator arrestPartyReportGenerator;
    @Mock
    private ArrestPartyReportDataSource arrestPartyReportDataSource;
    @Mock
    private JasperReportGenerator jasperReportGenerator;

    @Before
    public void setup() throws Exception {

        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void shouldGenerateReportIfReportParameterPassed() throws Exception {
        List<Map> objects = new ArrayList<>();
        Map<String, String> resultSet = new HashMap<>();

        objects.add(resultSet);
        ReportParameters reportParameters = new ReportParameters();
        JRBeanCollectionDataSource source = new JRBeanCollectionDataSource(objects);
        byte[] content = new byte[1];

        doReturn(source).when(arrestPartyReportDataSource).getDataSource(reportParameters);
        doReturn(content).when(jasperReportGenerator).generateReport("Wasib", new HashMap(), source);
        arrestPartyReportGenerator.generateReport(reportParameters, FISReportFormat.PDF);
    }
}
