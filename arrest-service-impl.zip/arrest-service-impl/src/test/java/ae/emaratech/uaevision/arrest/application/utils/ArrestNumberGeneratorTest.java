package ae.emaratech.uaevision.arrest.application.utils;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Nitesh.Gupta on 8/10/2016.
 */
public class ArrestNumberGeneratorTest {

    @Test
    public void shouldReturnPersistableArrestNumber() {
        assertThat(ArrestNumberGenerator.getPersistableArrestNumber("30/00000001/2017")).isNotNull();
    }

    @Test
    public void shouldReturnPersistableYear() {
        assertThat(ArrestNumberGenerator.getPersistableYear("130/00000001/2017")).isEqualTo(2017L);
    }

    @Test
    public void shouldReturnCurrentYear() {
        assertThat(ArrestNumberGenerator.getCurrentYear()).isEqualTo(2017L);
    }

    @Test
    public void shouldReturnTrueIfValidArrestNumber() {
        assertThat(ArrestNumberGenerator.checkValidArrestNumber("130/00000001/2017")).isEqualTo(true);
    }

    @Test
    public void shouldReturnFormattedArrestNumber() {
        assertThat(ArrestNumberGenerator.getFormattedArrestNumber("130", 1L, 2017L)).isEqualTo(
                "130/00000001/2017");
    }
    @Test
    public void shouldReturnNewFormattedArrestNumber() {
        assertThat(ArrestNumberGenerator.getFormattedArrestNumberWithoutDepartment( 1L, 2017L)).isEqualTo(
                "1/2017");
    }
}
