package ae.emaratech.uaevision.arrest.application.validators;

import ae.emaratech.uaevision.arrest.application.AddArrestTeamCommand;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.notification.NotificationBusinessException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

/**
 * Created by Nitesh.Gupta on 7/13/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class ArrestTeamValidatorTest {
    @InjectMocks
    private ArrestTeamValidator _test;


    @Mock
    private NotificationBus notificationBus;

    @Before
    public void init() {
        // Setting the behaviour of mocked dependencies.
        doThrow(NotificationBusinessException.class).when(notificationBus)
                .send(any(NotificationBuilder.class));
        NotificationBuilder notificationBuilder = new NotificationBuilder();
        doReturn(notificationBuilder).when(notificationBus).getBuilder();
    }

    @Test
    public void shouldValidateArrestTeamId() {

        AddArrestTeamCommand command = new AddArrestTeamCommand("2000");
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldValidateArrestTeamIdIfNoneProvided() {

        AddArrestTeamCommand command = new AddArrestTeamCommand("ML101");
        _test.validate(command);
    }

    @Test(expected = NotificationBusinessException.class)
    public void shouldValidateArrestTeamIdIfNotValidParty() {

        AddArrestTeamCommand command = new AddArrestTeamCommand("ML101001");
        _test.validate(command);
    }
}
