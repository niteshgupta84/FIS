package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.domain.ArrestAction;
import ae.emaratech.uaevision.arrest.domain.ArrestStatus;

import java.util.*;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
public class ArrestStateMachineConfiguration {


    private ArrestStateMachineConfiguration() {

    }

    private final static Map<ArrestStatus, List<ArrestAction>> stateMachineConfigForIcm;


    static {

        stateMachineConfigForIcm = new HashMap<>(ArrestStatus.values().length);

        // State Machine Configuration for ICM
        //Status NEW
        List<ArrestAction> nextActionsForNew = new ArrayList<>();
        nextActionsForNew.add(ArrestAction.OPEN);
        stateMachineConfigForIcm
                .put(ArrestStatus.NEW, Collections.unmodifiableList(nextActionsForNew));

        //Status OPENED
        List<ArrestAction> nextActionsForOpen = new ArrayList<>();

        nextActionsForOpen.add(ArrestAction.UPDATE);
        nextActionsForOpen.add(ArrestAction.CLOSE);
        nextActionsForOpen.add(ArrestAction.FORWARD_TO_SUPERVISOR);
        nextActionsForOpen.add(ArrestAction.FORWARD_TO_CASE);


        stateMachineConfigForIcm
                .put(ArrestStatus.OPENED, Collections.unmodifiableList(nextActionsForOpen));

        //Status PENDING_DECISION
        List<ArrestAction> nextActionsForPendingDecision = new ArrayList<>();
        nextActionsForPendingDecision.add(ArrestAction.FORWARD_TO_CASE);
        nextActionsForPendingDecision.add(ArrestAction.APPROVE);
        nextActionsForPendingDecision.add(ArrestAction.REJECT);

        stateMachineConfigForIcm.put(ArrestStatus.PENDING_DECISION,
                Collections.unmodifiableList(nextActionsForPendingDecision));

        // After CLOSED
        List<ArrestAction> nextActionsForClosed = new ArrayList<>();
        nextActionsForClosed.add(ArrestAction.REOPEN);

        stateMachineConfigForIcm
                .put(ArrestStatus.CLOSED, Collections.unmodifiableList(nextActionsForClosed));

        // After FORWARDED
        List<ArrestAction> nextActionsForForward = new ArrayList<>();

        stateMachineConfigForIcm
                .put(ArrestStatus.FORWARDED, Collections.unmodifiableList(nextActionsForForward));

        stateMachineConfigForIcm
                .put(ArrestStatus.APPROVED, Collections.unmodifiableList(nextActionsForOpen));


    }

    public static Map<ArrestStatus, List<ArrestAction>> getStateMachineConfigForIcm() {
        return stateMachineConfigForIcm;
    }

}
