package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportTrackDto;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@Component
public class ArrestReportHistoryMapper {

    /**
     * Reference to the lookup service.
     */
    @Autowired
    private LookupService lookupService;


    @Autowired
    private UserService userService;
    /**
     * Method which copies the relevant state information from Deportation History entity to dto.
     *
     * @param arrestActionHistory the arrest history entity bean.
     * @return deportation track transfer object
     */
    public ArrestReportTrackDto mapArrestReportTrackDto(
            ArrestActionHistory arrestActionHistory) {

        ArrestReportTrackDto arrestReportTrackDto = new ArrestReportTrackDto();

        arrestReportTrackDto.setId(arrestActionHistory.getId());
        arrestReportTrackDto.setComments(arrestActionHistory.getComments());
        arrestReportTrackDto.setCreatedBy(userService.getUserFirstNameByUserLogin(arrestActionHistory.getCreatedBy()));
        arrestReportTrackDto.setCreatedDate(arrestActionHistory.getCreatedDate());
        arrestReportTrackDto.setAction(
                lookupService.getLookupEntry(
                        LookupDefinition.ARREST_ACTION,
                        LocaleContextHolder
                                .getLocale(),
                        arrestActionHistory.getArrestActionId()).get());

        return arrestReportTrackDto;
    }
}
