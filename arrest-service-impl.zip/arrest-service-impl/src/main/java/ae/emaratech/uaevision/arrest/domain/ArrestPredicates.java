package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.query.RetrieveArrestBySearchQuery;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestsWithOwnerDetailQuery;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.common.util.DateUtils;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import org.springframework.data.querydsl.QSort;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
public class ArrestPredicates {

    public static BooleanExpression hasNoPredicate() {
        BooleanExpression where = null;
        return where;
    }

    /**
     * Order By Created Date
     */
    public static OrderSpecifier getOrderSpecifier() {

        QArrest qArrest = QArrest.arrest;
        QSort qsort = new QSort(qArrest.createdDate.desc());
        return qsort.getOrderSpecifiers().get(0);
    }

    /**
     * Where clause for getting all history for interrogation
     */
    public static Predicate getHistoryByArrestId(ArrestReportKey arrestReportKey) {

        Predicate predicate =
                QArrestActionHistory.arrestActionHistory.arrestId
                        .eq(arrestReportKey.id());
        return predicate;
    }

    public static OrderSpecifier getActionHistoryOrderSpecifier() {

        QArrestActionHistory
                qArrestActionHistory =
                QArrestActionHistory.arrestActionHistory;
        QSort qsort = new QSort(qArrestActionHistory.createdDate.desc());
        return qsort.getOrderSpecifiers().get(0);
    }

    public static Predicate getArrestBySearchCriteria(RetrieveArrestBySearchQuery query) {
        BooleanExpression queryExpression = null;
        if (query.getSection() != null && !Checks
                .isNotValidLookUpId(query.getSection().getId())) {
            queryExpression =
                    QArrest.arrest.owner.section.eq(query.getSection().getId());
        }
        if (query.getSectionUnit() != null && !Checks
                .isNotValidLookUpId(query.getSectionUnit().getId())) {
            queryExpression = queryExpression.and(
                    QArrest.arrest.arrest.owner.sectionUnit
                            .eq(query.getSectionUnit().getId()));
        }
        if (query.getArrestNumber() != null && !query.getArrestNumber().isEmpty()) {
            queryExpression =
                    queryExpression.and(QArrest.arrest.arrestNumber.like("%" + query.getArrestNumber() + "%"));
        } else {

            if (Checks.isValidString(query.getCreatedBy())) {
                queryExpression =
                        queryExpression.and(QArrest.arrest.createdBy.eq(query.getCreatedBy()));
            }
            if (query.getDepartment() != null && !Checks
                    .isNotValidLookUpId(query.getDepartment().getId())) {
                queryExpression =
                        queryExpression.or(QArrest.arrest.owner.department
                                .eq(query.getDepartment().getId()));
            }
            if (query.getArrestReason() != null && !Checks
                    .isNotValidLookUpId(query.getArrestReason().getId())) {
                queryExpression =
                        queryExpression.and(QArrest.arrest.arrestReasonId
                                .eq(query.getArrestReason().getId()));
            }
            if (query.getTransferredFrom() != null && !Checks
                    .isNotValidLookUpId(query.getTransferredFrom().getId())) {
                queryExpression =
                        queryExpression.and(QArrest.arrest.transferredFromDeptId
                                .eq(query.getTransferredFrom().getId()));
            }

            if (query.isUrgent())

            {
                queryExpression =
                        queryExpression.and(QArrest.arrest.isUrgent.eq(query.isUrgent() ? 1L : 0L));
            }
            if (query.getStatus() != null) {
                if (!Checks
                        .isNotValidLookUpId(query.getStatus().getId())) {
                    queryExpression =
                            queryExpression.and(QArrest.arrest.statusId
                                    .eq(query.getStatus().getId()));
                } else {
                    queryExpression =
                            queryExpression.and(QArrest.arrest.statusId
                                    .notIn(ArrestStatus.CLOSED.id(), ArrestStatus.FORWARDED.id()));
                }
            } else {
                queryExpression =
                        queryExpression.and(QArrest.arrest.statusId
                                .notIn(ArrestStatus.CLOSED.id(), ArrestStatus.FORWARDED.id()));
            }

            if (query.getCreatedDate() != null) {
                queryExpression =
                        queryExpression.and(
                                QArrest.arrest.createdDate
                                        .after(DateUtils.getDateBefore(query.getCreatedDate())));

                queryExpression =
                        queryExpression.and(
                                QArrest.arrest.createdDate
                                        .before(DateUtils.getDateAfter(query.getCreatedDate())));
            }

            if (query.getArrestDate() != null
                    && query.getArrestDateTo() != null) {
                queryExpression =
                        queryExpression.and(QArrest.arrest.arrestDatetime
                                .between(query.getArrestDate(),
                                        query.getArrestDateTo()));
                if (!query.getArrestTime().isEmpty() && !query
                        .getArrestTimeTo().isEmpty()) {
                    queryExpression =
                            queryExpression.and(QArrest.arrest.arrestDatetime.between(
                                    getArrestTimeStamp(query.getArrestDate(),
                                            query.getArrestTime()),
                                    getArrestTimeStamp(query.getArrestDate(),
                                            query.getArrestTimeTo())));
                }
            }
            if (query.getEmirateLk() != null && !Checks
                    .isNotValidLookUpId(query.getEmirateLk().getId())) {
                queryExpression = queryExpression.and(QArrest.arrest.arrestLocation.emirateId
                        .eq(
                                query
                                        .getEmirateLk().getId()));
            }
            if (query.getCityLk() != null && !Checks
                    .isNotValidLookUpId(query.getCityLk().getId())) {
                queryExpression = queryExpression.and(QArrest.arrest.arrestLocation.cityId
                        .eq(
                                query
                                        .getCityLk().getId()));
            }
            if (query.getAreaLk() != null && !Checks
                    .isNotValidLookUpId(query.getAreaLk().getId())) {
                queryExpression =
                        queryExpression.and(QArrest.arrest.arrestLocation.areaId.eq(
                                query.getAreaLk().getId()));
            }

        }
        return queryExpression;
    }

    public static Timestamp getArrestTimeStamp(Date arrestDate, String arrestTime) {
        Calendar calender = Calendar.getInstance();
        calender.setTime(arrestDate);

        if (arrestTime.contains(":")) {
            calender.set(Calendar.HOUR_OF_DAY,
                    Integer.parseInt(arrestTime.split(":")[0]));
            calender
                    .set(Calendar.MINUTE, Integer.parseInt(arrestTime.split(":")[1]));
        } else {
            calender.set(Calendar.HOUR_OF_DAY,
                    Integer.parseInt(arrestTime));


        }
        return new Timestamp(calender.getTime().getTime());
    }

    public static Predicate getArrestByOwnerDetails(RetrieveArrestsWithOwnerDetailQuery query) {

        BooleanExpression predicate = QArrest.arrest.owner.section.eq(
                query.getSectionId());

        if (Checks.isNotNull(query.getUserId())) {
            predicate = predicate.and(QArrest.arrest.assignedUser.eq(
                    query.getUserId()));
        }

        return predicate;
    }

    public static Predicate getActiveArrestForParty(List<Long> partyIdList) {

        Predicate predicate = QArrest.arrest.statusId.eq(ArrestStatus.OPENED.id()).and(
                QArrest.arrest.parties.any().partyId.in(partyIdList));
        return predicate;
    }
}
