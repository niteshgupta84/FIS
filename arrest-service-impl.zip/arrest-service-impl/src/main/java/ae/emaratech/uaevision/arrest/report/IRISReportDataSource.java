package ae.emaratech.uaevision.arrest.report;

/**
 *  * Created by Satya K on 10/06/2016
 *
 *
 */

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportDto;
import ae.emaratech.uaevision.arrest.query.ArrestQueryService;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestQuery;
import ae.emaratech.uaevision.document.service.api.DocumentService;
import ae.emaratech.uaevision.fis.common.exception.BusinessException;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.util.ApplicationConstants;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.party.application.dto.ChargeDto;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import ae.emaratech.uaevision.fis.party.query.RetrievePartyQuery;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperDataSource;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class is use for generating the party iris report. <p/> Created by Satya K on 10/06/2016
 */
@Component
public class IRISReportDataSource implements JasperDataSource {

    /**
     * Static containing the logger for the class.
     */
    private static final Logger LOGGER = LogManager.getLogger();

    @Autowired
    private PartyQueryService partyQueryService;


    @Autowired
    private DocumentService documentService;


    @Autowired
    private ArrestQueryService arrestQueryService;

    public JRDataSource getDataSource(ReportParameters parameters) throws BusinessException {

        LOGGER.info("Inside IRISReportDataSource.getDataSource() ");

        List<Map> objects = new ArrayList<>();
        Map<String, Object> resultSet = new HashMap<String, Object>();
        Long
                parentIncidentIdLong =
                Long.valueOf(
                        parameters.getParameter(ApplicationConstants.REPORT_PARAM_PARENT_INCIDENT_ID).toString());
        Long partyIdLong = Long.valueOf(parameters.getParameter("PARTY_ID_IRIS").toString());
        RetrieveArrestQuery
                retrieveArrestQuery =
                new RetrieveArrestQuery(new ArrestReportKey(parentIncidentIdLong));

        ArrestReportDto arrestReportDto = arrestQueryService.retrieveArrestReport(retrieveArrestQuery);

        //Get party details
        PartyKey partyKey = new PartyKey(partyIdLong);
        PartyDto partyDto = partyQueryService.retrieveParty(new RetrievePartyQuery(partyKey));
        //Get Party Photo
        byte[] partyPhoto = null;
        if (partyDto.getAttachmentId() != null) {
            partyPhoto = documentService.downloadDocument(partyDto.getAttachmentId()).getAttachment();
        }

        if (partyPhoto != null) {
            ByteArrayInputStream partyPhotoObj = new ByteArrayInputStream(partyPhoto);
            resultSet.put("partyPhoto", partyPhotoObj);
        }
        //Get List of Charges
        List<ChargeDto> listOfCharges = new ArrayList<>();
        listOfCharges = partyDto.getListofCharges();
        List<String> charge = new ArrayList<>();
        if (Checks.isNotNull(listOfCharges)) {
            for (ChargeDto chargeDto : listOfCharges) {
                String chargeName = chargeDto.getCharge().getName();
                charge.add(chargeName + ' ');
            }
        }

        String charges = org.apache.commons.lang3.StringUtils.join(charge, ',');

        resultSet.put("nameEn", String.valueOf(partyDto.getNameEn()));
        resultSet.put("nameAr", String.valueOf(partyDto.getNameAr()));
        resultSet.put("nationality", String.valueOf(partyDto.getNationality().getName()));

        resultSet.put("listOfCharges", String.valueOf(charges));
        resultSet.put("gender", String.valueOf(partyDto.getGender().getName()));
        resultSet.put("dateOfBirth", String.valueOf(partyDto.getDateofbirth()));
        resultSet.put("udbNo", String.valueOf(partyDto.getUdbNo()));
        if (null == partyDto.getPersonNo() || ("0").equals(partyDto.getPersonNo()) || ("").equals(partyDto.getPersonNo())) {
            resultSet.put("personNumber", "  --  ");
        } else {
            resultSet.put("personNumber", partyDto.getPersonNo());
        }

        resultSet.put("partyType", partyDto.getPersonType().getName());
        resultSet.put("age", String.valueOf(partyDto.getAge()));
        if (partyDto.getAge() == 0) {
            resultSet.put("age", "  --  ");
        }
        if (partyDto.getGetBirthplaceAr() != null) {
            resultSet.put("placeOfBirth", String.valueOf(partyDto.getGetBirthplaceAr()));
        } else {
            resultSet.put("placeOfBirth", "     --    ");
        }
        if (partyDto.getMotherNameAr() != null) {
            resultSet.put("nameOfMotherAr", partyDto.getMotherNameAr());
        } else {
            resultSet.put("nameOfMotherAr", "     --    ");
        }
        if (partyDto.getProfession() != null) {
            resultSet.put("occupation", partyDto.getProfession().getName());
        } else {
            resultSet.put("occupation", "     --    ");
        }
        if (partyDto.getCountry() != null) {
            resultSet.put("country_city", partyDto.getCountry().getName());
        } else {
            resultSet.put("country_city", "     --    ");
        }
        if (partyDto.getMotherNameEn() != null) {
            resultSet.put("nameOfMother", String.valueOf(partyDto.getMotherNameEn()));
        } else {
            resultSet.put("nameOfMother", "     --    ");
        }
        if (partyDto.getPhoneNumber() != null) {
            resultSet.put("phoneNumber", partyDto.getPhoneNumber());
        } else {
            resultSet.put("phoneNumber", "     --   ");
        }
        if (partyDto.getHomePhone() != null) {
            resultSet.put("homePhone", partyDto.getHomePhone());
        } else {
            resultSet.put("homePhone", "     --   ");
        }
        if (partyDto.getWorkPhone() != null) {
            resultSet.put("workPhone", partyDto.getWorkPhone());
        } else {
            resultSet.put("workPhone", "     --   ");
        }
        if (partyDto.getAddress() != null) {
            resultSet.put("address", partyDto.getAddress());
        } else {
            resultSet.put("address", "     --   ");
        }


        if (partyDto.getCountry() != null) {
            resultSet.put("country_city", partyDto.getCountry().getName());
        } else {
            resultSet.put("country_city", "     --    ");
        }

        //Department and Section Name
        if (arrestReportDto != null) {
            resultSet.put("incidentId", String.valueOf(arrestReportDto.getArrestReportNumber()));
            resultSet.put("departmentName", String.valueOf(arrestReportDto.getDepartment().getName()));
            resultSet.put("sectionName", String.valueOf(arrestReportDto.getSection().getName()));
            resultSet.put("incidentStatus", String.valueOf(arrestReportDto.getStatus().getName()));
            resultSet.put("createdDate", String.valueOf(arrestReportDto.getCreatedDate()));
            resultSet.put("createdBy", String.valueOf(arrestReportDto.getCreatedBy()));
        }

        //IRIS Information
        byte[] irisPhoto = null;
        if (Checks.isNotNull(partyDto.getIrisDto())) {
            if (partyDto.getIrisDto().getIrisAttachmentId() != null) {
                irisPhoto =
                        documentService.downloadDocument(partyDto.getIrisDto().getIrisAttachmentId())
                                .getAttachment();
            }
            if (irisPhoto != null) {
                ByteArrayInputStream iphoto = new ByteArrayInputStream(irisPhoto);
                resultSet.put("irisPhoto", iphoto);
            }
            if (partyDto.getIrisDto().getIrisNumber() != null) {
                resultSet.put("irisNumber", String.valueOf(partyDto.getIrisDto().getIrisNumber()));
            } else {
                resultSet.put("irisNumber", "     --    ");
            }
            if (partyDto.getIrisDto().getNameChangedId() != null) {
                resultSet.put("irisNameChanged",
                        String.valueOf(partyDto.getIrisDto().getNameChangedId().getName()));
            } else {
                resultSet.put("irisNameChanged", "     --    ");
            }
            if (partyDto.getIrisDto().getLocationId() != null) {
                resultSet
                        .put("irisLocation", String.valueOf(partyDto.getIrisDto().getLocationId().getName()));
            } else {
                resultSet.put("irisLocation", "     --    ");
            }
        }

        String airlineName = "     --    ";
        if (partyDto.getTravelDto() != null) {
            if (partyDto.getTravelDto().getArrivedAirline() != null) {
                airlineName = partyDto.getTravelDto().getArrivedAirline().getName();
            }
        }
        resultSet.put("arrivedFrom", airlineName);

        String destination = "     --    ";
        if (partyDto.getTravelDto() != null) {
            if (partyDto.getTravelDto().getArrivedFromDestination() != null) {
                destination = partyDto.getTravelDto().getArrivedFromDestination().getName();
            }
        }
        resultSet.put("departedTo", destination);

        objects.add(resultSet);

        JRBeanCollectionDataSource source = new JRBeanCollectionDataSource(objects);
        LOGGER.info("method getDataSource() stop");
        return source;
    }


}

