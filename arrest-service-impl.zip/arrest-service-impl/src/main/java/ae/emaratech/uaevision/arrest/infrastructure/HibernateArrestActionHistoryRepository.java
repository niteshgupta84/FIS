package ae.emaratech.uaevision.arrest.infrastructure;

import ae.emaratech.uaevision.arrest.domain.ArrestActionHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;

import java.io.Serializable;


public interface HibernateArrestActionHistoryRepository extends
        JpaRepository<ArrestActionHistory, Long>,
        QueryDslPredicateExecutor<ArrestActionHistory>,Serializable {

}
