package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportTrackDto;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
@Component
public class ArrestActionHistoryMapper {


    /**
     * Reference to the lookup service.
     */
    @Autowired
    private LookupService lookupService;


    @Autowired
    private UserService userService;

    /**
     * Method which copies the relevant state information from Interrogation History entity to dto.
     *
     * @param arrestActionHistory the arrest history entity bean.
     * @return arrest track transfer object
     */
    public ArrestReportTrackDto mapArrestTrackDto(
            ArrestActionHistory arrestActionHistory) {

        ArrestReportTrackDto arrestTrackDto = new ArrestReportTrackDto();

        arrestTrackDto.setId(arrestActionHistory.getId());
        arrestTrackDto.setComments(arrestActionHistory.getComments());
        arrestTrackDto.setCreatedBy(userService.getUserFirstNameByUserLogin(arrestActionHistory.getCreatedBy()));
        arrestTrackDto.setCreatedDate(arrestActionHistory.getCreatedDate());
        arrestTrackDto.setAction(
                lookupService.getLookupEntry(
                        LookupDefinition.ARREST_ACTION,
                        LocaleContextHolder
                                .getLocale(),
                        arrestActionHistory.getArrestActionId()).get());

        return arrestTrackDto;
    }
}
