package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportDto;
import ae.emaratech.uaevision.arrest.application.utils.LocationTypeEnum;
import ae.emaratech.uaevision.fis.common.resolver.MessageResolver;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.common.util.DateUtils;
import ae.emaratech.uaevision.fis.common.util.PreCondition;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@Component
public class ArrestMapper {

    @Autowired
    private LookupService lookupService;

    @Autowired
    private ArrestPartyMapper arrestPartyMapper;

    @Autowired
    private MessageResolver messageSource;

    @Autowired
    private UserService userService;

    public ArrestReportDto mapToArrestReportDto(Arrest arrestReport) {

        //Populating Arrest Information
        if (arrestReport != null) {
            ArrestReportDto arrestReportDto = new ArrestReportDto();
            arrestReportDto.setArrestNumber(getArrestNumberForDisplay(arrestReport));
            arrestReportDto.setId(arrestReport.id());
            arrestReportDto.setVersion(arrestReport.getVersion());
            arrestReportDto.setCreatedByAhwal(
                    arrestReport.getIsCreatedByAhwal() != null && arrestReport.getIsCreatedByAhwal() == 1L);
            String message = messageSource.resolveMessageCode("incident.label.ahwal");
            if (arrestReportDto.isCreatedByAhwal()) {
                arrestReportDto.setCreatedBy(" ( " + arrestReport.getCreatedBy() + " ( " + message);
            } else {
                arrestReportDto.setCreatedBy(userService.getUserFirstNameByUserLogin(arrestReport.getCreatedBy()));
            }
            arrestReportDto.setCreatedDate(arrestReport.getCreatedDate());
            arrestReportDto.setUrgent(arrestReport.getIsUrgent() != 0);

            if (arrestReportDto.isUrgent()) {
                arrestReportDto.setUrgentString(messageSource.resolveMessageCode("label.yes"));
            } else {
                arrestReportDto.setUrgentString(messageSource.resolveMessageCode("label.nope"));
            }

            if (arrestReport.getTransferredFromDeptId() != null) {
                arrestReportDto.setTransferredFrom(
                        lookupService.getLookupEntry(
                                LookupDefinition.TRANSFERREDFROM, LocaleContextHolder.getLocale(),
                                arrestReport.getTransferredFromDeptId()).get());
            }

            if (Checks.isNotNull(arrestReport.getArrestReasonId())) {
                arrestReportDto.setArrestReason(
                        lookupService.getLookupEntry(
                                LookupDefinition.ARREST_REASON, LocaleContextHolder.getLocale(),
                                arrestReport.getArrestReasonId()).get());
            }
            if (Checks.isNotNull(arrestReport.getStatusId())) {
                arrestReportDto.setStatus(
                        lookupService.getLookupEntry(
                                LookupDefinition.ARREST_STATUS, LocaleContextHolder.getLocale(),
                                arrestReport.getStatusId()).get());
            }
            if (Checks.isNotNull(arrestReport.getOwner().getDepartment())) {
                Entry departmentEntry = lookupService.getLookupEntry(
                        LookupDefinition.DEPARTMENT, LocaleContextHolder.getLocale(),
                        arrestReport.getOwner().getDepartment()).get();
                arrestReportDto.setDepartment(departmentEntry);
            }

            if (Checks.isNotNull(arrestReport.getEntryExitId())) {
                Entry entryExit = lookupService.getLookupEntry(
                        LookupDefinition.ENTRY_EXIT, LocaleContextHolder.getLocale(),
                        arrestReport.getEntryExitId()).get();
                arrestReportDto.setEntryExit(entryExit);
            }

            if (Checks.isNotNull(arrestReport.getOwner().getSection())) {
                arrestReportDto.setSection(
                        lookupService.getLookupEntry(
                                LookupDefinition.SECTION, LocaleContextHolder.getLocale(),
                                arrestReport.getOwner().getSection()).get());
            }
            if (Checks.isNotNull(arrestReport.getOwner().getSectionUnit())) {
                arrestReportDto.setSectionUnit(
                        lookupService.getLookupEntry(
                                LookupDefinition.SECTION_UNITS, LocaleContextHolder.getLocale(),
                                arrestReport.getOwner().getSectionUnit()).get());
            }
            if (Checks.isNotNull(arrestReport.getShiftId())) {
                arrestReportDto.setShift(
                        lookupService.getLookupEntry(
                                LookupDefinition.SHIFT, LocaleContextHolder.getLocale(),
                                arrestReport.getShiftId()).get());
            }

            if (Checks.isNotNull(arrestReport.getArrestDatetime())) {
                arrestReportDto.setArrestTime(DateUtils.getHHMMFromDate(
                        new Date(arrestReport.getArrestDatetime().getTime())));
            }
            arrestReportDto.setArrestDate(arrestReport.getArrestDatetime());
            arrestReportDto.setArrestReportDescription(arrestReport.getReportDescription());
            if (arrestReport.getArrestLocation() != null) {
                if (Checks.isNotNull(arrestReport.getArrestLocation().getTerminalLocation())) {
                    arrestReportDto.setTerminalLocation(
                            lookupService.getLookupEntry(
                                    LookupDefinition.ARREST_LOCATION_LK, LocaleContextHolder.getLocale(),
                                    arrestReport.getArrestLocation().getTerminalLocation()).get());
                }
                arrestReportDto.setBuilding(arrestReport.getArrestLocation().getBuilding());
                arrestReportDto.setArrestLocation(arrestReport.getArrestLocation().getLocation());

                if (Checks.isNotNull(arrestReport.getArrestLocation().getEmirateId())) {
                    arrestReportDto.setEmirateLk(
                            lookupService.getLookupEntry(
                                    LookupDefinition.EMIRATE, LocaleContextHolder.getLocale(),
                                    arrestReport.getArrestLocation().getEmirateId()).get());
                }
                if (Checks.isNotNull(arrestReport.getArrestLocation().getAreaId())) {
                    arrestReportDto.setAreaLk(
                            lookupService.getLookupEntry(
                                    LookupDefinition.AREA, LocaleContextHolder.getLocale(),
                                    arrestReport.getArrestLocation().getAreaId()).get());
                }
                if (Checks.isNotNull(arrestReport.getArrestLocation().getCityId())) {
                    arrestReportDto.setCityLk(
                            lookupService.getLookupEntry(
                                    LookupDefinition.CITY, LocaleContextHolder.getLocale(),
                                    arrestReport.getArrestLocation().getCityId()).get());
                }
                arrestReportDto.setStreet(arrestReport.getArrestLocation().getStreet());
                arrestReportDto
                        .setLocationDescription(arrestReport.getArrestLocation().getLocationDescription());
                arrestReportDto.setLocType(
                        getArrestTypeMappingByArrestLocationType(

                                arrestReport.getArrestLocation().getLocType()));
            }
            arrestReportDto.setCreatedDate(arrestReport.getCreatedDate());
            arrestReportDto.setCreatedBy(userService.getUserFirstNameByUserLogin(arrestReport.getCreatedBy()));
            arrestReportDto.setAssignedUser(arrestReport.getAssignedUser());
            arrestReportDto.setArrestReportNumber(getArrestNumberForDisplay(arrestReport));
            arrestReportDto
                    .setArrestPartyDtoList(arrestPartyMapper.mapToDtoList(arrestReport.getParties()));

            return arrestReportDto;
        }
        return null;
    }

    /**
     * Returning map of Arrest for given search Criteria
     */
    public Map mapEntityToDTOList(List<Arrest> arrestEntities) {
        Map<Long, ArrestReportDto> arrestReportDtoMap = new LinkedHashMap<>();
        long seqNo = 0;
        for (Arrest arrest : arrestEntities) {
            seqNo = seqNo + 1;
            ArrestReportDto arrestReportDto = mapToArrestReportDto(arrest);
            arrestReportDtoMap.put(arrest.id(), arrestReportDto);
        }
        return arrestReportDtoMap;
    }

    /**
     * Method will return Entry object based on Arrest location pattern validation If arresst location
     * is in pattern StringUtils.arrest_location_pattern then default value in drop down is
     * "Coordinates"
     */
    private Entry getArrestTypeMappingByArrestLocationType(Long locType) {
        Entry selectedArrestType = new Entry(LocationTypeEnum.LOC.getId());
        //If Arrest Location value matches pattern then default will be 'Coordinates'
        if (Checks.isNotNull(locType) && locType == LocationTypeEnum.COORDINATES.getId()) {
            selectedArrestType = new Entry(LocationTypeEnum.COORDINATES.getId());
        }
        return selectedArrestType;
    }


    private String getArrestNumberForDisplay(Arrest arrestReport){
        String arrestNumber = arrestReport.getArrestNumber()!=null ? arrestReport.getArrestNumber() : "";

        Long departmentId = arrestReport.getOwner().getDepartment();

        Long departmentDisplayId = Department.getDepartmentCodeByDepartmentId(departmentId);

        String number = departmentDisplayId + PreCondition.SEPARATOR + arrestNumber + PreCondition.SEPARATOR + arrestReport.getYear();

        return number;
    }

}
