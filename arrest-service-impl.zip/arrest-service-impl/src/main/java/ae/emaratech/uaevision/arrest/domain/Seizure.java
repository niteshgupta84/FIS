package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.entity.AbstractEntityBase;
import ae.emaratech.uaevision.fis.common.key.SeizureKey;

import javax.persistence.*;


/**
 * The persistent class for the SEIZURE database table.
 */
@Entity(name = "newSeizure")
@Table(name = "ARREST_SEIZURE")
public class Seizure extends AbstractEntityBase {

    private static final Long serialVersionUID = 1L;

    @Column(name = "ITEM_NAME", length = 200, nullable = false)
    private String itemName;

    @Column(name = "ITEM_COUNT", nullable = false)
    private Long itemCount;
    @Column(name = "IS_DELETED")
    private Long isDeleted;

    //bi-directional many-to-one association to ArrestReport
    @ManyToOne
    @JoinColumn(name = "ARREST_REPORT_ID", nullable = false)
    private Arrest arrestReport;

    private Seizure() {

    }

    public Seizure(SeizureKey seizureKey, String itemName, Long itemCount, Long isDeleted) {

        setId(seizureKey.id());
        this.itemCount = itemCount;
        this.itemName = itemName;
        this.isDeleted = isDeleted;
    }

    protected String getItemName() {
        return itemName;
    }

    protected Long getItemCount() {
        return itemCount;
    }

    protected Arrest getArrestReport() {
        return arrestReport;
    }

    protected void setArrestReport(Arrest arrestReport) {
        this.arrestReport = arrestReport;
    }

    protected Long getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Long isDeleted) {
        this.isDeleted = isDeleted;
    }

    protected Seizure withItemCount(Long itemCount) {
        this.itemCount = itemCount;
        return this;
    }

    protected Seizure withItemName(String itemName) {
        this.itemName = itemName;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Seizure that = (Seizure) o;

        if (id() != null ? !id().equals(that.id()) : that.id() != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return id() != null ? id().hashCode() : 0;
    }
}