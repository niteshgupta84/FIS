package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.lookup.service.annotation.LookupField;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Entity bean encapsulating the arrest location information.
 *
 * @author Haroon.Subair
 */
@Embeddable
public class ArrestLocation implements Serializable {

    @Column(name = "ARREST_LOCATION", length = 200, nullable = false)
    private String location;

    @LookupField(LookupDefinition.EMIRATE)
    @Column(name = "EMIRATE_ID", nullable = true)
    private Long emirateId;

    @LookupField(LookupDefinition.CITY)
    @Column(name = "CITY_ID", nullable = true)
    private Long cityId;

    @LookupField(LookupDefinition.AREA)
    @Column(name = "AREA_ID", nullable = true)
    private Long areaId;

    @Column(name = "STREET", length = 100)
    private String street;

    @Column(name = "BUILDING", length = 100)
    private String building;

    @Column(name = "LOCATION_TYPE", nullable = false)
    private Long locType;

    @Column(name = "TERMINAL_LOCATION", nullable = false)
    private Long terminalLocation;

    @Column(name = "LOCATION_DESC", length = 200)
    private String locationDescription;


    /**
     * Private constructor. Added for integration with Hibernate.
     */
    private ArrestLocation() {

    }

    /**
     * Initializes the Arrest location for Detective officer flow.
     *
     * @param emirateId           the emirates identifier.
     * @param cityId              the city identifier.
     * @param areaId              the area identifier.
     * @param locType             the location type (location/co-ordinates).
     * @param arrestLocation      the arrest location.
     * @param street              the street name
     * @param building            the building name
     * @param locationDescription the location description.
     */
    public ArrestLocation(Long emirateId, Long cityId, Long areaId, LocationType locType,
                          String arrestLocation, String street, String building,
                          String locationDescription, Long terminalLocation) {
        this.emirateId = emirateId;
        this.cityId = cityId;
        this.areaId = areaId;
        if (locType != null) {
            this.locType = locType.id();
        }
        this.location = arrestLocation;
        this.street = street;
        this.building = building;
        this.locationDescription = locationDescription;
        this.terminalLocation = terminalLocation;
    }

    /**
     * Initializes the Arrest location for Border Control flow.
     *
     * @param terminalLocation the terminal identifier
     */
    public ArrestLocation(Long terminalLocation) {

        this.terminalLocation = terminalLocation;
    }

    protected String getLocation() {
        return location;
    }

    protected Long getEmirateId() {
        return emirateId;
    }

    protected Long getCityId() {
        return cityId;
    }

    protected Long getAreaId() {
        return areaId;
    }

    protected String getStreet() {
        return street;
    }

    protected String getBuilding() {
        return building;
    }

    protected Long getLocType() {
        return locType;
    }

    protected Long getTerminalLocation() {
        return terminalLocation;
    }

    protected String getLocationDescription() {
        return locationDescription;
    }
}
