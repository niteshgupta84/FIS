package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceDefinition;
import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceService;
import ae.emaratech.uaevision.fis.common.key.ArrestTeamKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by Nitesh.Gupta on 6/5/2016.
 */
@Component
public class ArrestTeamKeyProvider {

    @Autowired
    private SequenceService sequenceService;

    public ArrestTeamKey next() {
        Long nextSequenceNumber = sequenceService.nextValue(SequenceDefinition.ARREST_TEAM);
        ArrestTeamKey arrestTeamKey = new ArrestTeamKey(nextSequenceNumber);
        return arrestTeamKey;
    }
}
