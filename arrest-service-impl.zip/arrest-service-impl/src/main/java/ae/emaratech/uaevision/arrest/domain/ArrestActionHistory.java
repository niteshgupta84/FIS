package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.entitylistener.Creatable;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedByListener;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedDateListener;
import ae.emaratech.uaevision.lookup.service.annotation.LookupField;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;

import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the ARREST_ACTION_HISTORY database table.
 */
@Entity
@EntityListeners({
        CreatedDateListener.class,
        CreatedByListener.class
})
@Table(name = "ARREST_ACTION_HISTORY")
public class ArrestActionHistory implements Creatable {

    private static final Long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "ARREST_ACTION_HISTORY_ID_GENERATOR", sequenceName = "SEQ_ARREST_ACTION_HISTORY", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ARREST_ACTION_HISTORY_ID_GENERATOR")
    @Column(name = "ID", unique = true, nullable = false, precision = 22, scale = 0)
    private Long id;


    @LookupField(LookupDefinition.ARREST_ACTION)
    @Column(name = "ARREST_ACTION_ID", nullable = false)
    private Long arrestActionId;

    @Column(name = "CREATED_BY", length = 20, nullable = false)
    private String createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE", nullable = false)
    private Date createdDate;

    @Column(name = "COMMENTS", length = 500)
    private String comments;

    @Column(name = "ARREST_REPORT_ID", nullable = false)
    private Long arrestId;

    private ArrestActionHistory() {

    }

    public ArrestActionHistory(Builder builder) {
        this.comments = builder.comments;
        this.arrestId = builder.arrestId;
        this.arrestActionId = builder.arrestActionId;

    }

    public Long getId() {
        return id;
    }

    public Long getArrestActionId() {
        return arrestActionId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    @Override
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getComments() {
        return comments;
    }

    public Long getArrestId() {
        return arrestId;
    }

    /**
     * Static method to prepare DeportationActionHistory object using Builder design pattern.
     */
    public static class Builder {

        private Long arrestId;
        private Long arrestActionId;
        private String comments;

        public Builder(Long arrestId) {
            this.arrestId = arrestId;
        }

        public Builder withActionId(Long arrestActionId) {
            this.arrestActionId = arrestActionId;
            return this;
        }

        public Builder withComments(String comments) {
            this.comments = comments;
            return this;
        }

        public ArrestActionHistory build() {
            return new ArrestActionHistory(this);
        }
    }
}