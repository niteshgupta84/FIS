package ae.emaratech.uaevision.arrest.application.utils;

import java.io.Serializable;

/**
 * Created by Nitesh.Gupta on 6/5/2016.
 */
public class ArrestConstants implements Serializable{
    public static final String ARREST_DIALOG_PATH = "/arrest/dialog/";
    public static final Long DEFAULT_ID = 0L;
    public static final String ARREST_DETAILS_URL = "arrest/ArrestDetails";
    public static final String ARREST_DTO = "arrestDto";
    public static final String ARREST_NOTE_DTO = "arrestNoteDto";
    public static final String ARREST_MODEL = "arrestModel";
    public static final String CURRENT_SECTION = "currentSection";
    public static final String ATTACHMENT_ID = "attachmentId";
    public static final String PRIVILEGED_USER = "isPrivilegedUser";
    public static final String DOCUMENT_INSPECTION_DTO = "documentInspectionDto";
    public static final String SEIZURE_DTO = "seizureDto";
    public static final String ARREST_TEAM_DTO = "arrestTeamDto";
    public static final String SUCCESS = "success";
    public static final String DEFAULT_STRING = "";
    public static final String PARTY_DTO = "partyDto";
    public static final String PARTY_CHARGE_DTO = "partyChargeDto";
    public static final String PARTY_PROFILE_VIEW_MODEL_OBJ = "partyProfileViewModelObj";
    public static final String Unknown_Party_Add = "Add";
    public static final String Party_Update = "Update";
    public static final String PASSPORT_DTO = "passportViewModel";
    public static final String DOCUMENT_DTO = "documentViewModel";
    public static final String IRIS_DATA_SESSION_KEY = "irisPartyDtoPhotoAddDetails";
    public static final String PARTY_PROFILE_PICTURE = "profilePicture";
    public static final String PARTY_IRIS_PICTURE = "irisPicture";
    public static final Long LONG_VALUE_ONE = 1L;
    public static final long NUMBER_ZERO = 0L;
    public static final String PARTY_IRIS_PICTURE_DESCRIPTION = "Party IRIS Picture";
    public static final Long SELECT_NONE_KEY = -1L;
    public static final Long DEFAULT_EMIRATE = 2L; // DUBAI
    public static final String BORDER_INCIDENT_URL = "borderControl/BorderIncident";
    public static final String EMPTY_STRING = "";
    public static final String ARRESTTYPE_VALUE_LOC_KEY = "incident.arrestReport.label.locvalue1";
    public static final String ARRESTTYPE_VALUE_COORDINATES_KEY = "incident.arrestReport.label.locvalue2";
    public static final String REPORT_PARAM_ARREST_ID = "ARREST_ID";
    public static final String ARREST_ATTACHMENT_UPLOAD_DTO = "arrestAttachmentDto";
    public static final String ATTACHMENT_REF_DTO = "attachmentReferecneDTO";
    public static final String CURRENT_UNIT = "currentUnit";
    public static final String LANDING_INCIDENT_SESSION_KEY = "arrestsSessionList";
    public static final String CURRENT_SECTION_NAME = "currentNameOfSection";
    public static final String CURRENT_DEPARTMENT_NAME = "currentNameOfDepartment";
    public static final String DETECTIVE_SECTIONNAME_KEY = "landingpage.label.detectiveSection";
    public static final String CRIMINAL_SECTIONNAME_KEY = "landingpage.label.criminalRecordsSection";
    public static final String DEFAULT_ASSOCIATION_TYPE = "1"; // Incident
    public static final String ARRESTS_IN_SESSION = "arrestsInSession"; // Incident
    public static final String REPORT_PARAM_IRIS_PARTYID = "PARTY_ID_IRIS";
    public static final String REPORT_PARAM_PARENT_INCIDENT_ID = "ARREST_ID";
    public static final String CASE_MODEL = "caseModel";
    public static final String CASES_IN_SESSION = "casesInSession";
    public static final String CASE_DIALOG_PATH = "/case/dialog/";
    public static final String CASE_DETAILS_URL = "case/CaseDetails";
    public static final String CASE_DTO = "caseDto";
    public static final String CASE_NOTE_DTO = "caseNoteDto";
    public static final String CASE_ATTACHMENT_UPLOAD_DTO = "caseAttachmentDto";
    public static final String LANDING_CASES_SESSION_KEY = "casesSessionList";
    public static final String ORDER_DTO = "orderDto";
    public static final String RELEASE_VIEW_MODEL = "releaseViewModel";
    public static final String REPORT_PARAM_CASE_ID = "CASE_ID";
    public static final String RETRIEVE_ARREST_BY_SEARCH_QUERY = "retrieveArrestBySearchQuery";
    public static final String RETRIEVE_CASES_BY_SEARCH_QUERY = "retrieveCasesBySearchQuery";
    public static final String PARTY_MODEL = "partyModel";
    public static final String REPORT_PARAM_PARENT_CASE_ID = "CASE_ID";
    public static final String ARREST_SEARCH_PAGE = "arrest/SearchArrests";
    public static final String BORDER_CONTROL_LANDING_PAGE = "borderControl/BCLanding";
    public static final String ARREST_VIEW_PAGE = "arrest/dialog/ArrestView";
    public static final String SEIZURE_ADD_PAGE = "arrest/dialog/SeizureAdd";
    public static final String ARREST_TEAM_ADD_PAGE = "arrest/dialog/ArrestTeamAdd";
    public static final String ARREST_NOTE_ADD_PAGE = "arrest/dialog/AddArrestNote";
    public static final String ARREST_DELETE_ATTACHMENT_PAGE = "arrest/dialog/DeleteAttachmentComment";
    public static final String ARREST_EDIT_ATTACHMENT_PAGE = "/arrest/dialog/EditAttachment";
    public static final String ARREST_PARTY_PROFILE = "arrest/dialog/ArrestPartyProfile";
    public static final String ARREST_PARTY_CHARGE_PAGE = "arrest/dialog/PartyCharge";
    public static final String EDIT_PARTY_PROFILE_PAGE = "arrest/dialog/EditPartyProfile";
    public static final Integer DEFAULT_LENGTH = 10;
    public static final Integer DEFAULT_START = 0;
    public static final Long FIS_ARREST_CREATE = 1208L;
    public static final Long FIS_CASE_CREATE = 1231L;
    public static final String PRIVIOUS_VISITED = "previousVisited";
    public static final String CURRENTLY_VISITED = "currentlyVisited";

    public static final Long DEFAULT_CITY = 902L; // UNKNOWN
    public static final Long DEFAULT_AREA = 99902L; // DUBAI


    public static final String ARREST_PROFILE = "arrest-clone";
    public static final String EDUCATION_DEGREE_DEFAULT ="260";
    public static final String RELIGION_DEFAULT ="12";
    public static final String SOCIAL_STATUS_DEFAULT ="6";

    public static final String TRAVEL_ROUTE_DTO = "travelRouteDto";
}
