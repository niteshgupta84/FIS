package ae.emaratech.uaevision.arrest.application.validators;

import ae.emaratech.uaevision.arrest.application.ArrestNotificationCode;
import ae.emaratech.uaevision.arrest.application.CreateArrestReportCommand;
import ae.emaratech.uaevision.arrest.application.UpdateArrestReportCommand;
import ae.emaratech.uaevision.arrest.application.dto.ArrestAssociationDto;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.common.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@Component
public class ArrestReportValidator {

    @Autowired
    private NotificationBus notificationBus;

    public boolean checkDuplicateAssociation(List<ArrestAssociationDto> associationDtoList,
                                             Long incidentId) {
        boolean isAlreadyAssociated = false;
        for (ArrestAssociationDto associationDto : associationDtoList) {
            if (associationDto.getLinkedArrestReportId() == incidentId.longValue()) {
                isAlreadyAssociated = true;
            }
        }
        return isAlreadyAssociated;
    }

    /**
     * Validating Arrest Report Information
     */
    public void validate(CreateArrestReportCommand command) {

        NotificationBuilder notificationBuilder = notificationBus.getBuilder();

        if (command.getDepartment().id() != Department.BORDER_CONTROL.id()) {

            if (!Checks.isValidString(command.getArrestLocation())) {
                notificationBuilder.add(ArrestNotificationCode.ARREST_LOCATION_MANDATORY);
            }
            if (command.getLocationType() == null) {
                notificationBuilder.add(ArrestNotificationCode.LOCATION_TYPE_MANDATORY);
            }
            if (Checks
                    .isNotValidLookUpId(command.getEmirateId().getId())) {
                notificationBuilder.add(ArrestNotificationCode.EMIRATE_MANDATORY);
            }
            if (Checks
                    .isNotValidLookUpId(command.getCityId().getId())) {
                notificationBuilder.add(ArrestNotificationCode.CITY_MANDATORY);
            }
            if (Checks
                    .isNotValidLookUpId(command.getAreaId().getId())) {
                notificationBuilder.add(ArrestNotificationCode.AREA_MANDATORY);
            }
            if (!Checks.isValidString(command.getArrestLocation())) {
                notificationBuilder.add(ArrestNotificationCode.ARREST_LOCATION_MANDATORY);
            }
        } else {
            if (Checks.isNotValidLookUpId(command.getTerminalLocation().getId())) {
                notificationBuilder.add(ArrestNotificationCode.ARREST_LOCATION_MANDATORY);
            }
            if (Checks.isNull(command.getUnit())) {
                notificationBuilder.add(ArrestNotificationCode.UNIT_MANDATORY);
            }
            //Validation for Terminal needs to be done as location check.
        }
        if (Checks.isNull(command.getTransferredFromId()) || Checks.isNotValidLookUpId(command.getTransferredFromId().getId())) {
            notificationBuilder.add(ArrestNotificationCode.TRANSFERRED_FROM_MANDATORY);
        }
        if (command.getArrestReason() == null) {
            notificationBuilder.add(ArrestNotificationCode.ARREST_REASON_MANDATORY);
        }
        if (command.getArrestDescription() != null && org.apache.commons.lang
                .StringUtils.isBlank(command.getArrestDescription().getValue())) {
            notificationBuilder.add(ArrestNotificationCode.ARREST_DESCRIPTION_MANDATORY);
        }
        if (!Checks.isNotNull(command.getArrestDate())) {
            notificationBuilder.add(ArrestNotificationCode.ARREST_DATE_MANDATORY);
        }
        if (!Checks.isNotNull(command.getArrestTime())) {
            notificationBuilder.add(ArrestNotificationCode.ARREST_TIME_MANDATORY);
        } else if (!Checks.isValidString(command.getArrestTime()) || !Checks
                .isRegexPatternMatches(command.getArrestTime(),
                        StringUtils.time_24hr_pattern)) {
            notificationBuilder.add(ArrestNotificationCode.ARREST_TIME_INVALID);
        }

        if (command.getPartyList().isEmpty()) {
            notificationBuilder.add(ArrestNotificationCode.PARTY_DETAIL_MISSING);
        }
        if (notificationBuilder.hasNotifications()) {
            notificationBus.send(notificationBuilder);
        }
    }

    public void validate(UpdateArrestReportCommand command) {

        NotificationBuilder notificationBuilder = notificationBus.getBuilder();

        if (command.getDepartment().id() != Department.BORDER_CONTROL.id()) {

            if (!Checks.isValidString(command.getArrestLocation())) {
                notificationBuilder.add(ArrestNotificationCode.ARREST_LOCATION_MANDATORY);
            }
            if (command.getLocationType() == null) {
                notificationBuilder.add(ArrestNotificationCode.LOCATION_TYPE_MANDATORY);
            }
            if (Checks
                    .isNotValidLookUpId(command.getEmirateId().getId())) {
                notificationBuilder.add(ArrestNotificationCode.EMIRATE_MANDATORY);
            }
            if (Checks
                    .isNotValidLookUpId(command.getCityId().getId())) {
                notificationBuilder.add(ArrestNotificationCode.CITY_MANDATORY);
            }
            if (Checks
                    .isNotValidLookUpId(command.getAreaId().getId())) {
                notificationBuilder.add(ArrestNotificationCode.AREA_MANDATORY);
            }
        } else {
            if (Checks.isNotValidLookUpId(command.getTerminalLocation().getId())) {
                notificationBuilder.add(ArrestNotificationCode.ARREST_LOCATION_MANDATORY);
            }
            if (Checks.isNotValidLookUpId(command.getUnit().getId())) {
                notificationBuilder.add(ArrestNotificationCode.UNIT_MANDATORY);
            }
        }
        if (Checks.isNull(command.getTransferredFromId()) || Checks.isNotValidLookUpId(command.getTransferredFromId().getId())) {
            notificationBuilder.add(ArrestNotificationCode.TRANSFERRED_FROM_MANDATORY);
        }
        if (command.getArrestReason() == null) {
            notificationBuilder.add(ArrestNotificationCode.ARREST_REASON_MANDATORY);
        }
        if (command.getArrestDescription() != null && org.apache.commons.lang
                .StringUtils.isBlank(command.getArrestDescription().getValue())) {
            notificationBuilder.add(ArrestNotificationCode.ARREST_DESCRIPTION_MANDATORY);
        }
        if (!Checks.isNotNull(command.getArrestDate())) {
            notificationBuilder.add(ArrestNotificationCode.ARREST_DATE_MANDATORY);
        }
        if (!Checks.isNotNull(command.getArrestTime())) {
            notificationBuilder.add(ArrestNotificationCode.ARREST_TIME_MANDATORY);
        } else if (!Checks.isValidString(command.getArrestTime()) || !Checks
                .isRegexPatternMatches(command.getArrestTime(),
                        StringUtils.time_24hr_pattern)) {
            notificationBuilder.add(ArrestNotificationCode.ARREST_TIME_INVALID);
        }

        if (command.getPartyList().isEmpty()) {
            notificationBuilder.add(ArrestNotificationCode.PARTY_DETAIL_MISSING);
        }
        if (notificationBuilder.hasNotifications()) {
            notificationBus.send(notificationBuilder);
        }
    }

}
