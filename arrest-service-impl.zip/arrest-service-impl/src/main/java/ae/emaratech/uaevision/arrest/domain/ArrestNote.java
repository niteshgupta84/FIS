package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.entity.AbstractEntityBase;
import ae.emaratech.uaevision.fis.common.key.NoteKey;

import javax.persistence.*;


/**
 * The persistent class for the ARREST_NOTE table.
 */
@Entity
@Table(name = "ARREST_NOTE")
public class ArrestNote extends AbstractEntityBase {

    private static final long serialVersionUID = 1L;

    @Column(name = "NOTE")
    private String note;

    @Column(name = "IS_DELETED")
    private Long isDeleted;

    //bi-directional many-to-one association to arrest report
    @ManyToOne
    @JoinColumn(name = "ARREST_REPORT_ID", nullable = false)
    private Arrest arrestReport;

    private ArrestNote() {

    }

    public ArrestNote(NoteKey noteKey, String note, Long isDeleted) {

        setId(noteKey.id());
        this.note = note;
        this.isDeleted = isDeleted;
    }

    protected String getNote() {
        return note;
    }

    protected void setNote(String note) {
        this.note = note;
    }

    protected Long getIsDeleted() {
        return isDeleted;
    }

    protected void setIsDeleted(Long isDeleted) {
        this.isDeleted = isDeleted;
    }

    protected Arrest getArrestReport() {
        return arrestReport;
    }

    protected void setArrestReport(Arrest arrestReport) {
        this.arrestReport = arrestReport;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ArrestNote that = (ArrestNote) o;

        if (id() != null ? !id().equals(that.id()) : that.id() != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return id() != null ? id().hashCode() : 0;
    }
}