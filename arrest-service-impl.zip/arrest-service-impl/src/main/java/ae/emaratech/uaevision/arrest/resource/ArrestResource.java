package ae.emaratech.uaevision.arrest.resource;

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestReportTrackDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamListDto;
import ae.emaratech.uaevision.arrest.application.utils.ArrestConstants;
import ae.emaratech.uaevision.arrest.query.ArrestQueryService;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestHistoryQuery;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestQuery;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestTeamByEmployeeIdQuery;
import ae.emaratech.uaevision.arrest.report.ArrestReportGenerator;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.util.PageUtils;
import ae.emaratech.uaevision.fis.report.core.FISReport;
import ae.emaratech.uaevision.fis.report.core.FISReportFormat;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import com.github.dandelion.datatables.core.ajax.DataSet;
import com.github.dandelion.datatables.core.ajax.DatatablesCriterias;
import com.github.dandelion.datatables.core.ajax.DatatablesResponse;
import com.github.dandelion.datatables.extras.spring3.ajax.DatatablesParams;
import io.swagger.annotations.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
@RequestMapping(value = "/rest/arrest")
@RestController
@Api(value="Arrest Resource ", description = "Arrest Resource Controller for handling all requests coming to Arrest module")
public class ArrestResource {
    /**
     * Static containing Logger for the class.
     */
    private static final Logger LOGGER = LogManager.getLogger();
    @Autowired
    private ArrestQueryService arrestQueryService;

    @Autowired
    private ArrestReportGenerator arrestReportGenerator;


    @ApiOperation(value = "Arrest Details", notes = "End point case Details will return complete information of Arrest", produces = "application/json")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Arrest Details found", response = ArrestReportDto.class)
    })
    @RequestMapping(value = "/{arrestId}", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ArrestReportDto getArrestReport(@ApiParam(value = "Target Arrest Id for Fetching Arrest ", required = true) @PathVariable Long arrestId) {

        ArrestReportKey arrestReportKey = new ArrestReportKey(arrestId);
        RetrieveArrestQuery query = new RetrieveArrestQuery(arrestReportKey);
        ArrestReportDto arrestReportDto = arrestQueryService.retrieveArrestReport(query);
        List<ArrestTeamDto> arrestTeamDtoList = arrestQueryService.retrieveArrestTeamsForArrest(query);
        if (CollectionUtils.isNotEmpty(arrestTeamDtoList)){
            arrestReportDto.setArrestTeamList(arrestTeamDtoList);
        }
        return arrestReportDto;

    }


    @ApiOperation(value = "Returns paginated Arrest action history", notes = "This uri will return list of actions taken for given Arrest Report Id")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Track Details found", response = ArrestReportTrackDto.class, responseContainer = "DatatablesResponse")})
    @RequestMapping(value = "/{arrestReportId}/tracks", method = RequestMethod.GET)
    @ResponseBody
    DatatablesResponse<ArrestReportTrackDto> fetchTracks(@ApiParam(value = "Target Arrest Id for Fetching Arrest Track", required = true) @PathVariable Long arrestReportId,
                                                         @DatatablesParams DatatablesCriterias criterias) {

        LOGGER.info("Retrieving Track for Arrest  ", arrestReportId);
        ArrestReportKey arrestReportKey = new ArrestReportKey(arrestReportId);
        RetrieveArrestHistoryQuery retrieveArrestHistoryQuery =
                new RetrieveArrestHistoryQuery(arrestReportKey);
        List<ArrestReportTrackDto> arrestReportTrackDtoList =
                arrestQueryService.retrieveArrestHistory(retrieveArrestHistoryQuery);

        long seqNo = 0;
        for (ArrestReportTrackDto trackDto : arrestReportTrackDtoList) {
            seqNo = seqNo + 1;
            trackDto.setSequenceNo(seqNo);
        }
        List<ArrestReportTrackDto> subList =
                (List) PageUtils.getPaginatedList(criterias.getStart(), criterias.getLength(),
                        arrestReportTrackDtoList);
        DataSet<ArrestReportTrackDto> dataset =
                new DataSet<>(subList, (long) subList.size(), (long) arrestReportTrackDtoList.size());
        return DatatablesResponse.build(dataset, criterias);
    }


    @ApiOperation(value = "Generate and Download Arrest Report", notes = "This URI will generate and download Arrest report for given Id")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Arrest Report Generated")})
    @RequestMapping(value = {"/viewArrestReport/{arrestId}"}, method = RequestMethod.GET)
    public void generateArrestReport(@ApiParam(value = "Target Arrest Id for downloading report ", required = true) @PathVariable Long arrestId, HttpServletResponse response) {

        ReportParameters parameters = new ReportParameters();
        parameters.addParameter(ArrestConstants.REPORT_PARAM_ARREST_ID, arrestId);
        try {
            FISReport report = arrestReportGenerator.generateReport(parameters, FISReportFormat.PDF);
            response.setContentType("application/pdf");
            response.setContentLength(report.getContent().length);
            ServletOutputStream servletOutputStream = response.getOutputStream();
            servletOutputStream.write(report.getContent(), 0, report.getContent().length);
            servletOutputStream.flush();
            servletOutputStream.close();
        } catch (Exception ex) {
            LOGGER.error("Exception occurred. ", ex);
        }
    }

    @RequestMapping(value = {"/arrestTeam"}, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ArrestTeamListDto getArrestTeam(
            @RequestBody RetrieveArrestTeamByEmployeeIdQuery retrieveArrestTeamByEmployee)
    {
        List<ArrestTeamDto> listArrestTeam = arrestQueryService.retrieveArrestTeam(retrieveArrestTeamByEmployee);
        ArrestTeamListDto result = null;

        if(CollectionUtils.isNotEmpty(listArrestTeam)){
            result = new ArrestTeamListDto();
            result.setArrestTeamDtoList(listArrestTeam);
        }

        return result;
    }

}
