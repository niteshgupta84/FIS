package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;
import ae.emaratech.uaevision.lookup.service.model.Entry;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Entity bean encapsulating the owner information like Department, Section and unit.
 *
 * @author Nitesh.Gupta
 */
@Embeddable
public class Owner implements Serializable {

    /**
     * Refers the Department of logged in user
     */
    @Column(name = "DEPARTMENT_ID")
    private Long department;

    /**
     * Refers the Section of logged in user
     */
    @Column(name = "SECTION_ID")
    private Long section;

    /**
     * Refers the Section Unit of logged in user
     */
    @Column(name = "SECTION_UNIT_ID")
    private Long sectionUnit;

    /**
     * Private constructor. Added for integration with Hibernate.
     */
    private Owner() {

    }

    public Owner(Department department, Section section, Entry sectionUnit) {
        this.department = department.id();
        this.section = section.id();
        if (sectionUnit != null) {
            this.sectionUnit = Long.valueOf(sectionUnit.getId());
        }
    }

    protected Long getDepartment() {
        return department;
    }

    protected Long getSection() {
        return section;
    }

    protected Long getSectionUnit() {
        return sectionUnit;
    }
}
