package ae.emaratech.uaevision.arrest.report;
/**
 * Created by Satya K on 26/4/2016.
 */

import ae.emaratech.uaevision.fis.common.exception.BusinessException;
import ae.emaratech.uaevision.fis.report.core.FISReport;
import ae.emaratech.uaevision.fis.report.core.FISReportFormat;
import ae.emaratech.uaevision.fis.report.core.FISReportGenerator;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperReportGenerator;
import net.sf.jasperreports.engine.JRDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;

@Component
public class IRISReportGenerator implements FISReportGenerator {

    private static final String IRIS_REPORT_NAME = "party-iris-report";

    @Autowired
    private IRISReportDataSource irisReportDataSource;
    @Autowired
    private JasperReportGenerator jasperReportGenerator;
    @Override
    public FISReport generateReport(ReportParameters parameters, FISReportFormat fisReportFormat) throws BusinessException {
        JRDataSource dataSource = irisReportDataSource.getDataSource(parameters);
        FISReport report = new FISReport();
        report.setContent(jasperReportGenerator.generateReport(IRIS_REPORT_NAME, new HashMap(), dataSource));
        return report;
    }
}
