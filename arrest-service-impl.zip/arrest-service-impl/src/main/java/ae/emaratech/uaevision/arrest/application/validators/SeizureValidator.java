package ae.emaratech.uaevision.arrest.application.validators;

import ae.emaratech.uaevision.arrest.application.AddSeizureCommand;
import ae.emaratech.uaevision.arrest.application.ArrestNotificationCode;
import ae.emaratech.uaevision.arrest.application.EditSeizureCommand;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.util.Checks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
@Component("newValidator")
public class SeizureValidator implements Serializable {

    @Autowired
    private NotificationBus notificationBus;


    public void validate(AddSeizureCommand command) {
        {

            NotificationBuilder notificationBuilder = notificationBus.getBuilder();
            if (Checks.isNotNull(command)) {

                if (!Checks.isValidString(command.getSeizedItem())) {
                    // TODO : Find out why cant we use the method with just two arguments
                    notificationBuilder
                            .add(ArrestNotificationCode.SEIZED_ITEMS_MANDATORY);
                } else if (!Checks.isValidString(command.getItemCount())) {
                    notificationBuilder
                            .add(ArrestNotificationCode.SEIZED_COUNT_MANDATORY);
                } else if (!Checks.isRegexPatternMatches(command.getItemCount(), "[0-9]+") || !Checks
                        .isNumberNonZero(command.getItemCount())) {
                    notificationBuilder
                            .add(ArrestNotificationCode.SEIZED_COUNT_INVALID);
                } else if (command.getItemCount().length() > 5) {
                    notificationBuilder
                            .add(ArrestNotificationCode.SEIZED_COUNT_LENGTH_ISSUE);
                } else if (command.getSeizedItem().length() > 200) {
                    notificationBuilder
                            .add(ArrestNotificationCode.SEIZED_ITEM_LENGTH_ISSUE);
                }
            }
            if (notificationBuilder.hasNotifications()) {
                notificationBus.send(notificationBuilder);
            }
        }
    }

    public void validate(EditSeizureCommand command) {

        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        if (Checks.isNotNull(command)) {

            if (!Checks.isValidString(command.getSeizedItem())) {
                // TODO : Find out why cant we use the method with just two arguments
                notificationBuilder
                        .add(ArrestNotificationCode.SEIZED_ITEMS_MANDATORY);
            } else if (!Checks.isValidString(command.getItemCount())) {
                notificationBuilder
                        .add(ArrestNotificationCode.SEIZED_COUNT_MANDATORY);
            } else if (!Checks.isRegexPatternMatches(command.getItemCount(), "[0-9]+") || !Checks
                    .isNumberNonZero(command.getItemCount())) {
                notificationBuilder
                        .add(ArrestNotificationCode.SEIZED_COUNT_INVALID);
            } else if (command.getItemCount().length() > 5) {
                notificationBuilder
                        .add(ArrestNotificationCode.SEIZED_COUNT_LENGTH_ISSUE);
            } else if (command.getSeizedItem().length() > 200) {
                notificationBuilder
                        .add(ArrestNotificationCode.SEIZED_ITEM_LENGTH_ISSUE);
            }
        }
        if (notificationBuilder.hasNotifications()) {
            notificationBus.send(notificationBuilder);
        }
    }
}
