package ae.emaratech.uaevision.arrest.application.validators;

import ae.emaratech.uaevision.arrest.application.AddArrestTeamCommand;
import ae.emaratech.uaevision.arrest.application.ArrestNotificationCode;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.util.Checks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.Serializable;


/**
 * Created by Nitesh.Gupta on 1/19/2016.
 * Arrest Team Validator
 */
@Component("newArrestTeamValidator")
public class ArrestTeamValidator implements Serializable {

    @Autowired
    private NotificationBus notificationBus;

    public void validate(AddArrestTeamCommand command) {

        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        if (command != null) {
            if (!Checks.isValidString(command.getEmployeeId()) || Checks
                    .isNotValidLookUpId(command.getEmployeeId())) {
                notificationBuilder
                        .add(ArrestNotificationCode.ARREST_TEAM_EMPLOYEEIDNULL);

            } else if (!Checks.isRegexPatternMatches(command.getEmployeeId(), "[0-9]+")) {
                notificationBuilder
                        .add(ArrestNotificationCode.ARREST_TEAM_EMPLOYEE_LENGTH);

            }
        }
        if (notificationBuilder.hasNotifications()) {
            notificationBus.send(notificationBuilder);
        }
    }

}
