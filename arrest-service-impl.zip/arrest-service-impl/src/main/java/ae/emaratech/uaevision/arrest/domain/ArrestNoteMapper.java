package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.application.dto.ArrestNoteDto;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@Component
public class ArrestNoteMapper {


    @Autowired
    private UserService userService;


    /**
     * Mapping Note Dto from Entity
     */
    public ArrestNoteDto mapToArrestNoteDto(ArrestNote arrestNoteEntity) {
        ArrestNoteDto arrestNoteDto = new ArrestNoteDto();

        arrestNoteDto.setCreatedDate(arrestNoteEntity.getCreatedDate());
        arrestNoteDto.setCreatedBy(userService.getUserFirstNameByUserLogin(arrestNoteEntity.getCreatedBy()));
        arrestNoteDto.setId(arrestNoteEntity.id());

        arrestNoteDto.setTextNote(arrestNoteEntity.getNote());
        arrestNoteDto.setViewId(arrestNoteEntity.id());
        return arrestNoteDto;
    }

    /**
     * Preparing Note List from Set
     */
    public List<ArrestNoteDto> mapToArrestNoteDtList(Set<ArrestNote> arrestNoteSet) {
        List<ArrestNoteDto> arrestNoteDtoList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(arrestNoteSet)) {
            arrestNoteDtoList.addAll(arrestNoteSet.stream().map(this::mapToArrestNoteDto).collect(Collectors.toList()));
        }
        return arrestNoteDtoList;

    }

}
