package ae.emaratech.uaevision.arrest.application.utils;

import ae.emaratech.uaevision.fis.common.dto.Identifiable;

/**
 * Created by Satya on 14/3/2016.
 */
public enum LocationTypeEnum implements Identifiable {
    LOC(1L, ArrestConstants.ARRESTTYPE_VALUE_LOC_KEY),
    COORDINATES(2L, ArrestConstants.ARRESTTYPE_VALUE_COORDINATES_KEY);
    private String key;
    private Long id;

    LocationTypeEnum(Long id, String key) {
        this.id = id;
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long id() {

        return this.id;
    }

}
