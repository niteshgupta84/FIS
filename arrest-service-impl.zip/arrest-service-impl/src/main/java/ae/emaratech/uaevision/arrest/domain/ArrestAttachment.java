package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.entitylistener.Creatable;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedByListener;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedDateListener;
import ae.emaratech.uaevision.fis.common.key.AttachmentReferenceKey;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the INCIDENT_ATTACHMENT database table.
 */
@Entity
@EntityListeners({
        CreatedDateListener.class,
        CreatedByListener.class,
})
@Table(name = "ARREST_ATTACHMENT")
public class ArrestAttachment implements Creatable, Serializable {

    /**
     * Holds Unique key for Arrest Attachment.
     */
    @Id
    @SequenceGenerator(name = "ARREST_ATTACHMENT_ID_GENERATOR", sequenceName = "SEQ_ARREST_ATTACHMENT", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ARREST_ATTACHMENT_ID_GENERATOR")
    @Column(name = "ID", unique = true, nullable = false)
    private Long id;

    @Column(name = "ATTACHMENT_REF_ID", nullable = false)
    private Long attachmentReferenceId;


    //bi-directional many-to-one association to Incident
    @ManyToOne
    @JoinColumn(name = "ARREST_REPORT_ID", nullable = false)
    private Arrest arrestReport;

    /**
     * Created By
     */
    @Column(name = "CREATED_BY", length = 30, nullable = false)
    private String createdBy;

    /**
     * Created Date field
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE", nullable = false)
    private Date createdDate;

    private ArrestAttachment() {

    }

    public ArrestAttachment(AttachmentReferenceKey attachmentReferenceKey) {
        this.attachmentReferenceId = attachmentReferenceKey.id();
    }

    protected Long id() {
        return this.id;
    }

    protected Long getAttachmentReferenceId() {
        return attachmentReferenceId;
    }

    protected Arrest getArrestReport() {
        return arrestReport;
    }

    protected void setArrestReport(Arrest arrestReport) {
        this.arrestReport = arrestReport;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    protected Date getCreatedDate() {
        return createdDate;
    }

    @Override
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
