package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.document.application.AttachedDocumentDto;
import ae.emaratech.uaevision.document.service.api.DocumentService;
import ae.emaratech.uaevision.document.service.dto.ContentType;
import ae.emaratech.uaevision.document.service.dto.DocumentInfoDto;
import ae.emaratech.uaevision.document.service.dto.DocumentKeyDto;
import ae.emaratech.uaevision.document.service.dto.DocumentReferenceDto;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.common.util.Enums;
import ae.emaratech.uaevision.fis.party.application.ModuleTypes;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@Component
public class ArrestAttachmentMapper {

    @Autowired
    private DocumentService documentService;

    @Autowired
    private LookupService lookupService;


    @Autowired
    private UserService userService;


    public AttachedDocumentDto mapArrestAttachmentDto(
            ArrestAttachment arrestAttachment) {

        AttachedDocumentDto arrestAttachmentDto = new AttachedDocumentDto();
        arrestAttachmentDto
                .setAttachmentReferenceId(arrestAttachment.getAttachmentReferenceId());
        arrestAttachmentDto.setViewId(UUID.randomUUID().toString());
        arrestAttachmentDto.setIncidentType(lookupService.getLookupEntry(LookupDefinition.INCIDENT_TYPE,
                LocaleContextHolder
                        .getLocale(),
                ModuleTypes.ARREST.id()).get());
        DocumentReferenceDto documentReferenceDto = documentService.downloadDocument(
                arrestAttachment.getAttachmentReferenceId());
        ContentType contentType =
                Enums.constant(ContentType.class, documentReferenceDto.getMimeTypeId());
        DocumentInfoDto documentInfoDto =
                new DocumentInfoDto(documentReferenceDto.getFileName(), contentType);
        documentInfoDto.setKey(new DocumentKeyDto(String.valueOf(documentReferenceDto.getId())));
        documentInfoDto.setDocumentSize(documentReferenceDto.getAttachmentSize());
        arrestAttachmentDto.setDescription(documentReferenceDto.getDescription());
        if (Checks.isNotNull(documentReferenceDto.getDocumentType())) {
            arrestAttachmentDto.setDocumentType(
                    lookupService.getLookupEntry(LookupDefinition.IDENTIFICATION_DOC_TYPE,
                            LocaleContextHolder.getLocale(),
                            documentReferenceDto.getDocumentType().getId()).get()
                            .getName());
            arrestAttachmentDto.setDocumentTypeId(
                    Long.valueOf(documentReferenceDto.getDocumentType().getId()));
        }

        arrestAttachmentDto.setCreatedBy(userService.getUserFirstNameByUserLogin(arrestAttachment.getCreatedBy()));
        arrestAttachmentDto.setCreatedDate(arrestAttachment.getCreatedDate());

        arrestAttachmentDto.setDocumentInfo(documentInfoDto);

        return arrestAttachmentDto;
    }


}
