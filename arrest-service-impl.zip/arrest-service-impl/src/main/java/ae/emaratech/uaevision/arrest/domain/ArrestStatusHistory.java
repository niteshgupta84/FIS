package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.entitylistener.Creatable;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedByListener;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedDateListener;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the INCIDENT_STATUS_HISTORY database table.
 */
@Entity
@EntityListeners({
        CreatedDateListener.class,
        CreatedByListener.class
})
@Table(name = "ARREST_STATUS_HISTORY")
public class ArrestStatusHistory implements Creatable {

    private static final Long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "SEQ_ARREST_STATUS_HIST_ID_GENERATOR", sequenceName = "SEQ_ARREST_STATUS_HIST", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ARREST_STATUS_HIST_ID_GENERATOR")
    @Column(name = "ID", unique = true, nullable = false)
    private Long id;

    @Column(name = "ARREST_REPORT_ID", nullable = false)
    private Long arrestReportId;

    @Column(name = "CREATED_BY", length = 30, nullable = false)
    private String createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE", nullable = false)
    private Date createdDate;

    @Column(name = "ARREST_STATUS_ID", nullable = false)
    private Long arrestStatusId;


    private ArrestStatusHistory() {

    }

    public ArrestStatusHistory(ArrestReportKey arrestKey, Long statusId) {

        this.arrestStatusId = statusId;
        this.arrestReportId = arrestKey.id();
    }

    private ArrestStatusHistory(Builder builder) {
        this.arrestStatusId = builder.arrestStatusId;
        this.arrestReportId = builder.arrestId;

    }

    public Long getArrestId() {
        return arrestReportId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    @Override
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Long getArrestStatusId() {
        return arrestStatusId;
    }

    public Long getId() {
        return id;
    }


    public static class Builder {

        private Long arrestStatusId;
        private Long arrestId;

        public Builder(Long arrestId) {
            this.arrestId = arrestId;
        }

        public Builder withStatusId(Long statusId) {
            this.arrestStatusId = statusId;
            return this;
        }

        public ArrestStatusHistory build() {
            return new ArrestStatusHistory(this);
        }

    }
}
