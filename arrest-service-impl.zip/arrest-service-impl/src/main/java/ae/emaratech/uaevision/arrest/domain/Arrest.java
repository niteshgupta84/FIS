package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.application.utils.ArrestConstants;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.entity.AbstractEntityBase;
import ae.emaratech.uaevision.fis.common.key.*;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.party.application.ModuleTypes;
import ae.emaratech.uaevision.lookup.service.annotation.LookupField;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.FetchProfile;

import javax.persistence.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Business object representing the Arrest Report domain. The state of the object provides the
 * contextual data for the domain and serves as the entity bean for persistence.
 *
 * @author Haroon.Subair, Nitesh.Gupta
 */
@Entity
@Table(name = "ARREST")
@FetchProfile(name = ArrestConstants.ARREST_PROFILE, fetchOverrides = {
        @FetchProfile.FetchOverride(entity = Arrest.class, association = "parties", mode = FetchMode.JOIN),
        @FetchProfile.FetchOverride(entity = Arrest.class, association = "arrestTeams", mode = FetchMode.JOIN)
        ,@FetchProfile.FetchOverride(entity = Arrest.class, association = "seizures", mode = FetchMode.JOIN)
        ,@FetchProfile.FetchOverride(entity = Arrest.class, association = "attachments", mode = FetchMode.JOIN)
        ,@FetchProfile.FetchOverride(entity = Arrest.class, association = "notes", mode = FetchMode.JOIN)
        ,@FetchProfile.FetchOverride(entity = Arrest.class, association = "arrestAssociations", mode = FetchMode.JOIN)

})

public class Arrest extends AbstractEntityBase {


    private static final Long serialVersionUID = 1L;

    @Embedded
    private ArrestLocation arrestLocation;

    @LookupField(LookupDefinition.ARREST_REASON)
    @Column(name = "ARREST_REASON_ID", nullable = false, insertable = true)
    private Long arrestReasonId;

    @Embedded
    private Owner owner;

    @Column(name = "IS_URGENT", precision = 1, nullable = false)
    private long isUrgent;

    @Column(name = "TRANSFERRED_FROM_DEPT_ID", nullable = false)
    private Long transferredFromDeptId;

    @Column(name = "REPORT_YEAR", nullable = false)
    private Long year;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "ARREST_DATETIME", nullable = false)
    private Date arrestDatetime;

    @Column(name = "REPORT_DESCRIPTION", length = 4000, nullable = false)
    private String reportDescription;

    @LookupField(LookupDefinition.SHIFT)
    @Column(name = "SHIFT_ID", nullable = false)
    private Long shiftId;

    @Column(name = "CREATED_BY_AHWAL", nullable = false)
    private Long isCreatedByAhwal;


    @LookupField(LookupDefinition.ARREST_STATUS)
    @Column(name = "STATUS_ID", nullable = false)
    private Long statusId;

    @Column(name = "ASSIGNED_USER", nullable = false)
    private String assignedUser;

    @Column(name = "TRACKER_ID", nullable = false)
    private Long trackerId;

    @Column(name = "ARREST_NUMBER", nullable = false)
    private String arrestNumber;

    //bi-directional many-to-one association to ArrestTeam
    @OneToMany(mappedBy = "arrestReport", fetch = FetchType.LAZY, orphanRemoval = true, cascade = CascadeType.ALL)
    private Set<ArrestTeam> arrestTeams = new HashSet<>();

    //bi-directional many-to-one association to Seizure
    @OneToMany(mappedBy = "arrestReport", fetch = FetchType.LAZY, orphanRemoval = true, cascade = CascadeType.ALL)
    private Set<Seizure> seizures = new HashSet<>();

    @OneToMany(mappedBy = "arrestReport", fetch = FetchType.LAZY, orphanRemoval = true, cascade = CascadeType.ALL)
    @OrderBy("createdDate DESC")
    private Set<ArrestAttachment> attachments = new HashSet<>();

    @OneToMany(mappedBy = "arrestReport", fetch = FetchType.LAZY, orphanRemoval = true, cascade = CascadeType.ALL)
    @OrderBy("createdDate DESC")
    private Set<ArrestNote> notes = new HashSet<>();

    @OneToMany(mappedBy = "arrestReport", fetch = FetchType.LAZY, orphanRemoval = true, cascade = CascadeType.ALL)
    @OrderBy("partyId ASC")
    private Set<ArrestParty> parties = new LinkedHashSet<>();

    @OneToMany(mappedBy = "arrestReport", fetch = FetchType.LAZY, orphanRemoval = true, cascade = CascadeType.ALL)
    @OrderBy("createdDate DESC")
    private Set<ArrestAssociation> arrestAssociations = new HashSet<>();

    @Column(name = "ENTRY_EXIT_ID")
    private Long entryExitId;

    private Arrest() {

    }

    /**
     * Initializes the Arrest Report domain with the mandatory fields.
     *
     * @param arrestReportKey   the arrest identifier
     * @param arrestReason      the arrest reason identifier
     * @param arrestDescription the arrest report description
     * @param arrestLocation    the arrest location
     * @param parties           the list of parties involved in the arrest incident
     * @param owner             the owner information
     */
    public Arrest(ArrestReportKey arrestReportKey, ArrestReason arrestReason,
                  ArrestDescription arrestDescription, ArrestLocation arrestLocation,
                  Set<ArrestParty> parties, Owner owner, TrackerKey trackerKey, String arrestNumber) {

        setId(arrestReportKey.id());
        this.arrestReasonId = arrestReason.id();
        this.reportDescription = arrestDescription.getValue();
        this.arrestLocation = arrestLocation;
        // Set reference of the arrest report within each arrest party.
        parties.forEach(arrestParty -> arrestParty.setArrestReport(this));
        this.parties = parties;

        this.owner = owner;
        this.year = Long.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        this.trackerId = trackerKey.id();
        this.arrestNumber = arrestNumber;

    }

    /**
     * Review Method for sending arrest to supervisor.
     *
     * @param reviewComments the comments for the supervisor before reviewing the arrest report.
     * @return the arrest report sent for review event
     */
    public ArrestReportReviewedEvent review(String reviewComments) {

        this.statusId = ArrestStatus.PENDING_DECISION.id();

        return new ArrestReportReviewedEvent.Builder(new EventContext(ModuleTypes.ARREST, trackerId),
                                                     new ArrestReportKey(this.id()))
                .withArrestStatus(this.statusId)
                .withReviewComments(reviewComments)
                .build();

    }

    /**
     * Review Method for sending arrest to supervisor.
     *
     * @param rejectComments the comments provided by the supervisor while rejecting the arrest report
     *                       submitted for review.
     * @return the arrest report review rejected event
     */
    public ArrestReportRejectedEvent reject(String rejectComments) {

        this.statusId = ArrestStatus.OPENED.id();

        return new ArrestReportRejectedEvent.Builder(new EventContext(ModuleTypes.ARREST, trackerId),
                                                     new ArrestReportKey(this.id()))
                .withArrestStatus(this.statusId)
                .withRejectedComments(rejectComments)
                .build();

    }

    /**
     * Review Method for sending arrest to supervisor.
     *
     * @param approveComments the approval comments from supervisor after reviewing the arrest
     *                        report.
     * @return the arrest report review approved event.
     */
    public ArrestReportApprovedEvent approve(String approveComments) {

        this.statusId = ArrestStatus.APPROVED.id();

        return new ArrestReportApprovedEvent.Builder(new EventContext(ModuleTypes.ARREST, trackerId),
                                                     new ArrestReportKey(this.id()))
                .withArrestStatus(this.statusId)
                .withApproveComments(approveComments)
                .build();
    }

    /**
     * Review Method for marking the arrest report as ended/completed .
     *
     * @param endComments the completion comments for the arrest report.
     * @return the arrest report ended event.
     */
    public ArrestReportEndedEvent end(String endComments) {

        this.statusId = ArrestStatus.ENDED.id();

        return new ArrestReportEndedEvent.Builder(new EventContext(ModuleTypes.ARREST, trackerId),
                                                  new ArrestReportKey(this.id()))
                .withArrestStatus(this.statusId)
                .withEndComments(endComments)
                .build();

    }

    /**
     * Review Method for forwarding incident to case.
     *
     * @param forwardComment the comments provided while forwarding the arrest report to CRM section.
     * @return the arrest report forwarded event.
     */
    public ArrestReportForwardedEvent forwardToCase(String forwardComment) {

        this.statusId = ArrestStatus.FORWARDED.id();

        return new ArrestReportForwardedEvent.Builder(new EventContext(ModuleTypes.ARREST, trackerId),
                                                      new ArrestReportKey(this.id()))
                .withArrestStatus(this.statusId)
                .withForwardComments(forwardComment)
                .withArrestReason(this.arrestReasonId)
                .withTransferredFrom(this.transferredFromDeptId)
                .build();

    }


    /**
     * Close Method for Arrest Report
     *
     * @param closeComments the closing comments.
     * @return the arrest report closed event.
     */
    public ArrestReportClosedEvent close(String closeComments) {

      this.statusId = ArrestStatus.CLOSED.id();

      return new ArrestReportClosedEvent.Builder(new EventContext(ModuleTypes.ARREST, trackerId),
                                                 new ArrestReportKey(this.id()))
              .withArrestStatus(this.statusId)
              .withCloseComments(closeComments)
              .build();
    }

    /**
     * Method to reopen a arrest report
     *
     * @param orderKey the order against which the arrest report was re-opened.
     * @return the arrest report reopened event.
     */
    public ArrestReportReopenedEvent reopen(OrderKey orderKey) {

        this.statusId = ArrestStatus.OPENED.id();

        return new ArrestReportReopenedEvent.Builder(new EventContext(ModuleTypes.ARREST, trackerId),
                                                   new ArrestReportKey(this.id()), orderKey)
                .withArrestStatus(this.statusId)
                .build();

    }

    /**
     * Method to Assign Arrest to user
     */
    public ArrestAssignedEvent assignUser(String userId) {

        this.assignedUser = userId;
        return new ArrestAssignedEvent.Builder(new EventContext(ModuleTypes.ARREST, trackerId),
                                               new ArrestReportKey(this.id()))
                .withAssignedUser(this.assignedUser)
                .build();
    }

    /**
     * Method which creates the arrest report for the detective section.
     *
     * @param arrestAttachments  the set of attachments associated with the arrest report.
     * @param seizures           the set of seizures.
     * @param arrestNotes        the set of notes.
     * @param arrestAssociations the set of associated arrest reports
     * @param arrestTeams        the set of arrest team details
     * @param transferredFromId  the transferred from department identifier.
     * @param shift              the shift identifier.
     * @param urgent             the urgent flag.
     * @param createdByAhwal     the created by ahwal flag.
     * @param arrestDateTime     the arrest date and time information
     */
    public ArrestReportCreatedEvent create(Set<ArrestAttachment> arrestAttachments,
                                           Set<Seizure> seizures, Set<ArrestNote> arrestNotes,
                                           Set<ArrestAssociation> arrestAssociations,
                                           Set<ArrestTeam> arrestTeams,
                                           Entry transferredFromId, Entry shift,
                                           boolean urgent, boolean createdByAhwal,
                                           Date arrestDateTime, String arrestNumber, Entry entryExit) {

        this.statusId = ArrestStatus.OPENED.id();

        if (transferredFromId != null && !Checks.isNotValidLookUpId(transferredFromId.getId())) {
            this.transferredFromDeptId = transferredFromId.getId();
        }
        if (shift != null && !Checks.isNotValidLookUpId(shift.getId())) {
            this.shiftId = shift.getId();
        }

        if (entryExit != null && !Checks.isNotValidLookUpId(entryExit.getId())) {
            this.entryExitId = entryExit.getId();
        }

        this.isUrgent = urgent ? 1L : 0L;
        this.isCreatedByAhwal = createdByAhwal ? 1L : 0L;
        this.arrestDatetime = arrestDateTime;
        this.arrestNumber = arrestNumber;

        // Set reference of the arrest report within each arrest association.
        if (CollectionUtils.isNotEmpty(arrestAssociations)) {
            arrestAssociations.forEach(arrestAssociation -> arrestAssociation.setArrestReport(this));
            this.arrestAssociations = arrestAssociations;
        }

        // Set reference of the arrest report within each arrest attachment.
        if (CollectionUtils.isNotEmpty(arrestAttachments)) {
            arrestAttachments.forEach(arrestAttachment -> arrestAttachment.setArrestReport(this));
            this.attachments = arrestAttachments;
        }

        // Set reference of the arrest report within each seizures.
        if (CollectionUtils.isNotEmpty(seizures)) {
            seizures.forEach(seizure -> seizure.setArrestReport(this));
            this.seizures = seizures;
        }

        // Set reference of the arrest report within each arrest notes.
        if (CollectionUtils.isNotEmpty(arrestNotes)) {
            arrestNotes.forEach(note -> note.setArrestReport(this));
            this.notes = arrestNotes;
        }

        // Set reference of the arrest report within each arrest teams.
        if (CollectionUtils.isNotEmpty(arrestTeams)) {
            arrestTeams.forEach(arrestTeam -> arrestTeam.setArrestReport(this));
            this.arrestTeams = arrestTeams;
        }

        // Populating the event instance for create operation.
        return new ArrestReportCreatedEvent.Builder(new EventContext(ModuleTypes.ARREST, trackerId),
                                                    new ArrestReportKey(this.id()),
                                                    new ArrestReason(this.arrestReasonId),
                                                    this.reportDescription)
            .withStatus(this.statusId)
            .withArrestLocation(this.arrestLocation.getLocation())
            .withTransferredFrom(transferredFromDeptId)
            .withArrestDateTime(arrestDatetime)
            .withIsCreatedByAhwal(isCreatedByAhwal)
            .withNotes(getNotesIdList())
            .withSeizures(getSeizureIdList())
            .withAttachments(getArrestAttachmentReferenceIdList())
            .withArrestAssociations(getArrestAssociationIdList())
            .withArrestTeams(getArrestTeamEmployeeNoList())
            .withArrestNumber(getArrestNumber())
            .withEntryExitId(getEntryExitId())
            .build();
    }


    private List<Long> getNotesIdList() {

      return notes.stream().filter(note -> Objects.equals(note.getIsDeleted(), 0L))
          .map(note -> note.id()).collect(Collectors.toList());
    }

    private List<Long> getSeizureIdList() {

      return seizures.stream().filter(seizure -> Objects.equals(seizure.getIsDeleted(), 0L))
          .map(seizure -> seizure.id()).collect(Collectors.toList());
    }

    private List<Long> getArrestAttachmentReferenceIdList() {

      return attachments.stream()
          .map(attachment -> attachment.getAttachmentReferenceId())
          .collect(Collectors.toList());
    }

    private List<Long> getArrestAssociationIdList() {

      return arrestAssociations.stream()
          .filter(arrestAssociation -> Objects.equals(arrestAssociation.getIsDeleted(), 0L))
          .map(arrestAssociation -> arrestAssociation.getAssociatedArrestReportId())
          .collect(Collectors.toList());
    }

    private List<String> getArrestTeamEmployeeNoList() {

      return arrestTeams.stream().filter(arrestTeam -> Objects.equals(arrestTeam.getIsDeleted(), 0L))
          .map(arrestTeam -> arrestTeam.getEmployeeNo()).collect(Collectors.toList());
    }

  public ArrestReportUpdatedEvent update(List<PartyKey> partyKeys,
                                           Set<ArrestParty> updatedArrestParties,
                                           ArrestReason arrestReason,
                                           ArrestDescription arrestDescription,
                                           ArrestLocation arrestLocation,
                                           List<AttachmentReferenceKey> updatedArrestAttachments,
                                           Set<AssociatedArrestReportKey> updatedArrestAssociations,
                                           Set<Seizure> updatedSeizures,
                                           Set<ArrestNote> updatedArrestNotes,
                                           Set<ArrestTeam> updatedArrestTeams,
                                           Entry transferredFromId, Entry shift, boolean urgent,
                                           boolean createdByAhwal, Date arrestDateTime, Long version, Entry entryExit) {


        this.setVersion(version);
        this.arrestReasonId = arrestReason.id();
        this.reportDescription = arrestDescription.getValue();
        if (transferredFromId != null && !Checks.isNotValidLookUpId(transferredFromId.getId())) {
            this.transferredFromDeptId = transferredFromId.getId();
        }
        if (shift != null && !Checks.isNotValidLookUpId(shift.getId())) {
            this.shiftId = shift.getId();
        }
        this.isUrgent = urgent ? 1L : 0L;
        this.isCreatedByAhwal = createdByAhwal ? 1L : 0L;
        this.arrestDatetime = arrestDateTime;
        this.arrestLocation = arrestLocation;
          if (entryExit != null && !Checks.isNotValidLookUpId(entryExit.getId())) {
              this.entryExitId = entryExit.getId();
          }


        // Update party list
        updateArrestParties(updatedArrestParties);
        // Update attachment list
        if (CollectionUtils.isNotEmpty(updatedArrestAttachments)) {
            updateArrestAttachments(updatedArrestAttachments);
        }
        // Update association list
        if (CollectionUtils.isNotEmpty(updatedArrestAssociations)) {
            updatedArrestAssociations(updatedArrestAssociations);
        }
        // Update arrest notes
        if (CollectionUtils.isNotEmpty(updatedArrestNotes)) {
            updateArrestNotes(updatedArrestNotes);
        }


        // Update arrest seizures
        if (CollectionUtils.isNotEmpty(updatedSeizures)) {
            updateArrestSeizures(updatedSeizures);
        }
        // Update arrest teams
        if (CollectionUtils.isNotEmpty(updatedArrestTeams)) {
            updateArrestTeams(updatedArrestTeams);
        }

        return new ArrestReportUpdatedEvent.Builder(new EventContext(ModuleTypes.ARREST, trackerId),
                                                    new ArrestReportKey(this.id()),
                                                    new ArrestReason(this.arrestReasonId),
                                                    this.reportDescription)
            .withStatus(this.statusId)
            .withArrestLocation(this.arrestLocation.getLocation())
            .withTransferredFrom(transferredFromDeptId)
            .withNotes(getNotesIdList())
            .withSeizures(getSeizureIdList())
            .withAttachments(getArrestAttachmentReferenceIdList())
            .withArrestAssociations(getArrestAssociationIdList())
            .withArrestTeams(getArrestTeamEmployeeNoList())
            .withEntryExitId(getEntryExitId())
            .build();
    }
    /**
     * Domain method to create Forwared Arrest into Detective Section
     * @param trackerKey
     * @param newArrestReportKey
     * @param arrestNumber
     * @param owner
     * @param arrestParties
     * @return
     */
    public TransferredArrestCreatedEvent createTransferredArrest(TrackerKey trackerKey, ArrestReportKey newArrestReportKey,
                                                                 String arrestNumber, Owner owner, Set<ArrestParty> arrestParties) {

        this.owner = owner;
        super.setId(newArrestReportKey.id());
        this.arrestNumber = arrestNumber;
        this.parties = new HashSet<>();
        updateArrestParties(arrestParties);
        this.assignedUser = null;
        this.statusId = ArrestStatus.FORWARDED.id();
        this.year = (long) Calendar.getInstance().get(Calendar.YEAR);
        arrestLocation =
                new ArrestLocation(ArrestConstants.DEFAULT_EMIRATE,
                        ArrestConstants.DEFAULT_CITY,
                        ArrestConstants.DEFAULT_AREA,
                        null, arrestLocation.getLocation(),
                        arrestLocation.getStreet(), arrestLocation.getBuilding(),
                        arrestLocation.getLocationDescription(),
                        null);
        return new TransferredArrestCreatedEvent.Builder(
                new EventContext(ModuleTypes.CRM, trackerKey.id()),
                new ArrestReportKey(newArrestReportKey.id()),arrestNumber)
                .withDepartment(owner.getDepartment())
                .withSection(owner.getSection())
                .build();
    }
  private void updatedArrestAssociations(
            Set<AssociatedArrestReportKey> updatedArrestAssociations) {

        for (AssociatedArrestReportKey associatedArrestReportKey : updatedArrestAssociations) {
            boolean isArrestAssociated = false;
            for (ArrestAssociation arrestAssociation : arrestAssociations) {
                if (associatedArrestReportKey.id().longValue() == arrestAssociation
                        .getAssociatedArrestReportId().longValue()) {

                    isArrestAssociated = true;
                    break;
                }
            }
            if (!isArrestAssociated) {
                ArrestAssociation newArrestAssociation = new ArrestAssociation(associatedArrestReportKey, 0L);
                newArrestAssociation.setArrestReport(this);
                arrestAssociations.add(newArrestAssociation);
            }
        }
        // Remove associations from arrest domain if the updatedArrestAssociations doesn't contain any
        // of the existing associated arrest report identifiers.
        arrestAssociations.removeIf(
                existingAssociation ->
                        !updatedArrestAssociations.contains(
                                new AssociatedArrestReportKey(existingAssociation.getAssociatedArrestReportId())));

    }

    private void updateArrestTeams(Set<ArrestTeam> updatedArrestTeams) {

        for (ArrestTeam updatedArrestTeam : updatedArrestTeams) {
            boolean isArrestTeamAdded = false;
            for (ArrestTeam existingTeam : arrestTeams) {
                if (existingTeam.id().longValue() == updatedArrestTeam.id().longValue()) {
                    existingTeam.setIsDeleted(updatedArrestTeam.getIsDeleted());
                    isArrestTeamAdded = true;
                    break;
                }
            }
            if (!isArrestTeamAdded) {
                updatedArrestTeam.setArrestReport(this);
                arrestTeams.add(updatedArrestTeam);
            }
        }

    }

    private void updateArrestSeizures(Set<Seizure> updatedSeizures) {

        for (Seizure updatedSeizure : updatedSeizures) {
            boolean isSeizureExists = false;
            for (Seizure existingSeizure : seizures) {
                if (existingSeizure.id().longValue() == updatedSeizure.id().longValue()) {
                    existingSeizure.setIsDeleted(updatedSeizure.getIsDeleted());
                    isSeizureExists = true;

                    break;
                }
            }
            if (!isSeizureExists) {
                updatedSeizure.setArrestReport(this);
                seizures.add(updatedSeizure);
            }

        }

    }

    private void updateArrestNotes(Set<ArrestNote> updatedArrestNotes) {

        for (ArrestNote updatedNote : updatedArrestNotes) {
            boolean isNoteExists = false;
            for (ArrestNote existingNote : notes) {
                if (existingNote.id().longValue() == updatedNote.id().longValue()) {
                    isNoteExists = true;
                    existingNote.setIsDeleted(updatedNote.getIsDeleted());
                    existingNote.setNote(updatedNote.getNote());
                    break;
                }
            }
            if (!isNoteExists) {
                updatedNote.setArrestReport(this);
                notes.add(updatedNote);
            }
        }
    }

    /**
     * Updating Arrest Party
     *
     * @param updatedArrestParties
     */
    private void updateArrestParties(Set<ArrestParty> updatedArrestParties) {

        for (ArrestParty updatedArrestParty : updatedArrestParties) {
            boolean isPartyAdded = false;
            for (ArrestParty arrestParty : parties) {
                if (updatedArrestParty.getPartyId().longValue() == arrestParty.getPartyId().longValue()) {
                    arrestParty.setPartyTypeId(updatedArrestParty.getPartyTypeId());
                    arrestParty.setIsDeleted(updatedArrestParty.getIsDeleted());
                    isPartyAdded = true;
                    break;
                }
            }
            if (!isPartyAdded) {
                updatedArrestParty.setArrestReport(this);
                parties.add(updatedArrestParty);
            }
        }

    }

    private void updateArrestAttachments(List<AttachmentReferenceKey> updatedArrestAttachments) {

        for (AttachmentReferenceKey attachmentReferenceKey : updatedArrestAttachments) {
            boolean isAttachmentAdded = false;
            for (ArrestAttachment arrestAttachment : attachments) {
                if (attachmentReferenceKey.id().longValue() == arrestAttachment.getAttachmentReferenceId()
                        .longValue()) {
                    isAttachmentAdded = true;
                    break;
                }
            }
            if (!isAttachmentAdded) {
                ArrestAttachment newArrestAttachment = new ArrestAttachment(attachmentReferenceKey);
                newArrestAttachment.setArrestReport(this);
                attachments.add(newArrestAttachment);
            }
        }
        // Remove attachments from arrest domain if the updatedArrestAttachments doesn't contain any of
        // the existing attachment identifiers.
        attachments.removeIf(
                existingAttachment -> !updatedArrestAttachments
                        .contains(new AttachmentReferenceKey(existingAttachment.getAttachmentReferenceId())));

    }


    protected ArrestLocation getArrestLocation() {
        return arrestLocation;
    }

    protected Long getArrestReasonId() {
        return arrestReasonId;
    }

    protected Owner getOwner() {
        return owner;
    }

    protected long getIsUrgent() {
        return isUrgent;
    }

    protected Long getTransferredFromDeptId() {
        return transferredFromDeptId;
    }

    protected Long getYear() {
        return year;
    }

    protected Date getArrestDatetime() {
        return arrestDatetime;
    }

    protected String getReportDescription() {
        return reportDescription;
    }

    public Set<ArrestTeam> getArrestTeams() {
        return arrestTeams;
    }

    public Set<Seizure> getSeizures() {
        return seizures;
    }

    public Set<ArrestAttachment> getAttachments() {
        return attachments;
    }

    public Set<ArrestNote> getNotes() {
        return notes;
    }

    public Set<ArrestParty> getParties() {
        return parties;
    }
    protected Long getShiftId() {
        return shiftId;
    }

    protected Long getIsCreatedByAhwal() {
        return isCreatedByAhwal;
    }

    public Set<ArrestAssociation> getArrestAssociations() {
        return arrestAssociations;
    }

    protected Long getStatusId() {
        return statusId;
    }

    protected String getAssignedUser() {
        return assignedUser;
    }

    protected String getArrestNumber() {
        return arrestNumber;
    }

    public Long getEntryExitId() {
        return entryExitId;
    }

}