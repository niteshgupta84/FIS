package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.fis.common.notification.NotificationCode;
import ae.emaratech.uaevision.fis.common.notification.NotificationType;

/**
 * Created by Nitesh.Gupta on 6/5/2016.
 */
public enum ArrestNotificationCode implements NotificationCode {
    ARREST_REASON_MANDATORY("AR0001", "arrestReport.error.required.arrestReason", NotificationType.ERROR),
    NO_ARREST_FOUND_FORGIVEN_ID("AR0002", "arrestReport.error.noRecordFound", NotificationType.ERROR),
    COMMENTS_MANDATORY("AR003", "arrestReport.error.required.rejectComments", NotificationType.ERROR),
    ARREST_DESCRIPTION_MANDATORY("AR004", "arrestReport.error.required.arrestDescription", NotificationType.ERROR),
    EMIRATE_MANDATORY("AR005", "arrestReport.error.required.emirate", NotificationType.ERROR),
    CITY_MANDATORY("AR006", "arrestReport.error.required.city", NotificationType.ERROR),
    AREA_MANDATORY("AR007", "arrestReport.error.required.area", NotificationType.ERROR),
    ARREST_LOCATION_MANDATORY("AR008", "arrestReport.error.required.arrestLocation", NotificationType.ERROR),
    ARREST_DATE_MANDATORY("AR009", "arrestReport.error.required.arrestDate", NotificationType.ERROR),
    ARREST_TIME_MANDATORY("AR010", "arrestReport.error.required.arrestTime", NotificationType.ERROR),
    ARREST_TIME_INVALID("AR011", "arrestReport.error.notValid.arrestTime", NotificationType.ERROR),
    PARTY_DETAIL_MISSING("AR012", "arrestReport.error.required.party", NotificationType.ERROR),
    SEIZED_ITEMS_MANDATORY("AR013", "arrestReport.seizure.warn.seizedItem.seizedItemNotNull", NotificationType.ERROR),
    SEIZED_COUNT_MANDATORY("AR014", " arrestReport.seizure.warn.count.countNotNull", NotificationType.ERROR),
    SEIZED_COUNT_INVALID("AR015", "arrestReport.seizure.warn.count.invalidInput", NotificationType.ERROR),
    SEIZED_COUNT_LENGTH_ISSUE("AR016", "arrestReport.seizure.warn.count.countLength", NotificationType.ERROR),
    SEIZED_ITEM_LENGTH_ISSUE("AR017", "arrestReport.seizure.warn.seizedItem.countLength", NotificationType.ERROR),
    SEIZURE_ADD_SUCCESS("AR018", "arrestReport.seizure.info.added", NotificationType.WARNING),
    SEIZURE_EDIT_SUCCESS("AR019", "arrestReport.seizure.info.updated", NotificationType.WARNING),
    SEIZURE_DELETE_SUCCESS("AR020", "arrestReport.seizure.info.delete", NotificationType.WARNING),
    ARRESTTEAM_ADD_SUCCESS("AR021", "arrestReport.arrestTeam.info.added", NotificationType.WARNING),
    ARREST_TEAM_EMPLOYEEIDNULL("AR022", "incident.arrestReport.arrestTeam.warn.employeeId.employeeIdNotNull", NotificationType.ERROR),
    ARREST_TEAM_OFFICERNAME_NOTNULL("AR023", "incident.arrestReport.arrestTeam.warn.officerName.officerNameNotNull", NotificationType.ERROR),
    ARREST_TEAM_EMPLOYEE_LENGTH("AR024", "incident.arrestReport.arrestTeam.warn.employeeId.employeeIdLength", NotificationType.ERROR),
    ARREST_TEAM_OFFICER_LENGTH("AR025", "incident.arrestReport.arrestTeam.warn.officerName.officerNameLength", NotificationType.ERROR),
    ARREST_TEAM_DUPLICATE("AR027", "incident.arrestReport.arrestTeam.error.duplicateRecord", NotificationType.ERROR),
    ARRESTTEAM_DELETE_SUCCESS("AR028", "arrestReport.arrestTeam.info.delete", NotificationType.WARNING),
    ARRESTTEAM_UPDATE_SUCCESS("AR029", "arrestReport.arrestTeam.info.updated", NotificationType.WARNING),
    NOTE_ADD_SUCCESS("AR030", "arrestReport.note.info.added", NotificationType.WARNING),
    NOTE_UPDATE_SUCCESS("AR031", "arrestReport.note.info.updated", NotificationType.WARNING),
    NOTE_DELETE_SUCCESS("AR032", "arrestReport.note.info.deleted", NotificationType.WARNING),
    DOCUMENT_INSPECTION_ADD_SUCCESS("AR033", "arrestReport.documentInspection.info.added", NotificationType.WARNING),
    DOCUMENT_INSPECTION_EDIT_SUCCESS("AR034", "arrestReport.documentInspection.info.updated", NotificationType.WARNING),
    DOCUMENT_INSPECTION_REMOVE_SUCCESS("AR035", "arrestReport.documentInspection.info.deleted", NotificationType.WARNING),
    ATTACHMENT_ADD_SUCCESS("AR036", "attachment.attachment.info.added", NotificationType.SUCCESS),
    ATTACHMENT_DELETED_SUCCESS("AR036", "attachment.attachment.info.deleted", NotificationType.SUCCESS),
    PARTY_IMPORT_SUCCESS("IC0062", "incident.message.success.info.import", NotificationType.ERROR),
    LOCATION_TYPE_MANDATORY("IC0063", "arrestReport.warn.required.arrestLocationType", NotificationType.ERROR),
    ARREST_REQUEST_ASSIGNED("IC0063", "arrestReport.assign.info.success", NotificationType.ERROR),
    NO_ARREST_FOUND("IC0064", "incident.association.warn.noIncidentFound", NotificationType.ERROR),
    ASSOCIATION_ALREADY_EXIST("IC0065", "incident.association.error.duplicateIncidentAssociation", NotificationType.ERROR),
    SAME_ARREST_ASSOCIATION("IC0065", "incident.association.error.sameIncidentAssociation", NotificationType.ERROR),
    ASSOCIATION_ADD_SUCCESS("IC0066", "incident.association.message.info.add", NotificationType.SUCCESS),
    ASSOCIATION_REMOVE_SUCCESS("IC0067", "incident.association.message.info.delete", NotificationType.SUCCESS),
    PARTY_MANDATORY("IC0068", "incident.party.error.notNull", NotificationType.ERROR),
    PARTY_CHARGE_MANDATORY("IC0069", "incident.party.charge.warn.chargeNotFound", NotificationType.ERROR),
    PARTY_TYPE_MANDATORY("IC0070", "incident.party.partyType.warn.notNull", NotificationType.ERROR),
    PARTY_TYPE_ACCUSED_MANDATORY("IC0071", "incident.party.charge.error.partyAccusedMandatory", NotificationType.ERROR),
    NO_PARTY_SELECTED("IC0071", "incident.party.error.partySelect", NotificationType.ERROR),
    ACCUSED_CHARGE_MANDATORY("IC0073", "arrestReport.party.accused.charge.mandatory", NotificationType.ERROR),
    PARTY_REMOVED_SUCCESSFUL("IC0074", "profile.label.note.delete", NotificationType.SUCCESS),
    DOCUMENT_TYPE_MANDATORY("IC0075", "case.documentInspection.documentType.mandatory", NotificationType.ERROR),
    DOCUMENT_INSPECTION_RESULT_MANDATORY("IC0075", "case.documentInspection.inspectionResult.mandatory", NotificationType.ERROR),
    CASE_ASSIGNED_SUCCESS("IC0076", "case.assign.info.success", NotificationType.SUCCESS),
    GUARANTEE_IMPORT_SUCCESS("IC0077", "guarantee.message.seflguarantor.info.import", NotificationType.ERROR),
    ARREST_EXISTS_FOR_PARTY("IC0077", "arrest.warn.party.case.exists", NotificationType.WARNING),
    ARREST_EXISTS_FOR_PARTY_SAME_INCIDENT("IC0078", "case.warn.party.case.exists.same.incident", NotificationType.WARNING),
    ARREST_REOPEN_FOR_UPDATE("IC0079", "arrest.order.reopen.success", NotificationType.SUCCESS),
    NO_ARREST_SELECTED("IN0001", "arrest.error.arrest.Select", NotificationType.ERROR),
    ARREST_COMENTS_SIZE_EXCEED("IN0006", "arrest.order.error.comments.exceed",
            NotificationType.ERROR),
    ARREST_ORDER_REQUEST_SUCCESS("IN0002", "arrest.order.success.message",
            NotificationType.SUCCESS),
    ACTIVE_ARREST_ORDER("IN0003", "arrest.order.error.message.active.order",
            NotificationType.ERROR),
    PARTY_DELETE_SUCCESS("AR020", "arrestReport.party.info.delete", NotificationType.WARNING),
    PARTY_HAS_ACTIVE_CASE("AR021", "arrestReport.party.delete.error.linked.case", NotificationType.ERROR),
    PARTY_EMAIL_MANDATORY("AR022", "arrestReport.party.email.mandatory", NotificationType.ERROR),
    PARTY_PHONE_MANDATORY("AR022", "arrestReport.party.phone.mandatory", NotificationType.ERROR),
    ARREST_TRAVEL_ROUTE_ADD("IC0080", "arrest.travel.route.add.success", NotificationType.SUCCESS),
    ARREST_TRAVEL_ROUTE_UPDATE("IC0080", "arrest.travel.route.update.success", NotificationType.SUCCESS),
	ARREST_TRAVEL_ROUTE_DELETE("IC0080", "arrest.travel.route.remove.success", NotificationType.SUCCESS), 	
    UNIT_MANDATORY("CA0021", "arrestReport.terminal.mandatory", NotificationType.ERROR),
    TRANSFERRED_FROM_MANDATORY("AR0001", "arrestReport.error.required.transferredFrom", NotificationType.ERROR),
    PARTY_PASSPORT_MANDATORY("AR022", "arrestReport.party.passport.mandatory", NotificationType.ERROR),
    ATTACHMENT_DELETED_COMMENTS_MANDATORY("AR036", "attachment.delete.comment.mandatory", NotificationType.ERROR),
    CANNOT_DETAIN_UNKNOWN("IC0071", "incident.party.detain.unknown", NotificationType.ERROR);

    /**
     * Code passed to the user interface.
     */
    private String displayCode;

    /**
     * Code used to resolve the message from the bundle.
     */
    private String messageCode;

    /**
     * Defines the type of notification.
     */
    private NotificationType notificationType;

    /**
     * Default Constructor.
     *
     * @param displayCode       the code which would be displayed in the user screen.
     * @param messageBundleCode the code used to resolve the message from bundle.
     * @param notificationType  the type of notification.
     */
    private ArrestNotificationCode(String displayCode, String messageBundleCode,
                                   NotificationType notificationType) {

        this.displayCode = displayCode;
        this.messageCode = messageBundleCode;
        this.notificationType = notificationType;
    }

    @Override
    public NotificationType getType() {
        return notificationType;
    }

    @Override
    public String getDisplayCode() {
        return displayCode;
    }

    @Override
    public String getMessageCode() {
        return messageCode;
    }
}
