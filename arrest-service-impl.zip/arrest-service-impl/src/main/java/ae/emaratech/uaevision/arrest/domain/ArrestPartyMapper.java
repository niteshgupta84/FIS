package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.application.dto.ArrestPartyDto;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Attribute;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Mapper class for mapping Arrest Party from Entity and DTO Created by Nitesh.Gupta on 6/6/2016.
 */
@Component
public class ArrestPartyMapper {

    @Autowired
    private LookupService lookupService;


    @Autowired
    private UserService userService;

    /**
     * Mapping Arrest Party Entity To Dto
     */
    public ArrestPartyDto mapToArrestPartyDto(ArrestParty arrestParty) {

        ArrestPartyDto arrestPartyDto = new ArrestPartyDto();
        arrestPartyDto.setId(arrestParty.id());
        arrestPartyDto.setArrestReportId(arrestParty.getArrestReport().id());
        arrestPartyDto.setPartyId(arrestParty.getPartyId());
        arrestPartyDto.setCreatedBy(userService.getUserFirstNameByUserLogin(arrestParty.getCreatedBy()));
        arrestPartyDto.setCreatedDate(arrestParty.getCreatedDate());
        arrestPartyDto.setIsDeleted(arrestParty.getIsDeleted());
        if (Checks.isNotNull(arrestParty.getPartyTypeId())) {
            List<Attribute> listOfAttributes = new ArrayList<>();
            listOfAttributes.add(new Attribute("IS_CHARGABLE"));
            Entry entry = lookupService.getLookupAttributes(LookupDefinition.PARTY_TYPE,
                    LocaleContextHolder.getLocale(),
                   arrestParty.getPartyTypeId(), listOfAttributes).get();
            arrestPartyDto.setPartyType(entry);
        }

        return arrestPartyDto;
    }

    /**
     * Map Seizure Entity to Dto List
     */
    public List<ArrestPartyDto> mapToDtoList(Set<ArrestParty> arrestPartySet) {
        List<ArrestPartyDto> arrestPartyDtoList = new LinkedList<>();
        if (CollectionUtils.isNotEmpty(arrestPartySet)) {
            arrestPartyDtoList.addAll(arrestPartySet.stream().map(this::mapToArrestPartyDto).collect(Collectors.toList()));
        }

        return arrestPartyDtoList;
    }

    /**
     * Preparing EntitySet for Guarantee Period
     */
    public Set<ArrestParty> mapToEntitySet(List<ArrestPartyDto> arrestPartyDtoList,
                                           Arrest arrestReport) {

        Set<ArrestParty> arrestParties = arrestReport.getParties();

        if (arrestPartyDtoList != null) {
            for (ArrestPartyDto arrestPartyDto : arrestPartyDtoList) {
                boolean arrestPartyFound = false;
                for (ArrestParty arrestParty : arrestParties) {
                    if (!Objects.equals(arrestParty.id(), 0L) && !Objects.equals(arrestPartyDto.getId(), 0L) &&
                            (Objects.equals(arrestParty.id(), arrestPartyDto.getId()))) {
                        arrestPartyFound = true;
                        break;
                    }
                }
                if (!arrestPartyFound) {
                    ArrestParty arrestParty =
                            new ArrestParty(new PartyKey(arrestPartyDto.getPartyId()));

                    arrestParties.add(arrestParty);
                }
            }
        }
        return arrestParties;
    }
}
