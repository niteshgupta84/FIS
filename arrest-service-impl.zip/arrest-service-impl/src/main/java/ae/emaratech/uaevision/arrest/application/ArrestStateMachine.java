package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.domain.ArrestAction;
import ae.emaratech.uaevision.arrest.domain.ArrestStatus;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * For managing state and transitions of Arrest.
 * <p/>
 * Concept and terms are based on that of FSM (Finite State Machine)
 */
public class ArrestStateMachine {


    /**
     * prevent instantiation
     */
    private ArrestStateMachine() {
    }

    public static List<ArrestAction> nextPossibleActions(ArrestStatus currentState,
                                                         boolean lockAcquired) {

        Map<ArrestStatus, List<ArrestAction>> stateMachineConfig =
                ArrestStateMachineConfiguration.getStateMachineConfigForIcm();

        List<ArrestAction> configuredActions = stateMachineConfig.get(currentState);

        List<ArrestAction> possibleActions = new ArrayList<>();
        if (configuredActions != null) {
            for (ArrestAction configuredAction : configuredActions) {
                if (configuredAction.requiresLock() && !lockAcquired) {
                    possibleActions.add(ArrestAction.ACQUIRE);
                    return possibleActions;
                }
            }
        } else {
            return possibleActions;
        }
        return configuredActions;
    }


}
