package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.application.dto.SeizureDto;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Mapping class to map Seizure Dto from Entity and Vice versa Created by Nitesh.Gupta on 6/5/2016.
 */
@Component
public class SeizureMapper {


    public SeizureDto mapToSeizureDto(Seizure seizureEntity) {
        SeizureDto seizureDto = new SeizureDto();
        seizureDto.setSeizureId(seizureEntity.id());
        seizureDto.setSeizedItem(seizureEntity.getItemName());
        seizureDto.setCount(String.valueOf(seizureEntity.getItemCount()));
        seizureDto.setId(seizureEntity.id());
        seizureDto.setCreatedBy(seizureEntity.getCreatedBy());
        seizureDto.setCreatedDate(seizureEntity.getCreatedDate());
        seizureDto.setIsDeleted(seizureEntity.getIsDeleted());
        return seizureDto;
    }

    /**
     * Map Seizure Entity to Dto List
     */
    public List<SeizureDto> mapToDtoList(Set<Seizure> seizureSet) {
        List<SeizureDto> seizureDtoList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(seizureSet)) {
            seizureDtoList.addAll(
                    seizureSet.stream().filter(seizure -> Objects.equals(seizure.getIsDeleted(), 0L))
                            .map(this::mapToSeizureDto).collect(Collectors.toList()));
        }
        return seizureDtoList;
    }
}
