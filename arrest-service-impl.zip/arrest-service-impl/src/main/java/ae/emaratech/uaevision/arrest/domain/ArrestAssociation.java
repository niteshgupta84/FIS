package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.entitylistener.Creatable;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedByListener;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedDateListener;
import ae.emaratech.uaevision.fis.common.key.AssociatedArrestReportKey;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@Entity
@Table(name = "ARREST_REPORT_ASSOCIATION")
@EntityListeners({
        CreatedDateListener.class,
        CreatedByListener.class,
})
public class ArrestAssociation implements Creatable, Serializable {

    /**
     * Holds Unique key for Arrest Association.
     */
    @Id
    @SequenceGenerator(name = "ARREST_ASSOC_ID_GENERATOR", sequenceName = "SEQ_ARREST_REPORT_ASSOCIATION", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ARREST_ASSOC_ID_GENERATOR")
    @Column(name = "ID", unique = true, nullable = false)
    private long id;

    @ManyToOne
    @JoinColumn(name = "ARREST_REPORT_ID", nullable = false)
    private Arrest arrestReport;

    @Column(name = "LINKED_ARREST_REPORT_ID", nullable = false)
    private Long associatedArrestReportId;

    @Column(name = "CREATED_BY", length = 30, nullable = false)
    private String createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE", nullable = false)
    private Date createdDate;

    @Column(name = "IS_DELETED")
    private Long isDeleted;

    private ArrestAssociation() {

    }

    public ArrestAssociation(AssociatedArrestReportKey associatedArrestReportKey, Long isDeleted) {

        this.associatedArrestReportId = associatedArrestReportKey.id();
        this.isDeleted = isDeleted;

    }

    protected Arrest getArrestReport() {
        return arrestReport;
    }

    protected void setArrestReport(Arrest arrestReport) {
        this.arrestReport = arrestReport;
    }

    protected Long getAssociatedArrestReportId() {
        return associatedArrestReportId;
    }

    protected Long id() {
        return id;
    }


    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    protected Date getCreatedDate() {
        return createdDate;
    }

    @Override
    public void setCreatedDate(Date date) {
        this.createdDate = date;
    }

    public Long getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Long isDeleted) {
        this.isDeleted = isDeleted;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
