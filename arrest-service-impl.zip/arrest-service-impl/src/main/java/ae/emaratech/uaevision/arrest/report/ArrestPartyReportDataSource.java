package ae.emaratech.uaevision.arrest.report;

/**
 * Created by Wasib.Khan on 6/8/2016.
 *
 *
 */

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportDto;
import ae.emaratech.uaevision.arrest.query.ArrestQueryService;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestQuery;
import ae.emaratech.uaevision.document.service.api.DocumentService;
import ae.emaratech.uaevision.fis.common.exception.BusinessException;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.util.ApplicationConstants;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.common.util.DateUtils;
import ae.emaratech.uaevision.fis.party.application.PartyService;
import ae.emaratech.uaevision.fis.party.application.dto.*;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import ae.emaratech.uaevision.fis.party.query.RetrievePartyQuery;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperDataSource;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.util.*;
import java.util.stream.Collectors;

/**
 * This class is use for generating the party  report. <p/> Created by Wasib.Khan on 6/8/2016.
 */
@Component
public class ArrestPartyReportDataSource implements JasperDataSource {

    /**
     * Static containing the logger for the class.
     */
    private static final Logger LOGGER = LogManager.getLogger();

    @Autowired
    private PartyQueryService partyQueryService;

    @Autowired
    private DocumentService documentService;

    @Autowired
    private MessageSource messageSource;

    @Autowired
    private ArrestQueryService arrestQueryService;

    @Autowired
    private PartyService partyService;

    public JRDataSource getDataSource(ReportParameters parameters) throws BusinessException {

        LOGGER.info("method  getDataSource() start");

        LOGGER.info("Inside PartyTransferReportDataSource ");
        Long
                parentIncidentIdLong =
                Long.valueOf(
                        parameters.getParameter(ApplicationConstants.REPORT_PARAM_PARENT_INCIDENT_ID).toString());
        Long partyIdLong = Long.valueOf(parameters.getParameter("PARTY_ID").toString());

        ArrestReportKey arrestReportKey = new ArrestReportKey(parentIncidentIdLong);
        RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(arrestReportKey);
        ArrestReportDto
                arrestReportDto = arrestQueryService.retrieveArrestReport(retrieveArrestQuery);

        //Get party details
        PartyKey partyKey = new PartyKey(partyIdLong);
        PartyDto partyDto = partyQueryService.retrieveParty(new RetrievePartyQuery(partyKey));
        //Get Party Photo
        byte[] partyPhoto = null;
        if (partyDto.getAttachmentId() != null) {
            partyPhoto = documentService.downloadPartyPhoto(partyDto.getAttachmentId()).getAttachment();
        }

        //Get List of Charges
        List<ChargeDto> listOfCharges = partyDto.getListofCharges();

        List<ChargeDto> filteredCharge = new ArrayList<>();

        if (Checks.isNotNull(listOfCharges)) {
            filteredCharge = listOfCharges.stream().filter(chargeDto -> Objects.equals(chargeDto.getIsDeleted(), 0L)).collect(Collectors.toList());

        }
        //String charges = org.apache.commons.lang3.StringUtils.join(charge, ',');
        List<PassportDto> listOfPassports = partyDto.getPassports();

        List<Map> objects = new ArrayList<>();
        Map<String, Object> resultSet = new HashMap<>();

        //Party Information
        if (partyPhoto != null) {
            ByteArrayInputStream bais = new ByteArrayInputStream(partyPhoto);
            resultSet.put("partyPhoto", bais);
        }
        if (partyDto.getPartyStatusLk() != null) {
            resultSet.put("partyStatus", String.valueOf(partyDto.getPartyStatusLk().getName()));
        } else {
            resultSet.put("partyStatus", "  --  ");
        }
        resultSet.put("nameEn", String.valueOf(partyDto.getNameEn()));
        resultSet.put("nameAr", String.valueOf(partyDto.getNameAr()));
        resultSet.put("nationality", String.valueOf(partyDto.getNationality().getName()));
        if (partyDto.getOriginalNationality() != null) {
            resultSet.put("orginalNationality", String.valueOf(partyDto.getOriginalNationality().getName()));
        }
        if (CollectionUtils.isNotEmpty(partyDto.getPassports())) {
            resultSet.put("passport", String.valueOf(partyDto.getPassports().get(0).getPassportNo()));
        } else {
            resultSet.put("passport", "  --  ");
        }
        resultSet.put("gender", String.valueOf(partyDto.getGender().getName()));
        //resultSet.put("listOfCharges", String.valueOf(charges));
        resultSet.put("udbNo", String.valueOf(partyDto.getUdbNo()));
        if (null == partyDto.getPersonNo() || ("").equals(partyDto.getPersonNo()) || "0".equals(partyDto.getPersonNo())) {
            resultSet.put("personNumber", "  --  ");
        } else {
            resultSet.put("personNumber", partyDto.getPersonNo());
        }

        resultSet.put("personType", partyDto.getPersonType().getName());
        resultSet.put("age", String.valueOf(partyDto.getAge()));
        if (partyDto.getAge() == 0) {
            resultSet.put("age", "  --  ");
        }
        if (partyDto.getGetBirthplaceAr() != null) {
            resultSet.put("placeOfBirth", String.valueOf(partyDto.getGetBirthplaceAr()));
        } else {
            resultSet.put("placeOfBirth", "     --    ");
        }
        if (partyDto.getMotherNameAr() != null) {
            resultSet.put("nameOfMotherAr", partyDto.getMotherNameAr());
        } else {
            resultSet.put("nameOfMotherAr", "     --    ");
        }
        if (partyDto.getProfession() != null) {
            resultSet.put("occupation", partyDto.getProfession().getName());
        } else {
            resultSet.put("occupation", "     --    ");
        }
        if (partyDto.getCountry() != null) {
            resultSet.put("country_city", partyDto.getCountry().getName());
        } else {
            resultSet.put("country_city", "     --    ");
        }
        if (partyDto.getMotherNameEn() != null) {
            resultSet.put("nameOfMother", String.valueOf(partyDto.getMotherNameEn()));
        } else {
            resultSet.put("nameOfMother", "     --    ");
        }
        if (partyDto.getPhoneNumber() != null) {
            resultSet.put("phoneNumber", partyDto.getPhoneNumber());
        } else {
            resultSet.put("phoneNumber", "     --   ");
        }

        if (partyDto.getHomePhone() != null) {
            resultSet.put("homePhone", partyDto.getHomePhone());
        } else {
            resultSet.put("homePhone", "     --   ");
        }
        if (partyDto.getWorkPhone() != null) {
            resultSet.put("workPhone", partyDto.getWorkPhone());
        } else {
            resultSet.put("workPhone", "     --   ");
        }

        if (partyDto.getAddress() != null) {
            resultSet.put("address", partyDto.getAddress());
        } else {
            resultSet.put("address", "     --   ");
        }

        if (partyDto.getIsBlackListed()) {
            resultSet.put("blacklist", messageSource
                    .getMessage("release.label.belonging.recieved.yes", new Object[]{},
                            LocaleContextHolder.getLocale()));
        } else {
            resultSet.put("blacklist", messageSource
                    .getMessage("release.label.belonging.recieved.no", new Object[]{},
                            LocaleContextHolder.getLocale()));
        }

        if (partyDto.getIsBanned()) {
            resultSet.put("ban", messageSource
                    .getMessage("release.label.belonging.recieved.yes", new Object[]{},
                            LocaleContextHolder.getLocale()));
            BanDto banDto = partyDto.getBanDto();
            resultSet.put("banType", banDto != null ? banDto.getBanType() : "-");
            resultSet.put("banReason", banDto != null ? banDto.getBanReason() : "-");
        } else {
            resultSet.put("ban", messageSource
                    .getMessage("release.label.belonging.recieved.no", new Object[]{},
                            LocaleContextHolder.getLocale()));
        }

        if (partyDto.getIsOverstayed()) {
            resultSet.put("overStay", messageSource
                    .getMessage("release.label.belonging.recieved.yes", new Object[]{},
                            LocaleContextHolder.getLocale()));
            ViolationDto violationDto = partyDto.getViolationDto();
            resultSet.put("overstayAmount", violationDto != null ? violationDto.getAmount() : "-");
            resultSet.put("overstayDays", violationDto != null ? violationDto.getDays() : "-");
        } else {
            resultSet.put("overStay", messageSource
                    .getMessage("release.label.belonging.recieved.no", new Object[]{},
                            LocaleContextHolder.getLocale()));
        }

        //IRIS Information

        byte[] irisPhoto = null;
        if (partyDto.getIrisDto().getIrisAttachmentId() != null) {
            irisPhoto =
                    documentService.downloadDocument(partyDto.getIrisDto().getIrisAttachmentId())
                            .getAttachment();
        }
        if (irisPhoto != null) {
            ByteArrayInputStream iphoto = new ByteArrayInputStream(irisPhoto);
            resultSet.put("irisPhoto", iphoto);
        }

        if (partyDto.getIrisDto().getIrisNumber() != null) {
            resultSet.put("irisNumber", String.valueOf(partyDto.getIrisDto().getIrisNumber()));
        } else {
            resultSet.put("irisNumber", "     --    ");
        }
        if (partyDto.getIrisDto().getNameChangedId() != null) {
            resultSet.put("irisNameChanged",
                    String.valueOf(partyDto.getIrisDto().getNameChangedId().getName()));
        } else {
            resultSet.put("irisNameChanged", "     --    ");
        }
        if (partyDto.getIrisDto().getLocationId() != null) {
            resultSet
                    .put("irisLocation", String.valueOf(partyDto.getIrisDto().getLocationId().getName()));
        } else {
            resultSet.put("irisLocation", "     --    ");
        }

        //Department and Section Name--
        resultSet.put("incidentId", String.valueOf(arrestReportDto.getArrestReportNumber()));
        resultSet.put("departmentName", String.valueOf(arrestReportDto.getDepartment().getName()));
        resultSet.put("sectionName", String.valueOf(arrestReportDto.getSection().getName()));
        resultSet.put("incidentStatus", String.valueOf(arrestReportDto.getStatus().getName()));
        resultSet.put("createdDate", String.valueOf(arrestReportDto.getCreatedDate()));
        resultSet.put("createdBy", String.valueOf(arrestReportDto.getCreatedBy()));
        resultSet.put("listOfCharges", getDataSource(filteredCharge));
        resultSet.put("listOfPassport",getDataSource(listOfPassports));

        VisaDto visaDto = partyDto.getVisaDto();
        if (Checks.isNotNull(visaDto)) {
            resultSet.put("visaStatus", visaDto.getVisaStatusDto().getNameEn());
            resultSet.put("visaIssueDate", DateUtils.getDateAsString(visaDto.getVisaIssueDate(), DateUtils.MMDDYYY_FORMAT));
            resultSet.put("visaExpireDate", DateUtils.getDateAsString(visaDto.getVisaExpiryDate(), DateUtils.MMDDYYY_FORMAT));
        }
        SponsorDto sponsorDto = partyDto.getSponsorDto();
        if (Checks.isNotNull(sponsorDto)) {
            resultSet.put("sponsorNo", sponsorDto.getSequenceNo());
            resultSet.put("sponsorNameInEng", sponsorDto.getSponsorNameEn());
            resultSet.put("sponsorNameInAr", sponsorDto.getSponsorNameAr());
            resultSet.put("sponsorCode", sponsorDto.getSponsorCode());

            resultSet.put("sponsorType", sponsorDto.getSponsorTypeName());
        }
        objects.add(resultSet);

        JRBeanCollectionDataSource source = new JRBeanCollectionDataSource(objects);

        LOGGER.info("method  getDataSource() stop");
        return source;
    }

    // This method is use for set JRDataset
    private JRDataSource getDataSource(List li) {
        JRDataSource jrDataSource = null;

        if (!CollectionUtils.isEmpty(li)) {
            jrDataSource = new JRBeanCollectionDataSource(li);
        } else {
            jrDataSource = new JRBeanCollectionDataSource(new ArrayList<>());
        }
        return jrDataSource;
    }


}

