package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.infrastructure.HibernateArrestActionHistoryRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository which manages the  persistence and retrieval of Arrest history Report domain entity.
 * Created by Nitesh.Gupta on 6/7/2016.
 */
@Repository
public interface ArrestActionHistoryRepository extends HibernateArrestActionHistoryRepository {

}
