package ae.emaratech.uaevision.arrest.application.utils;

import ae.emaratech.uaevision.fis.common.util.PreCondition;

import java.util.Calendar;
import java.util.StringJoiner;

/**
 * Created by Nitesh.Gupta on 6/13/2016.
 */
public class ArrestNumberGenerator {
    public static final int DEPARTMENT_CODE_POS = 0;
    public static final int SEQUENCE_NO_POS = 1;
    public static final int DETENTION_NO_POS = 0;
    public static final int YEAR_POS = 2;

    private ArrestNumberGenerator() {
    }

    /**
     * Generate Formatted IncidentNumber
     *
     * @param departmentCode 3 digit Department Code
     * @param arrestNumber   long value running sequence number
     * @param year           Numeric Year Digits
     */
    public static String getFormattedArrestNumber(String departmentCode, long arrestNumber,
                                                  long year) {

        StringJoiner stringJoiner = new StringJoiner(PreCondition.SEPARATOR);

        String incidentNo = String.format("%08d", arrestNumber);
        stringJoiner.add(departmentCode);
        stringJoiner.add(incidentNo);
        stringJoiner.add(String.valueOf(year));

        return stringJoiner.toString();
    }

    /**
     * Generate Formatted IncidentNumber
     *
     * @param arrestNumber long value running sequence number
     * @param year         Numeric Year Digits
     */
    public static String getFormattedArrestNumberWithoutDepartment(long arrestNumber,
                                                                   long year) {
        StringJoiner noBuilder = new StringJoiner(PreCondition.SEPARATOR);
        noBuilder.add(String.valueOf(arrestNumber));
        noBuilder.add(String.valueOf(year));
        return noBuilder.toString();
    }

    /**
     * @return persistable arrest sequence number
     */
    public static Long getPersistableArrestNumber(String arrestNumber) {

        return Long.parseLong(arrestNumber.split(PreCondition.SEPARATOR)[SEQUENCE_NO_POS]);
    }

    /**
     * @param incidentNumber - Complete Incident Number
     * @return persistable Year
     */
    public static Long getPersistableYear(String incidentNumber) {

        return Long.parseLong(incidentNumber.split(PreCondition.SEPARATOR)[YEAR_POS]);
    }

    /**
     * Return current Year
     */
    public static long getCurrentYear() {

        Calendar cal = Calendar.getInstance();
        return cal.get(Calendar.YEAR);
    }


    /**
     * TODO - Need to make constants for position and javadoc
     */
    public static boolean checkValidArrestNumber(String incidentNumber) {

        if (incidentNumber.length() == 17) {
            if (incidentNumber.charAt(3) == '/' && incidentNumber.charAt(12) == '/') {
                return true;
            }
        }

        return false;
    }

}
