package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceDefinition;
import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceService;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by Nitesh.Gupta on 6/5/2016.
 */
@Component
public class ArrestKeyProvider {

    @Autowired
    private SequenceService sequenceService;

    public ArrestReportKey next() {
        Long nextSequenceNumber = sequenceService.nextValue(SequenceDefinition.ARREST);
        ArrestReportKey arrestKey = new ArrestReportKey(nextSequenceNumber);
        return arrestKey;
    }
}
