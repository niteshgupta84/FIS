package ae.emaratech.uaevision.arrest.report;
/**
 * Created by Satya K on 26/4/2016.
 */

import ae.emaratech.uaevision.fis.common.exception.BusinessException;
import ae.emaratech.uaevision.fis.report.core.FISReport;
import ae.emaratech.uaevision.fis.report.core.FISReportFormat;
import ae.emaratech.uaevision.fis.report.core.FISReportGenerator;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperReportGenerator;
import net.sf.jasperreports.engine.JRDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;

@Component
public class ArrestReportGenerator implements FISReportGenerator {

    private static final String INTERROGATION_ARREST_REPORT = "arrest-report-new";

    @Autowired
    private ArrestReportDataSource arrestReportDataSource;
    @Autowired
    private JasperReportGenerator jasperReportGenerator;
    @Override
    public FISReport generateReport(ReportParameters parameters, FISReportFormat fisReportFormat) throws BusinessException {
        JRDataSource dataSource = arrestReportDataSource.getDataSource(parameters);
        FISReport report = new FISReport();
        report.setContent(jasperReportGenerator.generateReport(INTERROGATION_ARREST_REPORT, new HashMap(), dataSource));
        return report;
    }
}
