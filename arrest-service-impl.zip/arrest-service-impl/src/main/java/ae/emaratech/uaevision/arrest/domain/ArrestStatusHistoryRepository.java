package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.infrastructure.HibernateArrestStatusHistoryRepository;

/**
 * Repository which manages the  persistence and retrieval of Arrest history Report domain entity.
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public interface ArrestStatusHistoryRepository extends HibernateArrestStatusHistoryRepository {

}
