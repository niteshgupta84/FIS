package ae.emaratech.uaevision.arrest.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import ae.emaratech.uaevision.fis.common.entitylistener.Creatable;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedByListener;
import ae.emaratech.uaevision.fis.common.entitylistener.CreatedDateListener;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.lookup.service.annotation.LookupField;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;

/**
 * Business object representing the Arrest Party entity.
 *
 * @author Nitesh.Gupta
 */
@Entity
@Table(name = "ARREST_PARTY")
@EntityListeners({
        CreatedDateListener.class,
        CreatedByListener.class,
})
public class ArrestParty implements Creatable, Serializable {

    /**
     * Holds Unique key for Arrest Attachment.
     */
    @Id
    @SequenceGenerator(name = "ARREST_PARTY_ID_GENERATOR", sequenceName = "SEQ_ARREST_PARTY", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ARREST_PARTY_ID_GENERATOR")
    @Column(name = "ID", unique = true, nullable = false)
    private Long id;

    @Column(name = "PARTY_ID", nullable = false)
    private Long partyId;

    @ManyToOne(fetch = FetchType.EAGER, cascade = {CascadeType.ALL})
    @JoinColumn(name = "ARREST_REPORT_ID", nullable = false)
    private Arrest arrestReport;

    @Column(name = "CREATED_BY", length = 30, nullable = false)
    private String createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE", nullable = false)
    private Date createdDate;

    @LookupField(LookupDefinition.PARTY_TYPE)
    @Column(name = "PARTY_TYPE_ID", nullable = false)
    private Long partyTypeId;

    @Column(name = "IS_DELETED", nullable = false)
    private Long isDeleted;

    private ArrestParty() {

    }

    public ArrestParty(PartyKey partyKey) {
        this.partyId = partyKey.id();
    }

    public ArrestParty(PartyKey partyKey, Long partyTypeId, Long isDeleted) {
        this.partyId = partyKey.id();
        this.partyTypeId = partyTypeId;
        this.isDeleted = isDeleted;
    }

    public Long id() {
        return id;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    @Override
    public void setCreatedDate(Date date) {
        this.createdDate = date;
    }

    public Long getPartyId() {
        return partyId;
    }

    protected Arrest getArrestReport() {
        return arrestReport;
    }

    protected void setArrestReport(Arrest arrestReport) {
        this.arrestReport = arrestReport;
    }

    public Long getPartyTypeId() {
        return partyTypeId;
    }

    public void setPartyTypeId(Long partyTypeId) {
        this.partyTypeId = partyTypeId;
    }

    public Long getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Long isDeleted) {
        this.isDeleted = isDeleted;
    }
}
