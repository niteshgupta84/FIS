package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.application.dto.ArrestAssociationDto;
import ae.emaratech.uaevision.fis.common.key.AssociatedArrestReportKey;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@Component
public class ArrestAssociationMapper {


    @Autowired
    private UserService userService;

    /**
     * Mapping Dto from Entity
     */
    public ArrestAssociationDto mapArrestAssociationDto(ArrestAssociation arrestAssociation) {

        ArrestAssociationDto arrestAssociationDto = new ArrestAssociationDto();
        arrestAssociationDto.setCreatedDate(arrestAssociation.getCreatedDate());
        arrestAssociationDto.setCreatedBy(userService.getUserFirstNameByUserLogin(arrestAssociation.getCreatedBy()));
        arrestAssociationDto.setId(arrestAssociation.id());
        arrestAssociationDto.setAssociationId(arrestAssociation.id());
        arrestAssociationDto.setArrestReportId(arrestAssociation.getArrestReport().id());
        arrestAssociationDto.setLinkedArrestReportId(arrestAssociation.getAssociatedArrestReportId());
        return arrestAssociationDto;
    }

    /**
     * Mapping arrest association dto list
     */
    public List<ArrestAssociationDto> mapArrestAssociationDtoList(
            Set<ArrestAssociation> arrestAssociationSet) {
        List<ArrestAssociationDto> arrestAssociationDtoList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(arrestAssociationSet)) {
            arrestAssociationDtoList.addAll(arrestAssociationSet.stream().map(this::mapArrestAssociationDto).collect(Collectors.toList()));
        }
        return arrestAssociationDtoList;
    }

    /**
     * @param arrestAssociationDtoList
     * @param arrestReport
     * @return
     */
    public Set<ArrestAssociation> mapToEntitySet(List<ArrestAssociationDto> arrestAssociationDtoList,
                                                 Arrest arrestReport) {

        Set<ArrestAssociation> arrestAssociations = arrestReport.getArrestAssociations();
        if (arrestAssociationDtoList != null) {
            for (ArrestAssociationDto arrestAssociationDto : arrestAssociationDtoList) {
                boolean arrestAssociationFlag = false;
                for (ArrestAssociation arrestAssociationFromDB : arrestAssociations) {
                    if ((arrestAssociationFromDB.id() != 0 && arrestAssociationDto.getId() != 0)
                            && (arrestAssociationFromDB.id() == arrestAssociationDto.getId())) {

                        arrestAssociationFlag = true;
                        break;
                    }
                }
                if (!arrestAssociationFlag) {
                    AssociatedArrestReportKey
                            associatedArrestReportKey =
                            new AssociatedArrestReportKey(arrestAssociationDto.getLinkedArrestReportId());
                    ArrestAssociation arrestAssociation =
                            new ArrestAssociation(associatedArrestReportKey, 0L);
                    arrestAssociation.setArrestReport(arrestReport);
                    arrestAssociations.add(arrestAssociation);
                }
            }
        }
        return arrestAssociations;
    }

}
