package ae.emaratech.uaevision.arrest.query;

import ae.emaratech.uaevision.arrest.application.ArrestNotificationCode;
import ae.emaratech.uaevision.arrest.application.ArrestPageBuilder;
import ae.emaratech.uaevision.arrest.application.dto.*;
import ae.emaratech.uaevision.arrest.domain.*;
import ae.emaratech.uaevision.document.application.AttachedDocumentDto;
import ae.emaratech.uaevision.fis.common.notification.Notification;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.common.util.PageBuilder;
import ae.emaratech.uaevision.fis.gateway.incident.UserManagementServiceClient;
import ae.emaratech.uaevision.fis.gateway.usermanagementservice.EmployeeDetail;
import ae.emaratech.uaevision.fis.gateway.usermanagementservice.EmployeeDetails;
import ae.emaratech.uaevision.fis.user.service.dto.UserShiftDetail;
import ae.emaratech.uaevision.fis.workassignment.service.dto.EmployeeInfoDto;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Implementation class for Arrest Query Service Created by Nitesh.Gupta on 6/5/2016.
 */
@Service
@Transactional
public class ArrestQueryServiceImpl implements ArrestQueryService {

    @Autowired
    private ArrestActionHistoryRepository arrestActionHistoryRepository;

    @Autowired
    private ArrestActionHistoryMapper arrestActionHistoryMapper;

    @Autowired
    private UserManagementServiceClient userManagementServiceClient;

    @Autowired
    private ArrestRepository arrestRepository;

    @Autowired
    private ArrestMapper arrestMapper;
    @Autowired
    private ArrestNoteMapper arrestNoteMapper;
    @Autowired
    private ArrestAssociationMapper arrestAssociationMapper;
    @Autowired
    private SeizureMapper seizureMapper;
    @Autowired
    private ArrestTeamMapper arrestTeamMapper;
    @Autowired
    private ArrestAttachmentMapper arrestAttachmentMapper;

    @Autowired
    private NotificationBus notificationBus;
    @Autowired
    @Qualifier("entityManagerFactory")
    private EntityManager entityManager;


    @Override
    public List<ArrestReportTrackDto> retrieveArrestHistory(
            RetrieveArrestHistoryQuery retrieveArrestHistoryQuery) {
        // Create Predicate to retrieve ArrestHistory instances for Arrest identifier.
        Predicate predicate =
                ArrestPredicates.getHistoryByArrestId(
                        retrieveArrestHistoryQuery.getArrestReportKey());
        // Create order specifier for ordering the ArrestHistory instances based on created date.
        OrderSpecifier orderSpecifier = ArrestPredicates.getActionHistoryOrderSpecifier();
        Iterable<ArrestActionHistory> ArrestTrackDtoIterator =
                arrestActionHistoryRepository.findAll(predicate, orderSpecifier);

        // Populate ArrestTrack transfer object list from entity.
        List<ArrestReportTrackDto> arrestReportTrackDtoList = new ArrayList<>();
        for (ArrestActionHistory arrestActionHistory : ArrestTrackDtoIterator) {
            arrestReportTrackDtoList.add(
                    arrestActionHistoryMapper.mapArrestTrackDto(arrestActionHistory));
        }

        return arrestReportTrackDtoList;
    }

    @Override
    public List<ArrestTeamDto> retrieveArrestTeam(
            RetrieveArrestTeamByEmployeeIdQuery retrieveArrestTeamByEmployee) {

        EmployeeDetails employeeDetails = userManagementServiceClient.getAllEmployeeDetails();
        Long departmentId = retrieveArrestTeamByEmployee.getDepartment().id();
        List<ArrestTeamDto> arrestTeamDtoList = new ArrayList<>(300);
        for (EmployeeDetail employeeDetail : employeeDetails.getEmployeeDetail()) {

            if (retrieveArrestTeamByEmployee.getEmployeeId() != null) {
                if((employeeDetail.getEmployeeId().longValue() == Long.parseLong(retrieveArrestTeamByEmployee.getEmployeeId()))){
                    arrestTeamDtoList.add(getArrestTeamDtoFromEmployeeDetail(employeeDetail));
                }
            }else{
                if (Checks.isNotNull(employeeDetail.getSection()) && Objects.equals(departmentId, employeeDetail.getSection().getDepartmentId())) {
                    arrestTeamDtoList.add(getArrestTeamDtoFromEmployeeDetail(employeeDetail));
                }
            }
        }



        return arrestTeamDtoList;
    }



    private ArrestTeamDto getArrestTeamDtoFromEmployeeDetail(EmployeeDetail employeeDetail){

        List<String> userLogin = employeeDetail.getUserLogin();

        ArrestTeamDto arrestTeamDto = new ArrestTeamDto();
        arrestTeamDto.setId(employeeDetail.getEmployeeId());
        arrestTeamDto.setEmployeeId(employeeDetail.getEmployeeNo());
        arrestTeamDto.setRankAr(employeeDetail.getRankAr());
        arrestTeamDto.setRankEn(employeeDetail.getRankEn());

        if (employeeDetail.getShiftDetail() != null) {
            UserShiftDetail userShiftDetail = new UserShiftDetail();
            userShiftDetail.setId(employeeDetail.getShiftDetail().getId());
            userShiftDetail.setShiftEndTime(employeeDetail.getShiftDetail().getShiftEndTime());
            userShiftDetail.setShiftNameAr(employeeDetail.getShiftDetail().getShiftNameAr());
            userShiftDetail.setShiftNameEn(employeeDetail.getShiftDetail().getShiftNameAr());
            userShiftDetail.setShiftStartTime(employeeDetail.getShiftDetail().getShiftStartTime());
            arrestTeamDto.setUserShiftDetail(userShiftDetail);
        }

        arrestTeamDto.setOfficerName(employeeDetail.getNameEn());
        arrestTeamDto.setOfficerNameAr(employeeDetail.getNameAr());
        if (CollectionUtils.isNotEmpty(userLogin)) {
            arrestTeamDto.setUserLogin(employeeDetail.getUserLogin().get(0));
        } else {
            arrestTeamDto.setUserLogin("");
        }
        arrestTeamDto.generateDisplayString();

        return arrestTeamDto;
    }

    /**
     * Method to retrieve Arrest information from Repository if Arrest Key provided
     */
    @Override
    public ArrestReportDto retrieveArrestReport(RetrieveArrestQuery arrestQuery) {

        return arrestMapper
                .mapToArrestReportDto(arrestRepository.findOne(arrestQuery.getArrestReportKey().id()));

    }


    /**
     * Method to retrieve Arrest information from Repository if Arrest Key provided
     */
    @Override
    public ArrestReportDto retrieveArrestReportForParty(RetrieveArrestForPartyQuery arrestQuery) {

        Predicate predicate = QArrest.arrest.parties.any().partyId.eq(arrestQuery.getPartyKey().id());

        return arrestMapper.mapToArrestReportDto(arrestRepository.findOne(predicate));

    }

    /**
     * This method returns the list of Incidents which has the matching criteria as defined in
     * IncidentDto.
     */
    @Override
    public ArrestPageBuilder findIncidentsByCriteria(ArrestPageBuilder criterias,
                                                     RetrieveArrestBySearchQuery query) {
        Predicate predicate = null;
        if (query != null) {
            predicate = ArrestPredicates.getArrestBySearchCriteria(query);
        } else {
            predicate = ArrestPredicates.hasNoPredicate();
        }
        int start = criterias.getStart() != 0 ? criterias.getStart() + 1 : 0;
        int currentPage = (start % criterias.getLength()) + 1;

        Pageable
                pageable =
                new PageBuilder<>(currentPage, criterias.getLength(), criterias.getStart(),
                        new Sort(Sort.Direction.DESC, criterias.getSortColumns()));

        Page<Arrest> arrests = arrestRepository.findAll(predicate, pageable);

        return new ArrestPageBuilder(arrests.getTotalElements(),
                arrestMapper.mapEntityToDTOList(arrests.getContent()));


    }

    @Override
    public ArrestPageBuilder retrieveArrestBySearchCriteria(
            RetrieveArrestBySearchQuery query) {
        Predicate predicate ;
        Pageable
                pageable = null;
        if (query != null) {
            predicate = ArrestPredicates.getArrestBySearchCriteria(query);
            int
                    start =
                    query.getArrestPageBuilder().getStart() != 0 ? query.getArrestPageBuilder().getStart() + 1
                            : 0;
            int currentPage = (start % query.getArrestPageBuilder().getLength()) + 1;
                                pageable =
                    new PageBuilder<>(currentPage, query.getArrestPageBuilder().getLength(),
                            query.getArrestPageBuilder().getStart(),
                            new Sort(Sort.Direction.DESC,
                                    query.getArrestPageBuilder().getSortColumns()));

        } else {
            predicate = ArrestPredicates.hasNoPredicate();
        }
        Page<Arrest> arrests = arrestRepository.findAll(predicate, pageable);
        if (query != null) {
            if (query.fetchDependencies()) {
                return new ArrestPageBuilder(arrests.getTotalElements(),
                        arrestMapper.mapEntityToDTOList(arrests.getContent()));
            } else {
                return new ArrestPageBuilder(arrests.getTotalElements(),
                        arrestMapper.mapEntityToDTOList(arrests.getContent()));
            }

        }
         return new ArrestPageBuilder(arrests.getTotalElements(),
                arrestMapper.mapEntityToDTOList(arrests.getContent()));
    }

    /**
     * List Incidents Created By Current User
     */
    @Override
    public ArrestPageBuilder retrieveArrestsCreatedByUser(
            RetrieveArrestsWithOwnerDetailQuery query) {
        Predicate predicate = QArrest.arrest.createdBy.eq(query.getUserId());

        int
                start =
                query.getArrestPageBuilder().getStart() != 0 ? query.getArrestPageBuilder().getStart() + 1
                        : 0;
        int currentPage = (start % query.getArrestPageBuilder().getLength()) + 1;

        Pageable
                pageable =
                new PageBuilder<>(currentPage, query.getArrestPageBuilder().getLength(),
                        query.getArrestPageBuilder().getStart(),
                        new Sort(Sort.Direction.DESC,
                                query.getArrestPageBuilder().getSortColumns()));

        Page<Arrest> arrests = arrestRepository.findAll(predicate, pageable);

        return new ArrestPageBuilder(arrests.getTotalElements(),
                arrestMapper.mapEntityToDTOList(arrests.getContent()));
    }

    /**
     * Arrest Incidents Assigned To Current User
     */
    @Override
    public ArrestPageBuilder retrieveArrestsAssignedToUser(
            RetrieveArrestsWithOwnerDetailQuery query) {
        Predicate predicate = ArrestPredicates.getArrestByOwnerDetails(query);

        int
                start =
                query.getArrestPageBuilder().getStart() != 0 ? query.getArrestPageBuilder().getStart() + 1
                        : 0;
        int currentPage = (start % query.getArrestPageBuilder().getLength()) + 1;

        Pageable
                pageable =
                new PageBuilder<>(currentPage, query.getArrestPageBuilder().getLength(),
                        query.getArrestPageBuilder().getStart(),
                        new Sort(Sort.Direction.DESC,
                                query.getArrestPageBuilder().getSortColumns()));

        Page<Arrest> arrests = arrestRepository.findAll(predicate, pageable);

        return new ArrestPageBuilder(arrests.getTotalElements(),
                arrestMapper.mapEntityToDTOList(arrests.getContent()));
    }


    @Override
    public List<EmployeeInfoDto> getAllEmployees() {

        List<EmployeeInfoDto> employeeInfoDtos = new ArrayList<>();

        // fetch list of employees from vision
        EmployeeDetails employeeDetails = userManagementServiceClient.getAllEmployeeDetails();

        // iterate each employee from vision and prepare an object of EmployeeInfoDto
        for (EmployeeDetail employeeDetail : employeeDetails.getEmployeeDetail()) {

            EmployeeInfoDto employeeInfoDto = new EmployeeInfoDto();

            employeeInfoDto.setUserId(employeeDetail.getEmployeeId());
            employeeInfoDto.setEmployeeNumber(employeeDetail.getEmployeeNo());
            employeeInfoDto.setFirstNameEn(employeeDetail.getNameEn());
            employeeInfoDto.setFirstNameAr(employeeDetail.getNameAr());

            List<String> userLogin = employeeDetail.getUserLogin();

            if (CollectionUtils.isNotEmpty(userLogin)) {
                employeeInfoDto.setUserLogin(employeeDetail.getUserLogin().get(0));
            } else {
                employeeInfoDto.setUserLogin("");
            }
            employeeInfoDtos.add(employeeInfoDto);
        }
        return employeeInfoDtos;
    }

    /**
     * Method which validates whether a party is associated with any existing active arrest incident.
     *
     * @param validateActiveArrestForPartyQuery the query object with list of party ids to be
     *                                          validated.
     */
    @Override
    public Notification validateActiveArrestForParty(
            ValidateActiveArrestForPartyQuery validateActiveArrestForPartyQuery) {

        // Create Predicate to retrieve Active Case instances for list of party identifiers.
        Predicate predicate = ArrestPredicates.getActiveArrestForParty(
                validateActiveArrestForPartyQuery.getPartyIdList());
        OrderSpecifier orderSpecifier = ArrestPredicates.getOrderSpecifier();
        Iterable<Arrest> activeArrestForUdbList = arrestRepository.findAll(predicate,orderSpecifier);

        if (activeArrestForUdbList.iterator().hasNext()) {
            NotificationBuilder notificationBuilder = notificationBus.getBuilder();

            ArrestReportDto arrestReportDto = arrestMapper.mapToArrestReportDto(activeArrestForUdbList.iterator().next());
            notificationBuilder.add(ArrestNotificationCode.ARREST_EXISTS_FOR_PARTY,
                    arrestReportDto.getArrestNumber());
            return notificationBuilder.createNotification();
        }

        return null;
    }

    /**
     * Retrieving Notes for Arrest against Given Arrest Id
     */
    @Override
    public List<ArrestNoteDto> retrieveNotesForArrest(RetrieveArrestQuery retrieveArrestQuery) {

        Arrest arrest = arrestRepository.findOne(retrieveArrestQuery.getArrestReportKey().id());
        if (arrest != null) {
            return arrestNoteMapper.mapToArrestNoteDtList(arrest.getNotes());
        } else {
            return new ArrayList<>();
        }
    }

    /**
     * Retrieving Attachments for Arrest against Given Arrest Id
     */
    @Override
    public List<AttachedDocumentDto> retrieveAttachmentsForArrest(
            RetrieveArrestQuery retrieveArrestQuery) {
        Arrest arrest = arrestRepository.findOne(retrieveArrestQuery.getArrestReportKey().id());
        if (arrest != null) {
            return arrest.getAttachments().stream()
                    .map(arrestAttachment -> {
                        return arrestAttachmentMapper.mapArrestAttachmentDto(arrestAttachment);
                    })
                    .collect(Collectors.toList());
        } else {
            return new ArrayList<>();
        }

    }

    /**
     * Retrieving Associations for Arrest against Given Arrest Id
     */
    @Override
    public List<ArrestAssociationDto> retrieveAssociationsForArrest(
            RetrieveArrestQuery retrieveArrestQuery) {
        Arrest arrest = arrestRepository.findOne(retrieveArrestQuery.getArrestReportKey().id());
        if (arrest != null) {
            return arrestAssociationMapper.mapArrestAssociationDtoList(arrest.getArrestAssociations());
        } else {
            return new ArrayList<>();
        }
    }

    /**
     * Retrieving all Seizure Against Arrest
     */
    @Override
    public List<SeizureDto> retrieveSeizuresForArrest(RetrieveArrestQuery retrieveArrestQuery) {
        Arrest arrest = arrestRepository.findOne(retrieveArrestQuery.getArrestReportKey().id());
        if (arrest != null) {
            return seizureMapper.mapToDtoList(arrest.getSeizures());
        } else {
            return new ArrayList<>();
        }
    }

    /**
     * Retrieving all Arrest Teams Against Arrest
     */
    @Override
    public List<ArrestTeamDto> retrieveArrestTeamsForArrest(RetrieveArrestQuery retrieveArrestQuery) {
        Arrest arrest = arrestRepository.findOne(retrieveArrestQuery.getArrestReportKey().id());
        if (arrest != null) {
            return arrestTeamMapper.mapToDtoList(arrest.getArrestTeams());
        }
        return new ArrayList<>();

    }

    /**
     * Retrieving Forwarded Cases to Arrest
     */
    //TODO - Need to correct
    public ArrestPageBuilder retrieveForwardedArrestBySearchCriteria(
            RetrieveArrestBySearchQuery query) {

        StringBuilder queryToExecute = new StringBuilder("select  a from Arrest a \n"
                + "where a.id in (select arrestReport.id from ArrestParty where partyId not in (select partyId from CaseParty where isDeleted <>1) and isDeleted <>1) and a.statusId=5 ") ;

        if (Checks.isNotNull(query.getArrestNumber())){
            queryToExecute.append("and a.arrestNumber like '%" +query.getArrestNumber()+ "%' ");
        }
        if (Checks.isNotNull(query.getArrestReason())){
            queryToExecute.append("and a.arrestReasonId = " +query.getArrestReason().getId());
        }
        queryToExecute.append(" order by a.createdDate desc");
        Query queryInstance = entityManager.createQuery(queryToExecute.toString());
        queryInstance.setFirstResult(query.getArrestPageBuilder().getStart());
        queryInstance.setMaxResults(query.getArrestPageBuilder().getLength());
        List<Arrest> list = queryInstance.getResultList();

        String countQuery = "select count(*) from Arrest a where a.id in (select arrest_report_id from arrest_party where party_id not in (select party_id from case_party where is_deleted !=1) and is_deleted !=1 )and a.status_id=5 ";
        if (Checks.isNotNull(query.getArrestNumber())){
            countQuery = countQuery + " and a.arrest_number like '%"+ query.getArrestNumber()+"%'";
        }
        BigDecimal count = (BigDecimal)entityManager.createNativeQuery(countQuery).getSingleResult();
        return new ArrestPageBuilder(count.toBigInteger().intValue(),
                arrestMapper.mapEntityToDTOList(list));

    }
}
