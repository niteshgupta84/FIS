package ae.emaratech.uaevision.arrest.infrastructure;

import ae.emaratech.uaevision.arrest.domain.Arrest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;

import java.io.Serializable;

/**
 * Created by Nitesh.Gupta on 6/5/2016.
 */
public interface HibernateArrestRepository extends JpaRepository<Arrest, Long>,
        QueryDslPredicateExecutor<Arrest> ,Serializable {


}
