package ae.emaratech.uaevision.arrest.application;

import ae.emaratech.uaevision.arrest.application.dto.*;
import ae.emaratech.uaevision.arrest.application.utils.ArrestConstants;
import ae.emaratech.uaevision.arrest.application.validators.ArrestReportValidator;
import ae.emaratech.uaevision.arrest.application.validators.ArrestTeamValidator;
import ae.emaratech.uaevision.arrest.application.validators.SeizureValidator;
import ae.emaratech.uaevision.arrest.domain.*;
import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.IncidentNumberProvider;
import ae.emaratech.uaevision.fis.common.domain.TrackerKeyProvider;
import ae.emaratech.uaevision.fis.common.infrastructure.EventBus;
import ae.emaratech.uaevision.fis.common.key.*;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.common.util.PersistentUtil;
import ae.emaratech.uaevision.fis.common.util.ReflectionUtil;
import ae.emaratech.uaevision.fis.party.application.DepartmentTypes;
import ae.emaratech.uaevision.fis.party.application.ModuleTypes;
import ae.emaratech.uaevision.fis.party.application.SectionTypes;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mysema.query.types.expr.BooleanExpression;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Application Service Implementation which defines the operations performed by the Arrest Report
 * domain.
 *
 * @author Haroon.Subair, Nitesh.Gupta
 */
@Service
@Transactional

public class ArrestReportApplicationServiceImpl implements ArrestReportApplicationService {

    /**
     * Static containing Logger for the class.
     */
    private static final Logger LOGGER = LogManager.getLogger();

    @Autowired
    private ArrestKeyProvider arrestReportKeyProvider;

    @Autowired
    private SeizureKeyProvider seizureKeyProvider;

    @Autowired
    private ArrestTeamKeyProvider arrestTeamKeyProvider;

    @Autowired
    private ArrestNoteKeyProvider arrestNoteKeyProvider;

    @Autowired
    private ArrestRepository arrestRepository;

    @Autowired
    private NotificationBus notificationBus;

    @Autowired
    private EventBus<DomainEvent> eventBus;

    @Autowired
    private ArrestActionHistoryRepository arrestActionHistoryRepository;

    @Autowired
    private ArrestStatusHistoryRepository arrestStatusHistoryRepository;

    @Autowired
    private SeizureValidator seizureValidator;

    @Autowired
    private ArrestTeamValidator arrestTeamValidator;

    @Autowired
    private ArrestReportValidator arrestReportValidator;

    @Autowired
    private IncidentNumberProvider incidentNumberProvider;

    @Autowired
    private PersistentUtil persistentUtil;

    /**
     * Reference to JSON-Object jsonMapper.
     */
    @Autowired
    @Qualifier("jsonMapper")
    private ObjectMapper jsonMapper;

    @Autowired
    private TrackerKeyProvider trackerKeyProvider;

    /**
     * Method which creates the arrest report.
     *
     * @param command command object with information regarding the arrest.
     * @return result object with arrest key data
     */
    @Override
    public CreateArrestReportResult create(CreateArrestReportCommand command) {

        // Validate the input command object.
        arrestReportValidator.validate(command);

        ArrestReportKey arrestReportKey = arrestReportKeyProvider.next();
        @SuppressWarnings("UnusedAssignment") ArrestLocation arrestLocation = null;

        //TODO Need to handle it properly for Border Control
        if (Objects.equals(command.getDepartment().id(),Department.DETECTIVE.id())) {
            arrestLocation =
                    new ArrestLocation(command.getEmirateId().getId(),
                            command.getCityId().getId(),
                            command.getAreaId().getId(),
                            command.getLocationType(), command.getArrestLocation(),
                            command.getArrestStreet(), command.getArrestBuilding(),
                            command.getLocationDescription(),
                            null);
        } else {
            arrestLocation =
                    new ArrestLocation(null, null, null,
                            null, null,
                            command.getArrestStreet(), command.getArrestBuilding(),
                            command.getLocationDescription(),
                            command.getTerminalLocation().getId());
        }

        Owner owner = new Owner(command.getDepartment(), command.getSection(), command.getUnit());
        Set<ArrestParty> arrestParties = getArrestParties(command.getArrestPartyDtoList());



        Set<ArrestAttachment> arrestAttachments = null;
        if (CollectionUtils.isNotEmpty(command.getAttachmentList())) {
            arrestAttachments = command.getAttachmentList().stream()
                    .map(ArrestAttachment::new)
                    .collect(Collectors.toSet());
        }

        Set<ArrestAssociation> arrestAssociations = null;
        if (CollectionUtils.isNotEmpty(command.getAssociatedArrestList())) {
            arrestAssociations = command.getAssociatedArrestList().stream()
                    .map(arrestAssociationDto -> new ArrestAssociation(new AssociatedArrestReportKey(arrestAssociationDto.id()),
                            0L))
                    .collect(Collectors.toSet());
        }

        Set<Seizure> seizures = null;
        if (CollectionUtils.isNotEmpty(command.getSeizureList())) {

            seizures = command.getSeizureList().stream()
                    .map(seizureDto -> {
                        SeizureKey seizureKey = seizureKeyProvider.next();
                        return new Seizure(seizureKey, seizureDto.getSeizedItem(),
                                Long.valueOf(seizureDto.getCount()), 0L);
                    })
                    .collect(Collectors.toSet());
        }

        Set<ArrestNote> arrestNotes = null;
        if (CollectionUtils.isNotEmpty(command.getArrestNoteList())) {

            arrestNotes = command.getArrestNoteList().stream()
                    .map(arrestNoteDto -> {
                        NoteKey noteKey = arrestNoteKeyProvider.next();
                        return new ArrestNote(noteKey, arrestNoteDto.getTextNote(),
                                arrestNoteDto.getIsDeleted());
                    })
                    .collect(Collectors.toSet());
        }

        Set<ArrestTeam> arrestTeams = null;
        if (CollectionUtils.isNotEmpty(command.getArrestTeamList())) {

            arrestTeams = command.getArrestTeamList().stream()
                    .map(arrestTeam -> {
                        ArrestTeamKey arrestTeamKey = arrestTeamKeyProvider.next();
                        return new ArrestTeam(arrestTeamKey, arrestTeam.getEmployeeId(), 0L);
                    })
                    .collect(Collectors.toSet());
        }

        TrackerKey trackerKey = command.getTrackerKey();
        if (trackerKey == null) {
            // For BorderControl flow, use the tracker key set within the command object.
            trackerKey = trackerKeyProvider.next();
        }

        String arrestNumber = command.getArrestNumber();
        Long year = (long) Calendar.getInstance().get(Calendar.YEAR);
        BooleanExpression predicate ;
        do {
            if (Objects.equals(command.getDepartment().id(),DepartmentTypes.BORDER_CONTROL.id())){
                arrestNumber = incidentNumberProvider.next(command.getDepartment().id(),
                        command.getSection().id(),
                        ModuleTypes.ARREST.name());
            }
            else {
                arrestNumber = incidentNumberProvider.next(command.getDepartment().id(),
                        SectionTypes.DETECTIVE.id(),
                        ModuleTypes.ARREST.name());
            }

            predicate = QArrest.arrest.arrestNumber.eq(arrestNumber).and(QArrest.arrest.year.eq(year)
                    .and(QArrest.arrest.owner.department.eq(command.getDepartment().id())).and(QArrest.arrest.owner.section.eq(command.getSection().id())));

        }

        while (Checks.isNotNull(arrestRepository.findOne(predicate)));

        // Initializing the arrest report domain.
        Arrest arrestReport =
                new Arrest(arrestReportKey, command.getArrestReason(), command.getArrestDescription(),
                        arrestLocation, arrestParties, owner, trackerKey, arrestNumber);


        arrestReport.setCreatedBy(command.getCreatedBy());

        // Invoke the create operation on the arrest report domain.
        ArrestReportCreatedEvent event =
                arrestReport.create(arrestAttachments, seizures, arrestNotes, arrestAssociations,
                        arrestTeams, command.getTransferredFromId(),
                        command.getShift(), command.isUrgent(), command.isCreatedByAhwal(),
                        command.getArrestDateTime(), arrestNumber, command.getEntryExitInfo());
        // Persist the arrest report domain
        arrestRepository.save(arrestReport);

        //Storing Action in History table.
        trackAction(arrestReport, ArrestAction.OPEN.id(), null);
        //Tracking Status
        trackStatus(arrestReport, event.getStatus());

        event.withArrestPartiesJson(getArrestPartyListJson(arrestReport.getParties()));
        // Publish the domain event for probable listeners.
        eventBus.publish(event);

        LOGGER.info("Arrest Report created. Key: " + arrestReportKey.id());
        return new CreateArrestReportResult(arrestReportKey);
    }



    /**
     * Method to send Arrest Report to Supervisor
     *
     * @param command the wrapper providing information to for submitting arrest for review by
     */
    @Override
    public void review(ReviewArrestReportCommand command) {

        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        Arrest arrestReport = arrestRepository.findOne(command.getArrestReportKey().id());

        if (arrestReport == null) {
            LOGGER.error("Arrest Report Not found for Given Id ", command.getArrestReportKey().id());
            notificationBuilder.add(ArrestNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
            notificationBus.send(notificationBuilder);
        }

       else {

            ArrestReportReviewedEvent event = arrestReport.review(command.getReviewComments());
            // Persist the arrest report domain
            arrestRepository.save(arrestReport);

            //Storing Action in History table.
            trackAction(arrestReport, ArrestAction.FORWARD_TO_SUPERVISOR.id(), command.getReviewComments());

            //Storing Status in History Table.
            trackStatus(arrestReport, event.getStatus());
            eventBus.publish(event);
        }

    }

    @Override
    public void update(UpdateArrestReportCommand command) {

        arrestReportValidator.validate(command);
        Arrest arrest = arrestRepository.findOne(command.getArrestReportKey().id());
        if (arrest == null) {
            return;
        }
        @SuppressWarnings("UnusedAssignment") ArrestLocation arrestLocation = null;
        if (Objects.equals(command.getDepartment().id(), DepartmentTypes.BORDER_CONTROL.id())) {
            arrestLocation =
                    new ArrestLocation(null, null, null,
                            null, null,
                            command.getArrestStreet(), command.getArrestBuilding(),
                            command.getLocationDescription(),
                            command.getTerminalLocation().getId());
        } else {
            arrestLocation =
                    new ArrestLocation(command.getEmirateId().getId(),
                            command.getCityId().getId(),
                            command.getAreaId().getId(),
                            command.getLocationType(), command.getArrestLocation(),
                            command.getArrestStreet(), command.getArrestBuilding(),
                            command.getLocationDescription(), null);
        }

        Set<ArrestParty> arrestParties = getArrestParties(command.getArrestPartyDtoList());
        Set<Seizure> seizures = getUpdatedSeizures(command);
        Set<ArrestNote> arrestNotes = getUpdatedArrestNotes(command);
        Set<ArrestTeam> arrestTeams = getUpdatedArrestTeams(command);

        // Invoke the create operation on the arrest report domain.
        ArrestReportUpdatedEvent event =
                arrest.update(command.getPartyList(), arrestParties, command.getArrestReason(),
                        command.getArrestDescription(), arrestLocation, command.getAttachmentList(),
                        command.getAssociatedArrestList(), seizures, arrestNotes, arrestTeams,
                        command.getTransferredFromId(), command.getShift(), command.isUrgent(),
                        command.isCreatedByAhwal(), command.getArrestDateTime(), command.getVersion(), command.getEntryExitInfo());
        // Persist the arrest report domain
        arrestRepository.save(arrest);
        trackStatus(arrest, event.getStatus());

        // Publish the domain event for probable listeners.
        event.withArrestPartiesJson(getArrestPartyListJson(arrest.getParties()));
        eventBus.publish(event);

        LOGGER.info("Arrest Report updated. Key: " + arrest.id());
    }



    /**
     * Method is to Reject Arrest Incident
     *
     * @param command the wrapper providing information to for submitting arrest for reject by
     */
    @Override
    public void reject(RejectArrestReportCommand command) {

        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        if (command.getRejectComments() == null) {
            notificationBuilder.add(ArrestNotificationCode.COMMENTS_MANDATORY);
            notificationBus.send(notificationBuilder);
        }

        Arrest arrestReport = arrestRepository.findOne(command.getArrestReportKey().id());

        if(arrestReport!=null){
            ArrestReportRejectedEvent event = arrestReport.reject(command.getRejectComments());
            // Persist the arrest report domain
            arrestRepository.save(arrestReport);

            //Storing Action in History table.
            trackAction(arrestReport, ArrestAction.REJECT.id(), command.getRejectComments());

            //Storing Status in History Table.
            trackStatus(arrestReport, event.getStatus());
            eventBus.publish(event);
        }
        else{
            LOGGER.error("Arrest Report Not found for Given Id ", command.getArrestReportKey().id());
            notificationBuilder.add(ArrestNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
            notificationBus.send(notificationBuilder);
        }

    }

    /**
     * @param command the wrapper providing information to for submitting arrest for approved by
     */
    @Override
    public void approve(ApproveArrestReportCommand command) {

        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        Arrest arrestReport = arrestRepository.findOne(command.getArrestReportKey().id());

        if (arrestReport != null) {
            ArrestReportApprovedEvent event = arrestReport.approve(command.getApprovalComments());
            // Persist the arrest report domain
            arrestRepository.save(arrestReport);

            //Storing Action in History table.
            trackAction(arrestReport, ArrestAction.APPROVE.id(), command.getApprovalComments());

            //Storing Status in History Table.
            trackStatus(arrestReport, event.getStatus());
            eventBus.publish(event);
        }
        else{
            LOGGER.error("Arrest Report Not found for Given Id ", command.getArrestReportKey().id());
            notificationBuilder.add(ArrestNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
            notificationBus.send(notificationBuilder);
        }
    }


    /**
     * Method is to Reject Arrest Incident
     *
     * @param command the wrapper providing information to for submitting arrest for reject by
     */
    @Override
    public void end(EndArrestReportCommand command) {

        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        if (command.getEndComments() == null) {
            notificationBuilder.add(ArrestNotificationCode.COMMENTS_MANDATORY);
            notificationBus.send(notificationBuilder);
        }

        Arrest arrestReport = arrestRepository.findOne(command.getArrestReportKey().id());

        if (arrestReport != null) {
            ArrestReportEndedEvent event = arrestReport.end(command.getEndComments());
            // Persist the arrest report domain
            arrestRepository.save(arrestReport);

            //Storing Action in History table.
            trackAction(arrestReport, ArrestAction.END.id(), command.getEndComments());

            //Storing Status in History Table.
            trackStatus(arrestReport, event.getStatus());
            eventBus.publish(event);
        }
        else {
            LOGGER.error("Arrest Report Not found for Given Id ", command.getArrestReportKey().id());
            notificationBuilder.add(ArrestNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
            notificationBus.send(notificationBuilder);
        }
    }

    /**
     * Forwarding Arrest Report from Detective to CRM section
     *
     * @param command the wrapper providing information to for submitting arrest for approved by
     */
    @Override
    public void forwardToCase(ForwardArrestReportCommand command) {

        NotificationBuilder notificationBuilder = notificationBus.getBuilder();

        Arrest arrestReport = arrestRepository.findOne(command.getArrestReportKey().id());

        if (arrestReport != null) {
            ArrestReportForwardedEvent event = arrestReport.forwardToCase(command.getForwardComments());
            // Persist the arrest report domain
            arrestRepository.save(arrestReport);

            //Storing Action in History table.
            trackAction(arrestReport, ArrestAction.FORWARD_TO_CASE.id(), command.getForwardComments());

            //Storing Status in History Table.
            trackStatus(arrestReport, event.getStatus());

            eventBus.publish(event);
        }
        else {
            LOGGER.error("Arrest Report Not found for Given Id ", command.getArrestReportKey().id());
            notificationBuilder.add(ArrestNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
            notificationBus.send(notificationBuilder);
        }
    }


    @Override
    public void close(CloseArrestReportCommand command) {

        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        if (!Checks.isNotNull(command.getCloseComments()) || command.getCloseComments().isEmpty()) {
            notificationBuilder.add(ArrestNotificationCode.COMMENTS_MANDATORY);
            notificationBus.send(notificationBuilder);
        }

        Arrest arrestReport = arrestRepository.findOne(command.getArrestReportKey().id());

        if (arrestReport != null) {
            ArrestReportClosedEvent event = arrestReport.close(command.getCloseComments());
            // Persist the arrest report domain
            arrestRepository.save(arrestReport);

            //Storing Action in History table.
            trackAction(arrestReport, ArrestAction.CLOSE.id(), command.getCloseComments());

            // Track Status
            trackStatus(arrestReport, event.getStatus());

            eventBus.publish(event);
        }
        else{
            LOGGER.error("Arrest Report Not found for Given Id ", command.getArrestReportKey().id());
            notificationBuilder.add(ArrestNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
            notificationBus.send(notificationBuilder);
        }
    }

    @Override
    public void reOpen(ReOpenArrestReportCommand command) {
        NotificationBuilder notificationBuilder = notificationBus.getBuilder();

        Arrest arrestReport = arrestRepository.findOne(command.getArrestReportKey().id());

        if (arrestReport == null) {
            LOGGER.error("Arrest Report Not found for Given Id ", command.getArrestReportKey().id());
            notificationBuilder.add(ArrestNotificationCode.NO_ARREST_FOUND_FORGIVEN_ID);
            notificationBus.send(notificationBuilder);
        }

        ArrestReportReopenedEvent event = arrestReport != null ? arrestReport.reopen(command.getOrderKey()) : null;

        // Persist the arrest report domain
        arrestRepository.save(arrestReport);

        //Storing Action in History table.
        trackAction(arrestReport, ArrestAction.REOPEN.id(), null);

        //Storing Status in History Table.

        trackStatus(arrestReport, event != null ? event.getStatus() : null);

        eventBus.publish(event);
    }

    /**
     * Method is to add Seizure information in the seizure List which is there in the SEssion
     */
    @Override
    public List<SeizureDto> addSeizure(AddSeizureCommand command) {

        //Validating Seizure inputs
        seizureValidator.validate(command);

        List<SeizureDto> seizureDtoList = command.getSeizureDtoList();
        SeizureDto seizureDto = new SeizureDto();
        seizureDto.setSeizedItem(command.getSeizedItem());
        seizureDto.setCount(command.getItemCount());

        Long lastMaxId = 0L;
        for (SeizureDto seizureDtoFromRepository : seizureDtoList) {
            if (seizureDtoFromRepository.getId() > lastMaxId) {
                lastMaxId = seizureDtoFromRepository.getId();
            }
        }
        seizureDto.setSeizureId(lastMaxId + 1);
        seizureDto.setIsDeleted(0L);
        seizureDtoList.add(seizureDto);
        return seizureDtoList;
    }

    /**
     * Modify Existing Seizure Update
     */
    @Override
    public List<SeizureDto> modifySeizure(EditSeizureCommand command) {
        //Validating Seizure inputs
        seizureValidator.validate(command);
        List<SeizureDto>
                seizureDtosInSession =
                command.getSeizureDtoList();

        seizureDtosInSession.stream().filter(
                seizureDtoFromSession -> Objects.equals(seizureDtoFromSession.getSeizureId(), command
                        .getSeizureKey().id()) && Objects.equals(seizureDtoFromSession.getIsDeleted(), 0L))
                .forEach(seizureDtoFromSession -> {
                    seizureDtoFromSession.setSeizedItem(command.getSeizedItem());
                    seizureDtoFromSession.setCount(command.getItemCount());
                });
        return seizureDtosInSession;
    }

    /**
     * Remove Seizure from Arrest Report
     */
    @Override
    public List<SeizureDto> removeSeizure(RemoveSeizureCommand command) {

        List<SeizureDto>
                seizureDtosInSession =
                command.getSeizureDtoList();
        seizureDtosInSession.stream()
                .filter(
                        seizureDto -> Objects.equals(seizureDto.getSeizureId(), command.getSeizureKey().id())
                                && seizureDto.getSeizureId() != 0L)
                .forEach(seizureDto -> seizureDto.setIsDeleted(1L));
        seizureDtosInSession
                .removeIf(
                        seizureDto -> Objects.equals(seizureDto.getSeizureId(), command.getSeizureKey().id()) &&
                                Objects.equals(seizureDto.getIsDeleted(), 0L));

        return seizureDtosInSession;
    }

    /**
     * Adding Arrest Team information in the sesion
     */
    @Override
    public List<ArrestTeamDto> addArrestTeam(AddArrestTeamCommand command) {
        arrestTeamValidator.validate(command);
        List<ArrestTeamDto> arrestTeamDtosInSession = command.getArrestTeamDtoList();
        Long lastMaxId = 0L;
        ArrestTeamDto arrestTeamDto = new ArrestTeamDto();
        for (ArrestTeamDto arrestTeamDtoFromSession : arrestTeamDtosInSession) {
            if (arrestTeamDtoFromSession.getEmployeeId().equals(command.getEmployeeId()) && arrestTeamDtoFromSession.getIsDeleted() != 1) {

                NotificationBuilder notificationBuilder = notificationBus.getBuilder();
                notificationBuilder.add(ArrestNotificationCode.ARREST_TEAM_DUPLICATE);
                notificationBus.send(notificationBuilder);

            } else if (arrestTeamDtoFromSession.getArrestTeamId() > lastMaxId) {
                lastMaxId = arrestTeamDtoFromSession.getArrestTeamId();
            }
        }
        arrestTeamDto.setArrestTeamId(lastMaxId + 1);
        arrestTeamDto.setEmployeeId(command.getEmployeeId());
        arrestTeamDto.setOfficerName(command.getOfficerNameEn());
        arrestTeamDto.setOfficerNameAr(command.getOfficerNameAr());
        arrestTeamDto.setIsDeleted(0L);
        arrestTeamDtosInSession.add(arrestTeamDto);
        return arrestTeamDtosInSession;
    }

    /**
     * Method for removing Arrest Team Details
     */
    @Override
    public List<ArrestTeamDto> removeArrestTeam(DeleteArrestTeamCommand command) {
        List<ArrestTeamDto> arrestTeamDtoList = command.getArrestTeamDtoList();

        arrestTeamDtoList.stream()
                .filter(
                        arrestTeamDto ->
                                Objects.equals(arrestTeamDto.getArrestTeamId(), command.getArrestTeamKey().id())
                                        && !Objects.equals(arrestTeamDto.getId(), 0L))
                .forEach(arrestTeamDto -> arrestTeamDto.setIsDeleted(1L));

        arrestTeamDtoList.removeIf(arrestTeamDto ->
                Objects.equals(arrestTeamDto.getArrestTeamId(), command.getArrestTeamKey().id()) &&
                        Objects.equals(arrestTeamDto.getId(), 0L));
        return arrestTeamDtoList;
    }

    /**
     * Editing Existing Arrest Team details for given Arrest Team Id
     */
    @Override
    public List<ArrestTeamDto> modifyArrestTeam(EditArrestTeamCommand command) {

        List<ArrestTeamDto> arrestTeamDtosInSession = command.getArrestTeamDtoList();

        arrestTeamDtosInSession.stream().filter(
                arrestTeamDtoFromSession -> Objects
                        .equals(arrestTeamDtoFromSession.getArrestTeamId(), command.getArrestTeamKey().id())
                        && Objects.equals(arrestTeamDtoFromSession.getIsDeleted(), 0L))
                .forEach(arrestTeamDtoFromSession -> {
                    arrestTeamDtoFromSession.setEmployeeId(command.getEmployeeId());
                    arrestTeamDtoFromSession.setOfficerNameAr(command.getOfficerNameAr());
                    arrestTeamDtoFromSession.setOfficerName(command.getOfficerNameEn());
                });
        return arrestTeamDtosInSession;
    }

    /**
     * Service Method to add Note in the Arrest Report
     */
    @Override
    public List<ArrestNoteDto> addNote(AddNoteCommand addNoteCommand) {

        List<ArrestNoteDto> notesList = addNoteCommand.getArrestNoteDtoList();
        Long lastSavedMaxNoteIdInSession = 0L;
        for (ArrestNoteDto noteDto : notesList) {
            if (noteDto.getId() > lastSavedMaxNoteIdInSession) {
                lastSavedMaxNoteIdInSession = noteDto.getId();
            }
        }
        ArrestNoteDto arrestNoteDto = new ArrestNoteDto();
        lastSavedMaxNoteIdInSession += 1;
        arrestNoteDto.setViewId(lastSavedMaxNoteIdInSession);
        arrestNoteDto.setIsDeleted(0L);
        arrestNoteDto.setTextNote(addNoteCommand.getNoteText());
        arrestNoteDto.setDisplayTextNote(addNoteCommand.getNoteText());

        notesList.add(arrestNoteDto);
        return notesList;
    }

    /**
     * Editing Note
     */
    @Override
    public List<ArrestNoteDto> modifyNote(EditNoteCommand command) {
        List<ArrestNoteDto> noteDtosInSession = command.getArrestNoteDtoList();
        noteDtosInSession.stream().filter(
                arrestNoteDtoFromSession -> Objects
                        .equals(arrestNoteDtoFromSession.getViewId(), command.getNoteKey().id())
        )
                .forEach(arrestNoteDtoFromSession -> {
                    arrestNoteDtoFromSession.setTextNote(command.getNoteText());
                    arrestNoteDtoFromSession.setDisplayTextNote(command.getNoteText());
                });

        return noteDtosInSession;
    }

    /**
     * Deleting Arrest Note
     */
    @Override
    public List<ArrestNoteDto> removeNote(DeleteNoteCommand command) {

        List<ArrestNoteDto> arrestNoteDtoList = command.getArrestNoteDtoList();

        arrestNoteDtoList.stream()
                .filter(
                        arrestNoteDto -> Objects.equals(arrestNoteDto.getViewId(), command.getNoteKey().id())
                                && arrestNoteDto.getViewId() != 0L)
                .forEach(arrestNoteDto -> arrestNoteDto.setIsDeleted(1L));
        arrestNoteDtoList.removeIf(
                arrestNoteDto -> Objects.equals(arrestNoteDto.getViewId(), command.getNoteKey().id()) &&
                        Objects.equals(arrestNoteDto.getIsDeleted(), 0L)
        );
        return arrestNoteDtoList;
    }

    /**
     * Arrest assignment Service Method
     */
    @Override
    public void arrestAssignment(AssignArrestCommand command) {

        Arrest arrest = arrestRepository.findOne(command.getArrestReportKey().id());
        ArrestAssignedEvent event = arrest.assignUser(command.getUserId());
        arrestRepository.save(arrest);
        eventBus.publish(event);
    }

    /**
     * Method is to create Transferred Arrest to Detective Section, It will fetch case which needs to be transferred to Detective Department and create
     * new Arrest by doing deep cloning the Arrest. After cloning Arrest, all child entities id's will be set to null, so that Hibernate will be considering cloned
     * object as new and create new CASE.
     * Arrest Track will not be cloned and initial state of Case will be transferred.
     * @ command CreateTransferArrestCommand
     * @return CreateArrestReportResult which hold new arrest report key
     */
    @Override
    public CreateArrestReportResult createTransferredArrest(CreateTransferArrestDto command) {


        LOGGER.entry();
        LOGGER.info("Fetching Arrest Information for Arrest Id ", command.getArrestReportKey().id());
        Arrest oldArrest = (Arrest) persistentUtil.retrieveFullFetchedEntity(ArrestConstants.ARREST_PROFILE,
                Arrest.class,
                command.getArrestReportKey().id());

        if (oldArrest != null ){
            LOGGER.info("Creating cloned object of Fetched Arrest by doing deep cloning ");
            Arrest newArrest = (Arrest)ReflectionUtil.deepClone(oldArrest);

            ArrestReportKey newArrestReportKey = arrestReportKeyProvider.next();

            Owner owner = new Owner(Department.DETECTIVE, Section.DETECTIVE,null);
            LOGGER.info("Updating Id's of Child entities as null to create new record ");
            Set<ArrestParty> arrestParties = getArrestParties(command.getTransferredArrestPartyDtoList());
            newArrest.getAttachments().forEach(attachment -> attachment.setId(null));
            newArrest.getArrestAssociations().forEach(arrestAssociation -> arrestAssociation.setId(null));
            newArrest.getSeizures().forEach(seizure ->
                seizure.setId(seizureKeyProvider.next().id()));
            newArrest.getArrestTeams().forEach(arrestTeam ->
                arrestTeam.setId(arrestTeamKeyProvider.next().id()));
            newArrest.getNotes().forEach(arrestNote ->
                arrestNote.setId(arrestNoteKeyProvider.next().id()));

            TrackerKey trackerKey = command.getTrackerKey();
            if (trackerKey == null) {
                // For BorderControl flow, use the tracker key set within the command object.
                trackerKey = trackerKeyProvider.next();
            }

            String arrestNumber;
            Long year = (long) Calendar.getInstance().get(Calendar.YEAR);
            BooleanExpression predicate ;
            do {
                    arrestNumber = incidentNumberProvider.next(Department.DETECTIVE.id(),
                            SectionTypes.DETECTIVE.id(),
                            ModuleTypes.ARREST.name());


                predicate = QArrest.arrest.arrestNumber.eq(arrestNumber).and(QArrest.arrest.year.eq(year)
                        .and(QArrest.arrest.owner.department.eq(Department.DETECTIVE.id())).and(QArrest.arrest.owner.section.eq(Section.DETECTIVE.id())));

            }

            while (Checks.isNotNull(arrestRepository.findOne(predicate)));
            LOGGER.info("Preparing TransferredArrestCreatedEvent event which will be thrown ");
            TransferredArrestCreatedEvent event = newArrest.createTransferredArrest(trackerKey, newArrestReportKey,
                    arrestNumber, owner,arrestParties);
            arrestRepository.save(newArrest);

            //Storing Action in History table.
            trackAction(newArrest, ArrestAction.TRANSFERRED.id(), null);


            event.withArrestPartiesJson(getArrestPartyListJson(newArrest.getParties()));
            // Publish the domain event for probable listeners.
            eventBus.publish(event);

            LOGGER.info("Arrest Report created. Key: " + newArrestReportKey.id());
            return new CreateArrestReportResult(newArrestReportKey);

        }
        return null;
    }

    /**
     * Method to update Status of Arrest
     * @param arrestReport
     * @param status
     */
    private void trackStatus(Arrest arrestReport, Long status) {

        //Storing Status in History Table.
        LOGGER.info("Capturing Status taken on Arrest", status);
        ArrestStatusHistory arrestStatusHistory =
                new ArrestStatusHistory.Builder(arrestReport.id())
                        .withStatusId(status)
                        .build();
        arrestStatusHistoryRepository.save(arrestStatusHistory);
    }

    /**
     * Method to update Arrest Actions
     * @param arrestReport
     * @param actionId
     * @param comments
     */
    private void trackAction(Arrest arrestReport, Long actionId, String comments) {

        //Storing Status in History Table.
        LOGGER.info("Capturing Action taken on Arrest", actionId);
        ArrestActionHistory arrestActionHistory =
                new ArrestActionHistory.Builder(arrestReport.id())
                        .withActionId(actionId)
                        .withComments(comments)
                        .build();
        arrestActionHistoryRepository.save(arrestActionHistory);
    }

    /**
     * Preparing Set of Case Parties with Charges
     *
     * @param arrestPartyDtoList
     * @return
     */
    private Set<ArrestParty> getArrestParties(List<ArrestPartyDto> arrestPartyDtoList) {
        Set<ArrestParty> arrestParties = null;
        if (CollectionUtils.isNotEmpty(arrestPartyDtoList)) {
            arrestParties = arrestPartyDtoList.stream()
                    .map(arrestPartyDto -> {
                        ArrestParty newArrestParty = new ArrestParty(new PartyKey(arrestPartyDto.getPartyId()), arrestPartyDto.getPartyType().getId(),
                                arrestPartyDto.getIsDeleted());
                        newArrestParty.setCreatedBy(arrestPartyDto.getCreatedBy());
                        return newArrestParty;

                    })
                    .collect(Collectors.toSet());
        }
        return arrestParties;
    }

    /**
     * Helper Method to update Arrest Team object
     * @param command
     * @return List of updated Arrest Teams
     */
    private Set<ArrestTeam> getUpdatedArrestTeams(UpdateArrestReportCommand command) {

        Set<ArrestTeam> arrestTeams = null;
        if (CollectionUtils.isNotEmpty(command.getArrestTeamList())) {

            arrestTeams = command.getArrestTeamList().stream()
                    .map(arrestTeamDto -> {
                        if (Objects.equals(arrestTeamDto.getId(), 0L)) {
                            ArrestTeamKey arrestTeamKey = arrestTeamKeyProvider.next();
                            return new ArrestTeam(arrestTeamKey, arrestTeamDto.getEmployeeId(), 0L);
                        } else {
                            ArrestTeamKey arrestTeamKey = new ArrestTeamKey(arrestTeamDto.getId());
                            return new ArrestTeam(arrestTeamKey, arrestTeamDto.getEmployeeId(),
                                    arrestTeamDto.getIsDeleted());
                        }
                    })
                    .collect(Collectors.toSet());
        }
        return arrestTeams;
    }

    /**
     * Helper method to Prepare object for Updating Seizure Details
     * @param command
     * @return
     */
    private Set<Seizure> getUpdatedSeizures(UpdateArrestReportCommand command) {

        Set<Seizure> seizures = null;
        if (CollectionUtils.isNotEmpty(command.getSeizureList())) {

            seizures = command.getSeizureList().stream()
                    .map(seizureDto -> {
                        if (seizureDto.getId() == 0L) {
                            SeizureKey seizureKey = seizureKeyProvider.next();
                            return new Seizure(seizureKey, seizureDto.getSeizedItem(),
                                    Long.valueOf(seizureDto.getCount()), 0L);
                        } else {

                            SeizureKey seizureKey = new SeizureKey(seizureDto.getId());
                            return new Seizure(seizureKey, seizureDto.getSeizedItem(),
                                    Long.valueOf(seizureDto.getCount()), seizureDto.getIsDeleted());
                        }
                    })
                    .collect(Collectors.toSet());
        }
        return seizures;
    }

    /**
     * Helper method to prepare object for updating Arrest Notes
     * @param command
     * @return
     */
    private Set<ArrestNote> getUpdatedArrestNotes(UpdateArrestReportCommand command) {

        Set<ArrestNote> arrestNotes = null;
        if (CollectionUtils.isNotEmpty(command.getArrestNoteList())) {

            arrestNotes = command.getArrestNoteList().stream()
                    .map(arrestNoteDto -> {
                        if (arrestNoteDto.getId() == 0L) {
                            NoteKey newNoteKey = arrestNoteKeyProvider.next();
                            return new ArrestNote(newNoteKey, arrestNoteDto.getTextNote(),
                                    arrestNoteDto.getIsDeleted());
                        } else {
                            NoteKey noteKey = new NoteKey(arrestNoteDto.getId());
                            return new ArrestNote(noteKey, arrestNoteDto.getTextNote(), 0L);
                        }
                    })
                    .collect(Collectors.toSet());
        }
        return arrestNotes;
    }

    /**
     * Helper method to prepare JSON object for Arrest Party
     * @param arrestPartySet
     * @return
     */
    private String getArrestPartyListJson(Set<ArrestParty> arrestPartySet) {

        String arrestPartyListJson = null;
        List<Map<String, Object>> arrestPartyValueMap =
                arrestPartySet.stream()
                        .filter(arrestParty -> Objects.equals(arrestParty.getIsDeleted(), 0L))
                        .map(arrestParty -> {
                            Map<String, Object> valueMap = new TreeMap<>();
                            valueMap.put("id", arrestParty.id());
                            valueMap.put("partyId", arrestParty.getPartyId());
                            valueMap.put("partyType", arrestParty.getPartyTypeId());
                            return valueMap;

                        }).collect(Collectors.toList());
        try {
            arrestPartyListJson = jsonMapper.writeValueAsString(arrestPartyValueMap);
        } catch (JsonProcessingException jsonProcessingException) {
            LOGGER.error("JsonProcessingException occurred while reading getArrestPartyListJson. ",
                    jsonProcessingException);
        }
        return arrestPartyListJson;
    }
}
