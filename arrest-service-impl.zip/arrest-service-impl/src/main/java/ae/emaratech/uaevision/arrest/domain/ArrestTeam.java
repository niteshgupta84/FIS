package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.entity.AbstractEntityBase;
import ae.emaratech.uaevision.fis.common.key.ArrestTeamKey;

import javax.persistence.*;


/**
 * The persistent class for the ARREST_TEAM database table.
 */
@Entity(name = "newArrestTeam")
@Table(name = "ARREST_TEAM")
public class ArrestTeam extends AbstractEntityBase {

    private static final Long serialVersionUID = 1L;

    @Column(name = "EMPLOYEE_NO", length = 20, nullable = false)
    private String employeeNo;

    @Column(name = "IS_DELETED")
    private Long isDeleted;
    //bi-directional many-to-one association to ArrestReport
    @ManyToOne
    @JoinColumn(name = "ARREST_REPORT_ID", nullable = false)
    private Arrest arrestReport;

    private ArrestTeam() {

    }

    public ArrestTeam(ArrestTeamKey arrestTeamKey, String employeeNo, Long isDeleted) {
        setId(arrestTeamKey.id());
        this.employeeNo = employeeNo;
        this.isDeleted = isDeleted;
    }

    protected String getEmployeeNo() {
        return employeeNo;
    }

    protected Arrest getArrestReport() {
        return arrestReport;
    }

    protected void setArrestReport(Arrest arrestReport) {
        this.arrestReport = arrestReport;
    }

    protected Long getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Long isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ArrestTeam that = (ArrestTeam) o;

        if (id() != null ? !id().equals(that.id()) : that.id() != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return id() != null ? id().hashCode() : 0;
    }
}