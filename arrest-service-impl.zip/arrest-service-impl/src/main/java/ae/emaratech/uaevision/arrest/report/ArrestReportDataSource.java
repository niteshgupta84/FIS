package ae.emaratech.uaevision.arrest.report;
/**
 * Created by Satya K on 26/4/2016.
 */

import ae.emaratech.uaevision.arrest.application.dto.ArrestPartyDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestReportDto;
import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;
import ae.emaratech.uaevision.arrest.query.ArrestQueryService;
import ae.emaratech.uaevision.arrest.query.RetrieveArrestQuery;
import ae.emaratech.uaevision.document.service.api.DocumentService;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.common.util.DateUtils;
import ae.emaratech.uaevision.fis.gateway.incident.UserManagementServiceClient;
import ae.emaratech.uaevision.fis.gateway.usermanagementservice.EmployeeDetail;
import ae.emaratech.uaevision.fis.gateway.usermanagementservice.EmployeeDetails;
import ae.emaratech.uaevision.fis.party.application.PartyTypeEnum;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.query.PartyQueryService;
import ae.emaratech.uaevision.fis.party.query.RetrievePartyQuery;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperDataSource;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.jasperreports.JasperReportsUtils;


import java.io.ByteArrayInputStream;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class ArrestReportDataSource implements JasperDataSource {

    @Autowired
    private ArrestQueryService arrestQueryService;

    @Autowired
    private UserManagementServiceClient userManagementServiceClient;

    @Autowired
    private PartyQueryService partyQueryService;

    @Autowired
    private DocumentService documentService;


    public JRDataSource getDataSource(ReportParameters parameters) {

        Long parentIncidentIdLong = Long.valueOf(parameters.getParameter("ARREST_ID").toString());

        ArrestReportKey arrestReportKey = new ArrestReportKey(parentIncidentIdLong);
        RetrieveArrestQuery retrieveArrestQuery = new RetrieveArrestQuery(arrestReportKey);
        ArrestReportDto arrestReportDto = arrestQueryService.retrieveArrestReport(retrieveArrestQuery);
        List<ArrestTeamDto> arrestTeamDtos = arrestQueryService.retrieveArrestTeamsForArrest(retrieveArrestQuery);
        EmployeeDetails employeeDetails = userManagementServiceClient.getAllEmployeeDetails();
        List<EmployeeDetail> employeeDetailList = employeeDetails.getEmployeeDetail();

        List<Map> objects = new ArrayList<>();

        List<PartyDto> parties = new ArrayList<>();

        byte[] partyPhoto = null;

        if (CollectionUtils.isEmpty(arrestReportDto.getArrestPartyDtoList())) {
            return new JRBeanCollectionDataSource(objects);
        }

        for (ArrestPartyDto arrestPartyDto : arrestReportDto.getArrestPartyDtoList()) {

            RetrievePartyQuery retrievePartyQuery = new RetrievePartyQuery(new PartyKey(arrestPartyDto.getPartyId()));
            PartyDto partyDto = partyQueryService.retrieveParty(retrievePartyQuery);
            if (Objects.equals(partyDto.getIsDeleted(), 0L)) {
                if (partyDto.getAttachmentId() != null) {
                    partyPhoto = documentService.downloadDocument(partyDto.getAttachmentId()).getAttachment();
                }
                if (partyPhoto != null) {
                    ByteArrayInputStream bais = new ByteArrayInputStream(partyPhoto);
                    partyDto.setReportProfilePhoto(bais);
                }
                partyDto.setPartytype(arrestPartyDto.getPartyType());

                if (arrestPartyDto.getPartyType().getId().equals(PartyTypeEnum.ACCUSED.getId())) {
                    parties.add(0, partyDto);
                } else {
                    parties.add(partyDto);
                }
            }
        }

        Comparator<PartyDto> byPartyId = (currentParty, nextParty) -> Long.compare(currentParty.getId(), nextParty.getId());
        parties.sort(byPartyId);

        for (PartyDto party : parties) {

            Map<String, Object> resultSet = new HashMap<>();

            List<PartyDto> partyList = new ArrayList();
            partyList.add(party);
            resultSet.put("party", partyList);
            resultSet.put("cdeptName", arrestReportDto.getDepartment().getName());
            resultSet.put("csectionName", arrestReportDto.getSection().getName());
            resultSet.put("incidentCreator", arrestReportDto.getCreatedBy());
            resultSet.put("incidentNumber", arrestReportDto.getArrestReportNumber());
            resultSet.put("incidentCreationDateTime", DateUtils.getDateToDisplay(arrestReportDto.getCreatedDate()));
            resultSet.put("incidentStatus", arrestReportDto.getStatus().getName());
            resultSet.put("deptName", arrestReportDto.getDepartment().getName());
            resultSet.put("sectionName", arrestReportDto.getSection().getName());

            // Arrest Details

            if (Checks.isNotNull(arrestReportDto.getArrestLocation())) {
                resultSet.put("arrestLoc", arrestReportDto.getArrestLocation());
            }
            if (Checks.isNotNull(arrestReportDto.getEmirateLk())) {
                resultSet.put("arrestEmirate", arrestReportDto.getEmirateLk().getName());
            }
            if (Checks.isNotNull(arrestReportDto.getCityLk())) {
                resultSet.put("arrestCity", arrestReportDto.getCityLk().getName());
            }
            if (Checks.isNotNull(arrestReportDto.getAreaLk())) {
                resultSet.put("arrestArea", arrestReportDto.getAreaLk().getName());
            }
            if (Checks.isNotNull(arrestReportDto.getArrestLocation())) {
                resultSet.put("arrestLocDesc", arrestReportDto.getArrestLocation());
            }
            resultSet.put("arrestDate", DateUtils.getDateToDisplay(arrestReportDto.getArrestDate()));
            resultSet.put("arrestReport", arrestReportDto.getArrestReportDescription() + "<p>&nbsp;</p>");

            // Arrest team details
            JRDataSource jrArrestTeamLstDataSource = null;
            if (CollectionUtils.isEmpty(arrestTeamDtos)) {
                jrArrestTeamLstDataSource = new JRBeanCollectionDataSource(new ArrayList<>());
                resultSet.put("arrestTeamLst", jrArrestTeamLstDataSource);
            } else {

                //Iterating EmployeeDetails and filter with EMployee Id to get the name of Arrest team

                for (ArrestTeamDto arrestTeamDto : arrestTeamDtos) {
                    List<EmployeeDetail> employeeDetailListFiltered = employeeDetailList.stream().filter(empObj -> empObj.getEmployeeId() == Long.parseLong(arrestTeamDto.getEmployeeId())).
                            collect(Collectors.toList());
                    if (employeeDetailListFiltered.size() == 1) {
                        EmployeeDetail employeeDetail = employeeDetailListFiltered.get(0);
                        arrestTeamDto.setOfficerName(employeeDetail.getNameEn());
                        arrestTeamDto.setOfficerNameAr(employeeDetail.getNameAr());
                        employeeDetailListFiltered.clear();
                    }
                }


                jrArrestTeamLstDataSource = JasperReportsUtils.convertReportData(arrestTeamDtos);
                resultSet.put("arrestTeamLst", jrArrestTeamLstDataSource);
            }

            objects.add(resultSet);
        }

        return new JRBeanCollectionDataSource(objects);
    }
}
