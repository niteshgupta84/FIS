package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.application.dto.ArrestTeamDto;
import ae.emaratech.uaevision.fis.user.service.api.UserService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Mapper class for mapping Arrest Team entity to Dto and vice versa Created by Nitesh.Gupta on
 * 6/6/2016.
 */
@Component
public class ArrestTeamMapper {


    @Autowired
    private UserService userService;

    /**
     * Mapping Dto from Entity
     */
    public ArrestTeamDto mapToArrestTeamDto(ArrestTeam arrestTeamEntity) {
        ArrestTeamDto arrestTeamDto = new ArrestTeamDto();
        arrestTeamDto.setArrestTeamId(arrestTeamEntity.id());
        arrestTeamDto.setId(arrestTeamEntity.id());
        arrestTeamDto.setEmployeeId(arrestTeamEntity.getEmployeeNo());
        arrestTeamDto.setCreatedBy(userService.getUserFirstNameByUserLogin(arrestTeamEntity.getCreatedBy()));
        arrestTeamDto.setCreatedDate(arrestTeamEntity.getCreatedDate());
        arrestTeamDto.setIsDeleted(arrestTeamEntity.getIsDeleted());
        return arrestTeamDto;
    }

    /**
     * Map Arrest Entity to Dto List
     */
    public List<ArrestTeamDto> mapToDtoList(Set<ArrestTeam> arrestTeamSet) {
        List<ArrestTeamDto> arrestDtoList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(arrestTeamSet)) {
            arrestDtoList.addAll(
                    arrestTeamSet.stream().filter(arrestTeam -> Objects.equals(arrestTeam.getIsDeleted(), 0L))
                            .map(this::mapToArrestTeamDto).collect(Collectors.toList()));
        }
        return arrestDtoList;
    }


}
