package ae.emaratech.uaevision.arrest.report;

import ae.emaratech.uaevision.fis.common.exception.BusinessException;
import ae.emaratech.uaevision.fis.report.core.FISReport;
import ae.emaratech.uaevision.fis.report.core.FISReportFormat;
import ae.emaratech.uaevision.fis.report.core.FISReportGenerator;
import ae.emaratech.uaevision.fis.report.core.ReportParameters;
import ae.emaratech.uaevision.fis.report.jasper.JasperReportGenerator;
import net.sf.jasperreports.engine.JRDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;

/**
 * Created by Wasib.Khan on 6/8/2016.
 */
@Component
public class ArrestPartyReportGenerator implements FISReportGenerator {

    /**
     * Static containing the logger for the class.
     */
    private static final Logger LOGGER = LogManager.getLogger();

    private static final String JASPER_TEMPLATE = "party-report";
    @Autowired
    private ArrestPartyReportDataSource arrestPartyReportDataSource;
    @Autowired
    private JasperReportGenerator jasperReportGenerator;
    @Override
    public FISReport generateReport(ReportParameters parameters, FISReportFormat fisReportFormat) throws BusinessException {

        LOGGER.entry();
        LOGGER.info("method  generateReport() start");

        JRDataSource dataSource = arrestPartyReportDataSource.getDataSource(parameters);
        FISReport report = new FISReport();
        report.setContent(
                jasperReportGenerator.generateReport(JASPER_TEMPLATE, new HashMap(), dataSource));

        LOGGER.info("method  generateReport() stop");
        return report;


    }


}
