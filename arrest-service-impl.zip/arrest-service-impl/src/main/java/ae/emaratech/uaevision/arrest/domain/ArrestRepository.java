package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.arrest.infrastructure.HibernateArrestRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository which manages the  persistence and retrieval of Arrest Report domain entity.
 *
 * @author Haroon.Subair
 */
@Repository
public interface ArrestRepository extends HibernateArrestRepository {


}
