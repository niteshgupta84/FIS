package ae.emaratech.uaevision.arrest.domain;

import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceDefinition;
import ae.emaratech.uaevision.fis.common.dataaccess.repository.SequenceService;
import ae.emaratech.uaevision.fis.common.key.NoteKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by Nitesh.Gupta on 6/5/2016.
 */
@Component
public class ArrestNoteKeyProvider {

    @Autowired
    private SequenceService sequenceService;

    public NoteKey next() {
        Long nextSequenceNumber = sequenceService.nextValue(SequenceDefinition.ARREST_NOTE);
        NoteKey noteKey = new NoteKey(nextSequenceNumber);
        return noteKey;
    }
}
