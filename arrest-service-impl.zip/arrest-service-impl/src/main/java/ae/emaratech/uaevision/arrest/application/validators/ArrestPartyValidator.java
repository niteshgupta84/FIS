package ae.emaratech.uaevision.arrest.application.validators;

import ae.emaratech.uaevision.arrest.application.ArrestNotificationCode;
import ae.emaratech.uaevision.fis.common.notification.NotificationBuilder;
import ae.emaratech.uaevision.fis.common.notification.NotificationBus;
import ae.emaratech.uaevision.fis.common.util.Checks;
import ae.emaratech.uaevision.fis.party.application.CreatePartyCommand;
import ae.emaratech.uaevision.fis.party.application.UpdatePartyCommand;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.fis.party.application.dto.PartyTypeChargeEnum;
import ae.emaratech.uaevision.lookup.service.api.LookupService;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import ae.emaratech.uaevision.lookup.service.model.LookupDefinition;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Created by Nitesh.Gupta on 6/19/2016.
 */
@Component
public class ArrestPartyValidator {

    @Autowired
    private NotificationBus notificationBus;

    @Autowired
    private LookupService lookupService;

    public void validate(CreatePartyCommand command) {
        StringBuilder udbForEmail = new StringBuilder();
        StringBuilder udbForPhone = new StringBuilder();
        StringBuilder udbForPassport = new StringBuilder();
        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        List<PartyDto> listOfParty = command.getPartyList();

        String unknownName = lookupService.getLookupEntry(LookupDefinition.PERSON_TYPE, LocaleContextHolder.getLocale(),8L).get().getName();
        if (CollectionUtils.isEmpty(listOfParty)) {

            notificationBuilder.add(ArrestNotificationCode.PARTY_MANDATORY);

        } else {
            List<PartyDto>
                    validPartyList = listOfParty.stream().filter(party -> Objects.equals(
                    party.getIsDeleted(), 0L)).collect(
                    Collectors.toList());
            if (CollectionUtils.isEmpty(validPartyList)) {
                notificationBuilder.add(ArrestNotificationCode.PARTY_MANDATORY);
            } else {
                boolean partyTypeAccusedFound = false;
                for (PartyDto partyDto : listOfParty) {
                    Entry partyType = partyDto.getPartytype();
                    String partyTypeCharge = null;
                    String udbNumber = partyDto.getUdbNo() != null ? String.valueOf(partyDto.getUdbNo()) : unknownName;
                    if (partyType != null) {
                        partyTypeCharge = partyType.getSelectedAttributes().get(0).getValue();

                    }
                    if (partyTypeCharge != null) {
                        if (partyTypeCharge.equalsIgnoreCase(PartyTypeChargeEnum.MANDATORY.getId())
                                && Objects.equals(partyDto.getIsDeleted(), 0L)) {
                            partyTypeAccusedFound = true;
                            if (CollectionUtils.isEmpty(partyDto.getListofCharges())) {
                                // Charges for Accused
                                notificationBuilder.add(ArrestNotificationCode.ACCUSED_CHARGE_MANDATORY, partyType.getName());
                            }
                        }
                    } else {
                        // Party Type mandatory
                        notificationBuilder.add(ArrestNotificationCode.PARTY_TYPE_MANDATORY);
                    }

                    if (!Checks.isValidString(partyDto.getEmailAddress())){
                        udbForEmail.append(udbNumber);
                        udbForEmail.append(",");
                    }
                    if (!Checks.isValidString(partyDto.getPhoneNumber())){
                        udbForPhone.append(udbNumber);
                        udbForPhone.append(",");
                    }
                    if (CollectionUtils.isEmpty(partyDto.getPassports())){
                        udbForPassport.append(udbNumber);
                        udbForPassport.append(",");

                    }
                }
                if (udbForEmail.toString().length()>0){
                    notificationBuilder.add(ArrestNotificationCode.PARTY_EMAIL_MANDATORY,udbForEmail.toString());
                }
                if (udbForPhone.toString().length()>0){

                    notificationBuilder.add(ArrestNotificationCode.PARTY_PHONE_MANDATORY,udbForPhone.toString());
                }
                if (udbForPassport.toString().length()>0){
                    notificationBuilder.add(ArrestNotificationCode.PARTY_PASSPORT_MANDATORY,udbForPhone.toString());
                }
                if (command.isAccusedMandatory() && !partyTypeAccusedFound) {
                    notificationBuilder.add(ArrestNotificationCode.PARTY_TYPE_ACCUSED_MANDATORY);

                }
            }
        }

        if (notificationBuilder.hasNotifications()) {
            notificationBus.send(notificationBuilder);
        }
    }

    public void validate(UpdatePartyCommand command) {

        NotificationBuilder notificationBuilder = notificationBus.getBuilder();
        String unknownName = lookupService.getLookupEntry(LookupDefinition.PERSON_TYPE, LocaleContextHolder.getLocale(),8L).get().getName();
        List<PartyDto> listOfParty = command.getPartyList();
        StringBuilder udbForEmail = new StringBuilder();
        StringBuilder udbForPhone = new StringBuilder();
        StringBuilder udbForPassport = new StringBuilder();
        if (listOfParty.isEmpty()) {
            notificationBuilder.add(ArrestNotificationCode.PARTY_MANDATORY);

        } else {
            List<PartyDto>
                    validPartyList = listOfParty.stream().filter(
                    party -> Objects.equals(party.getIsDeleted(), 0L)).collect(
                    Collectors.toList());
            if (validPartyList.isEmpty()) {
                notificationBuilder.add(ArrestNotificationCode.PARTY_MANDATORY);
            } else {
                boolean partyTypeAccusedFound = false;
                boolean isPartyTypeExists = true;
                for (PartyDto partyDto : listOfParty) {
                    Entry partyType = partyDto.getPartytype();
                    String udbNumber = partyDto.getUdbNo() != null ? String.valueOf(partyDto.getUdbNo()) : unknownName;
                    if (null != partyType) {

                        if (CollectionUtils.isNotEmpty(partyType.getSelectedAttributes())) {
                            String partyTypeCharge = partyType.getSelectedAttributes().get(0).getValue();
                            if (partyTypeCharge != null) {
                                if (partyTypeCharge.equalsIgnoreCase(PartyTypeChargeEnum.MANDATORY.getId())
                                        && Objects.equals(partyDto.getIsDeleted(), 0L)) {
                                    partyTypeAccusedFound = true;
                                    if (CollectionUtils.isEmpty(partyDto.getListofCharges()) && Objects.equals(partyDto.getPartyId(), command.getPartyDto().getId())) {
                                        // Charges for Accused
                                        notificationBuilder.add(ArrestNotificationCode.ACCUSED_CHARGE_MANDATORY,  partyType.getName());
                                    }
                                }
                            } else {
                                isPartyTypeExists = false;
                            }
                        } else {
                            isPartyTypeExists = false;
                        }
                    } else {
                        isPartyTypeExists = false;
                    }
                    // Party Type mandatory
                    if (!isPartyTypeExists) {
                        notificationBuilder.add(ArrestNotificationCode.PARTY_TYPE_MANDATORY);
                    }
                    if (!Checks.isValidString(partyDto.getEmailAddress())){
                        udbForEmail.append(udbNumber);
                        udbForEmail.append(",");
                    }
                    if (!Checks.isValidString(partyDto.getPhoneNumber())){
                        udbForPhone.append(udbNumber);
                        udbForPhone.append(",");
                    }
                    if (CollectionUtils.isEmpty(partyDto.getPassports())){
                        udbForPassport.append(udbNumber);
                        udbForPassport.append(",");

                    }
                }

                if (command.isAccusedMandatory() && !partyTypeAccusedFound) {
                    notificationBuilder.add(ArrestNotificationCode.PARTY_TYPE_ACCUSED_MANDATORY);
                }
                if (udbForEmail.toString().length()>0){
                    notificationBuilder.add(ArrestNotificationCode.PARTY_EMAIL_MANDATORY,udbForEmail.toString());
                }
                if (udbForPhone.toString().length()>0){

                    notificationBuilder.add(ArrestNotificationCode.PARTY_PHONE_MANDATORY,udbForPhone.toString());
                }
                if (udbForPassport.toString().length()>0){

                    notificationBuilder.add(ArrestNotificationCode.PARTY_PASSPORT_MANDATORY,udbForPhone.toString());
                }
            }
        }
        if (notificationBuilder.hasNotifications()) {
            notificationBus.send(notificationBuilder);
        }
    }

}
