package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.crm.application.dto.CaseNoteDto;
import ae.emaratech.uaevision.fis.common.key.NoteKey;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
public class DeleteNoteCommand {

    private NoteKey noteKey;
    private List<CaseNoteDto> caseNoteDtoList = new ArrayList<>();


    public DeleteNoteCommand(NoteKey noteKey) {
        this.noteKey = noteKey;
    }

    public DeleteNoteCommand withNoteList(List<CaseNoteDto> caseNoteDtoList) {
        this.caseNoteDtoList = caseNoteDtoList;
        return this;
    }

    public NoteKey getNoteKey() {
        return noteKey;
    }

    public List<CaseNoteDto> getCaseNoteDtoList() {
        return caseNoteDtoList;
    }
}
