package ae.emaratech.uaevision.crm.query;

import ae.emaratech.uaevision.fis.common.key.CaseKey;

import java.io.Serializable;

/**
 * Created by Nitesh.Gupta on 6/19/2016.
 */
public class RetrieveCaseQuery implements Serializable {

    private CaseKey caseKey;

    public RetrieveCaseQuery(CaseKey caseKey) {
        this.caseKey = caseKey;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }
}
