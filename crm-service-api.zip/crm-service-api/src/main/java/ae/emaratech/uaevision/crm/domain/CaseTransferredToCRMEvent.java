package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Event triggered when case has been transferred.
 *
 * @author Nitesh.Gupta
 */
public class CaseTransferredToCRMEvent extends DomainEvent {

    private CaseKey caseKey;
    private ArrestReportKey arrestReportKey;
    private Long status;
    private Long latestSection;
    private Long transferDepartment;
    private String transferComments;

    private CaseTransferredToCRMEvent(Builder builder) {
        super(builder);
        this.caseKey = builder.caseKey;
        this.arrestReportKey = builder.arrestReportKey;
        this.status = builder.statusId;
        this.transferComments = builder.transferComments;
        this.transferDepartment = builder.transferDepartment;
        this.latestSection = builder.transferSection;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public Long getStatus() {
        return status;
    }

    public String getTransferComments() {
        return transferComments;
    }

    public Long getLatestSection() {
        return latestSection;
    }

    public Long getTransferDepartment() {
        return transferDepartment;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private CaseKey caseKey;
        private Long statusId;
        private String transferComments;
        private Long transferSection;
        private Long transferDepartment;

        public Builder(EventContext eventContext,CaseKey caseKey, ArrestReportKey arrestReportKey,
                       Long transferDepartment, Long transferSection) {
            super(eventContext);
            this.caseKey = caseKey;
            this.arrestReportKey = arrestReportKey;
            this.transferDepartment = transferDepartment;
            this.transferSection = transferSection;
        }

        public Builder withCaseStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withTransferComments(String transferComments) {
            this.transferComments = transferComments;
            return this;
        }

        public CaseTransferredToCRMEvent build() {
            return new CaseTransferredToCRMEvent(this);
        }
    }
}
