package ae.emaratech.uaevision.crm.query;

import ae.emaratech.uaevision.crm.application.CasePageBuilder;
import ae.emaratech.uaevision.crm.application.dto.*;
import ae.emaratech.uaevision.document.application.AttachedDocumentDto;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.common.key.CaseTransferKey;
import ae.emaratech.uaevision.fis.common.notification.Notification;

import java.util.List;
import java.util.Map;

/**
 * Created by Nitesh.Gupta on 6/19/2016.
 */
public interface CaseQueryService {

    /**
     * Method which retrieves the history records for the interrogation.
     *
     * @param caseHistoryQuery the query object for retrieving arrest history details.
     * @return list of CaseTrackDto information detailing the history of Arrest.
     */
    List<CaseTrackDto> retrieveCaseHistory(
            RetrieveCaseHistoryQuery caseHistoryQuery);


    /**
     * Method which will retrieve  arrest based on Key  Given
     *
     * @return
     */
    CaseDto retrieveCase(RetrieveCaseQuery retrieveCaseQuery);

    /**
     * Method to retrieve case by Search Criteria
     *
     * @param retrieveCasesBySearchQuery
     * @return
     */
    Map<Long, CaseDto> retrieveCasesBySearchCriteria(RetrieveCasesBySearchQuery retrieveCasesBySearchQuery);

    /**
     * Retrieve Cases with Owner Details
     *
     * @param retrieveCasesWithOwnerDetailQuery
     * @return
     */
    CasePageBuilder retrieveCasesAssignedToUser(
            RetrieveCasesWithOwnerDetailQuery retrieveCasesWithOwnerDetailQuery);

    /**
     * @param retrieveCasesWithOwnerDetailQuery
     * @return
     */
    CasePageBuilder retrieveCasesCreatedByUser(
            RetrieveCasesWithOwnerDetailQuery retrieveCasesWithOwnerDetailQuery);

    /**
     * Method which will retrieve all arrest based on Criteria Given
     *
     * @param criterias
     * @param query
     * @return
     */
    CasePageBuilder retrieveCasesBySearchCriteria(CasePageBuilder criterias, RetrieveCasesBySearchQuery query);

    /**
     * Retrieving Case based on Party
     *
     * @param retrieveCaseForParty
     * @return
     */
    CaseDto retrieveCaseForParty(RetrieveCaseForPartyQuery retrieveCaseForParty);

    /**
     * Retrieving Case based on Party
     *
     * @param retrieveCaseForArrestQuery
     * @return
     */
    List<CaseDto> retrieveCaseForArrest(RetrieveCaseForArrestQuery retrieveCaseForArrestQuery);


    List<CaseNoteDto> retrieveNotesForCase(RetrieveCaseQuery retrieveCaseQuery);

    List<AttachedDocumentDto> retrieveAttachmentsForCase(RetrieveCaseQuery retrieveCaseQuery);

    List<DocumentInspectionDto> retrieveDocumentInspectionsForCase(RetrieveCaseQuery retrieveCaseQuery);

    List<CaseAssociationDto> retrieveAssociationsForCase(RetrieveCaseQuery retrieveCaseQuery);

    /**
     * Method which validates whether a party is associated with any existing active cases.
     *
     * @param validateActiveCaseForPartyQuery the query object with list of party ids to be
     *                                        validated.
     */
    Notification validateActiveCaseForParty(
            ValidateActiveCaseForPartyQuery validateActiveCaseForPartyQuery);

    /**
     * Retreive Method for fetching all cases against Party
     * @param retrieveCaseForParty query object for filtering data
     * @return List of Cases
     */
    List<CaseDto> retrieveCasesForParty(RetrieveCaseForPartyQuery retrieveCaseForParty);

    /**
     * Retrieve method for getting all Transferred cases which are not received yet by oficer
     * @param casePageBuilder Pagination attributes
     * @return
     */
    CasePageBuilder retrieveAllTransferredCases(CasePageBuilder casePageBuilder);

    /**
     * Method is to retrieve Case Transfer Detail information against case transfer key
     * @param caseTransferKey
     * @return CaseTransferDetailDto
     */
    CaseTransferDetailDto retreiveCaseTransferDetail(CaseTransferKey caseTransferKey);

    /**
     * Method is to retrieve Case Transfer Detail information against case key
     * @param caseKey
     * @return CaseTransferDetailDto
     * @since 1.01.012
     */
    CaseTransferDetailDto retreiveCaseTransferDetail(CaseKey caseKey);
    /**
     * Method is to retrieve Case Transfer Detail information against case key
     * @param caseKey
     * @return CaseTransferDetailDto
     * @since 1.01.012
     */
    CaseTransferDetailDto retrieveTransferredCaseTransferDetail(CaseKey caseKey);

    /**
     * Method is to retrieve all cases transferred to Air Control from Sea
     * @param retrieveCasesWithOwnerDetailQuery
     * @return CaseTransferDetailDto
     * @since 1.01.017
     */
    CasePageBuilder retrieveCasesForwardToInternalSection(
            RetrieveCasesWithOwnerDetailQuery retrieveCasesWithOwnerDetailQuery);

}
