package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Event triggered when case submitted for review has been approved by the supervisor.
 *
 * @author Nitesh.Gupta
 */
public class CaseApprovedEvent extends DomainEvent {

    private CaseKey caseKey;
    private ArrestReportKey arrestReportKey;
    private Long status;
    private String approveComments;

    public CaseApprovedEvent(Builder builder) {
        super(builder);
        this.caseKey = builder.caseKey;
        this.arrestReportKey = builder.arrestReportKey;
        this.approveComments = builder.approveComments;
        this.status = builder.statusId;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private String approveComments;
        private Long statusId;
        private CaseKey caseKey;

        public Builder(EventContext eventContext,
                       CaseKey caseKey, ArrestReportKey arrestReportKey) {
            super(eventContext);
            this.caseKey = caseKey;
            this.arrestReportKey = arrestReportKey;
        }

        public ArrestReportKey getArrestReportKey() {
            return arrestReportKey;
        }

        public String getApproveComments() {
            return approveComments;
        }

        public Long getStatusId() {
            return statusId;
        }

        public CaseKey getCaseKey() {
            return caseKey;
        }

        public Builder withCaseStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withApproveComments(String approveComments) {
            this.approveComments = approveComments;
            return this;
        }

        public CaseApprovedEvent build() {
            return new CaseApprovedEvent(this);
        }


    }
}



