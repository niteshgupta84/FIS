package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Event triggered when the case is submitted to supervisor for review.
 *
 * @author Nitesh.Gupta
 */
public class CaseReviewedEvent extends DomainEvent {

    private CaseKey caseKey;
    private ArrestReportKey arrestReportKey;
    private Long status;
    private String reviewComments;

    public CaseReviewedEvent(Builder builder) {
        super(builder);
        this.caseKey = builder.caseKey;
        this.arrestReportKey = builder.arrestReportKey;
        this.reviewComments = builder.reviewComments;
        this.status = builder.statusId;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private String reviewComments;
        private Long statusId;
        private CaseKey caseKey;

        public Builder(EventContext eventContext,
                       CaseKey caseKey, ArrestReportKey arrestReportKey) {
            super(eventContext);
            this.caseKey = caseKey;
            this.arrestReportKey = arrestReportKey;
        }

        public Builder withCaseStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withReviewComments(String reviewComments) {
            this.reviewComments = reviewComments;
            return this;
        }

        public ArrestReportKey getArrestReportKey() {
            return arrestReportKey;
        }

        public CaseReviewedEvent build() {
            return new CaseReviewedEvent(this);
        }
    }
}
