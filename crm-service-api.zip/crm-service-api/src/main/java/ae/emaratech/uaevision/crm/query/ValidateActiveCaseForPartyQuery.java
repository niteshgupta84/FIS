package ae.emaratech.uaevision.crm.query;

import java.io.Serializable;
import java.util.List;

/**
 * Query object which wraps the list of party id nos to be validated whether they are associated
 * with any existing active case record.
 *
 * @author Haroon.Subair
 */
public class ValidateActiveCaseForPartyQuery implements Serializable {

    private List<Long> partyIdList;

    public ValidateActiveCaseForPartyQuery(List<Long> partyIdList) {
        this.partyIdList = partyIdList;
    }

    public List<Long> getPartyIdList() {
        return partyIdList;
    }
}
