package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public class CloseCaseCommand {

    private CaseKey caseKey;
    private String closeComments;

    public CloseCaseCommand(CaseKey caseKey, String closeComments) {
        this.caseKey = caseKey;
        this.closeComments = closeComments;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public String getCloseComments() {
        return closeComments;
    }
}
