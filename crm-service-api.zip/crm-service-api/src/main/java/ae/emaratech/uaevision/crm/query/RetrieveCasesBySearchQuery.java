package ae.emaratech.uaevision.crm.query;

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportDto;
import ae.emaratech.uaevision.crm.application.CasePageBuilder;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import org.springframework.format.annotation.DateTimeFormat;

import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by Nitesh.Gupta on 6/19/2016.
 */
public class RetrieveCasesBySearchQuery implements Serializable {
    @DateTimeFormat(pattern = "MM/dd/yyyy")
    private Date arrestDate;
    @DateTimeFormat(pattern = "MM/dd/yyyy")
    private Date arrestDateTo;
    private String arrestTime;
    private String arrestTimeTo;
    @Nullable
    private Entry department;
    @Nullable
    private Entry section;

    @Nullable
    private Entry nonCRMSection;

    @Nullable
    private Entry latestSection;

    @Nullable
    private Entry sectionUnit;

    @Nullable
    private Entry transferredFrom;

    private Entry status;
    private String createdBy;
    @DateTimeFormat(pattern = "MM/dd/yyyy")
    private Date createdDate;
    private String caseNumber;
    private String assignedUser;
    private boolean urgent;
    private ArrestReportDto arrestReportDto;
    private Integer start;
    private Integer length;
    private Integer currentPage;
    private long totalRecord;
    CasePageBuilder casePageBuilder;

    @Nullable
    public Entry getDepartment() {
        return department;
    }

    public void setDepartment(@Nullable Entry department) {
        this.department = department;
    }

    @Nullable
    public Entry getSection() {
        return section;
    }

    public void setSection(@Nullable Entry section) {
        this.section = section;
    }

    @Nullable
    public Entry getSectionUnit() {
        return sectionUnit;
    }

    public void setSectionUnit(@Nullable Entry sectionUnit) {
        this.sectionUnit = sectionUnit;
    }

    @Nullable
    public Entry getTransferredFrom() {
        return transferredFrom;
    }

    public void setTransferredFrom(@Nullable Entry transferredFrom) {
        this.transferredFrom = transferredFrom;
    }

    public Entry getStatus() {
        return status;
    }

    public void setStatus(Entry status) {
        this.status = status;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public String getAssignedUser() {
        return assignedUser;
    }

    public void setAssignedUser(String assignedUser) {
        this.assignedUser = assignedUser;
    }

    public ArrestReportDto getArrestReportDto() {
        return arrestReportDto;
    }

    public void setArrestReportDto(ArrestReportDto arrestReportDto) {
        this.arrestReportDto = arrestReportDto;
    }

    public Date getArrestDate() {
        return arrestDate;
    }

    public void setArrestDate(Date arrestDate) {
        this.arrestDate = arrestDate;
    }

    public Date getArrestDateTo() {
        return arrestDateTo;
    }

    public void setArrestDateTo(Date arrestDateTo) {
        this.arrestDateTo = arrestDateTo;
    }

    public String getArrestTime() {
        return arrestTime;
    }

    public void setArrestTime(String arrestTime) {
        this.arrestTime = arrestTime;
    }

    public String getArrestTimeTo() {
        return arrestTimeTo;
    }

    public void setArrestTimeTo(String arrestTimeTo) {
        this.arrestTimeTo = arrestTimeTo;
    }

    public boolean isUrgent() {
        return urgent;
    }

    public void setUrgent(boolean urgent) {
        this.urgent = urgent;
    }

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

    public Integer getLength() {
        return length;
    }

    public void setLength(Integer length) {
        this.length = length;
    }

    public Integer getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage;
    }

    public long getTotalRecord() {
        return totalRecord;
    }

    public void setTotalRecord(long totalRecord) {
        this.totalRecord = totalRecord;
    }

    public CasePageBuilder getCasePageBuilder() {
        return casePageBuilder;
    }

    public void setCasePageBuilder(CasePageBuilder casePageBuilder) {
        this.casePageBuilder = casePageBuilder;
    }

    @Nullable
    public Entry getNonCRMSection() {
        return nonCRMSection;
    }

    public void setNonCRMSection(@Nullable Entry nonCRMSection) {
        this.nonCRMSection = nonCRMSection;
    }

    @Nullable
    public Entry getLatestSection() {
        return latestSection;
    }

    public void setLatestSection(@Nullable Entry latestSection) {
        this.latestSection = latestSection;
    }
}
