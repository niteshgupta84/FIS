package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Created by Nitesh.Gupta on 7/20/2017.
 */
public class ReturnCaseCommand {
    private CaseKey caseKey;


    private String returnComments;

    public ReturnCaseCommand(CaseKey caseKey) {
        this.caseKey = caseKey;

    }

    public ReturnCaseCommand withReturnComments(String returnComments) {
        this.returnComments = returnComments;
        return this;
    }


    public CaseKey getCaseKey() {
        return caseKey;
    }

    public String getReturnComments() {
        return returnComments;
    }
}
