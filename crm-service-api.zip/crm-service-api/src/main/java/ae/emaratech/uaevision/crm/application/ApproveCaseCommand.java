package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Created by Nitesh.Gupta on 6/27/2016.
 */
public class ApproveCaseCommand {

    private CaseKey caseKey;

    private String approveComments;

    public ApproveCaseCommand(CaseKey caseKey, String approveComments) {
        this.caseKey = caseKey;
        this.approveComments = approveComments;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public String getApproveComments() {
        return approveComments;
    }

}
