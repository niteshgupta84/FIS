package ae.emaratech.uaevision.crm.domain;

import java.util.List;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Event triggered by the case module when the case information has been updated.
 *
 * @author Nitesh.Gupta
 */
public class CaseUpdatedEvent extends DomainEvent {

    private CaseKey caseKey;
    private ArrestReportKey arrestReportKey;
    private Long status;
    private Long arrestReason;
    private Long transferredFrom;
    private String firNumber;
    private String caseParties;
    private List<Long> notes;
    private List<Long> attachments;
    private List<Long> caseAssociations;

    public CaseUpdatedEvent(Builder builder) {
        super(builder);
        this.caseKey = builder.caseKey;
        this.arrestReportKey = builder.arrestReportKey;
        this.status = builder.statusId;
        this.arrestReason = builder.arrestReason;
        this.transferredFrom = builder.transferredFrom;
        this.firNumber = builder.firNumber;
        this.notes = builder.notes;
        this.attachments = builder.attachments;
        this.caseAssociations = builder.caseAssociations;

    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public Long getStatus() {
        return status;
    }

    public String getCaseParties() {
        return caseParties;
    }

    public void withCasePartiesJson(String casePartiesJson) {
        this.caseParties = casePartiesJson;
    }

    public static class Builder extends DomainEventBuilder {

        private CaseKey caseKey;
        private ArrestReportKey arrestReportKey;
        private Long statusId;
        private Long arrestReason;
        private Long transferredFrom;
        private String firNumber;
        private List<Long> notes;
        private List<Long> attachments;
        private List<Long> caseAssociations;

        public Builder(EventContext eventContext,
                       CaseKey caseKey, ArrestReportKey arrestReportKey) {
            super(eventContext);
            this.caseKey = caseKey;
            this.arrestReportKey = arrestReportKey;
        }

        public Builder withStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withNotes(List<Long> notesIdList) {
            this.notes =  notesIdList;
            return this;
        }

        public Builder withAttachments(List<Long> caseAttachments) {
            this.attachments = caseAttachments;
            return this;
        }

        public Builder withCaseAssociations(List<Long> caseAssociations) {
            this.caseAssociations = caseAssociations;
            return this;
        }

        public Builder withTransferredFrom(Long transferredFromDeptId) {
            this.transferredFrom = transferredFromDeptId;
            return this;
        }

        public Builder withFirNo(String firNo) {
            this.firNumber = firNo;
            return this;
        }

        public Builder withArrestReason(Long arrestReasonId) {
            this.arrestReason = arrestReasonId;
            return this;
        }

        public CaseUpdatedEvent build() {
            return new CaseUpdatedEvent(this);
        }
    }
}
