package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public class RejectCaseCommand {

    private CaseKey caseKey;
    private String rejectComments;

    public RejectCaseCommand(CaseKey caseKey, String rejectComments) {
        this.caseKey = caseKey;
        this.rejectComments = rejectComments;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public String getRejectComments() {
        return rejectComments;
    }
}
