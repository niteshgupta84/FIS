package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.lookup.service.model.Entry;

/**
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public class ManualReceiveCaseCommand {

    private CaseKey caseKey;
    private String receiveComments;

    private Entry manualReceivedFrom;

    public ManualReceiveCaseCommand(CaseKey caseKey, String receiveComments,
                                    Entry manualReceivedFrom) {
        this.caseKey = caseKey;
        this.receiveComments = receiveComments;
        this.manualReceivedFrom = manualReceivedFrom;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public String getReceiveComments() {
        return receiveComments;
    }

    public Entry getManualReceivedFrom() {
        return manualReceivedFrom;
    }
}
