package ae.emaratech.uaevision.crm.application.dto;

import ae.emaratech.uaevision.fis.common.dto.AbstractDtoBase;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.Date;

/**
 * Dto class to hold values which will be passed to UI
 * Created by Nitesh.Gupta on 3/29/2017.
 */
@ApiModel(value = "Case Transfer Detail Dto ")
public class CaseTransferDetailDto extends AbstractDtoBase implements Serializable {
    @ApiModelProperty(value = "Unique Case Transfer Id", required = true)
    private Long id;
    @ApiModelProperty(value = " Transferred Department Id   ", required = true )
    @Nullable
    private Entry transferredDeptId;
    @ApiModelProperty(value = " Transferred Section Id   ", required = true )
    @Nullable
    private Entry transferredSectionId;

    @ApiModelProperty(value = "Case Created By ", required = true )
    private String createdBy;
    @ApiModelProperty(value = "Case Created on Date ", required = true )
    private Date createdDate;
    @ApiModelProperty(value = "Is Received ", required = true )
    private Entry transferStatus;
    @ApiModelProperty(value = "Received By", required = true )
    private String receivedBy;
    @ApiModelProperty(value = "Version of Case for handling concurrency", required = true )
    private Long version;
    @ApiModelProperty(value = "Case ID ", required = true )
    private Long caseId;
    @ApiModelProperty(value = "Tranferred Case ID Case ID ", required = true )
    private Long transferredCaseId;

    @ApiModelProperty(value = "Tranferred Case Number", required = true )
    private String transferredCaseNumber;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Nullable
    public Entry getTransferredDeptId() {
        return transferredDeptId;
    }

    public void setTransferredDeptId(@Nullable Entry transferredDeptId) {
        this.transferredDeptId = transferredDeptId;
    }

    @Nullable
    public Entry getTransferredSectionId() {
        return transferredSectionId;
    }

    public void setTransferredSectionId(@Nullable Entry transferredSectionId) {
        this.transferredSectionId = transferredSectionId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }



    public String getReceivedBy() {
        return receivedBy;
    }

    public void setReceivedBy(String receivedBy) {
        this.receivedBy = receivedBy;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public Long getCaseId() {
        return caseId;
    }

    public void setCaseId(Long caseId) {
        this.caseId = caseId;
    }

    public Entry getTransferStatus() {
        return transferStatus;
    }

    public void setTransferStatus(Entry transferStatus) {
        this.transferStatus = transferStatus;
    }

    public Long getTransferredCaseId() {
        return transferredCaseId;
    }

    public void setTransferredCaseId(Long transferredCaseId) {
        this.transferredCaseId = transferredCaseId;
    }

    public String getTransferredCaseNumber() {
        return transferredCaseNumber;
    }

    public void setTransferredCaseNumber(String transferredCaseNumber) {
        this.transferredCaseNumber = transferredCaseNumber;
    }

    @Override
    public String toString() {
        return "CaseTransferDetailDto{" +
                "id=" + id +
                ", transferredDeptId=" + transferredDeptId +
                ", transferredSectionId=" + transferredSectionId +
                ", createdBy='" + createdBy + '\'' +
                ", createdDate=" + createdDate +
                ", transferStatus=" + transferStatus +
                ", receivedBy='" + receivedBy + '\'' +
                ", version=" + version +
                ", caseId=" + caseId +
                ", transferredCaseId=" + transferredCaseId +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        CaseTransferDetailDto that = (CaseTransferDetailDto) o;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (id != null ? id.hashCode() : 0);

        return result;
    }
}
