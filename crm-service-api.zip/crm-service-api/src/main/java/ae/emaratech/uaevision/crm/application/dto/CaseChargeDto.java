package ae.emaratech.uaevision.crm.application.dto;

import ae.emaratech.uaevision.fis.common.dto.AbstractDtoBase;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 11/26/2015. Modified by Thofiq 12/12/2015
 */
@ApiModel(value = "Case Charge Dto")
public class CaseChargeDto extends AbstractDtoBase implements Serializable, Comparable {

    @ApiModelProperty(value = "Case Note Created By ", required = true, dataType = "String")
    private String createdBy;
    @ApiModelProperty(value = "Case Note Created on Date ", required = true, dataType = "Date" )
    private Date createdDate;
    @ApiModelProperty(value = "Party UDB Number", required = true, dataType = "long" )
    private long partyFileNo;
    @ApiModelProperty(value = "Case Party Charge Unique Id", required = true, dataType = "long" )
    private long id;
    @ApiModelProperty(value = "Charge Unique Id", required = true, dataType = "long" )
    private long chargeId;
    @ApiModelProperty(value = "Charge Name in English", required = true, dataType = "String" )
    private String nameEn;
    @ApiModelProperty(value = "Charge Name in Arabic", required = true, dataType = "String" )
    private String nameAr;
    @ApiModelProperty(value = "Version of Case Party Charge ", required = true, dataType = "Long" )
    private Long version;
    @NotNull
    @ApiModelProperty(value = "Charge ", required = true, dataType = "Entry" )
    private Entry charge;
    @ApiModelProperty(value = "List of Charges ", required = true, dataType = "List" )
    private List<Entry> charges;
    @ApiModelProperty(value = " Deleted Flag ", required = true, dataType = "Long", allowableValues = "1 or 0")
    private Long isDeleted;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getPartyFileNo() {
        return partyFileNo;
    }

    public void setPartyFileNo(long partyFileNo) {
        this.partyFileNo = partyFileNo;
    }

    public Entry getCharge() {
        return charge;
    }

    public void setCharge(Entry charge) {
        this.charge = charge;
    }

    public List<Entry> getCharges() {
        return charges;
    }

    public void setCharges(List<Entry> charges) {
        this.charges = charges;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public long getChargeId() {
        return chargeId;
    }

    public void setChargeId(long chargeId) {
        this.chargeId = chargeId;
    }

    public String getNameEn() {
        return nameEn;
    }

    public void setNameEn(String nameEn) {
        this.nameEn = nameEn;
    }

    public String getNameAr() {
        return nameAr;
    }

    public void setNameAr(String nameAr) {
        this.nameAr = nameAr;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public Long getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Long isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CaseChargeDto chargeDto = (CaseChargeDto) o;

        if (id != chargeDto.id) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return (int) (id ^ (id >>> 32));
    }

    @Override
    public int compareTo(Object obj) {
        CaseChargeDto chargeDto = (CaseChargeDto) obj;
        return this.id > chargeDto.getId() ? 1 : -1;
    }
}
