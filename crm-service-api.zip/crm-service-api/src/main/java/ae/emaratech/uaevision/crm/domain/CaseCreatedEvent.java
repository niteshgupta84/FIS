package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Event thrown by Case module  when a new case has been created.
 *
 * @author Nitesh.Gupta
 */
public class CaseCreatedEvent extends DomainEvent {

  private CaseKey caseKey;
  private ArrestReportKey arrestReportKey;
  private Long status;
  private String caseParties;
  private Long latestSection;
  private Long transferredFrom;
  private String visionCaseNumber;
  private Long arrestReason;
  private String firNumber;
  private String caseNumber;

  public CaseCreatedEvent(Builder builder) {

    super(builder);
    this.caseKey = builder.caseKey;
    this.arrestReportKey = builder.arrestReportKey;
    this.status = builder.statusId;
    this.latestSection = builder.latestSection;
    this.transferredFrom = builder.transferredFrom;
    this.visionCaseNumber = builder.visionCaseNumber;
    this.arrestReason = builder.arrestReason;
    this.firNumber = builder.firNumber;
    this.caseNumber = builder.caseNumber;

  }

  public ArrestReportKey getArrestReportKey() {
    return arrestReportKey;
  }

  public CaseKey getCaseKey() {
    return caseKey;
  }

  public Long getStatus() {
    return status;
  }

  public String getCaseParties() {
    return caseParties;
  }

  public Long getLatestSection() {
    return latestSection;
  }

  public Long getTransferredFrom() {
    return transferredFrom;
  }

  public String getVisionCaseNumber() {
    return visionCaseNumber;
  }

  public String getFirNumber() {
    return firNumber;
  }

  public Long getArrestReason() {
    return arrestReason;
  }

  public String getCaseNumber() {
    return caseNumber;
  }

  public CaseCreatedEvent withCasePartiesJson(String casePartiesJson) {
    this.caseParties = casePartiesJson;
    return this;
  }

  public static class Builder extends DomainEventBuilder {

    private ArrestReportKey arrestReportKey;
    private Long statusId;
    private CaseKey caseKey;
    private Long latestSection;
    private Long transferredFrom;
    private String visionCaseNumber;
    private Long arrestReason;
    private String firNumber;
    private String caseNumber;

    protected Builder(EventContext eventContext, CaseKey caseKey, ArrestReportKey arrestReportKey) {

      super(eventContext);
      this.caseKey = caseKey;
      this.arrestReportKey = arrestReportKey;
    }

    public Builder withCaseStatus(Long statusId) {
      this.statusId = statusId;
      return this;
    }

    public Builder withLatestSection(Long latestSection) {
      this.latestSection = latestSection;
      return this;
    }

    public Builder withTransferredFrom(Long transferredFromDeptId) {
      this.transferredFrom = transferredFromDeptId;
      return this;
    }

    public Builder withVisionCaseNumber(String visionCaseNumber) {
      this.visionCaseNumber = visionCaseNumber;
      return this;
    }

    public Builder withArrestReason(Long arrestReasonId) {
      this.arrestReason = arrestReasonId;
      return this;
    }

    public Builder withFirNumber(String firNo) {
      this.firNumber = firNo;
      return this;
    }

    public Builder withCaseNumber(String caseNumber) {
      this.caseNumber = caseNumber;
      return this;
    }

    public CaseCreatedEvent build() {
      return new CaseCreatedEvent(this);
    }
  }
}
