package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.crm.application.*;
import ae.emaratech.uaevision.crm.application.dto.CaseNoteDto;
import ae.emaratech.uaevision.fis.common.key.CaseTransferKey;

import java.util.List;

/**
 * Case Application serivce to handle all request comming to Case domain
 * Created by Nitesh.Gupta on 6/15/2016.
 */

public interface CaseApplicationService {
    /**
     * Method is for creating Case
     * @param command object with information regarding the arrest.
     * @return result object with case key data
     */

    CreateCaseResult createCase(CreateCaseCommand command);

    /**
     * Method will Modify Note for associated case
     * @param editNoteCommand wrapper which hold note details
     * @return List of CaseNoteDto
     */
    List<CaseNoteDto> modifyNote(EditNoteCommand editNoteCommand);
    /**
     * Method will Remote Note for associated case
     * @param deleteNoteCommand wrapper which hold note details
     * @return List of CaseNoteDto
     */
    List<CaseNoteDto> removeNote(DeleteNoteCommand deleteNoteCommand);
    /**
     * Method will Add Note for associated case
     * @param addNoteCommand wrapper which hold note details
     * @return List of CaseNoteDto
     */
    List<CaseNoteDto> addNote(AddNoteCommand addNoteCommand);
    /**
     * Method will Add Track
     * @param addTrackCommand wrapper which hold track details
     */
    void addTrack(AddTrackCommand addTrackCommand);

    /**
     * Method is to update Case
     * @param command wrapper providing information for updating case
     */
    void update(UpdateCaseCommand command);

    /**
     * Method will mark Case as closed
     * @param command wrapper providing information for Closing Case
     */
    void close(CloseCaseCommand command);

    /**
     * Method will mark Case as re-open
     * @param command wrapper providing information for re-opening case
     */
    void reOpen(ReOpenCaseCommand command);

    /**
     * Method will mark case as Approve
     * @param command wrapper providing information for approving
     */
    void approve(ApproveCaseCommand command);

    /**
     * Method will mark Case as Reject
     * @param command wrapper providing information for rejecting case
     */

    void reject(RejectCaseCommand command);

    /**
     * Method will mark Case as Pending approval and will go to supervisor for approval/rejection
     * @param command wrapper providing information for approving review
     */
    void review(ReviewCaseCommand command);

    /**
     * Method will mark Case as Manual Transfer and will be sent to other department manually
     * @param command wrapper providing information for Manual Transfer
     */
    void manualTransfer(ManualTransferCaseCommand command);

    /**
     * Method will mark Case as Transfer and will be sent for other department
     * @param command wrapper providing information for Transfer
     */
    void transferToCRM(TransferToCaseCommand command);

    /**
     * Method will assign Case to some user.
     * @param assignCaseCommand wrapper providing information for Assignment
     */
    void caseAssignment(AssignCaseCommand assignCaseCommand);

    /**
     * Method will Receive Manually
     * @param command wrapper providing information for Manual Receive
     */
    void manualReceive(ManualReceiveCaseCommand command);

    /**
     * Method will Create Case for Transferred Case
     * @param command wrapper which will hold information for case creation
     * @return
     */
    CreateCaseResult createTransferredCase(TransferCaseCommand command);

    /**
     * Method will receive Case which has been transferred to Case
     * @param receivedBy User which will be receiving
     * @param caseTransferKey Case Transfer Key
     */
    void receiveTransferredCase(String receivedBy, CaseTransferKey caseTransferKey);

    /**
     * Method will mark Case as Transfer within sections
     * @param command wrapper providing information for Transfer
     * @since 1.01.017
     */
    void forwardToInternalSection(TransferToCaseCommand command);
    /**
     * Method will mark Case as Transfer within sections
     * @param command wrapper providing information for Transfer
     * @since 1.01.017
     */
    void returnToOriginalSection(ReturnCaseCommand command);
}
