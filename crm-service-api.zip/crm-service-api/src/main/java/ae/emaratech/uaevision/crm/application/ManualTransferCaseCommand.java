package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public class ManualTransferCaseCommand {

    private CaseKey caseKey;
    private String transferComments;

    private Long manualTransferTo;

    public ManualTransferCaseCommand(CaseKey caseKey, String transferComments,
                                     Long manualTransferTo) {
        this.caseKey = caseKey;
        this.transferComments = transferComments;
        this.manualTransferTo = manualTransferTo;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public String getTransferComments() {
        return transferComments;
    }

    public Long getManualTransferTo() {
        return manualTransferTo;
    }
}
