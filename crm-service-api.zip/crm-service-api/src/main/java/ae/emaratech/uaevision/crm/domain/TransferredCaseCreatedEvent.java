package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;

import java.util.List;


/**
 * Case Cloned Event
 * Created by Nitesh.Gupta on 3/20/2017.
 */
public class TransferredCaseCreatedEvent extends DomainEvent{

    private CaseKey oldCaseKey;
    private CaseKey caseKey;
    private Long departmentId;
    private Long sectionId;
    private String caseNumber;
    private List<PartyKey> partyKeyList;
    private TransferredCaseCreatedEvent(Builder builder) {
        super(builder);
        this.caseKey = builder.caseKey;
        this.departmentId = builder.departmentId;
        this.sectionId = builder.sectionId;
        this.caseNumber = builder.caseNumber;
        this.oldCaseKey = builder.oldCaseKey;
        this.partyKeyList = builder.partyKeyList;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public Long getSectionId() {
        return sectionId;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public CaseKey getOldCaseKey() {
        return oldCaseKey;
    }

    public List<PartyKey> getPartyKeyList() {
        return partyKeyList;
    }

    public static class Builder extends DomainEventBuilder {

        private CaseKey caseKey;
        private Long departmentId;
        private Long sectionId;
        private CaseKey oldCaseKey;
        private String caseNumber;
        private List<PartyKey> partyKeyList;
        public Builder(EventContext eventContext, CaseKey caseKey, String caseNumber) {
            super(eventContext);
            this.caseKey = caseKey;
            this.caseNumber = caseNumber;
        }
        public Builder withDepartment(Long department) {
            this.departmentId = department;
            return this;
        }
        public Builder withSection(Long sectionId) {
            this.sectionId = sectionId;
            return this;
        }
        public Builder withOldCaseKey(CaseKey oldCaseKey) {
            this.oldCaseKey = oldCaseKey;
            return this;
        }
        public  Builder withPartyKeyList (List<PartyKey> partyKeyList){
            this.partyKeyList = partyKeyList;
            return this;
        }
        public TransferredCaseCreatedEvent build() {
            return new TransferredCaseCreatedEvent(this);
        }
    }
}
