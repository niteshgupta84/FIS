package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Created by Nitesh.Gupta on 6/27/2016.
 */
public class ReviewCaseCommand {

    private CaseKey caseKey;
    private String reviewComments;

    public ReviewCaseCommand(CaseKey caseKey, String reviewComments) {
        this.caseKey = caseKey;
        this.reviewComments = reviewComments;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public String getReviewComments() {
        return reviewComments;
    }
}
