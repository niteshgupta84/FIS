package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Event triggered when case has been assigned to an officer for processing.
 *
 * @author Nitesh.Gupta
 */
public class CaseAssignedEvent extends DomainEvent {

    private CaseKey caseKey;
    private String assignedUser;

    private CaseAssignedEvent(Builder builder) {
        super(builder);
        this.caseKey = builder.caseKey;
        this.assignedUser = builder.assignedUser;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public String getAssignedUser() {
        return assignedUser;
    }

    public static class Builder extends DomainEventBuilder {

        private CaseKey caseKey;

        private String assignedUser;

        public Builder(EventContext eventContext, CaseKey caseKey) {
            super(eventContext);
            this.caseKey = caseKey;
        }

        public Builder withAssignedUser(String assignedUser) {
            this.assignedUser = assignedUser;
            return this;
        }

        public CaseAssignedEvent build() {
            return new CaseAssignedEvent(this);
        }
    }
}
