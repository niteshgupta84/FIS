package ae.emaratech.uaevision.crm.application.dto;

import ae.emaratech.uaevision.document.application.AttachedDocumentDto;
import ae.emaratech.uaevision.fis.common.dto.AbstractDtoBase;
import ae.emaratech.uaevision.fis.common.lock.Lockable;
import ae.emaratech.uaevision.fis.common.lock.LockableEntityName;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/18/2016.
 */
@ApiModel(value = "Case Dto ")
public class CaseDto extends AbstractDtoBase implements Serializable, Lockable {
    @ApiModelProperty(value = "Unique Case Id", required = true)
    private Long id;
    @ApiModelProperty(value = " Case Tracker Id ", required = false )
    private Long trackerId;
    @ApiModelProperty(value = " Logged In User Department  ", required = true )
    @Nullable
    private Entry department;
    @ApiModelProperty(value = " Logged In User Section  ", required = true )
    @Nullable
    private Entry section;
    @Nullable
    private Entry nonCRMSection;
    @ApiModelProperty(value = " Logged In User Section Unit  ", required = false )
    @Nullable
    private Entry sectionUnit;
    @ApiModelProperty(value = " Case Transferred From Department  ", required = false )
    @Nullable
    private Entry transferredFrom;
    @ApiModelProperty(value = " Arrest Reason for case creation", required = true )
    @Nullable
    private Entry arrestReason;
    @ApiModelProperty(value = " Case Status", required = true )
    private Entry status;
    @ApiModelProperty(value = "Last Action taken on Case", required = false )
    @Nullable
    private Entry lastAction;
    @ApiModelProperty(value = "Generated Case Number", required = true )
    private String caseNumber;
    @ApiModelProperty(value = "Case Created By ", required = true )
    private String createdBy;
    @ApiModelProperty(value = "Case Created on Date ", required = true )
    private Date createdDate;
    @ApiModelProperty(value = " Case assigned to user", required = false )
    private String assignedUser;
    @ApiModelProperty(value = " Case created against Arrest Id ", required = false )
    private Long arrestId;
    @ApiModelProperty(value = " Urgency of Case", required = false )
    private boolean urgent;
    private String urgentString;
    @ApiModelProperty(value = " Latest Case Section", required = true )
    @Nullable
    private Entry latestSection;
    @ApiModelProperty(value = " Fir No if any", required = false )
    private String firNo;
    @ApiModelProperty(value = " Case Manually Transferred to department", required = false )
    @Nullable
    private Entry manualTransferTo;
    @ApiModelProperty(value = "Version of Case for handling concurrency", required = true )
    private Long version;
    @ApiModelProperty(value = "Vision case number which will be generated", required = true )
    private String visionCaseNumber;
    @ApiModelProperty(value = "List of Associated Cases", required = false )
    private List<CaseAssociationDto> caseAssociationDtoList = null;
    @ApiModelProperty(value = "List of Associated Notes", required = false )
    private List<CaseNoteDto> caseNoteDtoList = null;
    @ApiModelProperty(value = "List of Actions taken on Case", required = false )
    private List<CaseTrackDto> caseTrackDtoList = new ArrayList<>();
    @ApiModelProperty(value = "Parties involved in case", required = true )
    private List<CasePartyDto> casePartyDtoList = new LinkedList<>();
    @ApiModelProperty(value = "Linked Attachments to case", required = false )
    private List<AttachedDocumentDto> caseAttachmentDtoList = null;
    @ApiModelProperty(value = " Linked document inspections details", required = false )
    private List<DocumentInspectionDto> documentInspectionDtoList = null;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTrackerId() {
        return trackerId;
    }

    public void setTrackerId(Long trackerId) {
        this.trackerId = trackerId;
    }

    @Nullable
    public Entry getDepartment() {
        return department;
    }

    public void setDepartment(@Nullable Entry department) {
        this.department = department;
    }

    @Nullable
    public Entry getSection() {
        return section;
    }

    public void setSection(@Nullable Entry section) {
        this.section = section;
    }

    @Nullable
    public Entry getNonCRMSection() {
        return nonCRMSection;
    }

    public void setNonCRMSection(@Nullable Entry nonCRMSection) {
        this.nonCRMSection = nonCRMSection;
    }

    @Nullable
    public Entry getSectionUnit() {
        return sectionUnit;
    }

    public void setSectionUnit(@Nullable Entry sectionUnit) {
        this.sectionUnit = sectionUnit;
    }

    @Nullable
    public Entry getTransferredFrom() {
        return transferredFrom;
    }

    public void setTransferredFrom(@Nullable Entry transferredFrom) {
        this.transferredFrom = transferredFrom;
    }

    public Entry getStatus() {
        return status;
    }

    public void setStatus(Entry status) {
        this.status = status;
    }

    @Nullable
    public Entry getLastAction() {
        return lastAction;
    }

    public void setLastAction(@Nullable Entry lastAction) {
        this.lastAction = lastAction;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getAssignedUser() {
        return assignedUser;
    }

    public void setAssignedUser(String assignedUser) {
        this.assignedUser = assignedUser;
    }

    public List<CaseAssociationDto> getCaseAssociationDtoList() {
        return caseAssociationDtoList;
    }

    public void setCaseAssociationDtoList(List<CaseAssociationDto> caseAssociationDtoList) {
        this.caseAssociationDtoList = caseAssociationDtoList;
    }

    public List<CaseNoteDto> getCaseNoteDtoList() {
        return caseNoteDtoList;
    }

    public void setCaseNoteDtoList(List<CaseNoteDto> caseNoteDtoList) {
        this.caseNoteDtoList = caseNoteDtoList;
    }

    public List<CaseTrackDto> getCaseTrackDtoList() {
        return caseTrackDtoList;
    }

    public void setCaseTrackDtoList(List<CaseTrackDto> caseTrackDtoList) {
        this.caseTrackDtoList = caseTrackDtoList;
    }

    public List<CasePartyDto> getCasePartyDtoList() {
        return casePartyDtoList;
    }

    public void setCasePartyDtoList(List<CasePartyDto> casePartyDtoList) {
        this.casePartyDtoList = casePartyDtoList;
    }

    public List<AttachedDocumentDto> getCaseAttachmentDtoList() {
        return caseAttachmentDtoList;
    }

    public void setCaseAttachmentDtoList(List<AttachedDocumentDto> caseAttachmentDtoList) {
        this.caseAttachmentDtoList = caseAttachmentDtoList;
    }

    public Long getArrestId() {
        return arrestId;
    }

    public void setArrestId(Long arrestId) {
        this.arrestId = arrestId;
    }

    public boolean isUrgent() {
        return urgent;
    }

    public void setUrgent(boolean urgent) {
        this.urgent = urgent;
    }

    public String getUrgentString() {
        return urgentString;
    }

    public void setUrgentString(String urgentString) {
        this.urgentString = urgentString;
    }

    @Override
    public String getLockId() {
        return String.valueOf(id);
    }

    @Override
    public LockableEntityName getLockableEntityName() {
        return LockableEntityName.CASE;
    }

    @Nullable
    public Entry getArrestReason() {
        return arrestReason;
    }

    public void setArrestReason(@Nullable Entry arrestReason) {
        this.arrestReason = arrestReason;
    }

    @Nullable
    public Entry getLatestSection() {
        return latestSection;
    }

    public void setLatestSection(@Nullable Entry latestSection) {
        this.latestSection = latestSection;
    }

    public List<DocumentInspectionDto> getDocumentInspectionDtoList() {
        return documentInspectionDtoList;
    }

    public void setDocumentInspectionDtoList(List<DocumentInspectionDto> documentInspectionDtoList) {
        this.documentInspectionDtoList = documentInspectionDtoList;
    }

    public String getFirNo() {
        return firNo;
    }

    public void setFirNo(String firNo) {
        this.firNo = firNo;
    }

    @Nullable
    public Entry getManualTransferTo() {
        return manualTransferTo;
    }

    public void setManualTransferTo(@Nullable Entry manualTransferTo) {
        this.manualTransferTo = manualTransferTo;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public String getVisionCaseNumber() {
        return visionCaseNumber;
    }

    public void setVisionCaseNumber(String visionCaseNumber) {
        this.visionCaseNumber = visionCaseNumber;
    }

    @Override
    public boolean equals(Object o) {


        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        CaseDto caseDto = (CaseDto) o;

        if (urgent != caseDto.urgent) return false;
        if (arrestId != null ? !arrestId.equals(caseDto.arrestId) : caseDto.arrestId != null) return false;
        if (arrestReason != null ? !arrestReason.equals(caseDto.arrestReason) : caseDto.arrestReason != null)
            return false;
        if (assignedUser != null ? !assignedUser.equals(caseDto.assignedUser) : caseDto.assignedUser != null)
            return false;
        if (caseAssociationDtoList != null ? !caseAssociationDtoList.equals(caseDto.caseAssociationDtoList) : caseDto.caseAssociationDtoList != null)
            return false;
        if (caseAttachmentDtoList != null ? !caseAttachmentDtoList.equals(caseDto.caseAttachmentDtoList) : caseDto.caseAttachmentDtoList != null)
            return false;
        if (caseNoteDtoList != null ? !caseNoteDtoList.equals(caseDto.caseNoteDtoList) : caseDto.caseNoteDtoList != null)
            return false;
        if (caseNumber != null ? !caseNumber.equals(caseDto.caseNumber) : caseDto.caseNumber != null) return false;
        if (casePartyDtoList != null ? !casePartyDtoList.equals(caseDto.casePartyDtoList) : caseDto.casePartyDtoList != null)
            return false;
        if (caseTrackDtoList != null ? !caseTrackDtoList.equals(caseDto.caseTrackDtoList) : caseDto.caseTrackDtoList != null)
            return false;
        if (createdBy != null ? !createdBy.equals(caseDto.createdBy) : caseDto.createdBy != null) return false;
        if (createdDate != null ? !createdDate.equals(caseDto.createdDate) : caseDto.createdDate != null) return false;
        if (department != null ? !department.equals(caseDto.department) : caseDto.department != null) return false;
        if (documentInspectionDtoList != null ? !documentInspectionDtoList.equals(caseDto.documentInspectionDtoList) : caseDto.documentInspectionDtoList != null)
            return false;
        if (firNo != null ? !firNo.equals(caseDto.firNo) : caseDto.firNo != null) return false;
        if (id != null ? !id.equals(caseDto.id) : caseDto.id != null) return false;
        if (lastAction != null ? !lastAction.equals(caseDto.lastAction) : caseDto.lastAction != null) return false;
        if (latestSection != null ? !latestSection.equals(caseDto.latestSection) : caseDto.latestSection != null)
            return false;
        if (manualTransferTo != null ? !manualTransferTo.equals(caseDto.manualTransferTo) : caseDto.manualTransferTo != null)
            return false;
        if (nonCRMSection != null ? !nonCRMSection.equals(caseDto.nonCRMSection) : caseDto.nonCRMSection != null)
            return false;
        if (section != null ? !section.equals(caseDto.section) : caseDto.section != null) return false;
        if (sectionUnit != null ? !sectionUnit.equals(caseDto.sectionUnit) : caseDto.sectionUnit != null) return false;
        if (status != null ? !status.equals(caseDto.status) : caseDto.status != null) return false;
        if (trackerId != null ? !trackerId.equals(caseDto.trackerId) : caseDto.trackerId != null) return false;
        if (transferredFrom != null ? !transferredFrom.equals(caseDto.transferredFrom) : caseDto.transferredFrom != null)
            return false;
        if (urgentString != null ? !urgentString.equals(caseDto.urgentString) : caseDto.urgentString != null)
            return false;
        if (version != null ? !version.equals(caseDto.version) : caseDto.version != null) return false;
        if (visionCaseNumber != null ? !visionCaseNumber.equals(caseDto.visionCaseNumber) : caseDto.visionCaseNumber != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (id != null ? id.hashCode() : 0);
        result = 31 * result + (trackerId != null ? trackerId.hashCode() : 0);
        result = 31 * result + (department != null ? department.hashCode() : 0);
        result = 31 * result + (section != null ? section.hashCode() : 0);
        result = 31 * result + (nonCRMSection != null ? nonCRMSection.hashCode() : 0);
        result = 31 * result + (sectionUnit != null ? sectionUnit.hashCode() : 0);
        result = 31 * result + (transferredFrom != null ? transferredFrom.hashCode() : 0);
        result = 31 * result + (arrestReason != null ? arrestReason.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (lastAction != null ? lastAction.hashCode() : 0);
        result = 31 * result + (caseNumber != null ? caseNumber.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
        result = 31 * result + (assignedUser != null ? assignedUser.hashCode() : 0);
        result = 31 * result + (arrestId != null ? arrestId.hashCode() : 0);
        result = 31 * result + (urgent ? 1 : 0);
        result = 31 * result + (urgentString != null ? urgentString.hashCode() : 0);
        result = 31 * result + (latestSection != null ? latestSection.hashCode() : 0);
        result = 31 * result + (firNo != null ? firNo.hashCode() : 0);
        result = 31 * result + (manualTransferTo != null ? manualTransferTo.hashCode() : 0);
        result = 31 * result + (version != null ? version.hashCode() : 0);
        result = 31 * result + (visionCaseNumber != null ? visionCaseNumber.hashCode() : 0);
        result = 31 * result + (caseAssociationDtoList != null ? caseAssociationDtoList.hashCode() : 0);
        result = 31 * result + (caseNoteDtoList != null ? caseNoteDtoList.hashCode() : 0);
        result = 31 * result + (caseTrackDtoList != null ? caseTrackDtoList.hashCode() : 0);
        result = 31 * result + (casePartyDtoList != null ? casePartyDtoList.hashCode() : 0);
        result = 31 * result + (caseAttachmentDtoList != null ? caseAttachmentDtoList.hashCode() : 0);
        result = 31 * result + (documentInspectionDtoList != null ? documentInspectionDtoList.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "CaseDto{" +
                "id=" + id +
                ", trackerId=" + trackerId +
                ", department=" + department +
                ", section=" + section +
                ", nonCRMSection=" + nonCRMSection +
                ", sectionUnit=" + sectionUnit +
                ", transferredFrom=" + transferredFrom +
                ", arrestReason=" + arrestReason +
                ", status=" + status +
                ", lastAction=" + lastAction +
                ", caseNumber='" + caseNumber + '\'' +
                ", createdBy='" + createdBy + '\'' +
                ", createdDate=" + createdDate +
                ", assignedUser='" + assignedUser + '\'' +
                ", arrestId=" + arrestId +
                ", urgent=" + urgent +
                ", urgentString='" + urgentString + '\'' +
                ", latestSection=" + latestSection +
                ", firNo='" + firNo + '\'' +
                ", manualTransferTo=" + manualTransferTo +
                ", version=" + version +
                ", visionCaseNumber='" + visionCaseNumber + '\'' +
                ", caseAssociationDtoList=" + caseAssociationDtoList +
                ", caseNoteDtoList=" + caseNoteDtoList +
                ", caseTrackDtoList=" + caseTrackDtoList +
                ", casePartyDtoList=" + casePartyDtoList +
                ", caseAttachmentDtoList=" + caseAttachmentDtoList +
                ", documentInspectionDtoList=" + documentInspectionDtoList +
                '}';
    }
}
