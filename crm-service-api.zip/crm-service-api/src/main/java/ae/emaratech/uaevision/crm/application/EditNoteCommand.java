package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.crm.application.dto.CaseNoteDto;
import ae.emaratech.uaevision.fis.common.key.NoteKey;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
public class EditNoteCommand {

    private NoteKey noteKey;

    private String noteText;

    private List<CaseNoteDto> caseNoteDtoList = new ArrayList<>();

    public EditNoteCommand(NoteKey noteKey, String noteText) {
        this.noteKey = noteKey;
        this.noteText = noteText;
    }

    public EditNoteCommand withNoteList(List<CaseNoteDto> caseNoteDtoList) {
        this.caseNoteDtoList = caseNoteDtoList;
        return this;
    }

    public NoteKey getNoteKey() {
        return noteKey;
    }

    public String getNoteText() {
        return noteText;
    }

    public List<CaseNoteDto> getCaseNoteDtoList() {
        return caseNoteDtoList;
    }
}
