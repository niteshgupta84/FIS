package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.dto.Identifiable;

/**
 * Created by Nitesh.Gupta on 6/5/2016.
 */
public enum CaseStatus implements Identifiable {
    NEW(1L),
    OPENED(2L),
    CLOSED(3L, true),
    PENDING_DECISION(4L, true),
    TRANSFERRED(5L, true),
    ENDED(6L, true),
    MANUALTRANSFERRED(7L, true),
    REQUESTINTERROGATION(8L, true),
    RECEIVEDINTERROGATION(9L, true),
    APPROVED(10L, true),
    COMPLETED(11L, true),
    RECEIVED_DETENTION(12L, true),
    TRANSFERREDTODEPARTMENT(13L, true),
    MANUALRECEIVED(14L, true),
    NOTRECEIVED(15L, true),
    RECEIVED(16L, true),
    FORWARD(17L, true);

    private final Long id;
    private Boolean makeReadOnly;


    private CaseStatus(Long id) {
        this(id, Boolean.FALSE);
    }

    private CaseStatus(Long id, Boolean makeReadOnly) {
        this.id = id;
        this.makeReadOnly = makeReadOnly;
    }


    public Long id() {

        return this.id;
    }

    public boolean makeReadOnly() {

        return makeReadOnly;
    }
}
