package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;

/**
 * TransferToCaseCommand command for capturing information related to Transfer
 * Created by Nitesh.Gupta on 6/29/2016.
 */
public class TransferToCaseCommand {

    private CaseKey caseKey;

    private Department department;

    private Section section;

    private String transferComments;

    public TransferToCaseCommand(CaseKey caseKey, Department department, Section section) {
        this.caseKey = caseKey;
        this.department = department;
        this.section = section;
    }

    public TransferToCaseCommand withTransferComments(String transferComments) {
        this.transferComments = transferComments;
        return this;
    }

    public Department getDepartment() {
        return department;
    }

    public Section getSection() {
        return section;
    }

    public String getTransferComments() {
        return transferComments;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }
}
