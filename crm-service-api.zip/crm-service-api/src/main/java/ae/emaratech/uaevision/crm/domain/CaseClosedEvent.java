package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Event thrown by Case module  when a new case has been marked as closed.
 *
 * @author Nitesh.Gupta
 */
public class CaseClosedEvent extends DomainEvent {

    private CaseKey caseKey;
    private ArrestReportKey arrestReportKey;
    private Long status;
    private String closeComments;

    public CaseClosedEvent(Builder builder) {
        super(builder);
        this.caseKey = builder.caseKey;
        this.arrestReportKey = builder.arrestReportKey;
        this.closeComments = builder.closeComments;
        this.status = builder.statusId;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private String closeComments;
        private Long statusId;
        private CaseKey caseKey;

        public Builder(EventContext eventContext,
                       CaseKey caseKey, ArrestReportKey arrestReportKey) {
            super(eventContext);
            this.caseKey = caseKey;
            this.arrestReportKey = arrestReportKey;
        }

        public Builder withCaseStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withCloseComments(String closeComments) {
            this.closeComments = closeComments;
            return this;
        }

        public ArrestReportKey getArrestReportKey() {
            return arrestReportKey;
        }

        public String getCloseComments() {
            return closeComments;
        }

        public Long getStatusId() {
            return statusId;
        }

        public CaseKey getCaseKey() {
            return caseKey;
        }

        public CaseClosedEvent build() {
            return new CaseClosedEvent(this);
        }
    }
}
