package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.common.key.TrackerKey;

import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public class TransferCaseCommand {


    private CaseKey oldCaseKey;
    private ArrestReportKey arrestReportKey;
    private TrackerKey trackerKey;
    private List<CasePartyDto> transferredCasePartyDtoList;

    public TransferCaseCommand (CaseKey oldCaseKey, ArrestReportKey arrestReportKey, TrackerKey trackerKey,
                                List<CasePartyDto> transferredCasePartyDtoList){
        this.oldCaseKey = oldCaseKey;
        this.arrestReportKey = arrestReportKey;
        this.trackerKey = trackerKey;
        this.transferredCasePartyDtoList = transferredCasePartyDtoList;
    }

    public CaseKey getOldCaseKey() {
        return oldCaseKey;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public TrackerKey getTrackerKey() {
        return trackerKey;
    }

    public List<CasePartyDto> getTransferredCasePartyDtoList() {
        return transferredCasePartyDtoList;
    }
}
