package ae.emaratech.uaevision.crm.application.dto;

import ae.emaratech.uaevision.lookup.service.model.Entry;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.annotation.Nullable;
import java.util.Date;

/**
 * Created by Nitesh.Gupta on 6/9/2016.
 */
@ApiModel(value="Case Document Inspection ")
public class DocumentInspectionDto {
    @ApiModelProperty(value = "The identifier for Case Inspection event", required = true, dataType = "long")
    private long id;
    @ApiModelProperty(value = "View Id for view purpose", required = true, dataType = "long")
    private long viewId;
    @ApiModelProperty(value = "Notes ", required = true, dataType = "string")
    private String textNote;
    @ApiModelProperty(value = "Case Document Inspection Created By ", required = true, dataType = "string")
    private String createdBy;
    @ApiModelProperty(value = "Case Document Inspection Created on Date ", required = true, dataType = "date" )
    private Date createdDate;
    @ApiModelProperty(value = "Created Date as String", required = true, dataType = "string" )
    private String createdDateAsString;
    @ApiModelProperty(value = "Notes in Details ", required = true, dataType = "string" )
    private String displayTextNote;
    @ApiModelProperty(value = "Sequence Number", required = true, dataType = "long" )
    private Long sequenceNo;
    @ApiModelProperty(value = "Version", required = true, dataType = "long" )
    private Long version;
    @ApiModelProperty(value = "Document Type ", required = true, dataType = "object" )
    @Nullable
    private Entry documentType;
    @ApiModelProperty(value = "Document Inspection Result ", required = true, dataType = "object" )
    @Nullable
    private Entry documentInspectionResultType;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getViewId() {
        return viewId;
    }

    public void setViewId(long viewId) {
        this.viewId = viewId;
    }

    public String getTextNote() {
        return textNote;
    }

    public void setTextNote(String textNote) {
        this.textNote = textNote;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedDateAsString() {
        return createdDateAsString;
    }

    public void setCreatedDateAsString(String createdDateAsString) {
        this.createdDateAsString = createdDateAsString;
    }

    public void setDisplayTextNote(String displayTextNote) {
        this.displayTextNote = displayTextNote;
    }

    public Long getSequenceNo() {
        return sequenceNo;
    }

    public void setSequenceNo(Long sequenceNo) {
        this.sequenceNo = sequenceNo;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    @Nullable
    public Entry getDocumentType() {
        return documentType;
    }

    public void setDocumentType(@Nullable Entry documentType) {
        this.documentType = documentType;
    }

    @Nullable
    public Entry getDocumentInspectionResultType() {
        return documentInspectionResultType;
    }

    public void setDocumentInspectionResultType(
            @Nullable Entry documentInspectionResultType) {
        this.documentInspectionResultType = documentInspectionResultType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DocumentInspectionDto that = (DocumentInspectionDto) o;

        if (id != that.id) return false;
        if (viewId != that.viewId) return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDate != null ? !createdDate.equals(that.createdDate) : that.createdDate != null) return false;
        if (createdDateAsString != null ? !createdDateAsString.equals(that.createdDateAsString) : that.createdDateAsString != null)
            return false;
        if (displayTextNote != null ? !displayTextNote.equals(that.displayTextNote) : that.displayTextNote != null)
            return false;
        if (documentInspectionResultType != null ? !documentInspectionResultType.equals(that.documentInspectionResultType) : that.documentInspectionResultType != null)
            return false;
        if (documentType != null ? !documentType.equals(that.documentType) : that.documentType != null) return false;
        if (sequenceNo != null ? !sequenceNo.equals(that.sequenceNo) : that.sequenceNo != null) return false;
        if (textNote != null ? !textNote.equals(that.textNote) : that.textNote != null) return false;
        if (version != null ? !version.equals(that.version) : that.version != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (id ^ (id >>> 32));
        result = 31 * result + (int) (viewId ^ (viewId >>> 32));
        result = 31 * result + (textNote != null ? textNote.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
        result = 31 * result + (createdDateAsString != null ? createdDateAsString.hashCode() : 0);
        result = 31 * result + (displayTextNote != null ? displayTextNote.hashCode() : 0);
        result = 31 * result + (sequenceNo != null ? sequenceNo.hashCode() : 0);
        result = 31 * result + (version != null ? version.hashCode() : 0);
        result = 31 * result + (documentType != null ? documentType.hashCode() : 0);
        result = 31 * result + (documentInspectionResultType != null ? documentInspectionResultType.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "DocumentInspectionDto{" +
                "id=" + id +
                ", viewId=" + viewId +
                ", textNote='" + textNote + '\'' +
                ", createdBy='" + createdBy + '\'' +
                ", createdDate=" + createdDate +
                ", createdDateAsString='" + createdDateAsString + '\'' +
                ", displayTextNote='" + displayTextNote + '\'' +
                ", sequenceNo=" + sequenceNo +
                ", version=" + version +
                ", documentType=" + documentType +
                ", documentInspectionResultType=" + documentInspectionResultType +
                '}';
    }
}
