package ae.emaratech.uaevision.fis.application.web.view;

import ae.emaratech.uaevision.arrest.application.dto.ArrestReportDto;
import ae.emaratech.uaevision.crm.application.dto.CaseDto;
import ae.emaratech.uaevision.fis.order.service.dto.OrderDto;
import ae.emaratech.uaevision.fis.order.service.dto.ReleaseOrderDto;
import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*import ae.emaratech.uaevision.interrogation.application.dto.InterrogationDto;*/

import java.io.Serializable;
import java.util.Date;

/**
 * Created by Nitesh.Gupta on 3/28/2016.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderViewModel implements Serializable{

    private OrderDto orderDto;
    /*  private InterrogationDto interrogationDto;*/
    private String interrogationDecisionName;
    private PartyDto partyDto;
    private Long sequenceNo;
    private CaseDto caseDto;
    private ArrestReportDto arrestReportDto;
    private String comments;
    private Date createdDate;
    private String createdBy;
    private String relatedDetentionNumber;
    private Long relatedDetentionOrderId;
    private ReleaseOrderDto releaseOrderDto;

    public OrderDto getOrderDto() {
        return orderDto;
    }

    public void setOrderDto(OrderDto orderDto) {
        this.orderDto = orderDto;
    }

   /* public InterrogationDto getInterrogationDto() {
        return interrogationDto;
    }

    public void setInterrogationDto(InterrogationDto interrogationDto) {
        this.interrogationDto = interrogationDto;
    }*/


    public String getInterrogationDecisionName() {
        return interrogationDecisionName;
    }

    public void setInterrogationDecisionName(String interrogationDecisionName) {
        this.interrogationDecisionName = interrogationDecisionName;
    }


    public PartyDto getPartyDto() {
        return partyDto;
    }

    public void setPartyDto(PartyDto partyDto) {
        this.partyDto = partyDto;
    }

    public Long getSequenceNo() {
        return sequenceNo;
    }

    public void setSequenceNo(Long sequenceNo) {
        this.sequenceNo = sequenceNo;
    }

    public CaseDto getCaseDto() {
        return caseDto;
    }

    public void setCaseDto(CaseDto caseDto) {
        this.caseDto = caseDto;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getRelatedDetentionNumber() {
        return relatedDetentionNumber;
    }

    public void setRelatedDetentionNumber(String relatedDetentionNumber) {
        this.relatedDetentionNumber = relatedDetentionNumber;
    }

    public Long getRelatedDetentionOrderId() {
        return relatedDetentionOrderId;
    }

    public void setRelatedDetentionOrderId(Long relatedDetentionOrderId) {
        this.relatedDetentionOrderId = relatedDetentionOrderId;
    }

    public ReleaseOrderDto getReleaseOrderDto() {
        return releaseOrderDto;
    }

    public void setReleaseOrderDto(ReleaseOrderDto releaseOrderDto) {
        this.releaseOrderDto = releaseOrderDto;
    }

    public ArrestReportDto getArrestReportDto() {
        return arrestReportDto;
    }

    public void setArrestReportDto(ArrestReportDto arrestReportDto) {
        this.arrestReportDto = arrestReportDto;
    }
}
