package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.crm.application.dto.CaseNoteDto;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Nitesh.Gupta on 6/8/2016.
 */
public class AddNoteCommand {

    private String noteText;

    private List<CaseNoteDto> caseNoteDtoList = new ArrayList<>();

    public AddNoteCommand(String noteText) {
        this.noteText = noteText;
    }

    public AddNoteCommand withNoteList(List<CaseNoteDto> caseNoteDtoList) {
        this.caseNoteDtoList = caseNoteDtoList;
        return this;
    }

    public List<CaseNoteDto> getCaseNoteDtoList() {
        return caseNoteDtoList;
    }

    public String getNoteText() {
        return noteText;
    }
}
