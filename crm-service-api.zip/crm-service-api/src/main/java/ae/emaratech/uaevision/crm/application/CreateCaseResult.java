package ae.emaratech.uaevision.crm.application;


import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.common.key.TrackerKey;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Result class which provides the acknowledgement information after the creation of arrest report.
 *
 * @author Haroon.Subair
 */
@ApiModel(value = "Returning Created Case ID")
public class CreateCaseResult {
    @ApiModelProperty(value = "CaseKey", required = true)
    private CaseKey caseKey;
    @ApiModelProperty(value = "Case Number ", required = true)
    private String caseNumber;

    private TrackerKey trackerKey;

    public CreateCaseResult(CaseKey caseKey, String caseNumber) {
        this.caseKey = caseKey;
        this.caseNumber = caseNumber;
    }
    CreateCaseResult withTrackerId(TrackerKey trackerKey){
        this.trackerKey = trackerKey;
        return this;
    }
    public CaseKey getCaseKey() {
        return caseKey;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public TrackerKey getTrackerKey() {
        return trackerKey;
    }
}
