package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Created by Nitesh.Gupta on 6/7/2016.
 */
public class ReOpenCaseCommand {

    private CaseKey caseKey;

    public ReOpenCaseCommand(CaseKey caseKey) {
        this.caseKey = caseKey;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }
}
