package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Created by Nitesh.Gupta on 6/14/2016.
 */
public class AssignCaseCommand {

    private CaseKey caseKey;

    private String userId;

    public AssignCaseCommand(CaseKey caseKey, String userId) {
        this.caseKey = caseKey;
        this.userId = userId;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public String getUserId() {
        return userId;
    }
}
