package ae.emaratech.uaevision.crm.application;

import java.util.List;

import ae.emaratech.uaevision.arrest.domain.ArrestReason;
import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.TrackerKey;
import ae.emaratech.uaevision.fis.common.type.Department;
import ae.emaratech.uaevision.fis.common.type.Section;
import ae.emaratech.uaevision.lookup.service.model.Entry;

/**
 * Command to create Case with Created by Nitesh.Gupta on 6/15/2016.
 */
public class CreateCaseCommand {

  private ArrestReportKey arrestReportKey;
  private Section section;
  private TrackerKey trackerKey;
  private Department department;
  private Section latestAssignedSection;
  private Entry unit;
  private ArrestReason arrestReason;
  private List<CasePartyDto> casePartyDtoList;
  private Entry transferredFrom;
  private String visionCaseNumber;
  private String firNumber;
  private String createdBy;
  private String caseNumber;
  private Section nonCRMSection;

  public CreateCaseCommand(Builder builder) {
    this.arrestReportKey = builder.arrestReportKey;
    this.casePartyDtoList = builder.casePartyDtoList;
    this.section = builder.section;
    this.department = builder.department;
    this.unit = builder.unit;
    this.latestAssignedSection = builder.latestAssignedSection;
    this.arrestReason = builder.arrestReason;
    this.transferredFrom = builder.transferredFrom;
    this.visionCaseNumber = builder.visionCaseNumber;
    this.firNumber = builder.firNumber;
    this.createdBy = builder.createdBy;
    this.trackerKey = builder.trackerKey;
    this.caseNumber = builder.caseNumber;
    this.nonCRMSection = builder.nonCRMSection;
  }


  public TrackerKey getTrackerKey() {
    return trackerKey;
  }

  public Entry getTransferredFrom() {
    return transferredFrom;
  }

  public ArrestReportKey getArrestReportKey() {
    return arrestReportKey;
  }

  public Section getSection() {
    return section;
  }

  public Department getDepartment() {
    return department;
  }

  public Entry getUnit() {
    return unit;
  }

  public List<CasePartyDto> getCasePartyDtoList() {
    return casePartyDtoList;
  }

  public Section getLatestAssignedSection() {
    return latestAssignedSection;
  }

  public ArrestReason getArrestReason() {
    return arrestReason;
  }

  public String getVisionCaseNumber() {
    return visionCaseNumber;
  }

  public String getFirNumber() {
    return firNumber;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public String getCaseNumber() {
    return caseNumber;
  }

  public Section getNonCRMSection() {
    return nonCRMSection;
  }

  public static class Builder {

    private ArrestReportKey arrestReportKey;
    private Section section;
    private Department department;
    private Entry unit;
    private List<CasePartyDto> casePartyDtoList;
    private Section latestAssignedSection;
    private ArrestReason arrestReason;
    private Entry transferredFrom;
    private String visionCaseNumber;
    private String firNumber;
    private String createdBy;
    private TrackerKey trackerKey;
    private String caseNumber;
    private Section nonCRMSection;

    public Builder(ArrestReportKey arrestReportKey, Section section, Department department,
                   Section latestAssignedSection) {

      this.arrestReportKey = arrestReportKey;
      this.section = section;
      this.department = department;
      this.latestAssignedSection = latestAssignedSection;

    }

    public Builder withUnit(Entry unit) {
      this.unit = unit;
      return this;
    }

    public Builder withArrestReason(ArrestReason arrestReason) {
      this.arrestReason = arrestReason;
      return this;
    }

    public Builder withCasePartyList(List<CasePartyDto> partyKeyList) {
      this.casePartyDtoList = partyKeyList;
      return this;
    }

    public Builder withTransferredFrom(Entry transferredFrom) {
      this.transferredFrom = transferredFrom;
      return this;
    }

    public Builder withVisionCaseNumber(String visionCaseNumber) {
      this.visionCaseNumber = visionCaseNumber;
      return this;
    }

    public Builder withFirNumber(String firNumber) {
      this.firNumber = firNumber;
      return this;
    }

    public Builder withCreatedBy(String createdBy) {
      this.createdBy = createdBy;
      return this;
    }

    public Builder withTrackerKey(TrackerKey trackerKey) {
      this.trackerKey = trackerKey;
      return this;
    }

    public Builder withCaseNumber(String caseNumber) {
      this.caseNumber = caseNumber;
      return this;
    }

    public Builder withNonCRMSection(Section nonCRMSection) {
      this.nonCRMSection = nonCRMSection;
      return this;
    }

    public CreateCaseCommand build() {
      return new CreateCaseCommand(this);
    }
  }
}
