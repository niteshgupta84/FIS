package ae.emaratech.uaevision.crm.query;

import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;

import java.io.Serializable;

/**
 * Created by Nitesh.Gupta on 7/11/2016.
 */
public class RetrieveCaseForArrestQuery implements Serializable{

    private ArrestReportKey arrestReportKey;

    public RetrieveCaseForArrestQuery(ArrestReportKey arrestReportKey) {
        this.arrestReportKey = arrestReportKey;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }
}
