package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Created by Nitesh.Gupta on 7/13/2017.
 */
public class CaseTransferredToSectionEvent extends DomainEvent {
    private CaseKey caseKey;

    private Long status;
    private Long latestSection;

    private String transferComments;

    private CaseTransferredToSectionEvent(Builder builder) {
        super(builder);
        this.caseKey = builder.caseKey;

        this.status = builder.statusId;
        this.transferComments = builder.transferComments;
        this.latestSection = builder.transferSection;
    }



    public CaseKey getCaseKey() {
        return caseKey;
    }

    public Long getStatus() {
        return status;
    }

    public String getTransferComments() {
        return transferComments;
    }

    public Long getLatestSection() {
        return latestSection;
    }



    public static class Builder extends DomainEventBuilder {


        private CaseKey caseKey;
        private Long statusId;
        private String transferComments;
        private Long transferSection;


        public Builder(EventContext eventContext,CaseKey caseKey,
                       Long transferSection) {
            super(eventContext);
            this.caseKey = caseKey;

            this.transferSection = transferSection;
        }

        public Builder withCaseStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withTransferComments(String transferComments) {
            this.transferComments = transferComments;
            return this;
        }

        public CaseTransferredToSectionEvent build() {
            return new CaseTransferredToSectionEvent(this);
        }
    }
}
