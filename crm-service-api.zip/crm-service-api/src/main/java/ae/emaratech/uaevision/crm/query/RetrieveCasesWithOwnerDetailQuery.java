package ae.emaratech.uaevision.crm.query;

import ae.emaratech.uaevision.crm.application.CasePageBuilder;

import java.io.Serializable;

/**
 * Retrieval Query which will be fetching cases based on information provided
 * Created by Nitesh.Gupta on 6/14/2016.
 */
public class RetrieveCasesWithOwnerDetailQuery implements Serializable {
    private Long sectionId;

    private Long sectionUnitId;

    private String userId;

    private Long latestSectionId;

    private CasePageBuilder casePageBuilder;

    public RetrieveCasesWithOwnerDetailQuery(Long sectionId) {
        this.sectionId = sectionId;
    }

    public RetrieveCasesWithOwnerDetailQuery withSectionUnitId(Long sectionUnitId) {
        this.sectionUnitId = sectionUnitId;
        return this;
    }
    public RetrieveCasesWithOwnerDetailQuery withLatestSectionId(Long latestSectionId) {
        this.latestSectionId = latestSectionId;
        return this;
    }
    /**
     * User
     *
     * @param userId
     * @return
     */
    public RetrieveCasesWithOwnerDetailQuery withUser(String userId) {
        this.userId = userId;
        return this;
    }

    public RetrieveCasesWithOwnerDetailQuery withCasePageBuilder(CasePageBuilder casePageBuilder) {
        this.casePageBuilder = casePageBuilder;
        return this;
    }

    public Long getSectionId() {
        return sectionId;
    }

    public Long getSectionUnitId() {
        return sectionUnitId;
    }

    public String getUserId() {
        return userId;
    }

    public CasePageBuilder getCasePageBuilder() {
        return casePageBuilder;
    }

    public Long getLatestSectionId() {
        return latestSectionId;
    }
}
