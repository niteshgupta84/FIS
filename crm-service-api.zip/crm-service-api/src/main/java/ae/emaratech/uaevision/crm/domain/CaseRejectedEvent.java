package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Event triggered when the case submitted for review has been rejected by the supervisor for
 * further updates.
 *
 * @author Nitesh.Gupta
 */
public class CaseRejectedEvent extends DomainEvent {

    private CaseKey caseKey;
    private ArrestReportKey arrestReportKey;
    private Long status;
    private String rejectComments;

    public CaseRejectedEvent(Builder builder) {
        super(builder);
        this.caseKey = builder.caseKey;
        this.arrestReportKey = builder.arrestReportKey;
        this.rejectComments = builder.rejectComments;
        this.status = builder.statusId;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private String rejectComments;
        private Long statusId;
        private CaseKey caseKey;

        public Builder(EventContext eventContext,
                       CaseKey caseKey, ArrestReportKey arrestReportKey) {
            super(eventContext);
            this.caseKey = caseKey;
            this.arrestReportKey = arrestReportKey;
        }

        public Builder withCaseStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withRejectComments(String rejectComments) {
            this.rejectComments = rejectComments;
            return this;
        }

        public ArrestReportKey getArrestReportKey() {
            return arrestReportKey;
        }

        public String getRejectComments() {
            return rejectComments;
        }

        public Long getStatusId() {
            return statusId;
        }

        public CaseKey getCaseKey() {
            return caseKey;
        }

        public CaseRejectedEvent build() {
            return new CaseRejectedEvent(this);
        }
    }
}
