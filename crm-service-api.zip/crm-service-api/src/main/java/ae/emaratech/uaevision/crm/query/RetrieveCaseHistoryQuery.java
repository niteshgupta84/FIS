package ae.emaratech.uaevision.crm.query;

import ae.emaratech.uaevision.fis.common.key.CaseKey;

import java.io.Serializable;

/**
 * Query class which provides the information to retrieve the case history details.
 * Created by Nitesh.Gupta on 6/19/2016.
 */
public class RetrieveCaseHistoryQuery implements Serializable {

    /**
     * Reference Key
     */
    private CaseKey caseKey;

    public RetrieveCaseHistoryQuery(CaseKey caseKey) {
        this.caseKey = caseKey;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }
}
