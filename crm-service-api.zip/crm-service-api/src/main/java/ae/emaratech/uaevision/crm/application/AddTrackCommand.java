package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.crm.domain.CaseAction;
import ae.emaratech.uaevision.fis.common.key.CaseKey;

import java.io.Serializable;

/**
 * Created by Nitesh.Gupta on 6/21/2016.
 */
public class AddTrackCommand implements Serializable{

    private CaseKey caseKey;

    private CaseAction caseAction;

    public String getUser_login_id() {
        return user_login_id;
    }

    public void setUser_login_id(String user_login_id) {
        this.user_login_id = user_login_id;
    }

    private String user_login_id=null;

    private String comments;

    public AddTrackCommand(){}
    public AddTrackCommand(CaseKey caseKey, CaseAction caseAction, String comments) {
        this.caseAction = caseAction;
        this.caseKey = caseKey;
        this.comments = comments;
    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public CaseAction getCaseAction() {
        return caseAction;
    }

    public String getComments() {
        return comments;
    }
}
