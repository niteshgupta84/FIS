package ae.emaratech.uaevision.crm.application.dto;

import ae.emaratech.uaevision.fis.party.application.dto.PartyDto;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@ApiModel(value="Case Association ")
public class CaseAssociationDto implements Serializable {
    @ApiModelProperty(value = "The identifier for Case Association", required = true, dataType = "long")
    private long id;
    @ApiModelProperty(value = "The identifier for Case Association", required = true, dataType = "long")
    private long associationId;
    @ApiModelProperty(value = "The identifier for Case ", required = true, dataType = "long")
    private long caseId;
    @ApiModelProperty(value = "The identifier for Linked Case ", required = true, dataType = "long")
    private long linkedCaseId;
    @ApiModelProperty(value = "Association Type ", required = true, dataType = "object")
    private Entry associationType;
    @ApiModelProperty(value = "Case Document Inspection Created By ", required = true, dataType = "string")
    private String createdBy;
    @ApiModelProperty(value = "Case Document Inspection Created on Date ", required = true, dataType = "date" )
    private Date createdDate;
    private Long version;
    @ApiModelProperty(value = "Case Details", required = true, dataType = "object" )
    private CaseDto caseDto;
    @ApiModelProperty(value = "Party Details", required = true, dataType = "object" )
    private PartyDto partyDto;


    public long getAssociationId() {
        return associationId;
    }

    public void setAssociationId(long associationId) {
        this.associationId = associationId;
    }

    public long getCaseId() {
        return caseId;
    }

    public void setCaseId(long caseId) {
        this.caseId = caseId;
    }

    public long getLinkedCaseId() {
        return linkedCaseId;
    }

    public void setLinkedCaseId(long linkedCaseId) {
        this.linkedCaseId = linkedCaseId;
    }

    public Entry getAssociationType() {
        return associationType;
    }

    public void setAssociationType(Entry associationType) {
        this.associationType = associationType;
    }


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public CaseDto getCaseDto() {
        return caseDto;
    }

    public void setCaseDto(CaseDto caseDto) {
        this.caseDto = caseDto;
    }

    public PartyDto getPartyDto() {
        return partyDto;
    }

    public void setPartyDto(PartyDto partyDto) {
        this.partyDto = partyDto;
    }
}
