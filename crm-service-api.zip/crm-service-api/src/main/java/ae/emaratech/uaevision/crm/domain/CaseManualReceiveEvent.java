package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Event triggered when a case which has been manually transferred from another department has been
 * received for further processing.
 *
 * @author Nitesh.Gupta
 */
public class CaseManualReceiveEvent extends DomainEvent {

    private CaseKey caseKey;
    private ArrestReportKey arrestReportKey;
    private Long status;
    private String receiveComments;
    private Long receivedFrom;

    private CaseManualReceiveEvent(Builder builder) {
        super(builder);
        this.caseKey = builder.caseKey;
        this.arrestReportKey = builder.arrestReportKey;
        this.status = builder.statusId;
        this.receiveComments = builder.receiveComments;
        this.receivedFrom = builder.receivedFrom;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public Long getStatus() {
        return status;
    }

    public String getReceiveComments() {
        return receiveComments;
    }

    public Long getReceivedFrom() {
        return receivedFrom;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private CaseKey caseKey;
        private Long statusId;
        private String receiveComments;
        private Long receivedFrom;

        public Builder(EventContext eventContext,
                       CaseKey caseKey, ArrestReportKey arrestReportKey) {
            super(eventContext);
            this.caseKey = caseKey;
            this.arrestReportKey = arrestReportKey;
        }

        public Builder withCaseStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withReceiveComments(String receiveComments) {
            this.receiveComments = receiveComments;
            return this;
        }

        public Builder withReceivedFrom(Long manualReceivedFrom) {
            this.receivedFrom = manualReceivedFrom;
            return this;
        }

        public CaseManualReceiveEvent build() {
            return new CaseManualReceiveEvent(this);
        }
    }
}
