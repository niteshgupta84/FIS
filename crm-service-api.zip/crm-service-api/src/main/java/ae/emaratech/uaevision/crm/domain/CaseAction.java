package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.dto.Identifiable;
import ae.emaratech.uaevision.fis.user.service.dto.PrivilegeConstant;

/**
 * Created by Nitesh.Gupta on 6/5/2016.
 */
public enum CaseAction implements Identifiable {
    //Name   (id  lock    commentable   track    priv   state
    NEW(1L, false, false, false, 1231L, null),
    OPEN(2L, false, false, true, PrivilegeConstant.FIS_CASE_CREATE, CaseStatus.OPENED),
    ACQUIRE(3L, false, false, false, PrivilegeConstant.FIS_CASE_UPDATE, null),
    UPDATE(4L, true, false, false, PrivilegeConstant.FIS_CASE_UPDATE, null),

    REOPEN(6L, false, false, true, PrivilegeConstant.FIS_CASE_REOPEN, CaseStatus.OPENED),
    CLOSE(7L, true, true, true, PrivilegeConstant.FIS_CASE_CLOSE, CaseStatus.CLOSED),
    REJECT(8L, true, true, true, PrivilegeConstant.FIS_CASE_SUPERVISOR_REJECT, CaseStatus.OPENED),
    FORWARD_TO_SUPERVISOR(9L, true, true, true, PrivilegeConstant.FIS_CASE_ESCALATE_TO_SUPERVISOR,
            CaseStatus.PENDING_DECISION), //TODO : rename to Forward
    END(10L, true, true, true, PrivilegeConstant.FIS_CASE_END, CaseStatus.ENDED),
    VIEW(11L, false, false, false, PrivilegeConstant.FIS_CASE_VIEW, null),
    SEARCH(12L, false, false, false, PrivilegeConstant.FIS_CASE_SEARCH, null),
    RELEASE(13L, true, false, true, PrivilegeConstant.FIS_CASE_RELEASE_ORDER_ISSUE, null),
    MANUAL_TRANSFER(14L, true, true, true, PrivilegeConstant.FIS_CASE_MANUAL_TRANSFER, CaseStatus.MANUALTRANSFERRED),

    /*Added for story VFIS 608
    TODO need to change the status value during refactoring
     During issue detention order from ICM , ICM will be updated with this action and status will
     be the current status
    */
    ISSUE_DETENTION_ORDER(15L, true, true, true, PrivilegeConstant.FIS_CASE_DETENTION_ORDER_ISSUE, null),
    ACQUIRE_LONGER(16L, true, false, true, 3016L, null),


    ISSUE_INTERROGATION_ORDER(17L, false, true, true, PrivilegeConstant.FIS_CASE_INTERROGATION_ORDER_ISSUE, CaseStatus.REQUESTINTERROGATION),
    RECEIVE_INTERROGATION_ORDER(18L, false, false, true, PrivilegeConstant.FIS_CASE_INTERROGATION_ORDER_ISSUE, CaseStatus.RECEIVEDINTERROGATION),
    APPROVE(19L, true, true, true, PrivilegeConstant.FIS_CASE_SUPERVISOR_APPROVE, CaseStatus.APPROVED),

    CANCEL(21L, true, true, true, 1136L, null),
    RECEIVE_DETENTION_ORDER(21L, false, false, true, 3022L, CaseStatus.RECEIVED_DETENTION),
    TRANSFERRED_TO(22L, true, true, true, PrivilegeConstant.FIS_TRANSFER_TO, CaseStatus.TRANSFERREDTODEPARTMENT),
    DELETE_PARTY(23L, true, true, true, PrivilegeConstant.FIS_CASE_PARTY_REMOVE, null),
    ADD_PARTY(24L, true, true, true, PrivilegeConstant.FIS_CASE_PARTY_ADD, null),
    ISSUE_PERMANENT_RELEASE_ORDER(25L, false, true, true, PrivilegeConstant.FIS_CASE_RELEASE_ORDER_ISSUE, null),
    ISSUE_TEMPORARY_RELEASE_ORDER(26L, false, true, true, PrivilegeConstant.FIS_CASE_RELEASE_ORDER_ISSUE, null),
    ISSUE_DEPORTATION_ORDER(27L, false, true, true, PrivilegeConstant.FIS_CASE_DEPORTATION_ORDER_ISSUE, null),
    ISSUE_GUARANTEE_ORDER(28L, false, true, true, PrivilegeConstant.FIS_CASE_GUARANTEE_ORDER_ISSUE, null),
    ADD_IRIS(29L, false, true, true, PrivilegeConstant.FIS_CASE_PARTY_IRIS_ADD_UPDATE, null),
    MANUAL_RECEIVE(30L, true, true, true, PrivilegeConstant.FIS_CASE_MANUAL_RECEIVE, CaseStatus.MANUALRECEIVED),
    ISSUE_ARREST_ORDER(31L, true, true, true, PrivilegeConstant.FIS_CASE_ARREST_ORDER_ISSUE, CaseStatus.MANUALRECEIVED),
    RECEIVE(32L, false, false, true, PrivilegeConstant.FIS_CASE_ARREST_ORDER_ISSUE, CaseStatus.RECEIVED),
    DOWNLOAD_MANUAL_TRANSFER_REPORT(33L, false, false, false, PrivilegeConstant.FIS_CASE_MANUAL_TRANSFER, null),
    FORWARD(34L, true, true, true, PrivilegeConstant.FIS_TRANSFER_TO, CaseStatus.FORWARD),
    RETURN(35L, true, true, true, PrivilegeConstant.FIS_TRANSFER_TO, CaseStatus.OPENED);

    private Long id;
    private Boolean requiresLock;
    private Boolean commentable;
    private Boolean trackable;
    private Long visionPrivilegeId;
    private CaseStatus resultState;

    CaseAction(Long id, Boolean requiresLock, Boolean commentable, Boolean trackable,
               Long visionPrivilegeId, CaseStatus resultState) {
        this.id = id;
        this.requiresLock = requiresLock;
        this.commentable = commentable;
        this.trackable = trackable;
        this.visionPrivilegeId = visionPrivilegeId;
        this.resultState = resultState;

    }

    public String authority() {

        return this.name();
    }

    public Long getId() {
        return id;
    }

    public boolean requiresLock() {
        return requiresLock;
    }

    public boolean commentable() {
        return commentable;
    }

    public boolean trackable() {
        return trackable;
    }

    public Long visionPrivilegeId() {
        return visionPrivilegeId;
    }

    public CaseStatus resultState() {
        return resultState;
    }


    @Override
    public String toString() {
        return "IncidentActions{" +
                "name=" + name() +
                ", id=" + id +
                ", requiresLock=" + requiresLock +
                ", commentable=" + commentable +
                ", trackable=" + trackable +
                ", visionPrivilegeId=" + visionPrivilegeId +
                ", resultState=" + resultState +
                '}';
    }

    @Override
    public Long id() {
        return id;
    }
}
