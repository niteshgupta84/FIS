package ae.emaratech.uaevision.crm.query;

import ae.emaratech.uaevision.fis.common.key.PartyKey;

import java.io.Serializable;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/14/2016.
 */
public class RetrieveCaseForPartyQuery implements Serializable {

    private PartyKey partyKey;
    private List<Long> sectionsList;
    private List<Long> partyKeys;

    public RetrieveCaseForPartyQuery(){

    }

    public RetrieveCaseForPartyQuery(PartyKey partyKey) {
        this.partyKey = partyKey;
    }

    public RetrieveCaseForPartyQuery(List<Long> partyKeys){
        this.partyKeys = partyKeys;
    }

    public RetrieveCaseForPartyQuery withSections(List<Long> sections) {
        sectionsList = sections;
        return this;
    }

    public PartyKey getPartyKey() {
        return partyKey;
    }

    public List<Long> getSectionsList() {
        return sectionsList;
    }

    public List<Long> getPartyKeys() {
        return partyKeys;
    }
}
