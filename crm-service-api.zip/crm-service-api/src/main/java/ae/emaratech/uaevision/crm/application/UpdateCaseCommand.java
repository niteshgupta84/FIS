package ae.emaratech.uaevision.crm.application;

import ae.emaratech.uaevision.arrest.domain.ArrestReason;
import ae.emaratech.uaevision.crm.application.dto.CaseNoteDto;
import ae.emaratech.uaevision.crm.application.dto.CasePartyDto;
import ae.emaratech.uaevision.crm.application.dto.DocumentInspectionDto;
import ae.emaratech.uaevision.fis.common.key.AssociatedCaseKey;
import ae.emaratech.uaevision.fis.common.key.AttachmentReferenceKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;
import ae.emaratech.uaevision.fis.common.key.PartyKey;
import ae.emaratech.uaevision.lookup.service.model.Entry;

import java.util.List;
import java.util.Set;

/**
 * Command class which provides the information to update the case
 *
 * @author Nitesh.Gupta
 */
public class UpdateCaseCommand {

    private CaseKey caseKey;
    private List<PartyKey> partyList;
    private List<AttachmentReferenceKey> attachmentList;
    private List<CaseNoteDto> caseNoteDtoList;
    private Set<AssociatedCaseKey> associatedCaseKeyList;
    private List<DocumentInspectionDto> documentInspectionDtoList;
    private Entry unit;
    private Entry transferredFromId;
    private boolean isUrgent;
    private String firNo;
    private List<CasePartyDto> casePartyDtoList;
    private String createdBy;

    private ArrestReason arrestReason;
    private Long version;

    public UpdateCaseCommand(Builder builder) {
        this.caseKey = builder.caseKey;
        this.partyList = builder.partyList;
        this.attachmentList = builder.attachmentList;
        this.unit = builder.unit;
        this.transferredFromId = builder.transferredFromId;
        this.isUrgent = builder.isUrgent;
        this.caseNoteDtoList = builder.caseNoteDtoList;
        this.associatedCaseKeyList = builder.associatedCaseList;
        this.arrestReason = builder.arrestReason;
        this.documentInspectionDtoList = builder.documentInspectionDtoList;
        this.firNo = builder.firNo;
        this.casePartyDtoList = builder.casePartyDtoList;
        this.version = builder.version;
        this.createdBy = builder.createdBy;

    }

    public CaseKey getCaseKey() {
        return caseKey;
    }

    public ArrestReason getArrestReason() {
        return arrestReason;
    }

    public List<PartyKey> getPartyList() {
        return partyList;
    }

    public List<CasePartyDto> getCasePartyDtoList() {
        return casePartyDtoList;
    }

    public List<AttachmentReferenceKey> getAttachmentList() {
        return attachmentList;
    }

    public List<CaseNoteDto> getCaseNoteDtoList() {
        return caseNoteDtoList;
    }

    public Entry getUnit() {
        return unit;
    }

    public Entry getTransferredFromId() {
        return transferredFromId;
    }

    public boolean isUrgent() {
        return isUrgent;
    }


    public String getFirNo() {
        return firNo;
    }

    public Set<AssociatedCaseKey> getAssociatedCaseKeyList() {
        return associatedCaseKeyList;
    }

    public Set<AssociatedCaseKey> getAssociatedCaseList() {
        return associatedCaseKeyList;
    }

    public List<DocumentInspectionDto> getDocumentInspectionDtoList() {
        return documentInspectionDtoList;
    }

    public Long getVersion() {
        return version;
    }


    public String getCreatedBy() {
        return createdBy;
    }

    public static class Builder {

        private CaseKey caseKey;
        private List<PartyKey> partyList;
        private List<AttachmentReferenceKey> attachmentList;
        private ArrestReason arrestReason;
        private List<CaseNoteDto> caseNoteDtoList;
        private Entry unit;
        private Entry transferredFromId;
        private Entry shift;
        private boolean isUrgent;
        private Set<AssociatedCaseKey> associatedCaseList;

        private List<DocumentInspectionDto> documentInspectionDtoList;
        private String firNo;
        private List<CasePartyDto> casePartyDtoList;
        private Long version;
        private String createdBy;

        public Builder(CaseKey caseKey, List<PartyKey> partyList) {

            this.caseKey = caseKey;
            this.partyList = partyList;
        }

        public Builder withDocumentInspection(List<DocumentInspectionDto> documentInspectionDtoList) {
            this.documentInspectionDtoList = documentInspectionDtoList;
            return this;
        }

        public Builder withAttachmentList(List<AttachmentReferenceKey> attachments) {
            this.attachmentList = attachments;
            return this;
        }

        public Builder withAssociatedCaseList(Set<AssociatedCaseKey> associatedCaseList) {
            this.associatedCaseList = associatedCaseList;
            return this;
        }

        public Builder withArrestReason(ArrestReason arrestReason) {
            this.arrestReason = arrestReason;
            return this;
        }

        public Builder withCaseNoteList(List<CaseNoteDto> caseNotes) {
            this.caseNoteDtoList = caseNotes;
            return this;
        }

        public Builder withFirNumber(String firNo) {
            this.firNo = firNo;
            return this;
        }

        public Builder withIsUrgent(boolean isUrgent) {
            this.isUrgent = isUrgent;
            return this;
        }

        public Builder withUnit(Entry unit) {
            this.unit = unit;
            return this;
        }

        public Builder withTransferredFrom(Entry transferredFromId) {
            this.transferredFromId = transferredFromId;
            return this;
        }

        public Builder withCasePartyList(List<CasePartyDto> partyKeyList) {
            this.casePartyDtoList = partyKeyList;
            return this;
        }

        public Builder withVersion(Long version) {
            this.version = version;
            return this;
        }

        public Builder withCreatedBy(String createdBy) {
            this.createdBy = createdBy;
            return this;
        }

        public UpdateCaseCommand build() {
            return new UpdateCaseCommand(this);
        }
    }
}
