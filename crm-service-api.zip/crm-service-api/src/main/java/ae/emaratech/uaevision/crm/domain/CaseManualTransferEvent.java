package ae.emaratech.uaevision.crm.domain;

import ae.emaratech.uaevision.fis.common.domain.DomainEvent;
import ae.emaratech.uaevision.fis.common.domain.DomainEventBuilder;
import ae.emaratech.uaevision.fis.common.domain.EventContext;
import ae.emaratech.uaevision.fis.common.key.ArrestReportKey;
import ae.emaratech.uaevision.fis.common.key.CaseKey;

/**
 * Event triggered when case has been manually transferred to a specific department.
 *
 * @author Nitesh.Gupta
 */
public class CaseManualTransferEvent extends DomainEvent {

    private CaseKey caseKey;
    private ArrestReportKey arrestReportKey;
    private Long status;
    private Long manualTransferTo;
    private String transferComments;

    private CaseManualTransferEvent(Builder builder) {
        super(builder);
        this.caseKey = builder.caseKey;
        this.arrestReportKey = builder.arrestReportKey;
        this.status = builder.statusId;
        this.transferComments = builder.transferComments;
        this.manualTransferTo = builder.manualTransferTo;
    }

    public ArrestReportKey getArrestReportKey() {
        return arrestReportKey;
    }

    public Long getStatus() {
        return status;
    }

    public String getTransferComments() {
        return transferComments;
    }

    public Long getManualTransferTo() {
        return manualTransferTo;
    }

    public static class Builder extends DomainEventBuilder {

        private ArrestReportKey arrestReportKey;
        private CaseKey caseKey;
        private Long statusId;
        private String transferComments;
        private Long manualTransferTo;

        public Builder(EventContext eventContext,
                       CaseKey caseKey, ArrestReportKey arrestReportKey) {
            super(eventContext);
            this.caseKey = caseKey;
            this.arrestReportKey = arrestReportKey;
        }

        public Builder withCaseStatus(Long statusId) {
            this.statusId = statusId;
            return this;
        }

        public Builder withTransferComments(String transferComments) {
            this.transferComments = transferComments;
            return this;
        }

        public Builder withManualTransferTo(Long manualTransferTo) {
            this.manualTransferTo = manualTransferTo;
            return this;
        }

        public CaseManualTransferEvent build() {
            return new CaseManualTransferEvent(this);
        }
    }
}
