package ae.emaratech.uaevision.crm.application.dto;

import ae.emaratech.uaevision.fis.party.application.dto.ChargeDto;
import ae.emaratech.uaevision.lookup.service.model.Entry;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Nitesh.Gupta on 6/6/2016.
 */
@ApiModel(value = "Case Party Dto")
public class CasePartyDto {
    @ApiModelProperty(value = "Charge List", required = true , dataType = "object")
    List<ChargeDto> chargeDtoList = new ArrayList<>();
    @ApiModelProperty(value = "Unique Case Party Id", required = true , dataType = "long")
    private Long id;
    @ApiModelProperty(value = "Case Id", required = true , dataType = "long")
    private Long caseId;
    @ApiModelProperty(value = "Party Id", required = true , dataType = "long")
    private Long partyId;
    @ApiModelProperty(value = " Case note Deleted or Note", required = true, dataType = "long", allowableValues = "1 or 0")
    private Long isDeleted;
    @ApiModelProperty(value = "Case Party Created By ", required = true, dataType = "string")
    private String createdBy;
    @ApiModelProperty(value = "Case Party Created on Date ", required = true, dataType = "date" )
    private Date createdDate;
    @ApiModelProperty(value = "Party Type", required = true , dataType = "object")
    private Entry partyType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCaseId() {
        return caseId;
    }

    public void setCaseId(Long caseId) {
        this.caseId = caseId;
    }

    public Long getPartyId() {
        return partyId;
    }

    public void setPartyId(Long partyId) {
        this.partyId = partyId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Long getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Long isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Entry getPartyType() {
        return partyType;
    }

    public void setPartyType(Entry partyType) {
        this.partyType = partyType;
    }

    public List<ChargeDto> getChargeDtoList() {
        return chargeDtoList;
    }

    public void setChargeDtoList(List<ChargeDto> chargeDtoList) {
        this.chargeDtoList = chargeDtoList;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CasePartyDto that = (CasePartyDto) o;

        if (caseId != null ? !caseId.equals(that.caseId) : that.caseId != null) return false;
        if (chargeDtoList != null ? !chargeDtoList.equals(that.chargeDtoList) : that.chargeDtoList != null)
            return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDate != null ? !createdDate.equals(that.createdDate) : that.createdDate != null) return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (isDeleted != null ? !isDeleted.equals(that.isDeleted) : that.isDeleted != null) return false;
        if (partyId != null ? !partyId.equals(that.partyId) : that.partyId != null) return false;
        if (partyType != null ? !partyType.equals(that.partyType) : that.partyType != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = chargeDtoList != null ? chargeDtoList.hashCode() : 0;
        result = 31 * result + (id != null ? id.hashCode() : 0);
        result = 31 * result + (caseId != null ? caseId.hashCode() : 0);
        result = 31 * result + (partyId != null ? partyId.hashCode() : 0);
        result = 31 * result + (isDeleted != null ? isDeleted.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
        result = 31 * result + (partyType != null ? partyType.hashCode() : 0);
        return result;
    }

    @Override
    public String

    toString() {
        return "CasePartyDto{" +
                "chargeDtoList=" + chargeDtoList +
                ", id=" + id +
                ", caseId=" + caseId +
                ", partyId=" + partyId +
                ", isDeleted=" + isDeleted +
                ", createdBy='" + createdBy + '\'' +
                ", createdDate=" + createdDate +
                ", partyType=" + partyType +
                '}';
    }
}
