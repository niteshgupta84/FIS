package ae.emaratech.uaevision.crm.domain;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Created by Nitesh.Gupta on 6/29/2016.
 */
public class CaseActionTest {
    @Test
    public void shouldReturnOpenAction() {
        CaseAction caseAction = CaseAction.valueOf("OPEN");
        assertTrue(caseAction.id() == 2);
        assertTrue(!caseAction.commentable());
        assertTrue(!caseAction.requiresLock());
        assertTrue(caseAction.trackable());
        assertTrue(caseAction.resultState() == CaseStatus.OPENED);
    }

    @Test
    public void shouldReturnAcquireAction() {
        CaseAction caseAction = CaseAction.valueOf("ACQUIRE");
        assertTrue(caseAction.id() == 3);
        assertTrue(!caseAction.commentable());
        assertTrue(!caseAction.requiresLock());
        assertTrue(!caseAction.trackable());

    }

    @Test
    public void shouldReturnUpdateAction() {
        CaseAction caseAction = CaseAction.valueOf("UPDATE");
        assertTrue(caseAction.id() == 4);
        assertTrue(!caseAction.commentable());
        assertTrue(caseAction.requiresLock());
        assertTrue(!caseAction.trackable());

    }


    @Test
    public void shouldReturnApproveAction() {
        CaseAction caseAction = CaseAction.valueOf("APPROVE");
        assertTrue(caseAction.id() == 19);
        assertTrue(caseAction.commentable());
        assertTrue(caseAction.requiresLock());
        assertTrue(caseAction.trackable());
        assertTrue(caseAction.resultState() == CaseStatus.APPROVED);
    }

    @Test
    public void shouldReturnRejectAction() {
        CaseAction caseAction = CaseAction.valueOf("REJECT");
        assertTrue(caseAction.id() == 8);
        assertTrue(caseAction.commentable());
        assertTrue(caseAction.requiresLock());
        assertTrue(caseAction.trackable());
        assertTrue(caseAction.resultState() == CaseStatus.OPENED);
    }

    @Test
    public void shouldReturnCloseAction() {
        CaseAction caseAction = CaseAction.valueOf("CLOSE");
        assertTrue(caseAction.id() == 7);
        assertTrue(caseAction.commentable());
        assertTrue(caseAction.requiresLock());
        assertTrue(caseAction.trackable());
        assertTrue(caseAction.resultState() == CaseStatus.CLOSED);
    }

    @Test
    public void shouldReturnReOpenAction() {
        CaseAction caseAction = CaseAction.valueOf("REOPEN");
        assertTrue(caseAction.id() == 6);
        assertTrue(!caseAction.commentable());
        assertTrue(!caseAction.requiresLock());
        assertTrue(caseAction.trackable());
        assertTrue(caseAction.resultState() == CaseStatus.OPENED);
    }

    @Test
    public void shouldReturnViewAction() {
        CaseAction caseAction = CaseAction.valueOf("VIEW");
        assertTrue(caseAction.id() == 11);
        assertTrue(!caseAction.commentable());
        assertTrue(!caseAction.requiresLock());
        assertTrue(!caseAction.trackable());

    }

    @Test
    public void shouldReturnForwardToSupervisorAction() {
        CaseAction caseAction = CaseAction.valueOf("FORWARD_TO_SUPERVISOR");
        assertTrue(caseAction.id() == 9);
        assertTrue(caseAction.getId() == 9);
        assertTrue(caseAction.commentable());
        assertTrue(caseAction.requiresLock());
        assertTrue(caseAction.trackable());
        assertTrue(caseAction.resultState() == CaseStatus.PENDING_DECISION);
        //assertTrue(CaseAction.visionPrivilegeId() == 3014L);
        assertTrue(caseAction.toString() != null);
    }

    @Test
    public void shouldReturnEndAction() {
        CaseAction caseAction = CaseAction.valueOf("END");
        assertTrue(caseAction.id() == 10);
        assertTrue(caseAction.getId() == 10);
        assertTrue(caseAction.commentable());
        assertTrue(caseAction.requiresLock());
        assertTrue(caseAction.trackable());
        assertTrue(caseAction.resultState() == CaseStatus.ENDED);
        //assertTrue(CaseAction.visionPrivilegeId() == 3014L);
        assertTrue(caseAction.toString() != null);
    }

    @Test
    public void shouldReturnSearchAction() {
        CaseAction caseAction = CaseAction.valueOf("SEARCH");
        assertTrue(caseAction.id() == 12);
        assertTrue(caseAction.getId() == 12);
        assertTrue(!caseAction.commentable());
        assertTrue(!caseAction.requiresLock());
        assertTrue(!caseAction.trackable());

        //assertTrue(CaseAction.visionPrivilegeId() == 3014L);
        assertTrue(caseAction.toString() != null);
    }

    @Test
    public void shouldAcquireLongerSearchAction() {
        CaseAction caseAction = CaseAction.valueOf("ACQUIRE_LONGER");
        assertTrue(caseAction.id() == 16);
        assertTrue(caseAction.getId() == 16);
        assertTrue(!caseAction.commentable());
        assertTrue(caseAction.requiresLock());
        assertTrue(caseAction.trackable());

        //assertTrue(CaseAction.visionPrivilegeId() == 3014L);
        assertTrue(caseAction.toString() != null);
    }

    @Test
    public void shouldReturnNEWAction() {
        CaseAction caseAction = CaseAction.valueOf("NEW");
        assertTrue(caseAction.id() == 1);
        assertTrue(!caseAction.commentable());
        assertTrue(!caseAction.requiresLock());
        assertTrue(!caseAction.trackable());
        assertTrue(caseAction.resultState() == null);
    }


}
